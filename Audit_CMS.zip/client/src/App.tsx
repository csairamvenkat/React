import './global.css';
import RequestInterceptor from '@/core/interceptors/Request.interceptor';
import { AdAuthProvider, PermissionProvider, AccessTierProvider } from '@/core/providers';
import { useScrollToTop } from '@/hooks/use-scroll-to-top';
import '@/locales/i18n';
import Router from '@/routes/routes';
import { InteractionType } from '@azure/msal-browser';
import { AuthenticatedTemplate, MsalAuthenticationTemplate } from '@azure/msal-react';
import type { MsalAuthenticationResult } from '@azure/msal-react';
import { useEffect } from 'react';
import { useLocation } from 'react-router';
import { AuthErrorView } from './components/error';
import { SESSION_STORAGE_KEYS } from './shared/constants';

function ErrorComponent({ error, login }: MsalAuthenticationResult) {
  return <AuthErrorView error={error} onRetry={() => login(InteractionType.Redirect)} />;
}

function App() {
  useScrollToTop();
  const location = useLocation();

  useEffect(() => {
    const key = SESSION_STORAGE_KEYS.VISITED_ROUTE_KEY;
    const visitedRoute = sessionStorage.getItem(key);
    if (!visitedRoute) {
      sessionStorage.setItem(key, `${location.pathname}${location.search}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AdAuthProvider>
      <MsalAuthenticationTemplate
        interactionType={InteractionType.Redirect}
        errorComponent={ErrorComponent}
      >
        <AuthenticatedTemplate>
          <RequestInterceptor>
            <PermissionProvider>
              <AccessTierProvider>
                <Router />
              </AccessTierProvider>
            </PermissionProvider>
          </RequestInterceptor>
        </AuthenticatedTemplate>
      </MsalAuthenticationTemplate>
    </AdAuthProvider>
  );
}

export default App;
