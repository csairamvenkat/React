import { Card, CardContent, Typography } from '@mui/material';
import { t } from 'i18next';
import { FC } from 'react';
import ReactApexChart from 'react-apexcharts';
import EmptyContent from '../empty-content/empty-content';

type Props = {
  heading: string;
  categories: string[] | number[];
  series: { name: string; data: number[] }[];
};

export const ApexStackedChart: FC<Props> = ({ heading, categories, series }) => {
  const state = {
    series: series,
    options: {
      chart: {
        type: 'bar',
        height: 300,
        stacked: true,
      },
      plotOptions: {
        bar: {
          horizontal: true,
          barHeight: '80%',
          dataLabels: {
            total: {
              enabled: true,
              offsetX: 0,
              style: {
                fontSize: '13px',
                fontWeight: 900,
              },
            },
          },
        },
      },
      stroke: {
        width: 1,
        colors: ['#fff'],
      },
      title: {
        text: undefined,
      },
      xaxis: {
        categories: categories,
        labels: {
          formatter: function (val: string) {
            return val;
          },
        },
      },
      yaxis: {
        title: {
          text: undefined,
        },
      },
      tooltip: {
        y: {
          formatter: function (val: string) {
            return val;
          },
        },
      },
      fill: {
        opacity: 1,
      },
      legend: {
        position: 'bottom',
        horizontalAlign: 'center',
        offsetX: 0,
      },
    },
  };

  return (
    <Card>
      <CardContent>
        <Typography gutterBottom variant="h6" component="div">
          {heading}
        </Typography>
        {categories.length ? (
          <ReactApexChart type="bar" options={state.options} series={state.series} height={400} />
        ) : (
          <EmptyContent
            filled={false}
            title={t('empty_state_messages.no_data_found')}
            sx={{
              py: 10,
            }}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default ApexStackedChart;
