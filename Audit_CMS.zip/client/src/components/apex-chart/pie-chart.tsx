import { Card, CardContent, Typography } from '@mui/material';
import { t } from 'i18next';
import { FC } from 'react';
import ReactApexChart from 'react-apexcharts';
import EmptyContent from '../empty-content/empty-content';

type Props = {
  heading: string;
  categories: string[];
  series: number[];
};

const ApexPieChart: FC<Props> = ({ heading, categories, series }) => {
  const total = series.reduce((acc, value) => acc + value, 0);
  const state = {
    series: series,
    options: {
      chart: {
        width: 450,
        type: 'pie',
      },
      labels: categories,
      colors: ['#00E396', '#FEB019', '#FF4560', '#775DD0'],
      dataLabels: {
        enabled: true,
        formatter: (_: number, { seriesIndex }: { seriesIndex: number }) => {
          const value = series[seriesIndex];
          const percentage = ((value / total) * 100).toFixed(2);
          return `${value} (${percentage}%)`;
        },
        style: {
          fontSize: '12px',
          colors: ['#000'],
        },
        dropShadow: {
          enabled: false,
        },
        position: 'center',
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200,
            },
            legend: {
              position: 'center',
            },
          },
        },
      ],
      legend: {
        position: 'bottom',
        horizontalAlign: 'center',
        offsetX: 0,
      },
      tooltip: {
        custom: ({ series, seriesIndex, w }: { series: number[]; seriesIndex: number; w: any }) => {
          const category = w.config.labels[seriesIndex];
          const value = series[seriesIndex];
          const percentage = ((value / total) * 100).toFixed(2);
          return `<div style="padding: 10px; border: 1px solid #ccc;">
                    <strong>${category}</strong>: ${value} (${percentage}%)
                  </div>`;
        },
      },
    },
  };
  const seriesCheck = series.filter(item => item > 0).length > 0;

  return (
    <Card>
      <CardContent>
        <Typography gutterBottom variant="h6" component="div">
          {heading}
        </Typography>
        {categories.length && seriesCheck ? (
          <ReactApexChart type="pie" options={state.options} series={state.series} height={445} />
        ) : (
          <EmptyContent
            filled={false}
            title={t('empty_state_messages.no_data_found')}
            sx={{
              py: 10,
            }}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default ApexPieChart;
