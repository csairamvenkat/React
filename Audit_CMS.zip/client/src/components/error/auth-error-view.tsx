import { m } from 'framer-motion';

import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

import { MotionContainer, varBounce } from '@/components/animate';
import { MaintenanceIllustration } from '../illustrations';

const SERVICE_NOW_URL =
  'https://dpworldprod.service-now.com/sp?id=sc_cat_item&sys_id=9876321297b9de101cf6b313e453af9d';

interface Props {
  /** The sign-in failure, if one was reported. Its code is what support actually needs. */
  error?: { errorCode?: string; message?: string } | null;
  onRetry?: () => void;
}

export default function AuthErrorView({ error, onRetry }: Props) {
  const detail = error?.errorCode || error?.message;

  return (
    <MotionContainer
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        textAlign: 'center',
        p: 3,
      }}
    >
      <m.div variants={varBounce().in}>
        <Typography variant="h3" sx={{ mb: 2 }}>
          We could not sign you in.
        </Typography>
      </m.div>

      <m.div variants={varBounce().in}>
        <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 520 }}>
          This is a sign-in problem, not a problem with your account. Try again — if it keeps
          happening, raise a ticket and quote the code below.
        </Typography>
      </m.div>

      {detail && (
        <Typography variant="caption" color="text.disabled" sx={{ mt: 1, fontFamily: 'monospace' }}>
          {detail}
        </Typography>
      )}

      <m.div variants={varBounce().in}>
        <MaintenanceIllustration sx={{ height: 260, my: { xs: 5, sm: 8 } }} />
      </m.div>

      <Stack direction="row" spacing={1.5} flexWrap="wrap" justifyContent="center">
        {onRetry && (
          <Button onClick={onRetry} size="large" variant="contained">
            Try again
          </Button>
        )}
        <Button
          onClick={() => (location.href = SERVICE_NOW_URL)}
          size="large"
          variant={onRetry ? 'outlined' : 'contained'}
        >
          Raise Service Now Ticket
        </Button>
      </Stack>
    </MotionContainer>
  );
}
