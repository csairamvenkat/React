import { m } from 'framer-motion';

import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { SeverErrorIllustration } from '../illustrations';

import { varBounce, MotionContainer } from '@/components/animate';
import { Link } from 'react-router-dom';
import { useRedirect } from '@/core/hooks';

export default function Page500() {
  const navigate = useRedirect();
  return (
    <MotionContainer
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
      }}
    >
      <m.div variants={varBounce().in}>
        <Typography variant="h3" sx={{ mb: 2 }}>
          500 Internal Server Error
        </Typography>
      </m.div>

      <m.div variants={varBounce().in}>
        <Typography sx={{ color: 'text.secondary' }}>
          There was an error, please try again later.
        </Typography>
      </m.div>

      <m.div variants={varBounce().in}>
        <SeverErrorIllustration sx={{ height: 260, my: { xs: 5, sm: 10 } }} />
      </m.div>

      <Button
        component={Link}
        to="/CMS"
        onClick={() => navigate('/CMS')}
        size="large"
        variant="contained"
      >
        Go to Home
      </Button>
    </MotionContainer>
  );
}
