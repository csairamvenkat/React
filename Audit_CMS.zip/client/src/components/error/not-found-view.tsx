import { m } from 'framer-motion';

import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import { varBounce, MotionContainer } from '@/components/animate';
import { Link } from 'react-router-dom';
import { useRedirect } from '@/core/hooks';
import { PageNotFoundIllustration } from '../illustrations';

export default function NotFoundView() {
  const navigate = useRedirect();

  return (
    <MotionContainer
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
      }}
    >
      <m.div variants={varBounce().in}>
        <Typography variant="h3" sx={{ mb: 2 }}>
          Sorry, Page Not Found!
        </Typography>
      </m.div>

      <m.div variants={varBounce().in}>
        <Typography sx={{ color: 'text.secondary' }}>
          Sorry, we couldn't find the page you're looking for. Perhaps you've mistyped the URL? Be
          sure to check your spelling.
        </Typography>
      </m.div>

      <m.div variants={varBounce().in}>
        <PageNotFoundIllustration
          sx={{
            height: 260,
            my: { xs: 5, sm: 10 },
          }}
        />
      </m.div>

      <Button
        component={Link}
        to="/CMS"
        onClick={() => navigate('/CMS')}
        size="large"
        variant="contained"
      >
        Go to Home
      </Button>
    </MotionContainer>
  );
}
