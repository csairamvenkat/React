import Iconify from '@/components/iconify/iconify';
import { Box, InputAdornment, Paper, Popper, Stack, TextField } from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import { TreeViewDataType } from '@/components/business-entity-treeview/treeview-types';
import { useTranslate } from '@/locales/use-locales';
import { RichTreeView } from '@mui/x-tree-view/RichTreeView';
import SearchNotFound from '../search-not-found';
import { bgBlur } from '@/theme/css';
import { COLORS } from '@/theme/colors';

type Props = {
  isMultiSelect: boolean;
  data: TreeViewDataType[];
  onNodeSelection: (node: TreeViewDataType) => void;
  defaultValue?: TreeViewDataType | null;
  error?: boolean | null;
  isChildrenSelection?: boolean | null | undefined;
  helperText?: string | null;
};

export function findNodeById(
  root: TreeViewDataType | undefined,
  id: string,
): TreeViewDataType | undefined {
  if (!root) return undefined;

  if (root.id === id) {
    return root;
  }

  if (root.children && root.children.length > 0) {
    for (const child of root.children) {
      const foundNode = findNodeById(child, id);
      if (foundNode) {
        return foundNode;
      }
    }
  }
  return undefined;
}
const BusinessEntityTreeView = ({
  isMultiSelect = false,
  data,
  onNodeSelection,
  defaultValue,
  error,
  helperText,
  isChildrenSelection = true,
}: Props) => {
  const { t } = useTranslate();

  const anchorRef = useRef<HTMLDivElement>(null);
  const popperRef = useRef<HTMLDivElement>(null);

  const [selectedNode, setSelectedNode] = useState<TreeViewDataType | null>(
    () => defaultValue || null,
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [openTreeview, setOpenTreeview] = useState(false);
  const filteredData: TreeViewDataType[] = searchNodeItem(searchTerm);
  const [expandedItems, setExpandedItems] = useState<string[]>([data[0]?.id]);

  useEffect(() => {
    if (defaultValue) setSelectedNode(defaultValue);
  }, [defaultValue]);

  useEffect(() => {
    if (!openTreeview) return;
    const handleClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (anchorRef.current?.contains(target) || popperRef.current?.contains(target)) return;
      setOpenTreeview(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [openTreeview]);

  const getAllItemsWithChildrenItemIds = () => {
    const itemIds: string[] = [];
    const registerItemId = (item: TreeViewDataType) => {
      if (item.children?.length) {
        itemIds.push(item.id);
        item.children.forEach(registerItemId);
      }
    };
    filteredData.forEach(registerItemId);
    return itemIds;
  };

  const handleSelectionNode = (selectedNodeItem: TreeViewDataType) => {
    setOpenTreeview(false);
    setSelectedNode(selectedNodeItem);
    onNodeSelection(selectedNodeItem);
  };

  const handleItemSelectionToggle = (event: any, itemId: string) => {
    if (event.target.className === 'MuiTreeItem-label') {
      const selectedNodeItem = findNodeById(filteredData[filteredData.length - 1], itemId);
      if (selectedNodeItem) {
        if (isChildrenSelection && selectedNodeItem.isNode) {
          handleSelectionNode(selectedNodeItem);
        }
        if (!isChildrenSelection) {
          handleSelectionNode(selectedNodeItem);
        }
      }
    }
  };

  /**
   * Depth first search.
   * @param node
   * @param term
   * @param foundIds
   * @returns
   */
  function dfs(node: TreeViewDataType, term: string, foundIds: string[]) {
    let isMatching = node.fullName && node.fullName.toLowerCase().indexOf(term.toLowerCase()) > -1;

    if (Array.isArray(node.children)) {
      node.children.forEach((child: TreeViewDataType) => {
        const hasMatchingChild = dfs(child, term, foundIds);
        isMatching = isMatching || hasMatchingChild;
      });
    }
    if (isMatching && node.id) {
      foundIds.push(node.id);
    }
    return isMatching;
  }

  function filter(data: TreeViewDataType[], matchedIDS: string[]): TreeViewDataType[] {
    return data
      .filter(item => matchedIDS.indexOf(item.id) > -1)
      .map(item => ({
        ...item,
        children: item.children ? filter(item.children, matchedIDS) : [],
      }));
  }

  function searchNodeItem(term: string): TreeViewDataType[] {
    const dataNode = {
      children: data,
    } as TreeViewDataType;

    const matchedIDS: string[] = [];
    dfs(dataNode, term, matchedIDS);

    return filter(data, matchedIDS);
  }

  const onSearchTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
    setExpandedItems(event.target.value ? getAllItemsWithChildrenItemIds() : [data[0]?.id]);
  };

  const handleExpandedItemsChange = (_event: React.SyntheticEvent, itemIds: string[]) => {
    setExpandedItems(itemIds);
  };

  return (
    <Box>
      <Box ref={anchorRef}>
        <TextField
          variant="outlined"
          value={
            !selectedNode
              ? `${t('placeholder.select_business_entity')} *`
              : `${selectedNode.fullName}`
          }
          sx={{
            borderRadius: 1,
            input: { cursor: 'pointer' },
            caretColor: 'transparent',
          }}
          fullWidth
          onClick={() => setOpenTreeview(prev => !prev)}
          size="medium"
          InputProps={{
            endAdornment: (
              <InputAdornment position="start">
                <Iconify
                  icon={!openTreeview ? 'eva:arrow-ios-downward-fill' : 'eva:arrow-ios-upward-fill'}
                  sx={{ color: 'text.disabled' }}
                />
              </InputAdornment>
            ),
          }}
          error={error ? true : false}
          helperText={helperText}
        />
      </Box>

      <Popper
        open={openTreeview}
        anchorEl={anchorRef.current}
        placement="bottom-start"
        style={{ zIndex: 1400, width: anchorRef.current?.offsetWidth }}
        modifiers={[
          {
            name: 'offset',
            options: { offset: [0, 4] },
          },
          {
            name: 'flip',
            options: {
              fallbackPlacements: ['top-start'],
            },
          },
        ]}
      >
        <Paper
          ref={popperRef}
          elevation={8}
          sx={{
            width: '100%',
            bgcolor: 'unset',
            ...bgBlur({
              blur: 20,
              opacity: 0.9,
              color: COLORS.white,
            }),
            backgroundImage: 'url(assets/cyan-blur.png), url(assets/red-blur.png)',
            backgroundRepeat: 'no-repeat, no-repeat',
            backgroundPosition: 'top right, left bottom',
            backgroundSize: '50%, 50%',
            boxShadow: theme => theme.customShadows.dropdown,
          }}
        >
          <Box sx={{ p: 1, overflowY: 'auto', maxHeight: 300 }}>
            <TextField
              placeholder={t('placeholder.filter')}
              fullWidth
              sx={{ mb: 1 }}
              value={searchTerm}
              onChange={onSearchTextChange}
              size="small"
              onClick={e => e.stopPropagation()}
            />
            {filteredData.length ? (
              <RichTreeView
                items={filteredData}
                onItemSelectionToggle={handleItemSelectionToggle}
                defaultExpandedItems={['fullName']}
                getItemLabel={item => item.fullName}
                expandedItems={expandedItems}
                multiSelect={isMultiSelect}
                onExpandedItemsChange={handleExpandedItemsChange}
                sx={{ padding: theme => theme.spacing(0.5) }}
                expansionTrigger="iconContainer"
              />
            ) : (
              <SearchNotFound query={searchTerm} sx={{ px: 2, pt: 4, pb: 4 }} />
            )}
          </Box>
        </Paper>
      </Popper>
    </Box>
  );
};

export default BusinessEntityTreeView;
