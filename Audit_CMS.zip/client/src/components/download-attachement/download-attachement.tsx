import { useEffect, useState } from 'react';
import { useQuery } from 'react-query';
import { useTranslate } from '@/locales/use-locales';
import { getAttachedFileById } from '@/features/kaizen/services/kaizen-card-service';
import LoadingButton from '@mui/lab/LoadingButton';

type Props = {
  attachmentName: string;
  fileId: string;
};
const DownloadAttachment = ({ attachmentName, fileId }: Props) => {
  const [fileDataId, setFileData] = useState<string>('');
  const { t } = useTranslate();
  const {
    data: fileData,
    isLoading,
    isError,
    refetch,
  } = useQuery(
    ['getAttachedfile', fileDataId],
    async () => {
      try {
        const data = await getAttachedFileById(fileDataId);
        return data;
      } catch (error) {
        throw new Error('Error fetching data');
      }
    },
    { enabled: false },
  );

  const handleDownload = () => {
    setFileData(fileId);
  };

  const handleCall = async () => {
    await refetch();
  };
  useEffect(() => {
    if (fileDataId) {
      handleCall();
    }
  }, [fileDataId]);

  if (!isLoading && !isError && fileData && fileDataId) {
    const blobUrl = URL.createObjectURL(new Blob([fileData]));

    const link = document.createElement('a');

    link.href = blobUrl;

    link.download = attachmentName;

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);

    URL.revokeObjectURL(blobUrl);
    setFileData('');
  }
  return (
    <LoadingButton
      size="medium"
      type="button"
      onClick={handleDownload}
      variant="contained"
      loading={isLoading}
    >
      {t('btn_name.download')}
    </LoadingButton>
  );
};

export default DownloadAttachment;
