import { alpha } from '@mui/material';
import type { SxProps, Theme } from '@mui/material';
import { COLORS } from '@/theme/colors';

export const capsuleTabsSx: SxProps<Theme> = {
  display: 'inline-flex',
  flexWrap: 'wrap',
  p: 0.5,
  border: '1px solid',
  borderColor: 'divider',
  borderRadius: 2.5,
  bgcolor: COLORS.white,
  '& .MuiToggleButtonGroup-grouped': {
    border: 0,
    borderRadius: '8px !important',
    textTransform: 'none',
    fontWeight: 600,
    fontSize: '0.83rem',
    px: 2,
    py: 0.9,
    color: 'text.secondary',
    transition: 'background 0.15s, color 0.15s',
    '&:not(:first-of-type)': { ml: 0 },

    '&:not(:last-of-type)': { boxShadow: `1px 0 0 0 ${alpha(COLORS.black, 0.08)}` },
    '&:hover': { bgcolor: alpha(COLORS.primary, 0.08) },
    '&.Mui-selected, &.Mui-selected:not(:last-of-type)': {
      bgcolor: COLORS.primary,
      color: COLORS.white,
      boxShadow: 'none',
      '&:hover': { bgcolor: COLORS.primaryDark },
    },
  },
};
