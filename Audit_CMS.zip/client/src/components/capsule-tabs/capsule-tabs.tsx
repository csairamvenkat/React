import { MouseEvent, memo } from 'react';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import { capsuleTabsSx } from './capsule-tabs.styles';

export interface TabOption<T extends string> {
  value: T;
  label: string;
}

interface CapsuleTabsProps<T extends string> {
  value: T;
  tabs: TabOption<T>[];
  onChange: (value: T) => void;
  ariaLabel: string;
}

function CapsuleTabsInner<T extends string>({
  value,
  tabs,
  onChange,
  ariaLabel,
}: CapsuleTabsProps<T>) {
  const handleChange = (_event: MouseEvent<HTMLElement>, next: T | null) => {
    if (next) onChange(next);
  };

  return (
    <ToggleButtonGroup
      exclusive
      size="small"
      value={value}
      onChange={handleChange}
      aria-label={ariaLabel}
      sx={capsuleTabsSx}
    >
      {tabs.map(tab => (
        <ToggleButton key={tab.value} value={tab.value} disableRipple>
          {tab.label}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
  );
}

export default memo(CapsuleTabsInner) as typeof CapsuleTabsInner;
