export { default } from './capsule-tabs';

export type { TabOption } from './capsule-tabs';
