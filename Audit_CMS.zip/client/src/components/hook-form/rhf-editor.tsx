import React from 'react';
import Editor from '../editor';

interface RHFEditorProps {
  field: any;
  form: any;
  value: string;
  name: string;
  onChange: (content: string) => void;
  error: boolean;
  helperText: string | undefined;
}

const RHFEditor: React.FC<RHFEditorProps> = ({ field, form, ...props }) => {
  return (
    <Editor
      id={field?.name}
      {...field}
      {...props}
      error={props.error}
      helperText={props.helperText}
      value={field?.value}
      onChange={(content: string) => form.setFieldValue(field?.name, content)}
    />
  );
};

export default RHFEditor;
