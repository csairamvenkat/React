import Button from '@mui/material/Button';
import Dialog, { DialogProps } from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import { useTranslate } from '@/locales/use-locales';
import { HistoryResponseDto } from '@/shared/models';
import { HistoryTimeline } from '.';

interface Param extends DialogProps {
  open: boolean;
  onClose: () => void;
  histories: HistoryResponseDto[];
}

export default function HistoryModal({ open, onClose, histories, ...other }: Param) {
  const { t } = useTranslate();

  return (
    <Dialog fullWidth maxWidth="md" open={open} onClose={onClose} {...other}>
      <DialogContent sx={{ typography: 'body2', marginTop: 4 }}>
        <HistoryTimeline histories={histories} />
      </DialogContent>

      <DialogActions>
        <Button variant="outlined" onClick={onClose}>
          {t('btn_name.cancel')}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
