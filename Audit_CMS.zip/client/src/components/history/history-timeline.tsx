import { useTranslate } from '@/locales/use-locales';
import Timeline from '@mui/lab/Timeline';
import TimelineItem, { timelineItemClasses } from '@mui/lab/TimelineItem';
import TimelineSeparator from '@mui/lab/TimelineSeparator';
import TimelineConnector from '@mui/lab/TimelineConnector';
import TimelineContent from '@mui/lab/TimelineContent';
import TimelineDot from '@mui/lab/TimelineDot';
import { Card, Grid, Typography } from '@mui/material';
import { HistoryResponseDto } from '@/shared/models';
import { fDateTime } from '@/shared/utils/format-time';

const HistoryTimeline = ({ histories }: { histories: HistoryResponseDto[] }) => {
  const { t } = useTranslate();

  return (
    <Card variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
      <Grid container>
        <Grid item xs={12} sx={{ mb: 2, pb: 1, borderBottom: 1, borderBottomColor: 'grey.300' }}>
          <Typography variant="subtitle1">{t('label.history')}</Typography>
        </Grid>
      </Grid>

      <Timeline
        sx={{
          [`& .${timelineItemClasses.root}:before`]: {
            flex: 0,
            padding: 0,
          },
        }}
      >
        {histories.map((history, index) => (
          <TimelineItem key={index}>
            <TimelineSeparator>
              <TimelineDot color="primary" />
              <TimelineConnector />
            </TimelineSeparator>
            <TimelineContent>
              <Typography variant="body2" component="span">
                {fDateTime(history.actionDate)}
              </Typography>

              <Typography variant="subtitle2" color={theme => `${theme.palette.grey[600]}`}>
                {history.actionPerformed} by {history.createdBy}
              </Typography>

              <Typography variant="caption" color={theme => `${theme.palette.grey[500]}`}>
                {history.actionComments}
              </Typography>
            </TimelineContent>
          </TimelineItem>
        ))}
      </Timeline>
    </Card>
  );
};

export default HistoryTimeline;
