import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Breadcrumbs from '@mui/material/Breadcrumbs';

import LinkItem from './link-item';
import { CustomBreadcrumbsProps } from './types';
import { Button, IconButton } from '@mui/material';

import { RouterLink } from '@/routes/components';

import ImageIcon from '../image/imageIcon';
import { bolderFont } from '@/theme/typography';

export default function CustomBreadcrumbs({
  links,
  action,
  heading,
  moreLink,
  activeLast,
  sx,
  backLink,
  onBack,
  ...other
}: CustomBreadcrumbsProps) {
  const lastLink = links.length ? links[links.length - 1].name : '';

  return (
    <Box sx={{ ...sx }}>
      <Stack direction="row" justifyContent={'start'} flexWrap={'wrap'}>
        <Box>
          {(backLink || onBack) && (
            <IconButton
              disableFocusRipple={true}
              disableTouchRipple={true}
              disableRipple={true}
              component={backLink ? RouterLink : Button}
              {...(backLink && { href: backLink })}
              {...(onBack && { onClick: onBack })}
              sx={{
                paddingTop: 1.5,
                '&:hover': {
                  backgroundColor: 'transparent',
                },
              }}
            >
              <ImageIcon src="assets/icons/custom-icons/backBtn.png" title="back" width="30px" />
            </IconButton>
          )}
        </Box>

        <Box sx={{ flexGrow: 1 }}>
          {heading && (
            <Typography fontFamily={bolderFont} fontSize={22}>
              {heading}
            </Typography>
          )}

          {!!links.length && (
            <Breadcrumbs separator={<Separator />} {...other}>
              {links.map(link => (
                <LinkItem
                  key={link.name || ''}
                  link={link}
                  activeLast={activeLast}
                  disabled={link.name === lastLink}
                />
              ))}
            </Breadcrumbs>
          )}
        </Box>

        {action && (
          <Box sx={{ flexShrink: 0, width: { xs: 'unset', md: 'unset' }, marginTop: { xs: 0.8 } }}>
            {' '}
            {action}{' '}
          </Box>
        )}
      </Stack>

      {!!moreLink && (
        <Box sx={{ mt: 2 }}>
          {moreLink.map(href => (
            <Link
              key={href}
              href={href}
              variant="body2"
              target="_blank"
              rel="noopener"
              sx={{ display: 'table' }}
            >
              {href}
            </Link>
          ))}
        </Box>
      )}
    </Box>
  );
}

function Separator() {
  return (
    <Box
      component="span"
      sx={{
        width: 4,
        height: 4,
        borderRadius: '50%',
        bgcolor: 'text.disabled',
      }}
    />
  );
}
