export { default as DetailCard } from './detail-card';
