import { Box, Card, Stack, Typography, Chip, IconButton, SxProps, Theme } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { ReactNode } from 'react';
import Iconify from '../iconify';

interface DetailCardProps {
  children: ReactNode;
  onClick?: () => void;
  header?: {
    title: string;
    subtitle?: string;
    statusColor?: 'primary' | 'warning' | 'error' | 'success';
    statusLabel?: string;
    showStatusIndicator?: boolean;
  };
  disabled?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  sx?: SxProps<Theme>;
}

export default function DetailCard({
  children,
  onClick,
  header,
  disabled = false,
  onEdit,
  onDelete,
  sx,
}: DetailCardProps) {
  const theme = useTheme();
  const getStatusColor = (color: string) => {
    switch (color) {
      case 'success':
        return 'success.main';
      case 'warning':
        return 'warning.main';
      case 'error':
        return 'error.main';
      default:
        return 'primary.main';
    }
  };

  return (
    <Card
      sx={{
        border: 1.5,
        borderColor: 'grey.300',
        borderRadius: 2,
        overflow: 'hidden',
        cursor: onClick && !disabled ? 'pointer' : 'default',
        transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
        boxShadow: theme.shadows[0],
        opacity: disabled ? 0.5 : 1,
        pointerEvents: disabled ? 'none' : 'auto',
        position: 'relative',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        '&:hover':
          onClick && !disabled
            ? {
                borderColor: 'primary.main',
                transform: 'translateY(-2px)',
                boxShadow: theme.shadows[4],
              }
            : {},
        '&:active':
          onClick && !disabled
            ? {
                transform: 'translateY(0px)',
                boxShadow: theme.shadows[2],
              }
            : {},
        '&:focus-visible': {
          outline: `2px solid ${theme.palette.primary.main}`,
          outlineOffset: '2px',
        },
        ...sx,
      }}
      onClick={onClick && !disabled ? onClick : undefined}
      tabIndex={onClick && !disabled ? 0 : undefined}
      onKeyDown={
        onClick && !disabled
          ? e => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
    >
      {header && (
        <Box
          sx={{
            px: 3,
            py: 2,
            borderBottom: 1,
            borderColor: 'divider',
            backgroundColor: 'grey.50',
            transition: 'background-color 0.2s ease',
          }}
        >
          <Stack direction="row" alignItems="center" justifyContent="space-between">
            <Stack direction="row" alignItems="center" spacing={1.5}>
              {header.showStatusIndicator && header.statusColor && (
                <Box
                  sx={{
                    width: 10,
                    height: 10,
                    borderRadius: '50%',
                    bgcolor: getStatusColor(header.statusColor),
                    position: 'relative',
                    '&::after': {
                      content: '""',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      borderRadius: '50%',
                      bgcolor: getStatusColor(header.statusColor),
                      animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                      opacity: 0.5,
                    },
                    '@keyframes pulse': {
                      '0%, 100%': {
                        transform: 'scale(1)',
                        opacity: 0.5,
                      },
                      '50%': {
                        transform: 'scale(1.5)',
                        opacity: 0,
                      },
                    },
                  }}
                />
              )}
              <Stack>
                <Typography variant="subtitle1" color="text.primary" sx={{ fontWeight: 600 }}>
                  {header.title}
                </Typography>
                {header.subtitle && (
                  <Typography variant="caption" color="text.secondary">
                    {header.subtitle}
                  </Typography>
                )}
              </Stack>
            </Stack>

            {header.statusLabel && header.statusColor && (
              <Chip
                label={header.statusLabel}
                color={header.statusColor as any}
                size="small"
                sx={{
                  fontWeight: 600,
                  textTransform: 'capitalize',
                  borderRadius: 1.5,
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    transform: 'scale(1.05)',
                  },
                }}
              />
            )}
            {(onEdit || onDelete) && (
              <Stack direction="row" spacing={0.5} sx={{ ml: 0.5 }}>
                {onEdit && (
                  <IconButton
                    size="small"
                    onClick={e => {
                      e.stopPropagation();
                      if (onEdit) {
                        onEdit();
                      }
                    }}
                    sx={{
                      padding: '6px',
                      color: 'text.secondary',
                      borderRadius: 1,
                      transition: 'all 0.2s ease',
                      '&:hover': {
                        backgroundColor: 'action.hover',
                        color: 'primary.main',
                        transform: 'scale(1.1)',
                      },
                      '&:active': {
                        transform: 'scale(0.95)',
                      },
                    }}
                  >
                    <Iconify icon="solar:pen-bold" width={16} />
                  </IconButton>
                )}

                {onDelete && (
                  <IconButton
                    size="small"
                    onClick={e => {
                      e.stopPropagation();
                      if (onDelete) {
                        onDelete();
                      }
                    }}
                    sx={{
                      padding: '6px',
                      color: 'text.secondary',
                      borderRadius: 1,
                      transition: 'all 0.2s ease',
                      '&:hover': {
                        backgroundColor: 'error.lighter',
                        color: 'error.main',
                        transform: 'scale(1.1)',
                      },
                      '&:active': {
                        transform: 'scale(0.95)',
                      },
                    }}
                  >
                    <Iconify icon="solar:trash-bin-minimalistic-bold" width={16} />
                  </IconButton>
                )}
              </Stack>
            )}
          </Stack>
        </Box>
      )}

      <Box sx={{ p: 2, flex: 1, display: 'flex', flexDirection: 'column' }}>{children}</Box>
    </Card>
  );
}
