import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { GraphUserResponse } from '@/shared/models';
import { useEffect, useState } from 'react';
import { useQuery } from 'react-query';
import { getUserDetails, searchGraphUsers } from '@/shared/services';
import { Stack } from '@mui/system';
import { useTranslation } from 'react-i18next';
import useDebounce from '@/core/hooks/useDebounce.hook';

type Prop = {
  initialUserId?: string | null;
  onSelect: (user: GraphUserResponse | null) => void;
  multiple?: boolean;
  required?: boolean;
  disabled?: boolean;
};

export default function AdUserSearchInput({
  initialUserId = null,
  onSelect,
  multiple = false,
  required = false,
  disabled = false,
}: Prop) {
  const { t } = useTranslation();
  const [value, setValue] = useState<GraphUserResponse | null>(null);

  const [inputText, setInputText] = useState('');
  const debouncedText = useDebounce(inputText, 350);

  const { data, isFetching } = useQuery(
    ['adUsers', debouncedText],
    () => searchGraphUsers(debouncedText, 'displayName'),
    {
      enabled: debouncedText.length >= 1,
      useErrorBoundary: false,
      retry: false,
    },
  );

  useEffect(() => {
    if (initialUserId) {
      const getInitialUserValue = async () => {
        const user = await getUserDetails(initialUserId);
        if (user?.value[user.value.length - 1]) {
          setValue(user?.value[user.value.length - 1]);
        }
      };
      getInitialUserValue();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Autocomplete
      disabled={disabled}
      loading={isFetching}
      fullWidth
      id="adUserSearch"
      getOptionLabel={option => option.displayName}
      filterOptions={x => x}
      options={data?.value || []}
      isOptionEqualToValue={(option, value) => option.id === value?.id}
      autoComplete
      includeInputInList
      value={value}
      multiple={multiple}
      noOptionsText={
        inputText ? t('empty_state_messages.no_user_found') : t('empty_state_messages.search_user')
      }
      onChange={(_, newValue: GraphUserResponse | null) => {
        setValue(newValue);
        onSelect(newValue);
      }}
      onInputChange={(_event, newInputValue) => {
        setInputText(newInputValue);
      }}
      renderInput={params => (
        <TextField {...params} label={t('label.search_user')} fullWidth required={required} />
      )}
      renderOption={(props, option) => {
        return (
          <li {...props} key={option.id}>
            <Grid container alignItems="center">
              <Grid item sx={{ width: 'calc(100% - 44px)', wordWrap: 'break-word' }}>
                <Stack flexDirection={'column'}>
                  <Typography variant="subtitle1" color="text.secondary" fontSize={14}>
                    {option.displayName}
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary" fontSize={12}>
                    {option.mail}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" fontSize={12}>
                    {option.jobTitle}
                  </Typography>
                </Stack>
              </Grid>
            </Grid>
          </li>
        );
      }}
    />
  );
}
