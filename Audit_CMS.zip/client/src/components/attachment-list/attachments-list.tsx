import { useDownloadAttachmentsZip } from '@/hooks/use-download-attachments-zip';
import { useLoading } from '@/hooks/use-loading';
import { useTranslate } from '@/locales/use-locales';
import { Attachment } from '@/shared/models';
import { getFileContent } from '@/shared/services';
import { Button, ButtonBase, Collapse } from '@mui/material';
import { Stack } from '@mui/system';
import saveAs from 'file-saver';
import FileThumbnail from '../file-thumbnail';
import Iconify from '../iconify';
import { COLORS } from '@/theme/colors';

export default function AttachmentsList({
  attachments,
  name = '',
}: {
  attachments: Attachment[];
  name?: string;
}) {
  const { setLoading, setMessage } = useLoading();
  const { t } = useTranslate();

  const downloadZip = useDownloadAttachmentsZip();

  const download = async (fileId: string | undefined, name: string) => {
    if (fileId) {
      handleStartLoading();
      const content = await getFileContent(fileId);
      saveAs(content, name);
      handleStopLoading();
    }
  };

  const handleStartLoading = () => {
    if (setLoading && setMessage) {
      setMessage(t('downloading'));
      setLoading(true);
    }
  };

  const handleStopLoading = () => {
    if (setLoading) {
      setLoading(false);
    }
  };

  return (
    <Stack
      spacing={1}
      sx={{
        p: 1,
        borderRadius: 1,
        bgcolor: COLORS.grey100,
      }}
    >
      <Stack direction="row" alignItems="center" justifyContent="space-between">
        <ButtonBase
          sx={{
            color: 'text.secondary',
            typography: 'caption',
            borderRadius: 0.5,
          }}
        >
          <Iconify icon="eva:attach-2-fill" sx={{ mr: 0.5 }} />
          {attachments?.length === 1 ? `${t('label.attachment')}` : `${t('label.attachments')}`}
        </ButtonBase>

        <Button
          startIcon={<Iconify icon="eva:cloud-download-fill" />}
          onClick={async () => await downloadZip(attachments, name)}
        >
          Download
        </Button>
      </Stack>

      <Collapse in={true} unmountOnExit timeout="auto">
        <Stack direction="row" flexWrap="wrap" spacing={1}>
          {attachments?.map(attachment => (
            <Stack
              key={attachment.id}
              alignItems="center"
              justifyContent="center"
              sx={{
                width: 40,
                height: 40,
                flexShrink: 0,
                borderRadius: 1,
                overflow: 'hidden',
                position: 'relative',
                backgroundColor: 'background.neutral',
              }}
            >
              <FileThumbnail
                imageView
                tooltip
                file={attachment}
                onDownload={() => download(attachment?.file_id, attachment.attachment_name)}
                sx={{ width: 36, height: 36 }}
              />
            </Stack>
          ))}
        </Stack>
      </Collapse>
    </Stack>
  );
}
