import { useTranslate } from '@/locales/use-locales';
import {
  TableContainer,
  Table,
  TableBody,
  Chip,
  TableCell,
  TableRow,
  Box,
  alpha,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import { useNavigate } from 'react-router';
import Scrollbar from '../scrollbar';
import { useTable, TableHeadCustom, TableNoData, TablePaginationCustom } from '../table';
import { SYSTEM_STATUS_COLOR_MAPPING } from '@/shared/mapping';
import _, { startCase } from 'lodash';
import { paths, ReplaceUrlVariable } from '@/routes/paths';
import { ChangeRequestData } from '@/features/change-request/types';
import { fDate } from '@/shared/utils/format-time';
import Iconify from '../iconify';
import { useTheme } from '@mui/system';
import { useState, useEffect } from 'react';

export const ChangeList = ({ changeRequests }: { changeRequests: ChangeRequestData[] }) => {
  const { t } = useTranslate();
  const TABLE_HEAD = [
    { id: 'reference_number', label: t('label.reference_number'), width: 180 },
    { id: 'requestor_name', label: t('label.requester_name') },
    { id: 'initiation_date', label: t('label.initiation_date') },
    { id: 'change_category', label: t('label.change_category') },

    { id: 'status', label: t('label.status') },
  ];

  const [filterValue, setFilterValue] = useState('all');
  const [filteredChangeRequests, setfilteredChangeRequests] = useState(changeRequests);
  const notFound = !filteredChangeRequests.length;
  useEffect(() => {
    setfilteredChangeRequests(
      changeRequests
        ?.filter(item => {

          if (filterValue == 'all') return item;
          else if (
            item.internalStatus == 'PENDING_APPROVAL' ||
            item.internalStatus == 'CONVERSION_IN_PROGRESS'
          ) {
            return item;
          }
        })
        .filter(item => item),
    );
  }, [filterValue]);
  const navigate = useNavigate();
  const navigateToView = (id: string) => {
    navigate(
      ReplaceUrlVariable(paths.changeRequests.root + paths.changeRequests.detailChangeRequest, {
        changeRequestId: id,
      }),
    );
  };
  const theme = useTheme();
  const table = useTable({ defaultDense: true, defaultRowsPerPage: 25 });
  return (
    <>
      {changeRequests?.length > 0 && (
        <Box sx={{ justifyContent: 'flex-end', width: '100%', display: 'flex', mb: 3 }}>
          <ToggleButtonGroup
            value={filterValue}
            exclusive
            onChange={(_, newType) => {
              if (newType !== null) {
                table.setPage(0);
                setFilterValue(newType);
              }
            }}
            size="small"
            sx={{
              p: 0.5,
              gap: 0.5,
              borderRadius: 1,
              backgroundColor: theme => alpha(theme.palette.grey[500], 0.08),
              '& .MuiToggleButtonGroup-grouped': {
                m: 0,
                border: 'none',
                borderRadius: 1,
                transition: 'all 0.2s',
                '&.Mui-selected': {
                  backgroundColor: 'background.paper',
                  boxShadow: '0 2px 8px 0 rgba(0,0,0,0.08)',
                  color: 'text.primary',
                  '&:hover': {
                    backgroundColor: 'background.paper',
                  },
                },
                '&:not(.Mui-selected):hover': {
                  backgroundColor: 'action.hover',
                },
              },
              '& .MuiToggleButton-root': {
                px: 2,
                py: 0.75,
                minWidth: 72,
                fontSize: '0.875rem',
                fontWeight: 600,
                color: 'text.secondary',
                textTransform: 'none',
              },
            }}
          >
            <ToggleButton value="all">{t('all')}</ToggleButton>
            <ToggleButton value="active">{t('active')}</ToggleButton>
          </ToggleButtonGroup>
        </Box>
      )}
      {filteredChangeRequests.length == 0 ? (
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            py: 6,
            width: '100%',
            px: 3,
          }}
        >
          <Box
            sx={{
              borderRadius: '50%',
              backgroundColor: alpha(theme.palette.grey[500], 0.12),
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 3,
            }}
          >
            <Iconify
              icon="mdi:file-document-edit-outline"
              width={28}
              color={theme.palette.grey[600]}
            />
          </Box>

          <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
            {t('empty_state_messages.no_CR_available')}
          </Typography>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 3, textAlign: 'center' }}>
            {t('empty_state_messages.no_CR_created')}
          </Typography>
        </Box>
      ) : (
        <>
          <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
            <Scrollbar>
              <Table size={table.dense ? 'small' : 'medium'} sx={{ minWidth: 960 }}>
                <TableHeadCustom
                  sx={{ th: { textAlign: 'center' } }}
                  order={table.order}
                  headLabel={TABLE_HEAD}
                  numSelected={table.selected.length}
                  rowCount={filteredChangeRequests.length || 0}
                  onSort={table.onSort}
                />

                <TableBody>
                  {filteredChangeRequests
                    ?.slice(
                      table.page * table.rowsPerPage,
                      table.page * table.rowsPerPage + table.rowsPerPage,
                    )
                    .map(row => {
                      return (
                        <TableRow hover>
                          <TableCell
                            align="center"
                            sx={{ cursor: 'pointer' }}
                            onClick={() => {
                              navigateToView(row?.id?.toString() ?? '');
                            }}
                          >
                            {row.referenceNumber ?? '-'}
                          </TableCell>
                          <TableCell align="center">{row.requesterName ?? '-'}</TableCell>

                          <TableCell align="center">{fDate(row.initiationDate)}</TableCell>
                          <TableCell align="center">
                            {row.changeCategory
                              ? startCase(row.changeCategory?.toLowerCase())
                              : '-'}
                          </TableCell>

                          <TableCell align="center">
                            <Chip
                              label={row.status.includes("@") ? row.status : startCase(row.status!.toLowerCase())}
                              color={
                                (SYSTEM_STATUS_COLOR_MAPPING[row.status || 'DEFAULT'] ??
                                  'primary') as any
                              }
                              size="small"
                              sx={{
                                fontWeight: 500,
                                fontSize: '0.82rem',
                                height: '24px',
                              }}
                            />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  <TableNoData notFound={notFound} />
                </TableBody>
              </Table>
            </Scrollbar>
          </TableContainer>
          {filteredChangeRequests.length > 10 && (
            <Box sx={{ justifyItems: 'self-end', width: '100%' }}>
              <TablePaginationCustom
                count={changeRequests?.length || 0}
                page={table.page}
                rowsPerPage={table.rowsPerPage}
                onPageChange={table.onChangePage}
                onRowsPerPageChange={table.onChangeRowsPerPage}
                dense={table.dense}
              />
            </Box>
          )}
        </>
      )}
    </>
  );
};
