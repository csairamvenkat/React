import { useTranslate } from '@/locales/use-locales';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Stack,
  Typography,
} from '@mui/material';
import Iconify from '../iconify';
import { FormikUpload } from '../formik-form';
import { Formik } from 'formik';
import * as yup from 'yup';
import * as ExcelJS from 'exceljs';

import { enqueueSnackbar } from 'notistack';

export default function CashflowImport({
  isOpen,
  onClose,
  onDownload,
  rowsImportCount,
  columnOffset,
  columnImportCount,
  rowOffset,
  onDataImport,
}: {
  isOpen: boolean;
  onClose: VoidFunction;
  onDownload: VoidFunction;
  rowsImportCount: number;
  columnImportCount: number;
  columnOffset: number;
  rowOffset: number;
  onDataImport: (data: any) => void;
}) {
  const { t } = useTranslate();
  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{}}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            {t('bulk_import_cashflow_records')}
          </Typography>
          <IconButton
            onClick={() => {
              onClose();
            }}
            size="small"
          >
            <span style={{ fontSize: '18px' }}>×</span>
          </IconButton>
        </Stack>
      </DialogTitle>
      <Formik
        initialValues={{ data_sheet: null }}
        validationSchema={yup.object().shape({
          data_sheet: yup.mixed().nullable(),
        })}
        onSubmit={async data => {
          if (!data.data_sheet || !data.data_sheet[0]) {
            enqueueSnackbar(t('error_messages.import_file_is_required'), {
              variant: 'error',
            });
          } else {
            let dataSheet = data.data_sheet[0] as any;

            const response = await fetch(dataSheet.file_base64);
            const blob = await response.blob();
            const arrayBuffer = await blob.arrayBuffer();
            const workbook = new ExcelJS.Workbook();
            let excelData = await workbook.xlsx.load(arrayBuffer);
            let sheet = excelData.getWorksheet(1);
            onDataImport(
              sheet?.getRows(rowOffset, rowsImportCount)?.map(row => {
                return new Array(columnImportCount).fill(0).map((_, index) => {
                  return row.getCell(index + columnOffset).value;
                });
              }),
            );
          }
        }}
      >
        {formik => {
          return (
            <>
              <DialogContent sx={{ p: 2 }}>
                <Divider sx={{ borderStyle: 'solid' }} />
                <Button
                  startIcon={<Iconify icon="eva:download-outline" />}
                  onClick={() => {
                    onDownload();
                  }}
                  variant="outlined"
                  fullWidth
                >
                  {t('download_excel_template')}
                </Button>

                <FormikUpload sx={{ mt: 2 }} name={'data_sheet'} multiple={false} />
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  {t('messages.import_same_as_template')}
                </Typography>
              </DialogContent>
              <DialogActions>
                <Button variant="outlined" color="inherit" onClick={onClose}>
                  Cancel
                </Button>

                <Button
                  variant="contained"
                  type="submit"
                  onClick={async () => {
                    await formik.submitForm();
                  }}
                >
                  Import
                </Button>
              </DialogActions>
            </>
          );
        }}
      </Formik>
    </Dialog>
  );
}
