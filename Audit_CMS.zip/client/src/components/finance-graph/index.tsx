import { formatCurrency } from '@/features/payment/utils';
import { getProjectBreakdown } from '@/features/project/services';
import { useTranslate } from '@/locales/use-locales';
import {
  Card,
  CircularProgress,
  Stack,
  ToggleButton,
  ToggleButtonGroup,
  Tooltip,
  Typography,
} from '@mui/material';
import { Box, useTheme } from '@mui/system';
import { enqueueSnackbar } from 'notistack';
import { useQuery } from 'react-query';
import Chart from '@/components/chart/chart';
import { ApexOptions } from 'apexcharts';
import { CASHFLOW_TYPE_ENUM } from '@/shared/enum';
import Iconify from '@/components/iconify';
import { useState } from 'react';

export const FinanceGraph = ({
  projectId,
  currency = 'USD',
  types,
}: {
  projectId: string;
  currency?: string;
  types: CASHFLOW_TYPE_ENUM[];
}) => {
  const { t } = useTranslate();
  const theme = useTheme();
  const [chartType, setChartType] = useState<'bar' | 'line'>('line');

  const {
    data: breakdown,
    isLoading: breakdownLoading,
    error,
  } = useQuery(
    ['project-breakdown', projectId, types],
    () => getProjectBreakdown(projectId ?? '', types ?? []),
    {
      enabled: !!projectId,
      onError: (error: any) => {
        enqueueSnackbar(
          error?.message && typeof error?.message === 'string'
            ? error?.message
            : t('error_messages.something_went_wrong'),
          { variant: 'error' },
        );
      },
    },
  );

  const chartOptions: ApexOptions = {
    chart: {
      type: chartType,
      height: 350,
      toolbar: {
        show: true,
        tools: {
          download: true,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: true,
          reset: true,
        },
      },
      zoom: {
        enabled: true,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        borderRadius: 4,
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: chartType === 'line' ? 3 : 2,
      colors:
        chartType === 'line'
          ? [theme.palette.primary.main, theme.palette.success.dark]
          : ['transparent'],
      curve: 'smooth',
    },
    markers: {
      size: chartType === 'line' ? 4 : 0,
      strokeWidth: 2,
      hover: {
        size: 6,
      },
    },
    xaxis: {
      categories: breakdown?.map(item => item.month) || [],
      labels: {
        style: {
          colors: theme.palette.text.secondary,
        },
      },
    },
    yaxis: {
      title: {
        text: `${t('placeholder.amount')} (${currency})`,
        style: {
          color: theme.palette.text.secondary,
        },
      },
      labels: {
        formatter: (value: number) => formatCurrency(value, currency),
        style: {
          colors: theme.palette.text.secondary,
        },
      },
    },
    fill: {
      opacity: 1,
    },
    tooltip: {
      theme: theme.palette.mode,
      y: {
        formatter: (value: number) => formatCurrency(value, currency),
      },
    },
    legend: {
      position: 'top',
      horizontalAlign: 'center',
      labels: {
        colors: theme.palette.text.primary,
      },
    },
    colors: [theme.palette.primary.main, theme.palette.success.dark],
    grid: {
      borderColor: theme.palette.divider,
      strokeDashArray: 3,
    },
  };
  const hasActualValue = breakdown?.filter(item => Boolean(item.actual));
  const hasPlannedValue = breakdown?.filter(item => Boolean(item.planned));
  const series = [
    {
      name: t('planned'),
      data:
        hasPlannedValue && hasPlannedValue?.length > 0 ? breakdown?.map(i => i.planned) || [] : [],
    },
    {
      name: t('actual'),
      data: hasActualValue && hasActualValue?.length > 0 ? breakdown?.map(i => i.actual) || [] : [],
    },
  ];

  const renderBarChart = () => {
    if (breakdownLoading) {
      return (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: 350,
          }}
        >
          <CircularProgress />
        </Box>
      );
    }

    if (!breakdownLoading && error) {
      return (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: 350,
          }}
        >
          <Typography variant="body1" color="text.secondary">
            {error?.response?.status == 403
              ? t('error_messages.permission_denied')
              : t('error_messages.something_went_wrong')}
          </Typography>
        </Box>
      );
    }

    if (!breakdown || breakdown.length === 0) {
      return (
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: 350,
          }}
        >
          <Typography variant="body1" color="text.secondary">
            {t('empty_state_messages.no_data_found')}
          </Typography>
        </Box>
      );
    }

    return <Chart type={chartType} series={series} options={chartOptions} height={350} />;
  };

  return (
    <Card
      sx={{
        p: 0,
        border: 1,
        borderColor: theme.palette.grey[300],
        borderRadius: 1,
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={{ p: 2, pb: 1.5 }}
      >
        <Stack direction="row" alignItems="center" spacing={2}>
          <Typography variant="subtitle1">{t('project_cashflow')}</Typography>
        </Stack>
        <ToggleButtonGroup
          value={chartType}
          exclusive
          onChange={(_, newType) => {
            if (newType !== null) {
              setChartType(newType);
            }
          }}
          size="small"
          sx={{
            '& .MuiToggleButton-root': {
              px: 1.5,
              py: 0.5,
              border: 1,
              borderColor: 'divider',
              '&.Mui-selected': {
                backgroundColor: theme.palette.primary.main,
                color: 'white',
                '&:hover': {
                  backgroundColor: theme.palette.primary.dark,
                },
              },
            },
          }}
        >
          <ToggleButton value="line">
            <Tooltip title="Line Chart">
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Iconify icon="mdi:chart-line" width={20} />
              </Box>
            </Tooltip>
          </ToggleButton>
          <ToggleButton value="bar">
            <Tooltip title="Bar Chart">
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Iconify icon="mdi:chart-bar" width={20} />
              </Box>
            </Tooltip>
          </ToggleButton>
        </ToggleButtonGroup>
      </Stack>
      <Box sx={{ px: 2, pb: 2 }}>{renderBarChart()}</Box>
    </Card>
  );
};
