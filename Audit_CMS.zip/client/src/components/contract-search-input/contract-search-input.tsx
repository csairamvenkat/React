import { ContractDetailResponse } from '@/shared/models/contract-response.model';
import { getContracts } from '@/shared/services';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from 'react-query';
import { enqueueSnackbar } from '../snackbar';
import { debounce, lte } from 'lodash';
import { Autocomplete, Grid, Stack, TextField, Typography } from '@mui/material';
import Iconify from '../iconify';
import { getContractDetails } from '@/features/contract/services/contract.service';

type Prop = {
  onSelect: (value: string | ContractDetailResponse | null) => void;
  placeholder?: string;
  initialContractId?: string | number | null;
  disabled?: boolean;
  returnFullObject?: boolean;
  projectId?: string;
  firstLoad?: boolean;
  error?: boolean;
  helperText?: string;
  isBond?: boolean;
};

export default function ContractSearchInput({
  onSelect,
  placeholder,
  firstLoad = false,
  initialContractId = null,
  disabled = false,
  returnFullObject = false,
  projectId,
  error = false,
  helperText,
  isBond = false,
}: Prop) {
  const { t } = useTranslation();
  const [value, setValue] = useState<ContractDetailResponse | null>(null);
  const [searchText, setSearchText] = useState('');
  const [options, setOptions] = useState<ContractDetailResponse[]>([]);
  const { isFetching, refetch } = useQuery(
    ['contracts', searchText, projectId],
    () => {
      return getContracts(searchText, projectId ? { projectId } : undefined);
    },
    {
      enabled: firstLoad || Boolean(searchText),
      onSuccess(data) {
        if (data) {
          let filteredRecords = (data.records ?? []).filter(
            contract => contract.status !== 'CLOSED' && contract.status !== 'CANCELLED',
          );

          if (isBond) {
            filteredRecords = filteredRecords.filter(contract => {
              return contract.expenseType == 'Contract';
            });
          }
          setOptions(filteredRecords);
        }
      },
      onError: () => {
        enqueueSnackbar(t('error_messages.something_went_wrong'), { variant: 'error' });
      },
    },
  );
  useEffect(() => {
    if (initialContractId) {
      const setInitialValue = async () => {
        const contractId =
          typeof initialContractId === 'number' ? initialContractId.toString() : initialContractId;
        const contract = await getContractDetails(contractId);
        setValue({
          id: +(contract.id ?? ''),
          referenceNumber: contract.referenceNo,
          contractType: contract.contractType.toString(),
          projectCode: contract.project.toString(),
          projectName: contract.projectParty,
          projectPartyName: contract.project.toString(),
          employer: contract.employer,
          expenseType: contract.expenseType,
        });
      };
      setInitialValue();
    }
  }, [initialContractId]);
  const debouncedSetSearchText = useMemo(() => debounce(setSearchText, 500), []);
  useEffect(() => {
    if (searchText.length) {
      refetch();
    }
  }, [refetch, searchText]);
  return (
    <Autocomplete
      loading={isFetching}
      fullWidth
      id="adUserSearch"
      getOptionLabel={option => `${option.projectName}`}
      disabled={disabled}
      filterOptions={x => x}
      options={options ?? []}
      isOptionEqualToValue={(option, value) => option.id === value?.id}
      autoComplete
      includeInputInList
      value={value}
      noOptionsText={
        searchText == '' || value !== null
          ? t('placeholder.search_contracts')
          : t('empty_state_messages.no_contracts_found')
      }
      onInputChange={(_event, value) => {
        debouncedSetSearchText(value);
      }}
      popupIcon={<Iconify icon="eva:search-fill" width={24} />}
      sx={{
        '& .MuiAutocomplete-popupIndicator': {
          transform: 'none !important',
        },
        '&.Mui-focused .MuiAutocomplete-popupIndicator': {
          transform: 'none !important',
        },
        '&[aria-expanded="true"] .MuiAutocomplete-popupIndicator': {
          transform: 'none !important',
        },
      }}
      onChange={(_, newValue: any | null) => {
        setValue(newValue);
        if (newValue) {
          if (returnFullObject) {
            onSelect(newValue);
          } else {
            onSelect(newValue.id);
          }
        } else {
          onSelect(null);
        }
      }}
      renderInput={params => {
        return (
          <TextField
            {...params}
            label={<span>{placeholder || t('label.search_contracts')}</span>}
            fullWidth
            error={error}
            helperText={helperText}
          />
        );
      }}
      renderOption={(props, option) => {
        return (
          <li {...props} key={option.id}>
            <Grid container alignItems="center">
              <Grid sx={{ wordWrap: 'break-word' }}>
                <Stack flexDirection={'column'}>
                  <Typography variant="subtitle1" color="text.secondary" fontSize={14}>
                    {option.projectName} - {option.referenceNumber}
                  </Typography>
                </Stack>
              </Grid>
            </Grid>
          </li>
        );
      }}
    />
  );
}
