import { useTranslate } from '@/locales/use-locales';
import {
  TableContainer,
  Table,
  TableBody,
  Chip,
  TableCell,
  TableRow,
  Box,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import { useNavigate } from 'react-router';
import Scrollbar from '../scrollbar';
import { useTable, TableHeadCustom, TableNoData, TablePaginationCustom } from '../table';
import { SYSTEM_STATUS_COLOR_MAPPING } from '@/shared/mapping';
import _, { startCase } from 'lodash';
import { BondItem } from '@/shared/models/bond-response.model';
import { differenceInBusinessDays } from 'date-fns';
import { bondPaths } from '@/features/bonds/utils/navigation';
import { alpha, useTheme } from '@mui/system';
import Iconify from '../iconify';
import { formatCurrency } from '@/features/payment/utils';
import { useEffect, useState } from 'react';

export const BondList = ({ bonds }: { bonds: BondItem[] }) => {
  const { t } = useTranslate();
  const originalHead = [
    { id: 'bond_number', label: t('label.bond_number') },
    { id: 'bond_type', label: t('label.bond_type') },
    { id: 'days_left', label: t('label.days_left') },

    { id: 'bond_amount', label: t('label.bond_amount') },
    { id: 'Status', label: t('label.status') },
    { id: 'physical_bond_status', label: t('label.physical_bond_status') },
  ];
  const [TABLE_HEAD, setTableHead] = useState(originalHead);
  const [filteredBonds, setFilteredBonds] = useState(bonds);

  const [filterValue, setFilterValue] = useState('all');
  useEffect(() => {
    setFilteredBonds(bonds);
  }, [bonds]);

  useEffect(() => {
    setFilteredBonds(
      bonds
        ?.filter(item => {
          if (filterValue == 'all') {
            if (item.internalStatus !== 'Released') {
              return item;
            }
          } else if (item.internalStatus === 'Released') {
            return item;
          }
        })
        .filter(item => item),
    );

    if (filterValue === 'released') {
      setTableHead(TABLE_HEAD.filter(head => head.id !== 'days_left'));
    } else {
      setTableHead(originalHead);
    }
  }, [filterValue]);

  const notFound = !bonds.length;
  const navigate = useNavigate();
  const navigateToView = (id: string) => {
    navigate(bondPaths.detail(+id));
  };
  const getBondStatusLabel = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'Approved';
      case 'CREATED':
        return 'Created';
      case 'PENDING_APPROVAL':
        return 'Pending Approval';
      case 'REJECTED':
        return 'Rejected';
      default:
        return status;
    }
  };

  const getPhysicalBondStatusLabel = (physicalBondStatus: string) => {
    switch (physicalBondStatus) {
      case 'IN_SAFE':
        return 'In Safe';
      case 'RELEASED':
        return 'Released';
      default:
        return physicalBondStatus?.includes('Pending With')
          ? physicalBondStatus
          : startCase(physicalBondStatus?.toLowerCase() || 'Not Available');
    }
  };
  const theme = useTheme();
  const table = useTable({ defaultDense: true, defaultRowsPerPage: 25 });
  return bonds.length == 0 ? (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        py: 6,
        width: '100%',
        px: 3,
      }}
    >
      <Box
        sx={{
          borderRadius: '50%',
          backgroundColor: alpha(theme.palette.grey[500], 0.12),
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          mb: 3,
        }}
      >
        <Iconify icon="mdi:file-document-edit-outline" width={28} color={theme.palette.grey[600]} />
      </Box>

      <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
        {t('empty_state_messages.no_bonds_available')}
      </Typography>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 3, textAlign: 'center' }}>
        {t('empty_state_messages.no_bonds_created')}
      </Typography>
    </Box>
  ) : (
    <>
      <Box sx={{ justifyContent: 'flex-end', width: '100%', display: 'flex', mb: 3 }}>
        <ToggleButtonGroup
          value={filterValue}
          exclusive
          onChange={(_, newType) => {
            if (newType !== null) {
              table.setPage(0);
              setFilterValue(newType);
            }
          }}
          size="small"
          sx={{
            p: 0.5,
            gap: 0.5,
            borderRadius: 1,
            backgroundColor: theme => alpha(theme.palette.grey[500], 0.08),
            '& .MuiToggleButtonGroup-grouped': {
              m: 0,
              border: 'none',
              borderRadius: 1,
              transition: 'all 0.2s',
              '&.Mui-selected': {
                backgroundColor: 'background.paper',
                boxShadow: '0 2px 8px 0 rgba(0,0,0,0.08)',
                color: 'text.primary',
                '&:hover': {
                  backgroundColor: 'background.paper',
                },
              },
              '&:not(.Mui-selected):hover': {
                backgroundColor: 'action.hover',
              },
            },
            '& .MuiToggleButton-root': {
              px: 2,
              py: 0.75,
              minWidth: 72,
              fontSize: '0.875rem',
              fontWeight: 600,
              color: 'text.secondary',
              textTransform: 'none',
            },
          }}
        >
          <ToggleButton value="all">{t('label.current_bonds')}</ToggleButton>
          <ToggleButton value="released">{t('label.previous_bonds')}</ToggleButton>
        </ToggleButtonGroup>
      </Box>
      <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
        <Scrollbar>
          <Table size={table.dense ? 'small' : 'medium'} sx={{ minWidth: 960 }}>
            <TableHeadCustom
              sx={{ th: { textAlign: 'center' } }}
              order={table.order}
              headLabel={TABLE_HEAD}
              numSelected={table.selected.length}
              rowCount={bonds.length || 0}
              onSort={table.onSort}
            />

            <TableBody>
              {filteredBonds
                ?.slice(
                  table.page * table.rowsPerPage,
                  table.page * table.rowsPerPage + table.rowsPerPage,
                )
                .map(row => {
                  let daysBeforeExpiration = differenceInBusinessDays(
                    new Date(row.expiryDate),
                    new Date(),
                  );

                  const getDaysLeftChipProps = (days: number) => {
                    const dayLabel = days === 1 ? 'day' : 'days';
                    if (days < 0) {
                      return {
                        color: 'error' as const,
                        label: 'Expired',
                        variant: 'filled' as const,
                      };
                    } else if (days <= 7) {
                      return {
                        color: 'error' as const,
                        label: `${days} ${dayLabel} left`,
                        variant: 'outlined' as const,
                      };
                    } else if (days <= 30) {
                      return {
                        color: 'warning' as const,
                        label: `${days} ${dayLabel} left`,
                        variant: 'outlined' as const,
                      };
                    } else if (days <= 90) {
                      return {
                        color: 'primary' as const,
                        label: `${days} ${dayLabel} left`,
                        variant: 'outlined' as const,
                      };
                    } else {
                      return {
                        color: 'success' as const,
                        label: `${days} ${dayLabel} left`,
                        variant: 'outlined' as const,
                      };
                    }
                  };

                  const daysChipProps = getDaysLeftChipProps(daysBeforeExpiration);
                  return (
                    <TableRow hover sx={{ textAlign: 'center' }}>
                      <TableCell
                        align="center"
                        sx={{ cursor: 'pointer' }}
                        onClick={() => {
                          navigateToView(row.id.toString());
                        }}
                      >
                        {row.number}
                      </TableCell>
                      <TableCell align="center">{startCase(row.bondType.toLowerCase())}</TableCell>
                      {filterValue != 'released' && (
                        <TableCell align="center">
                          {' '}
                          <Chip
                            label={daysChipProps.label}
                            color={daysChipProps.color}
                            variant={daysChipProps.variant}
                            size="small"
                            sx={{
                              fontWeight: 600,
                              fontSize: '0.82rem',
                              height: '26px',
                              minWidth: '95px',
                            }}
                          />
                        </TableCell>
                      )}
                      <TableCell align="center">
                        {formatCurrency(row.amount, row.currency)}
                      </TableCell>
                      <TableCell align="center">
                        {
                          <Chip
                            label={getBondStatusLabel(row.internalStatus)}
                            color={
                              (SYSTEM_STATUS_COLOR_MAPPING[
                                row.internalStatus === 'Released' ? 'RELEASED' : row.status
                              ] ?? 'primary') as any
                            }
                            size="small"
                            sx={{
                              fontWeight: 500,
                              fontSize: '0.82rem',
                              height: '24px',
                            }}
                          />
                        }
                      </TableCell>{' '}
                      <TableCell align="center">
                        <Chip
                          label={getPhysicalBondStatusLabel(row.physicalBondStatus)}
                          color={
                            (SYSTEM_STATUS_COLOR_MAPPING[row.physicalBondStatus] ??
                              'primary') as any
                          }
                          size="small"
                          sx={{
                            fontWeight: 500,
                            fontSize: '0.82rem',
                            height: '24px',
                          }}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })}
              <TableNoData notFound={notFound} />
            </TableBody>
          </Table>
        </Scrollbar>
      </TableContainer>
      {bonds.length > 10 && (
        <Box sx={{ justifyItems: 'self-end', width: '100%' }}>
          <TablePaginationCustom
            count={bonds?.length || 0}
            page={table.page}
            rowsPerPage={table.rowsPerPage}
            onPageChange={table.onChangePage}
            onRowsPerPageChange={table.onChangeRowsPerPage}
            dense={table.dense}
          />
        </Box>
      )}
    </>
  );
};
