import { FC, ReactNode } from 'react';
import { useField } from 'formik';
import { FormControl, FormControlProps, FormHelperText, OutlinedInput } from '@mui/material';

interface TextInputProps extends FormControlProps {
  readonly label: string;
  readonly name: string;
  readonly endAdornment?: ReactNode;
}

const FormikCustomTextArea: FC<TextInputProps> = ({ name, label, endAdornment, ...props }) => {
  const [field, meta] = useField(name);

  return (
    <FormControl error={meta.touched && Boolean(meta.error)} {...props}>
      <OutlinedInput
        placeholder={label}
        {...field}
        endAdornment={endAdornment ? endAdornment : ''}
      />
      {meta.touched && meta.error && <FormHelperText>{meta.error}</FormHelperText>}
    </FormControl>
  );
};

export default FormikCustomTextArea;
