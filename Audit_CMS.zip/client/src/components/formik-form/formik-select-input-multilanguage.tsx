import { FC } from 'react';
import { useField } from 'formik';
import {
  FormControl,
  FormControlProps,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
} from '@mui/material';
import { useLocales } from '@/locales/use-locales';
import { getTranslatedValue } from '@/shared/utils';
import { Translations } from '@/shared/types';
import { DataCatalogResponse } from '@/features/data-catalog/models';

interface Props extends FormControlProps {
  readonly label: string;
  readonly name: string;
  readonly values: { id: string; translations: Translations }[] | DataCatalogResponse[];
}

const FormikSelectInputMultiLanguageField: FC<Props> = ({ name, label, values, ...props }) => {
  const [field, meta] = useField(name);
  const { currentLang } = useLocales();
  return (
    <FormControl error={meta.touched && Boolean(meta.error)} {...props}>
      <InputLabel id={name}>{label}</InputLabel>
      <Select label={label} {...field}>
        {values.map((item, index) => (
          <MenuItem value={item.id} key={index}>
            {getTranslatedValue(item.translations, currentLang.value)}
          </MenuItem>
        ))}
      </Select>
      {meta.touched && meta.error && <FormHelperText>{meta.error}</FormHelperText>}
    </FormControl>
  );
};

export default FormikSelectInputMultiLanguageField;
