import { FC } from 'react';
import { useField } from 'formik';
import { MultiUserProfileSearchInputAll } from '../multi-user-profile-search-input-all';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly businessUnitId: string;
  readonly required?: boolean;
  readonly disabled?: boolean;
}

const FormikMultiUserProfileSelectAll: FC<Props> = ({
  name,
  label,
  businessUnitId,
  disabled,
  required = false,
}) => {
  const [field, meta, helper] = useField(name);

  return (
    <MultiUserProfileSearchInputAll
      label={label}
      businessUnitId={businessUnitId}
      name={name}
      setUserProfileValues={value => helper.setValue(value)}
      value={field.value}
      touched={meta.touched}
      error={meta.error}
      onTouchHandler={(touched: boolean) => helper.setTouched(touched)}
      required={required}
      disabled={disabled}
    />
  );
};

export default FormikMultiUserProfileSelectAll;
