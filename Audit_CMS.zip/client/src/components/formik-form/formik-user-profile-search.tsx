import { useField } from 'formik';
import { FC } from 'react';
import { UserProfileSearch } from '../user-profile-search-input';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly businessUnitId: string;
  readonly required?: boolean;
  readonly disabled?: boolean;
  readonly includeNonAccounted?: boolean;
}

const FormikUserProfileSearch: FC<Props> = ({
  name,
  label,
  businessUnitId,
  disabled,
  required = false,
  includeNonAccounted = false,
}) => {
  const [field, meta, helper] = useField(name);

  return (
    <UserProfileSearch
      label={label}
      businessUnitId={businessUnitId}
      name={name}
      setUserSearchValue={value => helper.setValue(value)}
      value={field.value}
      touched={meta.touched}
      error={meta.error}
      onTouchHandler={(touched: boolean) => helper.setTouched(touched)}
      required={required}
      disabled={disabled}
      includeNonAccounted={includeNonAccounted}
    />
  );
};

export default FormikUserProfileSearch;
