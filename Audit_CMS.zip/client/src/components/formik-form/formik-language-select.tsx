import TextField from '@mui/material/TextField';
import Autocomplete, { AutocompleteProps } from '@mui/material/Autocomplete';
import { useField } from 'formik';
import { Chip, InputAdornment } from '@mui/material';
import Iconify from '../iconify';
import { languages } from '@/shared/data';

interface Props<
  T,
  Multiple extends boolean | undefined,
  DisableClearable extends boolean | undefined,
  FreeSolo extends boolean | undefined,
> extends AutocompleteProps<T, Multiple, DisableClearable, FreeSolo> {
  name: string;
  label?: string;
  placeholder?: string;
}

export default function FormikLanguageSelect<
  T,
  Multiple extends boolean | undefined,
  DisableClearable extends boolean | undefined,
  FreeSolo extends boolean | undefined,
>({
  name,
  label,
  placeholder,
  multiple,
  ...other
}: Omit<Props<T, Multiple, DisableClearable, FreeSolo>, 'renderInput'>) {
  const [field, meta, helper] = useField(name);

  return (
    <Autocomplete
      {...field}
      multiple={undefined}
      id={`autocomplete-${name}`}
      autoHighlight={!multiple}
      disableCloseOnSelect={multiple}
      onChange={(_event, newValue) => helper.setValue(newValue)}
      renderOption={(props, option) => {
        const language = getLanguages(option as string);

        if (!language.label) {
          return null;
        }

        return (
          <li {...props} key={language.label}>
            <Iconify
              key={language.label}
              icon={`circle-flags:${language.code?.toLowerCase()}`}
              sx={{ mr: 1 }}
            />
            {language.label} ({language.lang})
          </li>
        );
      }}
      renderInput={params => {
        const language = getLanguages(params.inputProps.value as string);

        const baseField = {
          ...params,
          label,
          placeholder,
          error: meta.touched && Boolean(meta.error),
          helperText: meta.touched && meta.error,
          inputProps: {
            ...params.inputProps,
            autoComplete: 'new-password',
          },
        };

        if (multiple) {
          return <TextField {...baseField} />;
        }

        return (
          <TextField
            {...baseField}
            InputProps={{
              ...params.InputProps,
              startAdornment: (
                <InputAdornment
                  position="start"
                  sx={{
                    ...(!language.code && {
                      display: 'none',
                    }),
                  }}
                >
                  <Iconify
                    icon={`circle-flags:${language.code?.toLowerCase()}`}
                    sx={{ mr: -0.5, ml: 0.5 }}
                  />
                </InputAdornment>
              ),
            }}
          />
        );
      }}
      renderTags={(selected, getTagProps) =>
        selected.map((option, index) => {
          const language = getLanguages(option as string);
          return (
            <Chip
              {...getTagProps({ index })}
              key={language.label}
              label={language.label}
              icon={<Iconify icon={`circle-flags:${language.code?.toLowerCase()}`} />}
              size="small"
              variant="soft"
            />
          );
        })
      }
      {...other}
    />
  );
}

export function getLanguages(inputValue: string) {
  const option = languages.filter(country => country.label === inputValue)[0];

  return {
    ...option,
  };
}
