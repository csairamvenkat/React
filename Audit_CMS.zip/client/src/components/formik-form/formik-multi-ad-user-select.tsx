import { FC } from 'react';
import { useField } from 'formik';
import { MultiAdUserSearchInput } from '../multi-ad-user-search-input';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly initialUserIds?: string[];
  readonly required?: boolean;
  readonly disabled?: boolean;
}

const FormikMultiAdUserSelect: FC<Props> = ({
  name,
  label,
  disabled,
  initialUserIds,
  required = false,
}) => {
  const [field, meta, helper] = useField(name);

  return (
    <MultiAdUserSearchInput
      label={label}
      name={name}
      initialUserIds={initialUserIds}
      onSelect={value => helper.setValue(value)}
      value={field.value}
      touched={meta.touched}
      error={meta.error}
      onTouchHandler={(touched: boolean) => helper.setTouched(touched)}
      required={required}
      disabled={disabled}
    />
  );
};

export default FormikMultiAdUserSelect;
