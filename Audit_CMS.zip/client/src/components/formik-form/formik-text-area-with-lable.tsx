import { OutlinedTextFieldProps, Typography } from '@mui/material';
import { FC } from 'react';
import FormikInputField from './formik-input-field';

interface TextInputProps extends OutlinedTextFieldProps {
  readonly label: string;
  readonly name: string;
}

export const ForikTextAreaWithLable: FC<TextInputProps> = ({ label, name, ...other }) => {
  return (
    <>
      <Typography variant="body2" sx={{ paddingBottom: 1 }}>
        {label}
      </Typography>
      <FormikInputField name={name} label={''} multiline minRows={4} fullWidth {...other} />
    </>
  );
};
