import { useField } from 'formik';
import { FC } from 'react';
import ProjectManagerSearchInput from '../project-manager-search-input/project-manager-search-input';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly initialId?: string;
  readonly required?: boolean;
  readonly disabled?: boolean;
}

const FormikProjectManagerSearch: FC<Props> = ({
  name,
  label,
  initialId,
  disabled,
  required = false,
}) => {
  const [field, meta, helper] = useField(name);
  return (
    <ProjectManagerSearchInput
      label={label}
      name={name}
      initialId={initialId}
      setUserSearchValue={value => helper.setValue(value)}
      value={field.value}
      touched={meta.touched}
      error={meta.error}
      onTouchHandler={(touched: boolean) => helper.setTouched(touched)}
      required={required}
      disabled={disabled}
    />
  );
};

export default FormikProjectManagerSearch;
