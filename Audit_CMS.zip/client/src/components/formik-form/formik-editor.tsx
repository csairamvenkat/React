import React from 'react';
import Editor from '../editor';
import { FormHelperText } from '@mui/material';
import { useField } from 'formik';
import { UnprivilegedEditor } from 'react-quill';

interface Prop {
  id: string;
  name: string;
}

const FormikEditor: React.FC<Prop> = ({ id, name, ...other }) => {
  const [field, meta, helper] = useField(name);

  return (
    <Editor
      simple
      id={id}
      error={meta.touched && !!meta.error}
      helperText={
        !!meta.error &&
        meta.touched && (
          <FormHelperText error={!!meta.error} sx={{ px: 2 }}>
            {meta.error}
          </FormHelperText>
        )
      }
      value={field.value}
      onChange={(value: string, _delta, _source, editor: UnprivilegedEditor) => {
        if (editor.getText().trim() === '') {
          helper.setValue('');
        } else {
          helper.setValue(value);
        }
      }}
      {...other}
    />
  );
};

export default FormikEditor;
