/* eslint-disable @typescript-eslint/no-unused-vars */
import FormHelperText from '@mui/material/FormHelperText';

import { Attachment } from '@/shared/models';
import { getBase64 } from '@/shared/utils';
import { useField } from 'formik';
import { useCallback, useEffect, useState } from 'react';
import { Upload, UploadProps } from '../upload';

interface Props extends UploadProps {
  name: string;
  deletedAttachments?: string;
  maxSize?: number;
  maxFile?: number;
}

export default function FormikUpload({
  name,
  multiple = true,
  deletedAttachments = 'deletedAttachments',
  maxSize,
  maxFile,
  ...other
}: Props) {
  const [field, meta, helper] = useField(name);
  const [currentTotalSize, setCurrentTotalSize] = useState(0);
  const [deletedAttachmentsField, _deletedAttachmentsMeta, deleteAttachmentsHelper] =
    useField(deletedAttachments);

  const [error, setError] = useState(undefined);

  function filzeSizeInMB(fileSize: number): number {
    return +(fileSize / (1024 * 1024)).toFixed(2);
  }

  function aboveLimit(file: File) {
    const fileSize = filzeSizeInMB(file.size);
    if (currentTotalSize + fileSize > maxSize!) {
      setError(`File: ${file.name} is above allowed limit. (${maxSize} MB)`);
      return true;
    }
    if (error) {
      setError(undefined);
    }
    setCurrentTotalSize(currentTotalSize + fileSize);
    return false;
  }

  const handleDrop = useCallback(
    async (acceptedFiles: File[]) => {
      let newFiles = await Promise.all(
        acceptedFiles.map(async (file): Promise<Attachment | undefined> => {
          if (maxSize) {
            if (aboveLimit(file)) {
              return undefined;
            }
          }
          const fileBase64 = await getBase64(file);
          return {
            IsNew: true,
            IsEdited: false,
            attachment_name: file.name,
            attachment_content_type: file.type,
            fileimage: file.type,
            file: file,
            size: `${file.size}`,
            file_base64: fileBase64?.toString() || '',
            file_id: undefined,
          };
        }),
      );
      newFiles = newFiles.filter(files => files !== undefined);
      if (multiple) {
        if (maxFile) {
          if ((meta.value?.length ?? 0) + (newFiles?.length ?? 0) > maxFile) {
            setError(`Can't Upload more than ${maxFile} File(s)`);
            newFiles = newFiles.splice(0, Math.max(maxFile - (meta.value?.length ?? 0), 0));
          }
        }
        helper.setValue([...(field.value ?? []), ...newFiles]);
      } else {
        helper.setValue([...newFiles]);
      }
    },
    [field.value, helper],
  );

  const handleRemoveFile = (inputFile: Attachment | string) => {
    deleteAttachmentsHelper.setValue([...(deletedAttachmentsField.value ?? []), inputFile]);
    const filtered = field.value.filter((file: Attachment) => file !== inputFile);
    const totalSize = filtered.reduce(
      (sum: number, attachment: Attachment) =>
        sum + filzeSizeInMB(attachment.file?.size ?? +attachment.size),
      0,
    );
    setCurrentTotalSize(totalSize);
    if ((maxSize && totalSize <= maxSize) || (maxFile && (filtered?.length ?? 0) <= maxFile)) {
      setError(undefined);
    }
    helper.setValue(filtered);
  };

  return (
    <Upload
      multiple={multiple}
      files={meta.value}
      error={meta.touched && meta.error ? meta.error : undefined}
      helperText={
        ((!!meta.error && meta.touched) || error) && (
          <FormHelperText error={!!meta.error || !!error} sx={{ px: 2 }}>
            {meta.error ?? error}
          </FormHelperText>
        )
      }
      maxSize={30145728}
      onDrop={handleDrop}
      onRemove={handleRemoveFile}
      {...other}
    />
  );
}
