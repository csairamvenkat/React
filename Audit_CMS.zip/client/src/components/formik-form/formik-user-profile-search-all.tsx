import { useField } from 'formik';
import { FC } from 'react';
import { UserProfileSearchAll } from '../user-profile-search-input';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly required?: boolean;
  readonly disabled?: boolean;
}

const FormikUserProfileSearchAll: FC<Props> = ({ name, label, disabled, required = false }) => {
  const [field, meta, helper] = useField(name);

  return (
    <UserProfileSearchAll
      label={label}
      name={name}
      setUserSearchValue={value => helper.setValue(value)}
      value={field.value}
      touched={meta.touched}
      error={meta.error}
      onTouchHandler={(touched: boolean) => helper.setTouched(touched)}
      required={required}
      disabled={disabled}
    />
  );
};

export default FormikUserProfileSearchAll;
