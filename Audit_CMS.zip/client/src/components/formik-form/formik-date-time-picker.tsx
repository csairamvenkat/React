import { FC } from 'react';
import { useField } from 'formik';
import { MobileDateTimePicker } from '@mui/x-date-pickers';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly required?: boolean;
}

const FormikDateTimePickerField: FC<Props> = ({ name, label, required = false, ...props }) => {
  const [field, meta, helper] = useField(name);

  return (
    <MobileDateTimePicker
      {...props}
      name={name}
      label={label}
      sx={{ maxWidth: { md: '100%' } }}
      value={new Date(field.value)}
      onChange={(value: any) => {
        helper.setValue(new Date(value));
      }}
      format="dd/MM/yyyy hh:mm a"
      slotProps={{
        textField: {
          variant: 'outlined',
          error: meta.touched && Boolean(meta.error),
          helperText: meta.touched && meta.error,
          onBlur: field.onBlur,
          required: required,
        },
      }}
    />
  );
};

export default FormikDateTimePickerField;
