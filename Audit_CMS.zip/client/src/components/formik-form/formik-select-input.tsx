import { FC } from 'react';
import { useField } from 'formik';
import {
  FormControl,
  FormControlProps,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
} from '@mui/material';

interface Props extends FormControlProps {
  readonly label: string;
  readonly name: string;
  readonly values: { id: string; value: string }[];
}

const FormikSelectInputField: FC<Props> = ({ name, label, values, ...props }) => {
  const [field, meta] = useField(name);

  const handleChange = (event: any) => {
    field.onChange(event);
    if (props.onChange) props.onChange(event);
  };

  return (
    <FormControl error={meta.touched && Boolean(meta.error)} {...props}>
      <InputLabel id={name}>{label}</InputLabel>
      <Select label={label} {...field} onChange={handleChange}>
        {values.length < 1 ? (
          <MenuItem disabled={true}>No values Found</MenuItem>
        ) : (
          values.map((item, index) => (
            <MenuItem value={item.id} key={index}>
              {item.value}
            </MenuItem>
          ))
        )}
      </Select>
      {meta.touched && meta.error && <FormHelperText>{meta.error}</FormHelperText>}
    </FormControl>
  );
};

export default FormikSelectInputField;
