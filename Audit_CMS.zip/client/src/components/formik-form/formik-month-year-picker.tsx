import { DatePicker, DatePickerProps } from '@mui/x-date-pickers';
import { useField } from 'formik';
import { FC } from 'react';

interface Props extends DatePickerProps<Date> {
  readonly label: string;
  readonly name: string;
  readonly required?: boolean;
}

const FormikDMonthPickerField: FC<Props> = ({ name, label, required = false, ...props }) => {
  const [field, meta, helper] = useField(name);

  return (
    <DatePicker
      {...props}
      name={name}
      label={label}
      value={typeof field.value === 'object' ? field.value : new Date(field.value) || null}
      onChange={(value: Date | null) => {
        if (!value) {
          helper.setValue(null);
          return;
        }
        const selectedDate = new Date(value.getFullYear(), value.getMonth(), 1, 12);
        helper.setValue(selectedDate);
      }}
      slotProps={{
        textField: {
          variant: 'outlined',
          error: meta.touched && Boolean(meta.error),
          helperText: meta.touched && meta.error,
          onBlur: field.onBlur,
          required: required,
        },
      }}
    />
  );
};

export default FormikDMonthPickerField;
