import { FC } from 'react';
import { useField } from 'formik';
import { FormControl, FormControlLabel, FormHelperText, Radio, RadioGroup } from '@mui/material';
import { Stack } from '@mui/system';

interface Props {
  readonly label: string;
  readonly name: string;
  readonly options: { label: string; value: unknown }[];
}

const FormikRadioGroup: FC<Props> = ({ name, options }) => {
  const [field, meta] = useField(name);
  return (
    <FormControl component="fieldset" error={meta.touched && Boolean(meta.error)}>
      <RadioGroup {...field} name={name}>
        <Stack direction={'row'} flexWrap={'wrap'}>
          {options.map(option => (
            <FormControlLabel
              value={option.value}
              control={<Radio />}
              label={option.label}
              key={option.label}
            />
          ))}
        </Stack>
      </RadioGroup>
      {meta.touched && meta.error && <FormHelperText>{meta.error}</FormHelperText>}
    </FormControl>
  );
};

export default FormikRadioGroup;
