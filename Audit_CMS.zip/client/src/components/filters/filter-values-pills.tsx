import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Stack, { StackProps } from '@mui/material/Stack';
import { FilterValues } from '@/shared/types';
import ImageIcon from '../image/imageIcon';
import { startCase } from 'lodash';

type Props = StackProps & {
  filters: FilterValues;
  onFilterValueRemove: (key: string, value: unknown) => void;
  onResetFilters: VoidFunction;
  results: number;
};

export default function FilterValuesPills({
  filters,
  onFilterValueRemove,
  onResetFilters,
  results,
  ...other
}: Props) {
  const handleRemoveChip = (key: string, value: unknown) => {
    onFilterValueRemove(key, value);
  };

  return (
    <Stack spacing={1.5} {...other}>
      <Box sx={{ typography: 'body2' }}>
        <strong>{results}</strong>
        <Box component="span" sx={{ color: 'text.secondary', ml: 0.25 }}>
          results found
        </Box>
      </Box>

      <Stack flexGrow={1} spacing={1} direction="row" flexWrap="wrap" alignItems="center">
        {Object.entries(filters).map(filter => {
          if (filter[1]?.values?.length) {
            return (
              <Block label={filter[1].title} key={filter[0]}>
                {filter[1].values.map((value, index) => {
                  return (
                    <Chip
                      key={index}
                      label={value.trasnformDisplayName || filter[0].toLowerCase() == 'status' ? startCase(value.displayName.toLowerCase()) : value.displayName}
                      size="small"
                      onDelete={() => handleRemoveChip(filter[0], value.actualValue)}
                    />
                  );
                })}
              </Block>
            );
          }
        })}

        <Button
          sx={{ border: 1, paddingLeft: 4, paddingRight: 4, paddingTop: 1, paddingBottom: 1 }}
          onClick={() => onResetFilters()}
          startIcon={
            <ImageIcon src="assets/icons/custom-icons/cross2.png" title="close" width="18px" />
          }
        >
          Clear
        </Button>
      </Stack>
    </Stack>
  );
}

type BlockProps = StackProps & {
  label: string;
};

function Block({ label, children, sx, ...other }: BlockProps) {
  return (
    <Stack
      component={Paper}
      variant="outlined"
      spacing={1}
      direction="row"
      sx={{
        p: 1,
        borderRadius: 1,
        overflow: 'hidden',
        borderStyle: 'dashed',
        ...sx,
      }}
      {...other}
    >
      <Box component="span" sx={{ color: 'text.secondary', ml: 0.25 }}>
        {label} {':'}
      </Box>

      <Stack spacing={1} direction="row" flexWrap="wrap">
        {children}
      </Stack>
    </Stack>
  );
}
