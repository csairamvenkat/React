import { WorkflowAllowedActions } from '@/features/contract/types/workflow-allowed-actions';
import { useTranslate } from '@/locales/use-locales';
import { GraphUserResponse } from '@/shared/models';
import { ActionSubmit } from '@/shared/types/approval-workflow';
import { ApprovalSchema } from '@/shared/validation-schema/approval-action.schema';
import LoadingButton from '@mui/lab/LoadingButton';
import { Card, Grid, Stack, Typography } from '@mui/material';
import { Form, Formik } from 'formik';
import _ from 'lodash';
import { useEffect } from 'react';
import * as yup from 'yup';
import AdUserSearchInput from '../ad-user-search-input/ad-user-search-input';
import { FormikCustomTextArea, FormikRadioGroup, FormikUpload } from '../formik-form';

export interface WorkflowActionProp {
  action: WorkflowAllowedActions;
  label?: string;
  value?: string;
}

export const ApprovalActions = ({
  title,
  actions,
  onSubmit,
  onValueChange,
  commentRequired = false,
  showTitle = true,
  showRadioButtons = true,
  hideApprovalHeader = false,
  headerTitle,
  validationSchema,
}: {
  title: string;
  actions: WorkflowActionProp[];
  onSubmit: (action: ActionSubmit) => void;
  onValueChange?: (action: any) => void | undefined;
  commentRequired?: boolean;
  showTitle?: boolean;
  showRadioButtons?: boolean;
  hideApprovalHeader?: boolean;
  headerTitle?: string;
  validationSchema?: yup.ObjectSchema<any>;
}) => {
  const { t } = useTranslate();
  return (
    <Card variant="outlined" sx={{ p: 2, mb: 2 }}>
      <Grid container>
        {!hideApprovalHeader && (
          <Grid item xs={12} sx={{ mb: 2, pb: 1, borderBottom: 1, borderBottomColor: 'grey.300' }}>
            <Typography variant="subtitle1">{headerTitle || t('approval')}</Typography>
          </Grid>
        )}
      </Grid>
      <Grid container direction="column">
        {showTitle && (
          <Grid item>
            <Typography variant="subtitle2" color={theme => `${theme.palette.grey[600]}`}>
              {title}
            </Typography>
          </Grid>
        )}
        <Grid item>
          <Formik
            validateOnBlur
            validateOnChange
            validateOnMount
            initialValues={{
              action: actions.length === 1 ? actions[0].action : undefined,
              comment: '',
              signedCertificateFile: undefined,
              signature: undefined,
              user: undefined,
            }}
            validationSchema={
              validationSchema ??
              (commentRequired || actions.length === 0
                ? ApprovalSchema.shape({
                    action: yup.string().optional(),
                    comment: yup.string().required(),
                  })
                : ApprovalSchema)
            }
            onSubmit={async (values, helpers) => {
              helpers.setTouched({
                action: true,
                comment: true,
                signedCertificateFile: true,
                signature: true,
                user: true,
              });

              const errors = await helpers.validateForm();
              if (Object.keys(errors).length > 0) {
                return;
              }
              //@ts-ignore
              onSubmit(values);
            }}
          >
            {formik => {
              if (onValueChange) {
                useEffect(() => {
                  onValueChange(formik.values.action);
                }, [formik.values.action]);
              }
              return (
                <>
                  <Form>
                    <Grid sx={{ pb: 2 }}>
                      {showRadioButtons && actions.length >= 1 && (
                        <FormikRadioGroup
                          label={'action'}
                          name={'action'}
                          options={actions.map(action => ({
                            label: action.label ?? _.startCase(action.action?.toLowerCase()),
                            value: action.action,
                          }))}
                        />
                      )}
                      {(formik.values.action === WorkflowAllowedActions.SIGNATURE ||
                        formik.values.action ===
                          WorkflowAllowedActions.TAKING_OVER_CERTIFICATE_UPLOAD_SIGNED_COPY ||
                        formik.values.action ===
                          WorkflowAllowedActions.PERFORMANCE_CERTIFICATE_UPLOAD_SIGNED_COPY) && (
                        <Stack paddingTop={2}>
                          <FormikUpload
                            name={
                              formik.values.action ===
                                WorkflowAllowedActions.TAKING_OVER_CERTIFICATE_UPLOAD_SIGNED_COPY ||
                              formik.values.action ===
                                WorkflowAllowedActions.PERFORMANCE_CERTIFICATE_UPLOAD_SIGNED_COPY
                                ? 'signedCertificateFile'
                                : 'signature'
                            }
                            multiple={false}
                          />
                          {formik.values.action === WorkflowAllowedActions.SIGNATURE &&
                            formik.touched.signature &&
                            formik.errors.signature && (
                              <Typography color="error" variant="caption" sx={{ mt: 0.5 }}>
                                {String(formik.errors.signature)}
                              </Typography>
                            )}
                        </Stack>
                      )}
                      {(formik.values.action === WorkflowAllowedActions.REASSIGNED ||
                        formik.values.action === WorkflowAllowedActions.MORE_DETAIL) && (
                        <Stack paddingTop={2}>
                          <AdUserSearchInput
                            required={true}
                            onSelect={function (user: GraphUserResponse | null): void {
                              formik.setFieldValue('user', user?.mail);
                            }}
                          />
                          {formik.touched.user && formik.errors.user && (
                            <Typography color="error" variant="caption" sx={{ mt: 0.5 }}>
                              {String(formik.errors.user)}
                            </Typography>
                          )}
                        </Stack>
                      )}
                      <FormikCustomTextArea
                        sx={{ mt: 2 }}
                        label={t('Comment') + (commentRequired ? ' *' : '')}
                        name={'comment'}
                        fullWidth
                      />
                    </Grid>
                    <Grid sx={{ justifySelf: 'flex-end' }}>
                      <LoadingButton type="submit" variant="contained">
                        Submit
                      </LoadingButton>
                    </Grid>
                  </Form>
                </>
              );
            }}
          </Formik>
        </Grid>
      </Grid>
    </Card>
  );
};
