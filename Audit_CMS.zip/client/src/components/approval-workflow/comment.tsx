import { Comment } from '@/shared/types/approval-workflow';
import { Typography } from '@mui/material';
import { Box } from '@mui/system';

export const WorkflowComment: React.FC<{
  hasComments: boolean;
  isExpanded: boolean;
  comments: Comment[];
}> = ({ hasComments, isExpanded, comments }) => {
  return (
    hasComments &&
    isExpanded && (
      <Box
        sx={{
          mt: 1,
          p: 1.5,
          backgroundColor: theme => theme.palette.grey[50],
          borderRadius: 0.5,
          border: '1px solid',
          borderColor: theme => theme.palette.divider,
        }}
      >
        {comments.map((comment, commentIndex) => (
          <Box
            key={commentIndex}
            sx={{
              mb: commentIndex < comments.length - 1 ? 1 : 0,
              pb: commentIndex < comments.length - 1 ? 1 : 0,
              borderBottom: commentIndex < comments.length - 1 ? '1px solid' : 'none',
              borderColor: 'divider',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                mb: 0.25,
              }}
            ></Box>
            <Typography
              variant="body2"
              sx={{
                color: 'text.primary',
                fontSize: '0.82rem',
                lineHeight: 1.3,
              }}
            >
              {comment.message}
            </Typography>
          </Box>
        ))}
      </Box>
    )
  );
};
