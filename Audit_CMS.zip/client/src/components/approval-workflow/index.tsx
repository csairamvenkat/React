import Iconify from '@/components/iconify';
import { DetailsPageSkeleton } from '@/components/skeleton/detail-page-skeleton';
import { getApproverWorkflow as getCRApproverWorkflow } from '@/features/change-request/services/apperover.service';
import { getApproverWorkflow as getVOApproverWorkflow } from '@/features/variation-order/services/approver.service';

import { AccordionDetails, AccordionSummary, Typography } from '@mui/material';
import { CustomAccordionSummary } from '@/components/styled-components';
import { Box, Stack } from '@mui/system';
import { t } from 'i18next';
import { enqueueSnackbar } from 'notistack';
import { useQuery } from 'react-query';
import { Step } from './step';
import { bolderFont } from '@/theme/typography';
import {
  getPCApproverWorkflow,
  getTOCApproverWorkflow,
} from '@/features/certificate/services/certificate-approver.service';

type ApproverFlowProps = {
  changeReqId?: string;
  variationOrderId?: string;
  takingOverCertificateId?: string;
  performanceCertificateId?: string;
};

const getWorkflowFetcher = (
  changeReqId?: string,
  variationOrderId?: string,
  takingOverCertificateId?: string,
  performanceCertificateId?: string,
) => {
  if (changeReqId) {
    return {
      key: ['change-request-approval-workflow', changeReqId],
      fn: () => getCRApproverWorkflow(changeReqId),
    };
  }
  if (variationOrderId) {
    return {
      key: ['variation-order-approval-workflow', variationOrderId],
      fn: () => getVOApproverWorkflow(variationOrderId),
    };
  }
  if (takingOverCertificateId) {
    return {
      key: ['toc-approval-workflow', takingOverCertificateId],
      fn: () => getTOCApproverWorkflow(takingOverCertificateId),
    };
  }
  if (performanceCertificateId) {
    return {
      key: ['pc-approval-workflow', performanceCertificateId],
      fn: () => getPCApproverWorkflow(performanceCertificateId),
    };
  }

  return { key: [], fn: () => Promise.resolve(null) };
};

export const ApproverFlow = ({
  changeReqId,
  variationOrderId,
  takingOverCertificateId,
  performanceCertificateId,
}: ApproverFlowProps) => {
  const { key, fn } = getWorkflowFetcher(
    changeReqId,
    variationOrderId,
    takingOverCertificateId,
    performanceCertificateId,
  );

  const { data: approversData, isLoading: approvalWorkflowsLoading } = useQuery(key, fn, {
    enabled:
      !!changeReqId ||
      !!variationOrderId ||
      !!takingOverCertificateId ||
      !!performanceCertificateId,
    onError: (error: any) => {
      enqueueSnackbar(
        error?.message && typeof error?.message === 'string'
          ? error?.message
          : t('error_messages.something_went_wrong'),
        { variant: 'error' },
      );
    },
  });

  if (approvalWorkflowsLoading || !approversData || !approversData?.approversList?.length) {
    return null;
  }

  return (
    <CustomAccordionSummary sx={{ p: 1.5, border: 1, borderColor: '#EEF3FA' }} defaultExpanded>
      <AccordionSummary expandIcon={<Iconify icon="quill:chevron-down" />}>
        <Stack sx={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%' }}>
          <Typography variant="h6" fontFamily={bolderFont}>
            {t('label.approval_workflow')}
          </Typography>
        </Stack>
      </AccordionSummary>

      <AccordionDetails sx={{ py: 2 }}>
        <Box sx={{ position: 'relative' }}>
          <Box
            sx={{
              position: 'absolute',
              left: 11,
              top: 12,
              bottom: 12,
              width: 2,
              backgroundColor: theme => theme.palette.divider,
              zIndex: 0,
            }}
          />
          {approvalWorkflowsLoading && <DetailsPageSkeleton />}
          {approversData &&
            (() => {
              const hasAnyDates = approversData.approversList?.some(approver => approver.date);
              return approversData.approversList.map((approver, index) => (
                <Step
                  key={index}
                  approver={approver}
                  index={index}
                  isLast={index === approversData.approversList.length - 1}
                  hasAnyDates={hasAnyDates}
                />
              ));
            })()}
        </Box>
      </AccordionDetails>
    </CustomAccordionSummary>
  );
};
