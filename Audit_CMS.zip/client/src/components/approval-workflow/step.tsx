import Iconify from '@/components/iconify';
import { Typography } from '@mui/material';
import { Box } from '@mui/system';
import { WorkflowComment } from './comment';
import { getStatusBadgeColor } from '@/features/change-request/services/apperover.service';
import { useState } from 'react';
import { Approver } from '@/shared/types/approval-workflow';
import _ from 'lodash';
import { AttachmentsList } from '../attachment-list';

export const Step = ({
  approver,
  index,
  isLast,
  hasAnyDates,
}: {
  index: number;
  isLast: boolean;
  approver: Approver;
  hasAnyDates: boolean;
}) => {
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const handleStepClick = (stepIndex: number) => {
    setExpandedStep(expandedStep === stepIndex ? null : stepIndex);
  };

  const isExpanded = expandedStep === index;
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'not_started':
        return <Iconify icon="mdi:circle-outline" sx={{ color: 'white' }} width={16} />;
      case 'in_progress':
      case 'inprogress':
        return <Iconify icon="mdi:dots-horizontal" sx={{ color: 'white' }} width={16} />;
      case 'approved':
      case 'signed':
        return <Iconify icon="mdi:check" sx={{ color: 'white' }} width={16} />;
      case 'sent_back':
      case 'send_back':
        return <Iconify icon="mdi:arrow-u-left-top" sx={{ color: 'white' }} width={16} />;
      case 'rejected':
        return <Iconify icon="mdi:close" sx={{ color: 'white' }} width={16} />;
      case 'reassigned':
        return <Iconify icon="mdi:account-switch" sx={{ color: 'white' }} width={16} />;
      case 'more_detail':
        return <Iconify icon="mdi:help" sx={{ color: 'white' }} width={16} />;
      case 'reviewd':
      case 'reviewed':
        return <Iconify icon="mdi:eye-check" sx={{ color: 'white' }} width={16} />;
      case 'pending':
        return <Iconify icon="mdi:clock-outline" sx={{ color: 'white' }} width={16} />;
      default:
        return <Iconify icon="mdi:circle" sx={{ color: 'white' }} width={16} />;
    }
  };

  const statusColors = getStatusBadgeColor(approver.status);
  const hasComments = approver.comments && approver.comments.length > 0;
  return (
    <Box
      key={index}
      sx={{
        position: 'relative',
        display: 'flex',
        alignItems: 'flex-start',
        minHeight: 44,
        mb: isLast ? 0 : 0.5,
      }}
    >
      <Box
        sx={{
          width: 24,
          height: 24,
          borderRadius: '50%',
          backgroundColor: (() => {
            const status = approver.status as string;
            switch (status) {
              case 'approved':
              case 'signed':
              case 'reviewed':
                return '#6FD420';
              case 'rejected':
                return '#FF3C14';
              case 'sent_back':
              case 'send_back':
                return '#FF5F5F';
              case 'pending':
                return '#FFC90C';
              case 'waiting':
              case 'in_progress':
              case 'inprogress':
              case 'IN_PROGRESS':
                return '#5154B6';
              case 'reassigned':
                return '#3230BE';
              case 'more_detail':
                return '#FF2261';
              case 'not_started':
                return '#D5D5DD';
              default:
                return statusColors.border;
            }
          })(),
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        {getStatusIcon(approver.status.toLowerCase())}
      </Box>

      <Box
        onClick={hasComments ? () => handleStepClick(index) : undefined}
        sx={{
          flex: 1,
          ml: 1.5,
          cursor: hasComments ? 'pointer' : 'default',
          py: 0.5,
          px: 1,
          pb: 1,
          borderRadius: 0.5,
          transition: 'background-color 0.15s ease',
          borderBottom: isLast ? 'none' : '1px dashed',
          borderBottomColor: 'divider',
          '&:hover': hasComments
            ? {
                backgroundColor: theme => theme.palette.action.hover,
              }
            : {},
          ...(approver.status === 'pending' && {
            backgroundColor: theme => theme.palette.action.hover,
          }),
          ...(['IN_PROGRESS'].includes(approver.status as string) && {
            backgroundColor: (theme: any) => theme.palette.primary.light + '20',
          }),
        }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: 1.5,
          }}
        >
          {hasAnyDates && (
            <Box
              sx={{
                minWidth: 90,
                display: 'flex',
                flexDirection: 'column',
                flexShrink: 0,
              }}
            >
              {approver.date ? (
                <>
                  <Typography
                    variant="body2"
                    sx={{
                      fontWeight: 600,
                      color: 'text.primary',
                      fontSize: '0.875rem',
                      lineHeight: 1.2,
                    }}
                  >
                    {new Date(approver.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </Typography>
                  <Typography
                    variant="body2"
                    sx={{
                      color: 'text.secondary',
                      fontSize: '0.82rem',
                      lineHeight: 2,
                    }}
                  >
                    {new Date(approver.date).toLocaleTimeString('en-US', {
                      hour: 'numeric',
                      minute: '2-digit',
                      hour12: true,
                    })}
                  </Typography>
                </>
              ) : null}
            </Box>
          )}

          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1,
                    mb: 0.25,
                  }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{
                      color: 'text.primary',
                      fontSize: '0.8990rem',
                      lineHeight: 1.2,
                    }}
                  >
                    {approver.title}
                  </Typography>
                </Box>

                <Typography
                  variant="body2"
                  sx={{
                    color: 'text.secondary',
                    fontSize: '0.8125rem',
                    fontWeight: 500,
                    mb: 0.25,
                  }}
                >
                  {approver.actionBy
                    ? `${approver.actionBy.firstName} ${approver.actionBy.lastName}`
                    : approver.approvers
                        ?.map(details => `${details.firstName} ${details.lastName}`)
                        .join(',  ')}
                </Typography>
              </Box>

              {hasComments && (
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'primary.main',
                    ml: 1,
                  }}
                >
                  <Iconify
                    icon={isExpanded ? 'mdi:chevron-double-up' : 'mdi:chevron-double-down'}
                    width={20}
                    sx={{
                      fontWeight: 'bold',
                      animation: 'bounce 2s infinite',
                      '@keyframes bounce': {
                        '0%, 20%, 50%, 80%, 100%': {
                          transform: 'translateY(0)',
                        },
                        '40%': {
                          transform: 'translateY(-3px)',
                        },
                        '60%': {
                          transform: 'translateY(-1.5px)',
                        },
                      },
                    }}
                  />
                </Box>
              )}
            </Box>
          </Box>
        </Box>

        <Box sx={{ ml: hasAnyDates ? 0 : 0 }}>
          {isExpanded && approver.attachments.length > 0 && (
            <Box sx={{ mb: 1 }}>
              <AttachmentsList attachments={approver.attachments} />
            </Box>
          )}
          <WorkflowComment
            comments={approver.comments}
            hasComments={hasComments}
            isExpanded={isExpanded}
          />
        </Box>
      </Box>
    </Box>
  );
};
