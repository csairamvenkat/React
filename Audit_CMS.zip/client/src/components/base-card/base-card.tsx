import { useBoolean } from '@/hooks/use-boolean';
import { useTranslate } from '@/locales/use-locales';
import LoadingButton from '@mui/lab/LoadingButton';
import {
  Card,
  CardContent,
  CardActions,
  IconButton,
  Tooltip,
  Menu,
  MenuItem,
  ListItemText,
} from '@mui/material';
import { ReactNode, useState, MouseEvent } from 'react';
import { ConfirmDialog } from '@/components/custom-dialog';
import MoreVertIcon from '@mui/icons-material/MoreVert';

interface BaseCardProps {
  children: ReactNode;
  onClick?: () => void;
  navigateToView?: () => void;
  navigateToEdit?: () => void;
  onDeleteRow?: () => void;
  isDeleteInProgress?: boolean;
  showActions?: boolean;
  openDeleteDialog?: boolean;
  editLabel?: string;
}

export default function BaseCard({
  children,
  onClick,
  navigateToView,
  navigateToEdit,
  onDeleteRow,
  isDeleteInProgress = false,
  showActions = true,
  editLabel,
  openDeleteDialog = true,
}: BaseCardProps) {
  const { t } = useTranslate();
  const confirm = useBoolean();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleMenuClick = (e: MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    setAnchorEl(e.currentTarget);
  };

  const handleMenuClose = (e?: MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setAnchorEl(null);
  };

  const handleViewClick = (e: MouseEvent) => {
    e.stopPropagation();
    handleMenuClose();
    if (navigateToView) {
      navigateToView();
    }
  };

  const handleEditClick = (e: MouseEvent) => {
    e.stopPropagation();
    handleMenuClose();
    if (navigateToEdit) {
      navigateToEdit();
    }
  };

  const handleDeleteClick = (e: MouseEvent) => {
    e.stopPropagation();
    handleMenuClose();
    if (openDeleteDialog) {
      confirm.onTrue();
    } else if (onDeleteRow) {
      onDeleteRow();
    }
  };

  return (
    <>
      <Card
        sx={{
          width: '100%',
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 2,
          position: 'relative',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: theme =>
              `0 8px 25px -5px ${theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.3)'}, 0 8px 10px -6px ${theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.3)'}`,
            borderColor: 'primary.main',
            borderWidth: '1px',
          },
          cursor: onClick || navigateToView ? 'pointer' : 'default',
        }}
        onClick={onClick || navigateToView}
      >
        {showActions && (navigateToView || navigateToEdit || onDeleteRow) && (
          <CardActions
            sx={{
              position: { xs: 'absolute', md: 'absolute' },
              top: { xs: 15, md: 28 },
              right: { xs: 5, md: 8 },
              justifyContent: 'flex-end',
              flexDirection: 'row',
              alignItems: 'center',
              minWidth: 'auto',
              zIndex: 1,
            }}
          >
            <Tooltip title={t('Actions')} placement="top" arrow>
              <IconButton size="small" onClick={handleMenuClick} disabled={isDeleteInProgress}>
                <MoreVertIcon sx={{ fontSize: '22px' }} />
              </IconButton>
            </Tooltip>

            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={() => handleMenuClose()}
              onClick={e => e.stopPropagation()}
              transformOrigin={{ horizontal: 'left', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
              PaperProps={{
                sx: {
                  mt: 0.5,
                  minWidth: 120,
                },
              }}
            >
              {navigateToView && (
                <MenuItem
                  onClick={handleViewClick}
                  sx={{
                    minHeight: 0,
                  }}
                >
                  <ListItemText
                    primary={t('tool_tip.more_detail')}
                    primaryTypographyProps={{
                      fontSize: '0.875rem',
                      minHeight: 0,
                    }}
                  />
                </MenuItem>
              )}

              {navigateToEdit && (
                <MenuItem
                  onClick={handleEditClick}
                  sx={{
                    minHeight: 0,
                  }}
                >
                  <ListItemText
                    primary={editLabel ? editLabel : t('tool_tip.edit')}
                    primaryTypographyProps={{
                      fontSize: '0.875rem',
                      minHeight: 0,
                    }}
                  />
                </MenuItem>
              )}

              {onDeleteRow && (
                <MenuItem
                  onClick={handleDeleteClick}
                  disabled={isDeleteInProgress}
                  sx={{
                    minHeight: 0,
                  }}
                >
                  <ListItemText
                    primary={t('tool_tip.delete')}
                    primaryTypographyProps={{
                      fontSize: '0.875rem',
                      minHeight: 0,
                    }}
                  />
                </MenuItem>
              )}
            </Menu>
          </CardActions>
        )}

        <CardContent sx={{ flexGrow: 1, p: { xs: 2, md: 2.5 } }}>{children}</CardContent>
      </Card>

      {onDeleteRow && (
        <ConfirmDialog
          open={confirm.value}
          onClose={confirm.onFalse}
          title={t('delete')}
          content={t('are_you_sure_want_to_delete')}
          action={
            <LoadingButton
              variant="contained"
              onClick={event => {
                if (onDeleteRow) {
                  onDeleteRow();
                }
                confirm.onFalse();
              }}
              loading={isDeleteInProgress}
            >
              {t('delete')}
            </LoadingButton>
          }
        />
      )}
    </>
  );
}
