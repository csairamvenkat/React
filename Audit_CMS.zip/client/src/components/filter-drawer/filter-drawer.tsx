import { memo, useCallback, useState, type ReactNode } from 'react';
import { Box, Button, Divider, Drawer, IconButton, Stack, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import {
  activeCountSx,
  advanceFilterButtonSx,
  drawerApplyButtonSx,
  drawerBodySx,
  drawerFooterSx,
  drawerHeaderSx,
  drawerPaperSx,
  drawerRemoveButtonSx,
} from './filter-drawer.styles';

export interface FilterDrawerProps {

  activeCount: number;

  children: ReactNode;

  onOpen?: () => void;

  onApply: () => void;

  onRemove: () => void;
}

function FilterDrawer({ activeCount, children, onOpen, onApply, onRemove }: FilterDrawerProps) {
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);
  const handleOpen = useCallback(() => {
    onOpen?.();
    setOpen(true);
  }, [onOpen]);
  const handleApply = useCallback(() => {
    onApply();
    setOpen(false);
  }, [onApply]);
  const handleRemove = useCallback(() => {
    onRemove();
    setOpen(false);
  }, [onRemove]);

  return (
    <>
      <Button
        variant="outlined"
        startIcon={<TuneOutlinedIcon />}
        sx={advanceFilterButtonSx}
        onClick={handleOpen}
      >
        Advance Filter
        {activeCount > 0 && (
          <Box component="span" sx={activeCountSx}>
            {activeCount}
          </Box>
        )}
      </Button>

      <Drawer anchor="right" open={open} onClose={close} PaperProps={{ sx: drawerPaperSx }}>
        <Box sx={drawerHeaderSx}>
          <Typography variant="h6" fontWeight={700}>
            Advance Filter
          </Typography>
          <IconButton size="small" onClick={close}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </Box>
        <Divider />

        <Stack spacing={2.5} sx={drawerBodySx}>
          {children}
        </Stack>

        <Box sx={drawerFooterSx}>
          <Button sx={drawerRemoveButtonSx} onClick={handleRemove}>
            Remove Filters
          </Button>
          <Button variant="contained" sx={drawerApplyButtonSx} onClick={handleApply}>
            Apply Filters
          </Button>
        </Box>
      </Drawer>
    </>
  );
}

export default memo(FilterDrawer);
