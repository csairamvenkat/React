import type { SxProps, Theme } from '@mui/material';
import { alpha } from '@mui/material';
import { COLORS } from '@/theme/colors';

export const advanceFilterButtonSx: SxProps<Theme> = {
  textTransform: 'none',
  fontWeight: 700,
  borderRadius: 2,
  px: 2.5,
  py: 1.05,
  whiteSpace: 'nowrap',
  bgcolor: COLORS.white,
  borderColor: 'divider',
  color: COLORS.grey800,
  '&:hover': { bgcolor: COLORS.grey50, borderColor: COLORS.grey300 },
};

export const activeCountSx: SxProps<Theme> = {
  ml: 1,
  minWidth: 20,
  height: 20,
  px: 0.75,
  borderRadius: '99px',
  bgcolor: alpha(COLORS.primary, 0.12),
  color: COLORS.primary,
  fontSize: '0.80rem',
  fontWeight: 700,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
};

export const drawerPaperSx: SxProps<Theme> = {
  width: { xs: '100%', sm: 400 },
  display: 'flex',
  flexDirection: 'column',
};

export const drawerHeaderSx: SxProps<Theme> = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  px: 3,
  py: 2.5,
};

export const drawerBodySx: SxProps<Theme> = {
  flex: 1,
  overflowY: 'auto',
  px: 3,
  py: 2.5,
};

export const drawerFieldSx: SxProps<Theme> = {
  width: '100%',
  '& .MuiOutlinedInput-root': { borderRadius: 2 },
};

export const drawerDateFieldSx: SxProps<Theme> = {
  width: '100%',
  '& .MuiOutlinedInput-root': { borderRadius: 2 },
};

export const drawerFooterSx: SxProps<Theme> = {
  display: 'flex',
  gap: 1.5,
  px: 3,
  py: 2.5,
  borderTop: '1px solid',
  borderColor: 'divider',
  '& > button': { flex: 1 },
};

export const drawerRemoveButtonSx: SxProps<Theme> = {
  textTransform: 'none',
  fontWeight: 600,
  color: COLORS.primary,
  borderRadius: 2,
  py: 1.05,
  '&:hover': { bgcolor: alpha(COLORS.primary, 0.06) },
};

export const drawerApplyButtonSx: SxProps<Theme> = {
  textTransform: 'none',
  fontWeight: 700,
  borderRadius: 2,
  py: 1.05,
  boxShadow: 'none',
  '&:hover': { boxShadow: 'none', bgcolor: COLORS.primaryDark },
};
