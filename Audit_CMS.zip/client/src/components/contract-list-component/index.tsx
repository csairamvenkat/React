import { contractPaths } from '@/features/contract/utils/navigation';
import { useTranslate } from '@/locales/use-locales';
import { ProjectContractItem } from '@/shared/models/project-response.model';
import {
  TableContainer,
  Table,
  TableBody,
  Chip,
  TableCell,
  TableRow,
  Link,
  Box,
  alpha,
  Typography,
  IconButton,
  Dialog,
  DialogContent,
  DialogTitle,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import { useNavigate } from 'react-router';
import Scrollbar from '../scrollbar';
import { useTable, TableHeadCustom, TableNoData, TablePaginationCustom } from '../table';
import { SYSTEM_STATUS_COLOR_MAPPING } from '@/shared/mapping';
import _, { startCase } from 'lodash';
import { paths, ReplaceUrlVariable } from '@/routes/paths';
import Iconify from '../iconify';
import { Stack, useTheme } from '@mui/system';
import { useEffect, useState } from 'react';
import { statusLabelParse } from '@/features/contract/services/contract.service';

export const ContractList = ({ contracts }: { contracts: ProjectContractItem[] }) => {
  const { t } = useTranslate();
  const TABLE_HEAD = [
    { id: 'referenceNo', label: t('label.reference_number') },
    { id: 'contractType', label: t('label.contract_type') },
    { id: 'expenseType', label: t('label.expense_type') },
    { id: 'status', label: t('label.status') },
    { id: 'totalAmount', label: t('label.total_amount') },
    { id: 'totalPayed', label: t('total_amount_certified') },
    { id: 'Consumed', label: t('label.amount_consumed') },
    { id: 'TOC', label: t('label.TOC') },
    { id: 'POC', label: t('label.POC') },
  ];

  const navigate = useNavigate();
  const navigateToView = (id: string) => {
    navigate(contractPaths.detail(id));
  };
  const [filterValue, setFilterValue] = useState('all');
  const [filteredContracts, setFilteredContracts] = useState(contracts);
  const [showCertificates, setShowCertificates] = useState<{
    isVisible: boolean;
    certificateType: string;
    selectedContract: ProjectContractItem | undefined;
  }>({ isVisible: false, certificateType: '', selectedContract: undefined });
  const notFound = !filteredContracts.length;

  useEffect(() => {
    setFilteredContracts(contracts);
  }, [contracts]);
  const theme = useTheme();
  const table = useTable({ defaultDense: true, defaultRowsPerPage: 25 });
  useEffect(() => {
    setFilteredContracts(
      contracts
        ?.filter(item => {
          if (filterValue == 'all') return item;
          else if (item.status == 'IN_PROGRESS') {
            return item;
          }
        })
        .filter(item => item),
    );
  }, [filterValue]);

  return (
    <>
      {contracts?.length > 0 && (
        <Box sx={{ justifyContent: 'flex-end', width: '100%', display: 'flex', mb: 3 }}>
          <ToggleButtonGroup
            value={filterValue}
            exclusive
            onChange={(_, newType) => {
              if (newType !== null) {
                table.setPage(0);
                setFilterValue(newType);
              }
            }}
            size="small"
            sx={{
              p: 0.5,
              gap: 0.5,
              borderRadius: 1,
              backgroundColor: theme => alpha(theme.palette.grey[500], 0.08),
              '& .MuiToggleButtonGroup-grouped': {
                m: 0,
                border: 'none',
                borderRadius: 1,
                transition: 'all 0.2s',
                '&.Mui-selected': {
                  backgroundColor: 'background.paper',
                  boxShadow: '0 2px 8px 0 rgba(0,0,0,0.08)',
                  color: 'text.primary',
                  '&:hover': {
                    backgroundColor: 'background.paper',
                  },
                },
                '&:not(.Mui-selected):hover': {
                  backgroundColor: 'action.hover',
                },
              },
              '& .MuiToggleButton-root': {
                px: 2,
                py: 0.75,
                minWidth: 72,
                fontSize: '0.875rem',
                fontWeight: 600,
                color: 'text.secondary',
                textTransform: 'none',
              },
            }}
          >
            <ToggleButton value="all">{t('all')}</ToggleButton>
            <ToggleButton value="active">{t('active')}</ToggleButton>
          </ToggleButtonGroup>
        </Box>
      )}
      {filteredContracts.length == 0 ? (
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            py: 6,
            width: '100%',
            px: 3,
          }}
        >
          <Box
            sx={{
              borderRadius: '50%',
              backgroundColor: alpha(theme.palette.grey[500], 0.12),
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 3,
            }}
          >
            <Iconify
              icon="mdi:file-document-edit-outline"
              width={28}
              color={theme.palette.grey[600]}
            />
          </Box>

          <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
            {t('empty_state_messages.no_contracts_available')}
          </Typography>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 3, textAlign: 'center' }}>
            {t('empty_state_messages.no_contracts_created')}
          </Typography>
        </Box>
      ) : (
        <>
          <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
            <Scrollbar>
              <Table size={table.dense ? 'small' : 'medium'} sx={{ minWidth: 960 }}>
                <TableHeadCustom
                  sx={{ th: { textAlign: 'center' } }}
                  order={table.order}
                  headLabel={TABLE_HEAD}
                  numSelected={table.selected.length}
                  rowCount={filteredContracts.length || 0}
                  onSort={table.onSort}
                />

                <TableBody>
                  {filteredContracts
                    .slice(
                      table.page * table.rowsPerPage,
                      table.page * table.rowsPerPage + table.rowsPerPage,
                    )
                    .map(row => (
                      <TableRow
                        hover
                        sx={{
                          backgroundColor:
                            row.consumbedAmount >= 90 ? 'var(--bs-danger-bg-subtle)' : 'inherit',
                          '&:hover': {
                            backgroundColor:
                              row.consumbedAmount >= 90
                                ? 'var(--bs-danger-border-subtle)!important'
                                : 'rgba(0, 0, 0, 0.04)',
                            cursor: 'pointer',
                          },
                        }}
                      >
                        <TableCell
                          align="center"
                          sx={{ cursor: 'pointer' }}
                          onClick={() => {
                            navigateToView(row.id.toString());
                          }}
                        >
                          {row.referenceNumber ?? '-'}
                        </TableCell>
                        <TableCell align="center">{row.contractType ?? '-'}</TableCell>
                        <TableCell align="center">{row.expenseType ?? '-'}</TableCell>
                        <TableCell align="center">
                          {' '}
                          <Chip
                            label={statusLabelParse(row.status)}
                            color={
                              (SYSTEM_STATUS_COLOR_MAPPING[row.status ?? 'DEFAULT'] ??
                                'primary') as any
                            }
                            size="small"
                            sx={{
                              fontWeight: 500,
                              fontSize: '0.82rem',
                              height: '24px',
                            }}
                          />
                        </TableCell>
                        <TableCell align="center">
                          {row.totalAmount
                            ? new Intl.NumberFormat('en-US', {
                                style: 'currency',
                                currency: row.currency,
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 2,
                              }).format(row.totalAmount)
                            : '-'}
                        </TableCell>
                        <TableCell align="center">
                          {row.totalPayments
                            ? new Intl.NumberFormat('en-US', {
                                style: 'currency',
                                currency: row.currency,
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 2,
                              }).format(row.totalPayments)
                            : '-'}
                        </TableCell>
                        <TableCell align="center">
                          {row.consumbedAmount ? `${row.consumbedAmount}%` : '-'}
                        </TableCell>

                        <TableCell align="center">
                          {row.TOCs ? (
                            <Link>
                              <Box
                                onClick={() => {
                                  setShowCertificates({
                                    isVisible: true,
                                    certificateType: 'TOC',
                                    selectedContract: row,
                                  });
                                }}
                              >
                                {t('messages.click_here_for_certificates')}
                              </Box>
                            </Link>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell align="center">
                          {row.POCs ? (
                            <Link>
                              <Box
                                onClick={() => {
                                  setShowCertificates({
                                    isVisible: true,
                                    certificateType: 'POC',
                                    selectedContract: row,
                                  });
                                }}
                              >
                                {t('messages.click_here_for_certificates')}
                              </Box>
                            </Link>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  <TableNoData notFound={notFound} />
                </TableBody>
              </Table>
            </Scrollbar>
          </TableContainer>
          {filteredContracts.length > 10 && (
            <Box sx={{ justifyItems: 'self-end', width: '100%' }}>
              <TablePaginationCustom
                count={contracts?.length || 0}
                page={table.page}
                rowsPerPage={table.rowsPerPage}
                onPageChange={table.onChangePage}
                onRowsPerPageChange={table.onChangeRowsPerPage}
                dense={table.dense}
              />
            </Box>
          )}
          <Dialog
            fullWidth
            maxWidth="sm"
            open={showCertificates.isVisible}
            onClose={() => {
              setShowCertificates({
                isVisible: false,
                certificateType: '',
                selectedContract: undefined,
              });
            }}
          >
            <DialogTitle>
              <Stack direction="row" alignItems="center" justifyContent="space-between">
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  {t('certificates')}
                </Typography>
                <IconButton
                  onClick={() => {
                    setShowCertificates({
                      isVisible: false,
                      certificateType: '',
                      selectedContract: undefined,
                    });
                  }}
                  size="small"
                >
                  <span style={{ fontSize: '18px' }}>×</span>
                </IconButton>
              </Stack>
            </DialogTitle>
            <DialogContent sx={{ p: 2 }}>
              <Stack spacing={1}>
                {showCertificates.selectedContract &&
                  showCertificates.selectedContract[
                    showCertificates.certificateType == 'TOC' ? 'TOCs' : 'POCs'
                  ]?.map(certificate => {
                    const link =
                      showCertificates.certificateType == 'TOC'
                        ? ReplaceUrlVariable(
                            paths.takingOverCertificate.root + '/detail/:takingOverCertificateId',
                            {
                              takingOverCertificateId: certificate.id,
                            },
                          )
                        : ReplaceUrlVariable(
                            paths.performanceCertificate.root + '/detail/:performanceCertificateId',
                            {
                              performanceCertificateId: certificate.id,
                            },
                          );

                    return (
                      <Link key={certificate.id} href={link} underline="none">
                        <Box
                          sx={{
                            p: 2,
                            borderRadius: 1,
                            bgcolor: theme => alpha(theme.palette.grey[500], 0.08),
                            border: theme => `1px dashed ${theme.palette.divider}`,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            '&:hover': {
                              bgcolor: theme => alpha(theme.palette.grey[500], 0.16),
                            },
                          }}
                        >
                          <Typography variant="subtitle2" sx={{ color: 'text.primary' }}>
                            {certificate.referenceNumber}
                          </Typography>

                          <Chip
                            label={startCase(certificate.status?.toLowerCase())}
                            color={
                              (SYSTEM_STATUS_COLOR_MAPPING[certificate.status ?? 'DEFAULT'] ??
                                'primary') as any
                            }
                            size="small"
                            sx={{ height: 24, fontSize: '0.82rem', fontWeight: 600 }}
                          />
                        </Box>
                      </Link>
                    );
                  })}
              </Stack>
            </DialogContent>
          </Dialog>
        </>
      )}
    </>
  );
};
