import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Tooltip from '@mui/material/Tooltip';
import { Theme, SxProps } from '@mui/material/styles';

import DownloadButton from './download-button';
import { fileThumb, fileFormat } from './utils';
import { Attachment } from '@/shared/models';
import { useEffect, useState } from 'react';
import { getFileContent } from '@/shared/services';

type FileIconProps = {
  file: Attachment;
  tooltip?: boolean;
  imageView?: boolean;
  onDownload?: VoidFunction;
  sx?: SxProps<Theme>;
  imgSx?: SxProps<Theme>;
};

export default function FileThumbnail({
  file,
  tooltip,
  imageView,
  onDownload,
  sx,
  imgSx,
}: FileIconProps) {
  const {
    attachment_name: name,
    attachment_name: path,
    file_base64: preview,
    file_id: fileId,
  } = file;

  const format = fileFormat(path || preview);

  const [imageSrc, setImageSrc] = useState<string | null>(null);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        if (fileId) {
          const blob = await getFileContent(fileId);
          const url = URL.createObjectURL(blob);
          setImageSrc(url);
        }
      } catch (error) {
        console.error('Error fetching image:', error);
      }
    };

    if (format === 'image' && imageView && fileId) {
      fetchImage();
    } else if (format === 'image' && imageView) {
      setImageSrc(preview);
    } else {
      setImageSrc(fileThumb(format));
    }
  }, [preview, format, imageView]);

  const renderContent =
    format === 'image' && imageView ? (
      <Box
        component="img"
        src={imageSrc || ''}
        sx={{
          width: 1,
          height: 1,
          flexShrink: 0,
          objectFit: 'cover',
          ...imgSx,
        }}
      />
    ) : (
      <Box
        component="img"
        src={fileThumb(format)}
        sx={{
          width: 32,
          height: 32,
          flexShrink: 0,
          ...sx,
        }}
      />
    );

  if (tooltip) {
    return (
      <Tooltip title={name}>
        <Stack
          flexShrink={0}
          component="span"
          alignItems="center"
          justifyContent="center"
          sx={{
            width: 'fit-content',
            height: 'inherit',
          }}
        >
          {renderContent}
          {onDownload && <DownloadButton onDownload={onDownload} />}
        </Stack>
      </Tooltip>
    );
  }

  return (
    <>
      {renderContent}
      {onDownload && <DownloadButton onDownload={onDownload} />}
    </>
  );
}
