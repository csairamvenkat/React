module.exports = {
  root: true,
  env: { browser: true, es2020: true },
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:react-hooks/recommended',
    'plugin:react/recommended'
  ],
  ignorePatterns: ['dist', '.eslintrc.cjs'],
  parser: '@typescript-eslint/parser',
  plugins: ['react-refresh'],
  rules: {
    'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],

    // Spacing and blank line rules for logical sections
    'padding-line-between-statements': [
      'error',
      // Require blank line after imports
      { blankLine: 'always', prev: 'import', next: '*' },
      { blankLine: 'never', prev: 'import', next: 'import' },

      // Require blank line before/after function declarations
      { blankLine: 'always', prev: '*', next: 'function' },
      { blankLine: 'always', prev: 'function', next: '*' },

      // React specific: blank line before/after export default
      { blankLine: 'always', prev: '*', next: 'export' },
      { blankLine: 'always', prev: 'export', next: '*' },

      // Require blank line before return statements
      { blankLine: 'always', prev: '*', next: 'return' },

      // Require blank line after variable declarations
      { blankLine: 'always', prev: ['const', 'let', 'var'], next: '*' },
      { blankLine: 'never', prev: ['const', 'let', 'var'], next: ['const', 'let', 'var'] },

      // Require blank line before/after try-catch blocks
      { blankLine: 'always', prev: '*', next: 'try' },
      { blankLine: 'always', prev: 'try', next: '*' },

      // Require blank line before/after if statements
      { blankLine: 'always', prev: '*', next: 'if' },
      { blankLine: 'always', prev: 'if', next: '*' },

      // Require blank line before/after for/while loops
      { blankLine: 'always', prev: '*', next: ['for', 'while'] },
      { blankLine: 'always', prev: ['for', 'while'], next: '*' },

      // React specific: blank line before/after export default
      { blankLine: 'always', prev: '*', next: 'export' },
      { blankLine: 'always', prev: 'export', next: '*' }
    ],

    // Enforce blank lines between class members (for class components)
    '@typescript-eslint/lines-between-class-members': [
      'error',
      'always',
      { exceptAfterSingleLine: false }
    ],

    // Enforce blank lines around comments
    'lines-around-comment': [
      'error',
      {
        beforeBlockComment: true,
        afterBlockComment: false,
        beforeLineComment: true,
        afterLineComment: false,
        allowBlockStart: true,
        allowBlockEnd: true,
        allowObjectStart: true,
        allowObjectEnd: true,
        allowArrayStart: true,
        allowArrayEnd: true
      }
    ],

    // Enforce consistent spacing inside blocks
    'block-spacing': ['error', 'always'],

    // Enforce spacing around operators
    'space-infix-ops': 'error',

    // Enforce spacing around keywords
    'keyword-spacing': ['error', { before: true, after: true }],

    // Enforce spacing around commas
    'comma-spacing': ['error', { before: false, after: true }],

    // Object and array spacing
    'object-curly-spacing': ['error', 'always'],
    'array-bracket-spacing': ['error', 'never'],
  },
};
