# CMS Client

React 18 + TypeScript + Vite front end for the Case Management System.

## Quick start

```bash
npm install
npm run dev        # http://localhost:4200/CMS/
```

The dev server runs on port **4200** (set in `vite.config.ts`; the API's config expects the client
there for redirects). The app is served under the **`/CMS/`** base path in every mode — set both in
`vite.config.ts` and on the `dev`/`build` scripts — and route paths are built from
`import.meta.env.BASE_URL`, so hitting `/` will not load it.

## Configuration

A `.env` file at the project root supplies three Vite variables, read once in
[`src/config/app.config.ts`](src/config/app.config.ts):

```sh
VITE_HTTP_PROTOCOL=      # http | https
VITE_BASE_URL=           # API host, e.g. localhost:5600/api
VITE_DEFAULT_LANG=       # e.g. en
```

Import config through `AppConfig` rather than touching `import.meta.env` elsewhere.

## Stack

| Concern | Choice |
| --- | --- |
| Build | Vite 7 |
| UI | MUI 5 — both `sx` and `@mui/styles` `makeStyles` are in use (see Conventions) |
| Server state | `react-query` 3 |
| Routing | `react-router-dom` 6 |
| HTTP | `axios`, wrapped in a shared http service |
| Auth | `@azure/msal-browser` |
| Charts | ApexCharts |

## Structure

```
src/
├── features/          # feature-first application code
│   ├── case-management/
│   ├── analytics/
│   ├── dashboard/
│   ├── landing/
│   └── navex-integration/
├── components/        # shared, app-agnostic component library
├── layouts/           # dashboard shell, header, nav
├── routes/            # route table, paths, tier guards
├── core/              # auth, hooks, cross-cutting services
├── shared/            # types, utilities, http service
├── theme/             # MUI theme, palette, COLORS
├── hooks/             # generic hooks
└── locales/           # i18n resources
```

A feature owns its own slice and follows a consistent shape:

```
features/case-management/
├── views/         # route-level screens
├── components/    # feature components, incl. panels/ per lifecycle stage
├── services/      # API calls
├── models/        # domain types, enums, constants
├── constants/
├── utils/
└── routes/
```

Larger components are split further into `components/`, `hooks/`, `constants/`, `types/`,
`utils/` and `styles/` subfolders — `features/case-management/components/panels/triage` and
`.../panels/scope` are the reference examples.

### Features

- **case-management** — the bulk of the app. Case list with filters and search, case detail with
  the lifecycle stage sidebar (one panel per stage: triage, scope, procedures, perform, results,
  remediation, recommendations, reporting, fraud risk, evidence, access), My Tasks, work
  management, action management, task review.
- **landing** — entry screen, full or limited depending on the user's access tier.
- **analytics** / **dashboard** — KPI and reporting screens. Currently driven by mock data;
  backend wiring is deferred.
- **navex-integration** — NAVEX (EthicsPoint) whistleblower intake: import screen, case preview
  dialog, sync history. Also mock-backed today — `services/navex.service.ts` serves fixtures, no
  live Navex calls are made.

### Routing

Paths are centralised in [`src/routes/paths.ts`](src/routes/paths.ts) and always derived from
`AppConfig.baseUrl`; never hard-code a URL string. `ReplaceUrlVariable` fills `:id`-style
parameters. `RequireTier` guards routes by access tier.

## Conventions

- **Styling.** New and refactored components use `makeStyles`/`useStyles` from `@mui/styles`, with
  the hook in a sibling `styles/<component>.styles.ts` file. Older components still use `sx`;
  follow whatever the file you are editing already does rather than mixing both in one component.
- **Colours** come from `@/theme/colors` (`COLORS`) or the MUI palette — no literal hex values in
  components.
- **Path aliases.** Not a single `@/*` wildcard — [`vite.config.ts`](vite.config.ts) declares one
  alias per top-level folder (`@/components`, `@/features`, `@/shared`, `@/theme`, `@/core`,
  `@/hooks`, `@/layouts`, `@/routes`, `@/config`, `@/locales`, …). A new top-level folder needs an
  entry adding there before it can be imported that way.
- **Dialogs** are lazy-loaded (`lazy` + `Suspense`) and mounted only while open; heavy list rows
  are `memo`-ised and feature-hook callbacks wrapped in `useCallback`.
- **Shared before local.** Check `src/components` (stat-card, status-chip, list-card, buttons and
  friends) before writing a new primitive.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Vite dev server on `/CMS/` (`--force` clears the dep cache). |
| `npm run build` | Production build (`--mode prod`). |
| `npm run preview` | Serve the built output locally. |
| `npm run lint` | ESLint over `.ts` / `.tsx`. |
| `npm run format` | Prettier over `src`. |

`npm run lint` currently reports a large number of pre-existing errors across the codebase
(chiefly `react/react-in-jsx-scope` and `padding-line-between-statements`). When touching a file,
judge your change by whether it adds *new* categories of error rather than by the total count.
