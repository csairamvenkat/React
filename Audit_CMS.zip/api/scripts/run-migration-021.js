const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const cfg = require(path.resolve(__dirname, '../src/config.dev.json')).database;
const sql = fs.readFileSync(
  path.resolve(__dirname, '../../database/migrations/021_investigation_required_no_default.sql'),
  'utf8',
);

(async () => {
  const client = new Client({
    host: cfg.host,
    port: cfg.port,
    user: cfg.username,
    password: cfg.password,
    database: cfg.db,
    ssl: cfg.enableSSL ? { rejectUnauthorized: false } : false,
  });
  await client.connect();
  try {
    await client.query(`SET search_path TO "${cfg.schema}"`);
    await client.query(sql);
    console.log(`✅ Migration 021 applied to ${cfg.host}/${cfg.db} (schema ${cfg.schema})`);

    const def = await client.query(
      `SELECT column_default FROM information_schema.columns
       WHERE table_schema = $1 AND table_name = 'cases'
         AND column_name = 'investigation_required'`,
      [cfg.schema],
    );
    console.log('investigation_required default:', def.rows[0]?.column_default ?? 'none');

    const counts = await client.query(
      `SELECT investigation_required AS value, COUNT(*)::int AS cases
       FROM cases
       WHERE deleted = FALSE AND current_stage = 'Case Created'
       GROUP BY investigation_required
       ORDER BY 1 NULLS FIRST`,
    );
    console.log('cases still in triage by pathway value:', counts.rows);
  } finally {
    await client.end();
  }
})().catch((e) => {
  console.error('❌ Migration failed:', e.message);
  process.exit(1);
});
