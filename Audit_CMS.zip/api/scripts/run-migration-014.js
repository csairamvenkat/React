const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const cfg = require(path.resolve(__dirname, '../src/config.dev.json')).database;
const sql = fs.readFileSync(
  path.resolve(__dirname, '../../database/migrations/014_add_analytics_fields.sql'),
  'utf8',
);

(async () => {
  const client = new Client({
    host: cfg.host,
    port: cfg.port,
    user: cfg.username,
    password: cfg.password,
    database: cfg.db,
    ssl: cfg.enableSSL ? { rejectUnauthorized: false } : false,
  });
  await client.connect();
  try {
    await client.query(`SET search_path TO "${cfg.schema}"`);
    await client.query(sql);
    console.log(`✅ Migration 014 applied to ${cfg.host}/${cfg.db} (schema ${cfg.schema})`);

    const check = await client.query(
      `SELECT column_name FROM information_schema.columns
       WHERE table_schema = $1 AND table_name = 'cases'
         AND column_name IN ('region','country','business_pillar','intake_channel','is_anonymous','closed_on')
       ORDER BY column_name`,
      [cfg.schema],
    );
    console.log('cases now has:', check.rows.map((r) => r.column_name).join(', '));

    const cpe = await client.query(
      `SELECT to_regclass($1) AS tbl`,
      [`${cfg.schema}.cpe_hours_logs`],
    );
    console.log('cpe_hours_logs table:', cpe.rows[0].tbl ? 'created' : 'MISSING');
  } finally {
    await client.end();
  }
})().catch((e) => {
  console.error('❌ Migration failed:', e.message);
  process.exit(1);
});
