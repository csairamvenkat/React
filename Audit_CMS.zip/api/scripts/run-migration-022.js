const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

const cfg = require(path.resolve(__dirname, '../src/config.dev.json')).database;
const sql = fs.readFileSync(
  path.resolve(__dirname, '../../database/migrations/022_retire_frs_investigator.sql'),
  'utf8',
);

(async () => {
  const client = new Client({
    host: cfg.host,
    port: cfg.port,
    user: cfg.username,
    password: cfg.password,
    database: cfg.db,
    ssl: cfg.enableSSL ? { rejectUnauthorized: false } : false,
  });
  await client.connect();
  try {
    await client.query(`SET search_path TO "${cfg.schema}"`);

    const before = await client.query(
      `SELECT COUNT(*)::int AS carried
       FROM cases
       WHERE deleted = FALSE
         AND frs_investigator IS NOT NULL AND frs_investigator <> ''
         AND (case_lead IS NULL OR case_lead = '')`,
    );
    console.log(`cases whose FRS Investigator becomes the Case Lead: ${before.rows[0].carried}`);

    await client.query(sql);
    console.log(`✅ Migration 022 applied to ${cfg.host}/${cfg.db} (schema ${cfg.schema})`);

    const col = await client.query(
      `SELECT column_name FROM information_schema.columns
       WHERE table_schema = $1 AND table_name = 'cases' AND column_name = 'frs_investigator'`,
      [cfg.schema],
    );
    console.log('frs_investigator column:', col.rowCount ? 'STILL PRESENT' : 'dropped');
  } finally {
    await client.end();
  }
})().catch((e) => {
  console.error('❌ Migration failed:', e.message);
  process.exit(1);
});
