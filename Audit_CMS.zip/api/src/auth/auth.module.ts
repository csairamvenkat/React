import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConfigService } from 'src/config/config.service';
import { AzureADStrategy } from './azure-ad.strategy';
import { AuthController } from './controllers';
import { AuthService } from './services';

@Module({
	imports: [PassportModule.register({ defaultStrategy: 'oauth-bearer' })],
	providers: [AzureADStrategy, ConfigService, AuthService],
	controllers: [AuthController],
})
export class AuthModule {}
