import { Logger, Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DatabaseModule } from './database/database.module';
import { ConfigModule } from './config/config.module';
import { CoreModule } from './core/core.module';
import { AuthModule } from './auth/auth.module';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { LoggingInterceptor } from './core/interceptors/logger.interceptor';
import { SharedModule } from './shared/shared.module';
import { SequelizeModule } from '@nestjs/sequelize';
import { getSequelizeOrmConfig } from './database/orm-config';
import { HttpRequestInterceptor } from './core/interceptors';
import { BusinessEntityModule } from './business-entity/business-entity.module';
import { PermissionModule } from './permission/permission.module';
import { ConfigService } from './config/config.service';
import { Dialect } from 'sequelize';
import { AttachmentModule } from './attachment/attachments.module';
import { GraphUserModule } from './graph-user/graph-user.module';
import { NotificationModule } from './notification/notification.module';
import { SetupModule } from './setup/setup.module';
import { CaseModule } from './case/case.module';
import { AiModule } from './ai/ai.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { NavexModule } from './navex/navex.module';
import { HierarchyModule } from './hierarchy/hierarchy.module';

@Module({
	imports: [
		DatabaseModule,
		ConfigModule,
		CoreModule,
		AuthModule,
		SharedModule,
		SequelizeModule.forRootAsync({
			imports: [ConfigModule],
			useFactory: async (configService: ConfigService) => {
				const { database } = configService.getAppConfig();
				const { dialect, host, password, db, port, username, schema, enableSSL } = database;
				return {
					dialect: dialect as Dialect,
					host,
					port,
					database: db,
					username,
					password,
					schema,
					logging: false,
					...getSequelizeOrmConfig(enableSSL),
				};
			},
			inject: [ConfigService],
		}),
		BusinessEntityModule,
		PermissionModule,
		AttachmentModule,
		GraphUserModule,
		NotificationModule,
		SetupModule,
		CaseModule,
		AiModule,
		AnalyticsModule,
		NavexModule,
		HierarchyModule,
	],
	controllers: [AppController],
	providers: [
		AppService,
		Logger,
		{
			provide: APP_INTERCEPTOR,
			useClass: LoggingInterceptor,
		},
		{
			provide: APP_INTERCEPTOR,
			useClass: HttpRequestInterceptor,
		},
	],
})
export class AppModule { }
