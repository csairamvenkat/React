import {
	Case,
	CaseScopeItem,
	CaseProcedure,
	CaseResult,
	CaseRemediationAction,
	CaseRecommendation,
	CaseRecommendationItem,
	CaseEvidence,
	CaseAllegation,
	CaseFraudRisk,
	CaseUserPermission,
} from '@/case/models';
import { AiPrompt, AiUsageLog } from '@/ai/models';
import { SetupData } from '@/setup/models';
import { CpeHoursLog } from '@/analytics/models';

const models = [
	Case,
	CaseScopeItem,
	CaseProcedure,
	CaseResult,
	CaseRemediationAction,
	CaseRecommendation,
	CaseRecommendationItem,
	CaseEvidence,
	CaseAllegation,
	CaseFraudRisk,
	CaseUserPermission,
	AiPrompt,
	AiUsageLog,
	SetupData,
	CpeHoursLog,
];

const TRANSIENT_CONNECTION_ERRORS = [
	/EADDRNOTAVAIL/,
	/ECONNRESET/,
	/ECONNREFUSED/,
	/EHOSTUNREACH/,
	/ENETUNREACH/,
	/ENETDOWN/,
	/ETIMEDOUT/,
	/EPIPE/,
	/ENOTFOUND/,
	/Connection terminated unexpectedly/,
];

export const getSequelizeOrmConfig = enableSSL => {
	return {
		synchronize: false,
		sync: { alter: false },
		autoLoadModels: true,
		models,

		retry: {
			match: TRANSIENT_CONNECTION_ERRORS,
			max: 4,
			backoffBase: 500,
			backoffExponent: 1.5,
		},

		pool: {
			max: 10,
			min: 0,
			acquire: 30_000,
			idle: 10_000,
			evict: 10_000,
		},

		dialectOptions: {
			keepAlive: true,
			...(enableSSL && { ssl: { require: true } }),
		},
		...(enableSSL && { ssl: true }),
	};
};
