import { Module } from '@nestjs/common';
import { SetupController } from './controllers';
import { SetupService } from './services';
import { SetupDataRepository } from './repositories';

@Module({
	controllers: [SetupController],
	providers: [SetupService, SetupDataRepository],
	exports: [SetupService, SetupDataRepository],
})
export class SetupModule {}
