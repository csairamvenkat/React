import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { SetupData } from '../models';

@Injectable()
export class SetupDataRepository extends BaseRepository<SetupData> {
	constructor() {
		super(SetupData);
	}

	public findByType(setupType: string): Promise<SetupData | null> {
		return this.findOne({ where: { setupType } });
	}
}
