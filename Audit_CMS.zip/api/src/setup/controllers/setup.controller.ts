import { Controller, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { SetupService } from '../services';

@ApiTags('Setup APIs')
@ApiBearerAuth()
@UseGuards(AuthGuard('oauth-bearer'))
@Controller('setup')
export class SetupController {
	constructor(private readonly setupService: SetupService) { }
}
