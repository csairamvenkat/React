import { Column, CreatedAt, DataType, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';

@Table({ tableName: 'setup_data' })
export class SetupData extends BaseModel<SetupData> {
	@Column({ field: 'setup_type', type: DataType.TEXT, allowNull: false, unique: true })
	public setupType: string;

	@Column({ field: 'setup_detail', type: DataType.JSON, allowNull: false })
	public setupDetail: any;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({
		field: 'created_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({
		field: 'updated_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
