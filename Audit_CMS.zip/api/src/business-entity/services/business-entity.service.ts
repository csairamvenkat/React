import { HttpStatus } from '@/shared/enums';
import { HttpException } from '@/shared/exceptions';
import { Injectable } from '@nestjs/common';
import { AdminApiClient } from 'src/shared/clients';
import { instanceToPlain } from 'src/shared/helpers';
import { BusinessEntityWithChildren, CurrentContext } from 'src/shared/types';
import { BusinessEntityResponseDto } from '../dtos';
import { BusinessEntityLevelResponseDto } from '../dtos/response/business-entity-level.dto';
import { BusinessEntityRoleResponseDto } from '../dtos/response/business-entity-role.dto';
import { UserListResponseDto } from '../dtos/response/user-list.dto';

@Injectable()
export class BusinessEntityService {
	constructor(private readonly adminApiClient: AdminApiClient) {}

	/**
	 * Get all the locations or business entities hierarchy for given permission of a user
	 * @param currentContext
	 * @param permission
	 * @returns
	 */
	public async getBusinessEntitiesForGivenPermissionForUser(
		currentContext: CurrentContext,
		permission: string,
		parentId: number = null,
		lastLevel: string = null,
	) {
		const { username } = currentContext.user;

		const data = await this.adminApiClient.getAllBusinessHierarchyByUserAndPermission(
			username,
			permission,
			parentId,
			lastLevel,
		);

		if (!data) {
			throw new HttpException("You don't have an access", HttpStatus.UNAUTHORIZED);
		}

		const response = new BusinessEntityResponseDto(data);
		return instanceToPlain(this.sortBusinessEntitiesByFullName([response])[0]);
	}

	/**
	 * Get all business entities hierarchy.
	 * @returns
	 */
	public async getAllBusinessHierarchy() {
		const data = await this.adminApiClient.getAllBusinessHierarchy();
		const response = new BusinessEntityResponseDto(data);
		return instanceToPlain(this.sortBusinessEntitiesByFullName([response])[0]);
	}

	private sortBusinessEntitiesByFullName(
		entities: BusinessEntityResponseDto[],
		ascending: boolean = true,
	): BusinessEntityResponseDto[] {
		const sortedEntities = [...entities];

		sortedEntities.sort((a, b) => {
			if (!a.full_name && !b.full_name) return 0;
			if (!a.full_name) return ascending ? 1 : -1;
			if (!b.full_name) return ascending ? -1 : 1;

			const comparison = a.full_name.localeCompare(b.full_name, undefined, { sensitivity: 'base' });

			return ascending ? comparison : -comparison;
		});

		sortedEntities.forEach(entity => {
			if (entity.children && entity.children.length > 0) {
				entity.children = this.sortBusinessEntitiesByFullName(entity.children, ascending);
			}
		});

		return sortedEntities;
	}

	/**
	 * Get all business entity levels.
	 * @returns
	 */
	public async getAllBusinessEntityLevels(): Promise<Record<string, any>> {
		let data = await this.adminApiClient.getBusinessEntityLevels();
		data = data.sort((a, b) => a.order_number - b.order_number);
		return data.map(d => instanceToPlain(new BusinessEntityLevelResponseDto(d)));
	}

	/**
	 * Get all business entity roles.
	 * @returns
	 */
	public async getAllBusinessEntityRoles(entityLevel: string): Promise<Record<string, any>> {
		const data = await this.adminApiClient.getBusinessEntityRoles(entityLevel);
		return data.map(d => instanceToPlain(new BusinessEntityRoleResponseDto(d)));
	}

	/**
	 * Get all business entity roles.
	 * @returns
	 */
	public async getUsersByRoleOfAnEntity(
		entityId: number,
		roleName: string,
	): Promise<Record<string, any>> {
		const data = await this.adminApiClient.getUsersByRoleOfAnEntityWithChild(roleName, entityId);
		return data.map(d => instanceToPlain(new UserListResponseDto(d)));
	}

	public async getBusinessEntitiesChildIds(entities: number[]): Promise<number[]> {
		let allChildEntities = [...entities.map(entityId => Number(entityId))];
		for (const entityId of entities) {
			const childs = await this.adminApiClient.getChildernListOfBusinessEntity(entityId);
			allChildEntities.push(...childs);
		}
		return [...new Set(allChildEntities)];
	}

	public async getAllBusinessUnits(): Promise<BusinessEntityWithChildren[]> {
		const businessEntities = await this.adminApiClient.getAllBusinessHierarchy();
		const result = [];

		const traverse = node => {
			if (node.is_node) {
				result.push(node);
			}

			if (node.children && node.children.length > 0) {
				node.children.forEach(child => traverse(child));
			}
		};

		traverse(businessEntities);
		return result;
	}
}
