import { Module } from '@nestjs/common';
import { AdminApiClient } from 'src/shared/clients';
import { BusinessEntityController } from './controllers';
import { BusinessEntityService } from './services';
import { EntitySetupRepository } from './repositories';

const repositories = [EntitySetupRepository];

@Module({
	controllers: [BusinessEntityController],
	providers: [BusinessEntityService, AdminApiClient, ...repositories],
})
export class BusinessEntityModule {}
