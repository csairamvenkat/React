import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class UserListResponseDto {
	@ApiProperty({ name: 'userName' })
	@Expose({ name: 'userName' })
	public user_name: string;

	@ApiProperty({ name: 'entityName' })
	@Expose({ name: 'entityName' })
	public business_entity_name: string;

	@ApiProperty({ name: 'entityCode' })
	@Expose({ name: 'entityCode' })
	public business_entity_code: string;

	constructor(partial: Partial<UserListResponseDto> = {}) {
		Object.assign(this, partial);
	}
}
