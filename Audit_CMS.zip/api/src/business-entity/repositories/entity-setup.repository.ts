import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { EntitySetup } from '../models';

@Injectable()
export class EntitySetupRepository extends BaseRepository<EntitySetup> {
	constructor() {
		super(EntitySetup);
	}

	public getEntitySetupWithCurrency(entityIds: number[]): Promise<EntitySetup | null> {
		const orConditions = entityIds.map(entityId => ({ entityId }));
		return this.findOne({
			where: { [Op.or]: orConditions },
		});
	}
}
