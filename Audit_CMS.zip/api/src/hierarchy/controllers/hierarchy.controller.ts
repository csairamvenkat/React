import { Controller, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { HierarchyNodeResponseDto } from '../dtos';
import { HierarchyService } from '../services/hierarchy.service';

@ApiTags('Hierarchy Reference APIs')
@ApiBearerAuth()
@UseGuards(AuthGuard('oauth-bearer'))
@Controller('hierarchy')
export class HierarchyController {
	constructor(private readonly hierarchyService: HierarchyService) {}

	@ApiOperation({
		summary: 'Argus organisation reference',
		description:
			'Every active business unit with its region, pillar and vertical. Flat and unfiltered — ' +
			'the list is a few hundred rows and the client builds the tree and caches it for the session.',
	})
	@ApiResponse({ status: 200, type: [HierarchyNodeResponseDto] })
	@Get()
	public getHierarchy(): Promise<HierarchyNodeResponseDto[]> {
		return this.hierarchyService.getHierarchy();
	}
}
