/** How long the Argus reference list is served from memory before it is read again. */
export const HIERARCHY_CACHE_TTL_MS = 15 * 60 * 1000;
