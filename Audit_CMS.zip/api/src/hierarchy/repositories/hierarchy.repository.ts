import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/sequelize';
import { QueryTypes } from 'sequelize';
import { Sequelize } from 'sequelize-typescript';
import { ConfigService } from '@/config/config.service';

/**
 * `hierarchy_reference` is the Argus organisation reference — one row per business unit, with
 * its region (level1), pillar (level2), vertical (level3) and unit (level4) spelled out.
 *
 * It is owned upstream, not by this project's migrations, and its shape does not fit
 * `BaseRepository`: the primary key is the Argus id (VARCHAR, not the BIGINT `BaseModel`
 * declares) and it carries `is_active` rather than the `active`/`deleted` pair every
 * `findAll` here injects into the WHERE clause. Raw SQL, as `NavexRepository` does for the
 * sync tables, keeps that mismatch out of the model layer.
 */
@Injectable()
export class HierarchyRepository {
	private readonly schema: string;

	constructor(
		@InjectConnection() private readonly sequelize: Sequelize,
		configService: ConfigService,
	) {
		this.schema = `"${configService.getAppConfig().database.schema.replace(/"/g, '""')}"`;
	}

	public async getActiveNodes(): Promise<HierarchyReferenceRow[]> {
		const rows = await this.sequelize.query(
			`SELECT id,
			        name,
			        bu_type              AS "buType",
			        level1,
			        level2,
			        level3,
			        level4,
			        bu_code              AS "buCode",
			        unloc_terminal_code  AS "unlocTerminalCode",
			        country
			 FROM   ${this.schema}.hierarchy_reference
			 WHERE  is_active = TRUE
			 ORDER  BY level1, level2, level3, level4, name`,
			{ type: QueryTypes.SELECT },
		);

		return rows as HierarchyReferenceRow[];
	}
}

export interface HierarchyReferenceRow {
	id: string;
	name: string;
	buType: string | null;
	level1: string | null;
	level2: string | null;
	level3: string | null;
	level4: string | null;
	buCode: string | null;
	unlocTerminalCode: string | null;
	country: string | null;
}
