import { Injectable } from '@nestjs/common';
import { HierarchyReferenceRow, HierarchyRepository } from '../repositories/hierarchy.repository';
import { HIERARCHY_CACHE_TTL_MS } from '../hierarchy.constant';

/**
 * The reference list is small (hundreds of rows), identical for every user and changes only
 * when the Argus master data does, so it is read once and held for `HIERARCHY_CACHE_TTL_MS`
 * rather than re-queried on every case report a user opens.
 */
@Injectable()
export class HierarchyService {
	private cached: HierarchyReferenceRow[] | null = null;
	private cachedAt = 0;
	private inFlight: Promise<HierarchyReferenceRow[]> | null = null;

	constructor(private readonly hierarchyRepository: HierarchyRepository) {}

	public getHierarchy(): Promise<HierarchyReferenceRow[]> {
		if (this.cached && Date.now() - this.cachedAt < HIERARCHY_CACHE_TTL_MS) {
			return Promise.resolve(this.cached);
		}

		// Concurrent misses share one query instead of each opening their own.
		if (!this.inFlight) {
			this.inFlight = this.hierarchyRepository
				.getActiveNodes()
				.then(rows => {
					this.cached = rows;
					this.cachedAt = Date.now();

					return rows;
				})
				.finally(() => {
					this.inFlight = null;
				});
		}

		return this.inFlight;
	}
}
