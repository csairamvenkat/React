import { ApiProperty } from '@nestjs/swagger';

export class HierarchyNodeResponseDto {
	@ApiProperty({ description: 'Argus unique id — the natural key a case stores as argusUniqueId.' })
	public id: string;

	@ApiProperty({ description: 'Canonical business unit name.' })
	public name: string;

	@ApiProperty({ required: false, description: 'PT, IPT, RO, POML, SS, Corp.' })
	public buType: string | null;

	@ApiProperty({ required: false, description: 'Region.' })
	public level1: string | null;

	@ApiProperty({ required: false, description: 'Pillar.' })
	public level2: string | null;

	@ApiProperty({ required: false, description: 'Business vertical.' })
	public level3: string | null;

	@ApiProperty({ required: false, description: 'Business unit.' })
	public level4: string | null;

	@ApiProperty({ required: false })
	public buCode: string | null;

	@ApiProperty({ required: false })
	public unlocTerminalCode: string | null;

	@ApiProperty({ required: false })
	public country: string | null;
}
