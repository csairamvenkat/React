import { Module } from '@nestjs/common';
import { ConfigModule } from '@/config/config.module';
import { HierarchyController } from './controllers/hierarchy.controller';
import { HierarchyRepository } from './repositories/hierarchy.repository';
import { HierarchyService } from './services/hierarchy.service';

@Module({
	imports: [ConfigModule],
	controllers: [HierarchyController],
	providers: [HierarchyService, HierarchyRepository],
	exports: [HierarchyService],
})
export class HierarchyModule {}
