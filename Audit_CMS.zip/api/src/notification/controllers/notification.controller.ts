import {
	Body,
	Controller,
	Get,
	HttpCode,
	Param,
	Post,
	Query,
	Req,
	UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Pagination } from '@/core/pagination';
import { RequestContext } from '@/shared/types';
import {
	NotificationResponseDto,
	PaginatedNotificationResponseDto,
	ViewNotificationRequestDto,
} from '../dtos';
import { NotificationService } from '../services';
import { PERMISSIONS } from '@/shared/enums';
import { PermissionsGuard } from '@/core/guards';
import { Permissions } from '@/core/decorators';

@ApiTags('Notification APIs')
@ApiBearerAuth()
@Controller('notifications')
export class NotificationController {
	constructor(private readonly notificationService: NotificationService) {}

	@Permissions(PERMISSIONS.GLOBAL_ADMIN, { checkEntity: true })
	@UseGuards(AuthGuard('oauth-bearer'), PermissionsGuard)
	@ApiResponse({
		status: 204,
		description: 'Mark the notifications viewed by the user.',
	})
	@Post('viewed')
	@HttpCode(204)
	public async notificationsViewedByUser(
		@Req() request: RequestContext,
		@Body() viewNotificationRequestDto: ViewNotificationRequestDto,
	): Promise<void> {
		return this.notificationService.notificationsViewedByUser(
			viewNotificationRequestDto.notificationsIds,
			request.currentContext,
		);
	}

	@UseGuards(AuthGuard('oauth-bearer'))
	@ApiResponse({
		status: 200,
		description: 'Return the list of notifications for the user',
		type: [PaginatedNotificationResponseDto],
	})
	@ApiQuery({
		name: 'limit',
		type: Number,
		description: 'Number of records in response.',
		required: false,
	})
	@ApiQuery({
		name: 'page',
		type: Number,
		description: 'Page number of the paginated record.',
		required: false,
	})
	@Get('')
	public getNotificationsListForUser(
		@Req() request: RequestContext,
		@Query('limit') limit?: number,
		@Query('page') page?: number,
	): Promise<Pagination<NotificationResponseDto>> {
		return this.notificationService.getNotificationsListForUser(
			request.currentContext,
			limit,
			page,
		);
	}
}
