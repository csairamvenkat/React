import { Injectable } from '@nestjs/common';
import { Pagination } from '@/core/pagination';
import { multiObjectToInstance, singleObjectToInstance } from '@/shared/helpers';
import { CurrentContext, NotificationPayload } from '@/shared/types';
import { NotificationResponseDto } from '../dtos';
import { NotificationRepository } from '../repositories';

@Injectable()
export class NotificationService {
	constructor(private readonly notificationRepository: NotificationRepository) {}

	/**
	 * Add new notification.
	 * @param title
	 * @param description
	 * @param subscribers
	 * @param currentContext
	 * @returns
	 */
	public async createNotification(
		notificationPayload: NotificationPayload,
		currentContext: CurrentContext,
	): Promise<NotificationResponseDto> {
		const notification = await this.notificationRepository.createNotification(
			notificationPayload,
			currentContext,
		);
		return singleObjectToInstance(NotificationResponseDto, notification);
	}

	/**
	 * Get the paginated notifications list for the current user.
	 * @param currentContext
	 * @param limit
	 * @param page
	 */
	public async getNotificationsListForUser(
		currentContext: CurrentContext,
		limit?: number,
		page?: number,
	): Promise<Pagination<NotificationResponseDto>> {
		return new Pagination({ records: [], total: 0 });
	}

	/**
	 * Add user to viewed by list fo the notifications.
	 * @param notificationsIds
	 * @param currentContext
	 */
	public async notificationsViewedByUser(
		notificationsIds: number[],
		currentContext: CurrentContext,
	): Promise<void> {
		await this.notificationRepository.addNotificationsViewerToViewedByList(
			notificationsIds,
			currentContext,
		);
	}
}
