import { Injectable } from '@nestjs/common';
import { literal, Op } from 'sequelize';
import { BaseRepository } from '@/shared/repositories';
import { CurrentContext, NotificationPayload } from '@/shared/types';
import { Notification } from '../models';

@Injectable()
export class NotificationRepository extends BaseRepository<Notification> {
	constructor() {
		super(Notification);
	}

	public createNotification(payload, currentContext: CurrentContext): Promise<Notification | null> {
		const entity = new Notification(payload);
		return this.save(entity, currentContext);
	}

	public bulkNotificationsInsert(records: NotificationPayload[], currentContext: CurrentContext) {
		return this.insertMany(records, currentContext);
	}

	public async addNotificationsViewerToViewedByList(
		notificationIds: number[],
		currentContext: CurrentContext,
	): Promise<void> {
		const { user } = currentContext;
		await this.update(
			{
				viewedBy: literal(
					`(CASE WHEN viewed_by IS NULL THEN '[]'::JSONB ELSE viewed_by END) || '["${user.username}"]'::jsonb`,
				),
			},
			currentContext,
			{
				where: { id: { [Op.in]: notificationIds } },
			},
		);
	}

	public getPaginatedNotificationListForUser(
		userId: string,
		limit?: number,
		page?: number,
	): Promise<{ rows: Notification[]; count: number } | null> {
		return this.findAndCountAll({
			where: {
				subscribers: { [Op.contains]: [userId] },
				expireAt: { [Op.gt]: new Date() },
				[Op.or]: [{ viewedBy: null }, { [Op.not]: { viewedBy: { [Op.contains]: [userId] } } }],
			},
			...(page && { offset: (page - 1) * limit }),
			...(limit && { limit }),
			order: [['createdOn', 'desc']],
		});
	}
}
