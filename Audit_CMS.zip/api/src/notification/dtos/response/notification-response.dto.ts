import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { NOTIFICATION_TYPE } from '@/shared/enums';

export class NotificationResponseDto {
	@ApiProperty({ type: Number })
	@Expose()
	public id: number;

	@ApiProperty({ type: String })
	@Expose()
	public title: string;

	@ApiProperty({ type: String })
	@Expose()
	public description: string;

	@ApiProperty({ type: String })
	@Expose()
	public url: string;

	@ApiProperty({ type: String })
	@Expose()
	public type: NOTIFICATION_TYPE;

	@ApiProperty({ type: Date })
	@Expose()
	public createdOn: Date;
}
