import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { NotificationResponseDto } from './notification-response.dto';

export class PaginatedNotificationResponseDto {
	@ApiProperty()
	@Expose()
	public pageTotal: number;

	@ApiProperty({ isArray: true, type: NotificationResponseDto })
	@Expose()
	public records: NotificationResponseDto[];

	@ApiProperty()
	@Expose()
	public total: number;
}
