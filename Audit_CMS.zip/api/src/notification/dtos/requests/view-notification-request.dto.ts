import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty } from 'class-validator';

export class ViewNotificationRequestDto {
	@ApiProperty({ type: Number, isArray: true })
	@IsArray()
	@IsNotEmpty()
	notificationsIds: number[];
}
