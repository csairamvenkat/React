import { Module } from '@nestjs/common';
import { NotificationController } from './controllers';
import { NotificationRepository } from './repositories';
import { NotificationService } from './services';
import { AdminApiClient } from '@/shared/clients';
import { SharedPermissionService } from '@/shared/services';

const repositories = [NotificationRepository];

@Module({
	providers: [NotificationService, ...repositories, AdminApiClient, SharedPermissionService],
	controllers: [NotificationController],
})
export class NotificationModule {}
