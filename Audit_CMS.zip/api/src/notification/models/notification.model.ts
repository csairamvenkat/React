import { Column, CreatedAt, DataType, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { NOTIFICATION_TYPE } from '@/shared/enums/notification-type.enum';
import { enumToArray } from '@/shared/helpers';
import { BaseModel } from '@/shared/models';

@Table({ tableName: 'notifications' })
export class Notification extends BaseModel<Notification> {
	@Column({ type: DataType.STRING, allowNull: false })
	public title: string;

	@Column({ type: DataType.STRING, allowNull: true })
	public description: string | null;

	@Column({ type: DataType.STRING, allowNull: false })
	public url: string;

	@Column({ field: 'expire_at', allowNull: false, type: 'TIMESTAMP' })
	public expireAt: Date;

	@Column({
		field: 'type',
		type: DataType.ENUM(...enumToArray(NOTIFICATION_TYPE)),
		allowNull: false,
		defaultValue: NOTIFICATION_TYPE.INFO,
	})
	public type: NOTIFICATION_TYPE;

	@Column({ field: 'viewed_by', type: DataType.JSONB, allowNull: true })
	public viewedBy: string[] | null;

	@Column({ field: 'subscribers', type: DataType.JSONB, allowNull: true })
	public subscribers: string[] | null;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
