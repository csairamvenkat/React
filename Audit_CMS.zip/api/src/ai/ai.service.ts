import { Injectable, Logger } from '@nestjs/common';
import { OpenAI } from 'openai';
import { ConfigService } from 'src/config/config.service';
import { SetupDataRepository } from 'src/setup/repositories';
import { SETUP_TYPE } from 'src/shared/enums';
import { CurrentContext } from 'src/shared/types';
import {
	ANALYTICS_ACTION,
	AnalyticsResult,
	CLASSIFY_ACTIONS,
	ClassifyResult,
	DRAFT_ACTIONS,
	DraftResult,
	RECOMMEND_ACTIONS,
	RecommendResult,
	REVIEW_ACTIONS,
	ReviewResult,
} from './ai-actions.registry';
import { AiPromptRepository, AiUsageLogRepository } from './repositories';
import { AiActionDefinition, AiActionInput, AiOutputFormat } from './ai.types';
import {
	AiAnalyticsRequestDto,
	AiClassifyRequestDto,
	AiDraftRequestDto,
	AiRecommendRequestDto,
	AiReviewRequestDto,
} from './dtos/ai-request.dto';

@Injectable()
export class AiService {
	private readonly logger = new Logger(AiService.name);
	private readonly client: OpenAI;
	private readonly deployment: string;

	constructor(
		private readonly configService: ConfigService,
		private readonly aiPromptRepository: AiPromptRepository,
		private readonly setupDataRepository: SetupDataRepository,
		private readonly aiUsageLogRepository: AiUsageLogRepository,
	) {
		const { endpoint, apiKey, deployment } = this.configService.getAppConfig().azureOpenAI;
		this.deployment = deployment;
		this.client = new OpenAI({
			apiKey,
			baseURL: `${endpoint}/openai/v1`,
			maxRetries: 3,
			timeout: 30_000,
		});
	}

	private async getIncidentTypes(): Promise<string> {
		const setup = await this.setupDataRepository.findByType(SETUP_TYPE.INCIDENT_TYPES);
		const incidentTypes: string[] = setup?.setupDetail ?? [];
		return incidentTypes.join(', ');
	}

	private renderTemplate(template: string, vars: Record<string, any> = {}): string {
		return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_match, key) => {
			const value = vars[key];
			if (value === undefined || value === null) {
				return '';
			}
			return typeof value === 'object' ? JSON.stringify(value) : String(value);
		});
	}

	private async getPrompt(promptKey: string): Promise<{ system: string; user: string }> {
		const prompt = await this.aiPromptRepository.findByKey(promptKey);
		if (!prompt) {
			throw new Error(`AI prompt not configured for key: ${promptKey}`);
		}
		return { system: prompt.systemPrompt, user: prompt.userPromptTemplate };
	}

	private buildTextFormat(format: AiOutputFormat) {
		switch (format.kind) {
			case 'json_object':
				return { format: { type: 'json_object' as const } };
			case 'json_schema':
				return {
					format: {
						type: 'json_schema' as const,
						name: format.name,
						schema: format.schema,
						strict: true,
					},
				};
			case 'text':
				return undefined;
		}
	}

	private async complete(params: {
		promptKey: string;
		actionGroup: string;
		caseId: number | null;
		systemPrompt: string;
		userMessage: string;
		format: AiOutputFormat;
		currentContext: CurrentContext;
	}): Promise<{ raw: string; parsed: any }> {
		const { promptKey, actionGroup, caseId, systemPrompt, userMessage, format, currentContext } =
			params;
		const startedAt = Date.now();
		const textConfig = this.buildTextFormat(format);

		try {
			const response = await this.client.responses.create({
				model: this.deployment,
				max_output_tokens: 2048,
				reasoning: { effort: 'low' },
				...(textConfig ? { text: textConfig } : {}),
				input: [
					{ type: 'message', role: 'system', content: systemPrompt },
					{ type: 'message', role: 'user', content: userMessage },
				],
			});

			const durationMs = Date.now() - startedAt;
			this.logger.log(
				`ai action="${promptKey}" status=${
					response.status ?? 'unknown'
				} duration_ms=${durationMs} tokens=${response.usage?.total_tokens ?? 'n/a'}`,
			);
			if (response.incomplete_details) {
				this.logger.warn(
					`ai action="${promptKey}" incomplete reason=${response.incomplete_details.reason}; output may be empty or truncated`,
				);
			}

			const raw = response.output_text ?? '';
			let parsed: any;
			if (format.kind !== 'text' && raw) {
				try {
					parsed = JSON.parse(raw);
				} catch (err) {
					this.logger.error(
						`ai action="${promptKey}" returned invalid JSON for format=${format.kind}`,
						err,
					);
				}
			}

			await this.recordUsage({
				promptKey,
				actionGroup,
				caseId,
				systemPrompt,
				userMessage,
				response: raw,
				status: response.status ?? 'completed',
				incompleteReason: response.incomplete_details?.reason ?? null,
				durationMs,
				inputTokens: response.usage?.input_tokens ?? null,
				outputTokens: response.usage?.output_tokens ?? null,
				totalTokens: response.usage?.total_tokens ?? null,
				requestId: response.id ?? null,
				currentContext,
			});

			return { raw, parsed };
		} catch (err: any) {
			const durationMs = Date.now() - startedAt;
			await this.recordUsage({
				promptKey,
				actionGroup,
				caseId,
				systemPrompt,
				userMessage,
				response: null,
				status: 'failed',
				incompleteReason: null,
				durationMs,
				inputTokens: null,
				outputTokens: null,
				totalTokens: null,
				requestId: null,
				errorMessage: err?.message ?? String(err),
				currentContext,
			});
			throw err;
		}
	}

	private async recordUsage(entry: {
		promptKey: string;
		actionGroup: string;
		caseId: number | null;
		systemPrompt: string;
		userMessage: string;
		response: string | null;
		status: string;
		incompleteReason: string | null;
		durationMs: number;
		inputTokens: number | null;
		outputTokens: number | null;
		totalTokens: number | null;
		requestId: string | null;
		errorMessage?: string;
		currentContext: CurrentContext;
	}): Promise<void> {
		try {
			await this.aiUsageLogRepository.createUsageLog(
				{
					caseId: entry.caseId,
					actionGroup: entry.actionGroup,
					promptKey: entry.promptKey,
					model: this.deployment,
					request: { system: entry.systemPrompt, user: entry.userMessage },
					response: entry.response,
					status: entry.status,
					incompleteReason: entry.incompleteReason,
					errorMessage: entry.errorMessage ?? null,
					durationMs: entry.durationMs,
					inputTokens: entry.inputTokens,
					outputTokens: entry.outputTokens,
					totalTokens: entry.totalTokens,
					requestId: entry.requestId,
				},
				entry.currentContext,
			);
		} catch (err) {
			this.logger.error(`failed to persist ai usage log for action="${entry.promptKey}"`, err);
		}
	}

	private async executeAction<TResult>(
		actionGroup: string,
		definition: AiActionDefinition<TResult>,
		input: AiActionInput,
		currentContext: CurrentContext,
	): Promise<TResult> {
		const prompt = await this.getPrompt(definition.promptKey);
		const systemVars = definition.buildSystemVars
			? await definition.buildSystemVars(input, { getIncidentTypes: () => this.getIncidentTypes() })
			: {};
		const overrideVars = definition.buildUserVars ? definition.buildUserVars(input) : {};
		const vars = {
			...input.context,
			...(input.content !== undefined ? { content: input.content } : {}),
			...systemVars,
			...overrideVars,
		};
		const system = this.renderTemplate(prompt.system, vars);
		const userMessage = this.renderTemplate(prompt.user, vars);
		const caseId = input.context?.caseId ?? null;

		try {
			const { raw, parsed } = await this.complete({
				promptKey: definition.promptKey,
				actionGroup,
				caseId,
				systemPrompt: system,
				userMessage,
				format: definition.format,
				currentContext,
			});
			return definition.shapeResult(raw, parsed, input);
		} catch (err) {
			this.logger.error(`ai action="${definition.promptKey}" failed`, err);
			throw err;
		}
	}

	async testConnection(
		currentContext: CurrentContext,
	): Promise<{ success: boolean; message: string }> {
		try {
			const { system, user } = await this.getPrompt('test_connection');
			const { raw } = await this.complete({
				promptKey: 'test_connection',
				actionGroup: 'system',
				caseId: null,
				systemPrompt: system,
				userMessage: user,
				format: { kind: 'text' },
				currentContext,
			});
			return { success: true, message: raw };
		} catch (err: any) {
			this.logger.error('Azure OpenAI connectivity test failed', err);
			return { success: false, message: err?.message ?? 'Unknown error' };
		}
	}

	async draft(dto: AiDraftRequestDto, currentContext: CurrentContext): Promise<DraftResult> {
		const definition = DRAFT_ACTIONS[dto.action];
		if (!definition) {
			return { text: '' };
		}
		return this.executeAction('draft', definition, { context: dto.context }, currentContext);
	}

	async classify(
		dto: AiClassifyRequestDto,
		currentContext: CurrentContext,
	): Promise<ClassifyResult> {
		const definition = CLASSIFY_ACTIONS[dto.action];
		if (!definition) {
			return { result: null };
		}
		return this.executeAction('classify', definition, { context: dto.context }, currentContext);
	}

	async recommend(
		dto: AiRecommendRequestDto,
		currentContext: CurrentContext,
	): Promise<RecommendResult> {
		const definition = RECOMMEND_ACTIONS[dto.action];
		if (!definition) {
			return { suggestions: [] };
		}
		return this.executeAction('recommend', definition, { context: dto.context }, currentContext);
	}

	async review(dto: AiReviewRequestDto, currentContext: CurrentContext): Promise<ReviewResult> {
		const definition = REVIEW_ACTIONS[dto.action];
		if (!definition) {
			return { score: 0, gaps: [], improved: dto.content, summary: '' };
		}
		return this.executeAction(
			'review',
			definition,
			{ context: dto.context ?? {}, content: dto.content },
			currentContext,
		);
	}

	async analytics(
		dto: AiAnalyticsRequestDto,
		currentContext: CurrentContext,
	): Promise<AnalyticsResult> {
		return this.executeAction(
			'analytics',
			ANALYTICS_ACTION,
			{ context: dto.context },
			currentContext,
		);
	}
}
