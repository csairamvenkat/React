import { DraftAction, ClassifyAction, RecommendAction, ReviewAction } from './dtos/ai-request.dto';
import {
	ALLEGATIONS_SCHEMA,
	ANALYTICS_SCHEMA,
	REVIEW_SCHEMA,
	SUGGESTIONS_SCHEMA,
} from './ai-response.schemas';
import {
	AiActionDefinition,
	extractJsonArray,
	jsonObjectFormat,
	jsonSchemaFormat,
	textFormat,
} from './ai.types';

export interface DraftResult {
	text: string;
	allegations?: Array<{ label: string; description: string }>;
}

export const DRAFT_ACTIONS: Record<DraftAction, AiActionDefinition<DraftResult>> = {
	[DraftAction.ALLEGATION_FIRST_DRAFT]: {
		promptKey: DraftAction.ALLEGATION_FIRST_DRAFT,
		format: jsonSchemaFormat('allegation_first_draft', ALLEGATIONS_SCHEMA),
		shapeResult: (raw, parsed) => ({ text: raw, allegations: parsed?.allegations ?? [] }),
	},

	[DraftAction.SYNOPSIS_CONCLUSION]: {
		promptKey: DraftAction.SYNOPSIS_CONCLUSION,
		format: textFormat(),
		shapeResult: raw => ({ text: raw }),
	},

	[DraftAction.DASHBOARD_SUBJECT]: {
		promptKey: DraftAction.DASHBOARD_SUBJECT,
		format: textFormat(),
		shapeResult: raw => ({ text: raw }),
	},

	[DraftAction.RESULT_ENHANCE]: {
		promptKey: DraftAction.RESULT_ENHANCE,
		format: textFormat(),
		shapeResult: raw => ({ text: raw }),
	},

	[DraftAction.REMEDIATION_ENHANCE]: {
		promptKey: DraftAction.REMEDIATION_ENHANCE,
		format: textFormat(),
		shapeResult: raw => ({ text: raw }),
	},

	[DraftAction.RECOMMENDATION_ENHANCE]: {
		promptKey: DraftAction.RECOMMENDATION_ENHANCE,
		format: textFormat(),
		shapeResult: raw => ({ text: raw }),
	},
};

export interface ClassifyResult {
	result: any;
}

const classifyResult = (raw: string, parsed: any): ClassifyResult => ({
	result: parsed ?? { raw },
});

export const CLASSIFY_ACTIONS: Record<ClassifyAction, AiActionDefinition<ClassifyResult>> = {
	[ClassifyAction.OVERALL_INCIDENT_TYPE]: {
		promptKey: ClassifyAction.OVERALL_INCIDENT_TYPE,
		format: jsonObjectFormat(),
		buildSystemVars: async (_input, deps) => ({ incidentTypes: await deps.getIncidentTypes() }),
		shapeResult: classifyResult,
	},

	[ClassifyAction.ALLEGATION_INCIDENT_TYPE]: {
		promptKey: ClassifyAction.ALLEGATION_INCIDENT_TYPE,
		format: jsonObjectFormat(),
		buildSystemVars: async (_input, deps) => ({ incidentTypes: await deps.getIncidentTypes() }),
		shapeResult: classifyResult,
	},

	[ClassifyAction.FRAUD_RISK_IDENTIFICATION]: {
		promptKey: ClassifyAction.FRAUD_RISK_IDENTIFICATION,
		format: jsonObjectFormat(),
		shapeResult: classifyResult,
	},
};

export interface RecommendResult {
	suggestions: any[];
}

export const RECOMMEND_ACTIONS: Record<RecommendAction, AiActionDefinition<RecommendResult>> = {
	[RecommendAction.SCOPE_SUGGESTIONS]: {
		promptKey: RecommendAction.SCOPE_SUGGESTIONS,
		format: jsonSchemaFormat('scope_suggestions', SUGGESTIONS_SCHEMA),
		shapeResult: (raw, parsed) => ({ suggestions: parsed?.suggestions ?? [] }),
	},

	[RecommendAction.PROCEDURE_SUGGESTIONS]: {
		promptKey: RecommendAction.PROCEDURE_SUGGESTIONS,
		format: textFormat(),
		shapeResult: raw => ({ suggestions: extractJsonArray(raw) }),
	},
};

export interface ReviewResult {
	score: number;
	gaps: string[];
	improved: string;
	summary: string;
}

const reviewResult =
	(fallbackContent: (input: { content?: string }) => string) =>
	(raw: string, parsed: any, input: { content?: string }): ReviewResult => ({
		score: parsed?.score ?? 0,
		gaps: parsed?.gaps ?? [],
		improved: parsed?.improved ?? fallbackContent(input),
		summary: parsed?.summary ?? '',
	});

export const REVIEW_ACTIONS: Record<ReviewAction, AiActionDefinition<ReviewResult>> = {
	[ReviewAction.ALLEGATION_REVIEW]: {
		promptKey: ReviewAction.ALLEGATION_REVIEW,
		format: jsonSchemaFormat('review_result', REVIEW_SCHEMA),
		shapeResult: reviewResult(input => input.content ?? ''),
	},

	[ReviewAction.RESULT_REVIEW]: {
		promptKey: ReviewAction.RESULT_REVIEW,
		format: jsonSchemaFormat('review_result', REVIEW_SCHEMA),
		shapeResult: reviewResult(input => input.content ?? ''),
	},

	[ReviewAction.REMEDIATION_REVIEW]: {
		promptKey: ReviewAction.REMEDIATION_REVIEW,
		format: jsonSchemaFormat('review_result', REVIEW_SCHEMA),
		shapeResult: reviewResult(input => input.content ?? ''),
	},

	[ReviewAction.RECOMMENDATION_REVIEW]: {
		promptKey: ReviewAction.RECOMMENDATION_REVIEW,
		format: jsonSchemaFormat('review_result', REVIEW_SCHEMA),
		shapeResult: reviewResult(input => input.content ?? ''),
	},
};

export interface AnalyticsResult {
	insights: string[];
	patterns: string[];
	summary: string;
}

export const ANALYTICS_ACTION: AiActionDefinition<AnalyticsResult> = {
	promptKey: 'analytics_insights',
	format: jsonSchemaFormat('analytics_insights', ANALYTICS_SCHEMA),
	shapeResult: (raw, parsed) => ({
		insights: parsed?.insights ?? [],
		patterns: parsed?.patterns ?? [],
		summary: parsed?.summary ?? '',
	}),
};
