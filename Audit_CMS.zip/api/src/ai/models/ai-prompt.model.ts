import { Column, CreatedAt, DataType, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';

@Table({ tableName: 'ai_prompts' })
export class AiPrompt extends BaseModel<AiPrompt> {
	@Column({ field: 'prompt_key', type: DataType.STRING, allowNull: false, unique: true })
	public promptKey: string;

	@Column({ field: 'prompt_group', type: DataType.STRING, allowNull: false })
	public promptGroup: string;

	@Column({ field: 'description', type: DataType.STRING, allowNull: true })
	public description: string;

	@Column({ field: 'system_prompt', type: DataType.TEXT, allowNull: false })
	public systemPrompt: string;

	@Column({ field: 'user_prompt_template', type: DataType.TEXT, allowNull: false })
	public userPromptTemplate: string;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({
		field: 'created_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({
		field: 'updated_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
