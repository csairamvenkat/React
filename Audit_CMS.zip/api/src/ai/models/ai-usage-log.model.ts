import { Column, CreatedAt, DataType, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';

@Table({ tableName: 'ai_usage_logs' })
export class AiUsageLog extends BaseModel<AiUsageLog> {
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: true })
	public caseId: number | null;

	@Column({ field: 'action_group', type: DataType.STRING, allowNull: false })
	public actionGroup: string;

	@Column({ field: 'prompt_key', type: DataType.STRING, allowNull: false })
	public promptKey: string;

	@Column({ field: 'model', type: DataType.STRING, allowNull: false })
	public model: string;

	@Column({ field: 'request', type: DataType.JSON, allowNull: false })
	public request: { system: string; user: string };

	@Column({ field: 'response', type: DataType.TEXT, allowNull: true })
	public response: string | null;

	@Column({ field: 'status', type: DataType.STRING, allowNull: false })
	public status: string;

	@Column({ field: 'incomplete_reason', type: DataType.STRING, allowNull: true })
	public incompleteReason: string | null;

	@Column({ field: 'error_message', type: DataType.TEXT, allowNull: true })
	public errorMessage: string | null;

	@Column({ field: 'duration_ms', type: DataType.INTEGER, allowNull: false })
	public durationMs: number;

	@Column({ field: 'input_tokens', type: DataType.INTEGER, allowNull: true })
	public inputTokens: number | null;

	@Column({ field: 'output_tokens', type: DataType.INTEGER, allowNull: true })
	public outputTokens: number | null;

	@Column({ field: 'total_tokens', type: DataType.INTEGER, allowNull: true })
	public totalTokens: number | null;

	@Column({ field: 'request_id', type: DataType.STRING, allowNull: true })
	public requestId: string | null;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({
		field: 'created_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({
		field: 'updated_on',
		allowNull: false,
		type: 'TIMESTAMP',
		defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)'),
	})
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
