export const ALLEGATIONS_SCHEMA = {
	type: 'object',
	properties: {
		allegations: {
			type: 'array',
			items: {
				type: 'object',
				properties: {
					label: { type: 'string' },
					description: { type: 'string' },
				},
				required: ['label', 'description'],
				additionalProperties: false,
			},
		},
	},
	required: ['allegations'],
	additionalProperties: false,
} as const;

export const REVIEW_SCHEMA = {
	type: 'object',
	properties: {
		score: { type: 'number' },
		gaps: { type: 'array', items: { type: 'string' } },
		improved: { type: 'string' },
		summary: { type: 'string' },
	},
	required: ['score', 'gaps', 'improved', 'summary'],
	additionalProperties: false,
} as const;

export const ANALYTICS_SCHEMA = {
	type: 'object',
	properties: {
		insights: { type: 'array', items: { type: 'string' } },
		patterns: { type: 'array', items: { type: 'string' } },
		summary: { type: 'string' },
	},
	required: ['insights', 'patterns', 'summary'],
	additionalProperties: false,
} as const;

export const SUGGESTIONS_SCHEMA = {
	type: 'object',
	properties: {
		suggestions: { type: 'array', items: { type: 'string' } },
	},
	required: ['suggestions'],
	additionalProperties: false,
} as const;
