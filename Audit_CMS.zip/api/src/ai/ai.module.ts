import { Module } from '@nestjs/common';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { AiPromptRepository, AiUsageLogRepository } from './repositories';
import { SetupModule } from 'src/setup/setup.module';

@Module({
	imports: [SetupModule],
	controllers: [AiController],
	providers: [AiService, AiPromptRepository, AiUsageLogRepository],
	exports: [AiService],
})
export class AiModule {}
