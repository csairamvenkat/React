import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RequestContext } from 'src/shared/types';
import { SYSTEM_USER } from 'src/shared/constants';
import { AiService } from './ai.service';
import {
	AiDraftRequestDto,
	AiClassifyRequestDto,
	AiRecommendRequestDto,
	AiReviewRequestDto,
	AiAnalyticsRequestDto,
} from './dtos/ai-request.dto';

@ApiTags('AI Capability APIs')
// @ApiBearerAuth()
// @UseGuards(AuthGuard('oauth-bearer'))
@Controller('ai')
export class AiController {
	constructor(private readonly aiService: AiService) {}

	@Get('test-connection')
	testConnection(@Req() request: RequestContext) {
		return this.aiService.testConnection(request.currentContext ?? SYSTEM_USER);
	}

	@Post('draft')
	draft(@Body() dto: AiDraftRequestDto, @Req() request: RequestContext) {
		return this.aiService.draft(dto, request.currentContext ?? SYSTEM_USER);
	}

	@Post('classify')
	classify(@Body() dto: AiClassifyRequestDto, @Req() request: RequestContext) {
		return this.aiService.classify(dto, request.currentContext ?? SYSTEM_USER);
	}

	@Post('recommend')
	recommend(@Body() dto: AiRecommendRequestDto, @Req() request: RequestContext) {
		return this.aiService.recommend(dto, request.currentContext ?? SYSTEM_USER);
	}

	@Post('review')
	review(@Body() dto: AiReviewRequestDto, @Req() request: RequestContext) {
		return this.aiService.review(dto, request.currentContext ?? SYSTEM_USER);
	}

	@Post('analytics')
	analytics(@Body() dto: AiAnalyticsRequestDto, @Req() request: RequestContext) {
		return this.aiService.analytics(dto, request.currentContext ?? SYSTEM_USER);
	}
}
