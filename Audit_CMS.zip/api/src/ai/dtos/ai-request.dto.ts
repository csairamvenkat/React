import { IsEnum, IsObject, IsOptional, IsString } from 'class-validator';
import { DraftAction, ClassifyAction, RecommendAction, ReviewAction } from '../enums';

export { DraftAction, ClassifyAction, RecommendAction, ReviewAction } from '../enums';

export class AiDraftRequestDto {
  @IsEnum(DraftAction)
  action: DraftAction;

  @IsObject()
  context: Record<string, any>;
}

export class AiClassifyRequestDto {
  @IsEnum(ClassifyAction)
  action: ClassifyAction;

  @IsObject()
  context: Record<string, any>;
}

export class AiRecommendRequestDto {
  @IsEnum(RecommendAction)
  action: RecommendAction;

  @IsObject()
  context: Record<string, any>;
}

export class AiReviewRequestDto {
  @IsEnum(ReviewAction)
  action: ReviewAction;

  @IsString()
  content: string;

  @IsObject()
  @IsOptional()
  context?: Record<string, any>;
}

export class AiAnalyticsRequestDto {
  @IsObject()
  context: Record<string, any>;
}
