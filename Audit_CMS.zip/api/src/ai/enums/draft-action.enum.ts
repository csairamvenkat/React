export enum DraftAction {
  ALLEGATION_FIRST_DRAFT = 'allegation_first_draft',
  SYNOPSIS_CONCLUSION = 'synopsis_conclusion',
  DASHBOARD_SUBJECT = 'dashboard_subject',
  RESULT_ENHANCE = 'result_enhance',
  REMEDIATION_ENHANCE = 'remediation_enhance',
  RECOMMENDATION_ENHANCE = 'recommendation_enhance',
}
