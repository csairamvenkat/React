export enum ClassifyAction {
  OVERALL_INCIDENT_TYPE = 'overall_incident_type',
  ALLEGATION_INCIDENT_TYPE = 'allegation_incident_type',
  FRAUD_RISK_IDENTIFICATION = 'fraud_risk_identification',
}
