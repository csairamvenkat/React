export enum RecommendAction {
  SCOPE_SUGGESTIONS = 'scope_suggestions',
  PROCEDURE_SUGGESTIONS = 'procedure_suggestions',
}
