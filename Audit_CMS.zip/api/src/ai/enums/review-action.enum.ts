export enum ReviewAction {
  ALLEGATION_REVIEW = 'allegation_review',
  RESULT_REVIEW = 'result_review',
  REMEDIATION_REVIEW = 'remediation_review',
  RECOMMENDATION_REVIEW = 'recommendation_review',
}
