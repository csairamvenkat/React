import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { AiPrompt } from '../models';

@Injectable()
export class AiPromptRepository extends BaseRepository<AiPrompt> {
	constructor() {
		super(AiPrompt);
	}

	public findByKey(promptKey: string): Promise<AiPrompt | null> {
		return this.findOne({ where: { promptKey } });
	}
}
