import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { AiUsageLog } from '../models';
import { CurrentContext } from '@/shared/types';

@Injectable()
export class AiUsageLogRepository extends BaseRepository<AiUsageLog> {
	constructor() {
		super(AiUsageLog);
	}

	public async createUsageLog(
		usageLogData: Partial<AiUsageLog>,
		currentContext: CurrentContext,
	): Promise<AiUsageLog> {
		return this.save(usageLogData as AiUsageLog, currentContext);
	}
}
