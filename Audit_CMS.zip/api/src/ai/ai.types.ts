export type AiOutputFormat =
	| { kind: 'text' }
	| { kind: 'json_object' }
	| { kind: 'json_schema'; name: string; schema: Record<string, unknown> };

export const textFormat = (): AiOutputFormat => ({ kind: 'text' });
export const jsonObjectFormat = (): AiOutputFormat => ({ kind: 'json_object' });
export const jsonSchemaFormat = (
	name: string,
	schema: Record<string, unknown>,
): AiOutputFormat => ({
	kind: 'json_schema',
	name,
	schema,
});

export interface AiActionInput {
	context: Record<string, any>;
	content?: string;
}

export interface AiActionDeps {
	getIncidentTypes(): Promise<string>;
}

export interface AiActionDefinition<TResult> {
	promptKey: string;
	format: AiOutputFormat;
	buildSystemVars?: (
		input: AiActionInput,
		deps: AiActionDeps,
	) => Promise<Record<string, any>> | Record<string, any>;
	buildUserVars?: (input: AiActionInput) => Record<string, any>;
	shapeResult: (raw: string, parsed: any, input: AiActionInput) => TResult;
}

export function extractJsonArray(raw: string): any[] {
	try {
		const match = raw.match(/\[[\s\S]*\]/);
		return match ? JSON.parse(match[0]) : [];
	} catch {
		return [];
	}
}
