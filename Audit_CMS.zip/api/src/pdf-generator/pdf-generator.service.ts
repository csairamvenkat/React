import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as Handlebars from 'handlebars';
import path from 'path';
import * as puppeteer from 'puppeteer';
import { currencyFormatter, formatDateString, formatDateStringDDMMYY } from 'src/shared/helpers';

@Injectable()
export class PdfGeneratorService {
	constructor() {
		this.setCustomHandlebarsHelpers();
	}

	public async generatePdf(data: any, templateName: string): Promise<Buffer> {
		const templatePath = path.join(__dirname, `templates/${templateName}.hbs`);
		const template = Handlebars.compile(fs.readFileSync(templatePath, 'utf8'));
		const html = template(data);
		const browser = await puppeteer.launch({
			headless: true,
			args: ['--font-render-hinting=none', '--no-sandbox', '--disable-setuid-sandbox'],
		});
		const page = await browser.newPage();

		await page.setContent(html);

		const pdf = await page.pdf({
			format: 'A4',
			printBackground: true,
			landscape: true,
			margin: {
				top: '20px',
				bottom: '20px',
				left: '20px',
				right: '20px',
			},
		});

		await browser.close();

		return Buffer.from(pdf);
	}

	private setCustomHandlebarsHelpers() {
		Handlebars.registerHelper('eq', (value1, value2) => value1 === value2);
		Handlebars.registerHelper('neq', (value1, value2) => value1 !== value2);
		Handlebars.registerHelper('or', (value1, value2) => value1 || value2);
		Handlebars.registerHelper('and', (value1, value2) => value1 && value2);
		Handlebars.registerHelper('contains', (str, substr) => str?.indexOf(substr) !== -1);
		Handlebars.registerHelper('formattedCurrency', (amount, currency) =>
			currencyFormatter(amount, currency),
		);
		Handlebars.registerHelper('formattedDate', date => formatDateString(date));
		Handlebars.registerHelper('formattedDateDDMMYY', date => formatDateStringDDMMYY(date));
		Handlebars.registerHelper('translation', (translations, lang) => translations[lang || 'en']);
		Handlebars.registerHelper('joinStrings', arr => arr.join(', '));
		Handlebars.registerHelper('formatDate', date => (!date ? '' : formatDateString(date)));
		Handlebars.registerHelper('formatCurrency', amount => {
			if (!amount && amount !== 0) return '0.00';

			return new Intl.NumberFormat('en-US', {
				minimumFractionDigits: 2,
				maximumFractionDigits: 2,
			}).format(amount);
		});
		Handlebars.registerHelper('inc', value => parseInt(value) + 1);
		Handlebars.registerHelper('add', (a, b) => (a || 0) + (b || 0));
		Handlebars.registerHelper('calculatePercentage', (value, total) => {
			if (!total || total === 0) return 0;

			return parseFloat(((value / total) * 100).toFixed(2));
		});

		Handlebars.registerHelper('calculateSubtotal1', payments => {
			const originalContract = payments.originalContract || 0;
			const variationOrders = payments.variationOrders || 0;
			const addendum = payments.addendum || 0;
			let otherPaymentsTotal = 0;

			if (Array.isArray(payments.otherPaymentsDetails)) {
				otherPaymentsTotal = payments.otherPaymentsDetails.reduce(
					(sum, detail) => sum + (detail.amount || 0),
					0,
				);
			}

			return originalContract + variationOrders + addendum + otherPaymentsTotal;
		});

		Handlebars.registerHelper('calculateSubtotal2', payments => {
			const retentionDeduction = payments.retentionDeduction || 0;
			const adRecoveryDeduction = payments.adRecoveryDeduction || 0;
			let otherDeductionTotal = 0;

			if (Array.isArray(payments.otherDeductionDetails)) {
				otherDeductionTotal = payments.otherDeductionDetails.reduce(
					(sum, detail) => sum + (detail.amount || 0),
					0,
				);
			}

			return retentionDeduction + adRecoveryDeduction + otherDeductionTotal;
		});

		Handlebars.registerHelper('calculateSubtotal3', payments => {
			const releaseOfRetention = payments.releaseOfRetention || 0;
			let otherAdjustmentsTotal = 0;

			if (Array.isArray(payments.otherAdjustmentsDetails)) {
				otherAdjustmentsTotal = payments.otherAdjustmentsDetails.reduce(
					(sum, detail) =>
						sum +
						(detail.deductionType == 'DEDUCTION' ? -1 * (detail.amount ?? 0) : detail.amount ?? 0),
					0,
				);
			}

			return releaseOfRetention + otherAdjustmentsTotal;
		});

		Handlebars.registerHelper('calculateGrossPayment', payments => {
			const subtotal1 = Handlebars.helpers.calculateSubtotal1(payments);
			const subtotal2 = Handlebars.helpers.calculateSubtotal2(payments);
			const subtotal3 = Handlebars.helpers.calculateSubtotal3(payments);

			return payments.advancedPayments + subtotal1 - subtotal2 + subtotal3;
		});

		Handlebars.registerHelper('calculateNetAmount', payments => {
			const grossPayment = Handlebars.helpers.calculateGrossPayment(payments);
			const previouslyPaidAmount = payments.previouslyPaidAmount || 0;

			return grossPayment - previouslyPaidAmount;
		});

		Handlebars.registerHelper('calculateTotalPayment', payments => {
			const netAmount = Handlebars.helpers.calculateNetAmount(payments);
			const tax = payments.tax || 0;

			return netAmount + tax;
		});
	}
}
