export const NOTIFICATION_TITLES = {
	BOND_SUBMIT: {
		SUBMITTER: 'Bond Submitted for approval',
		SUBSCRIBER: 'New Bond Approval request',
	},
};

export const NOTIFICATION_URLS = {
	BOND_DETAILS_URL: 'bonds/detail/{id}',
};
