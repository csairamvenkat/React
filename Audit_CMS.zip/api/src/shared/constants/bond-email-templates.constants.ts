export const BondEmailTemplates = {
	CREATE: 'GGPMD.BOND.CREATED',
	REJECTED: 'GPPMD.BOND.REJECTED',
};
