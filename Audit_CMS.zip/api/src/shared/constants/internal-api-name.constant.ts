export class INTERNAL_API {
	public static readonly ADMIN_API_PROVIDER = 'ADMIN_API';
	public static readonly REQUEST_API_PROVIDER = 'REQUEST_API';
	public static readonly NOTIFICATION_API_PROVIDER = 'NOTIFICATION_API';
}
