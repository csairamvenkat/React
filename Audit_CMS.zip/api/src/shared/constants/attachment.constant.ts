export const ATTACHMENT_REL_PATH = {
	CHANGE_REQUEST_SIGNATURE: 'change-request/{entity_id}/signature',
	CHANGE_REQUEST_SUPPPORT_DOCS: 'change-request/{entity_id}/support-docs',
	APG_ADJUSTMENT: 'bond/{entity_id}/signature',
	PAYMENT: 'payment/{entity_id}/signature',
	TAKING_OVER_CERTIFICATE_SIGNED_CERTIFICATE:
		'taking-over-certificate/{entity_id}/signed-certificate',
	PERFORMANCE_CERTIFICATE_SIGNED_CERTIFICATE:
		'performance-certificate/{entity_id}/signed-certificate',
	VARIATION_ORDER_SIGNATURE: 'variation-order/{entity_id}/signature',
	VENDOR_REGION_SLA: 'vendor-region/{entity_id}/sla-document',
	VENDOR_REGION_NDA: 'vendor-region/{entity_id}/nda-document',
};
