/**
 * The `business_entity_id` sent to the admin API when a case has no entity of its own and
 * the caller has not selected one either — an unscoped lookup rather than a refusal.
 *
 * Navex-imported cases have no `business_entity_id`: the sync mirrors what Navex sends, and
 * Navex has no concept of a CMS business entity (it carries a location name and, for about
 * one case in nine, an Argus id — neither of which maps to an entity id). Scoping their
 * role lookups to an entity is therefore impossible, and treating that as "no approvers
 * configured" left every imported case unable to request HFRS approval.
 *
 * Note this makes the lookup unscoped, not hierarchy-aware: it asks the admin API for role
 * holders without narrowing to a branch. Give imported cases a real entity and the normal
 * ancestor-chain resolution in `RoleService.getUsersDetailsByRoleForEntityHierarchy` takes
 * over again — this only applies when there is nothing better to ask with.
 */
export const UNSCOPED_ENTITY_ID = 0;
