export const CMS_TASK_TERMINAL_STATUSES: string[] = [
	'completed',
	'complete',
	'cancelled',
	'canceled',
	'closed',
	'rejected',
];
