export enum APP_URL {
	SUBMIT_REQUEST = '/cms/submit/{#id#}',
	CMS_CASE_DETAIL = 'case-management/{#id#}',
	CMS_TASK_REVIEW = 'my-task/review/{#id#}',
}
