export enum ENV {
	DEV = 'dev',
	PROD = 'prod',
	STAGING = 'staging',
}
