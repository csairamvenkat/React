export enum PERMISSIONS {
	CASE_SUBMIT = 'Case.Submit',
	CASE_VIEW = 'Case.View',
	CASE_MANAGE = 'Case.Manage',
	GLOBAL_ADMIN = 'Global.Admin',
}
