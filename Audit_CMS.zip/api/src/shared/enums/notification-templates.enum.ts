export enum NOTIFICATION_TEMPLATES {
	CMS_SUBMIT = 'CMS.Submit',
	CMS_TASK_ASSIGNED = 'CMS.TaskAssigned',
	CMS_WORK_ASSIGNED = 'CMS.WorkAssigned',
	CMS_DELEGATION = 'CMS.Delegation',
}
