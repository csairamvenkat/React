export enum CURRENCY {
	EUR = 'EUR',
	USD = 'USD',
	AED = 'AED',
	EGP = 'EGP',
}
