export enum AD_USER_TYPE {
	GUEST = 'Guest',
	MEMBER = 'Member',
}
