import { AuthTokenPayload } from './auth-token-payload.type';
import { Language } from './language-keys.type';

export type NonAuthTokenUser = {
	family_name?: string;
	given_name?: string;
	name?: string;
	unique_name?: string;
	upn?: string;
	username: string;
	email?: string;
};

export type SystemContext = {
	username: string;
};

export type CurrentContext = {
	user: AuthTokenPayload | NonAuthTokenUser;
	entityId: number;
	locations?: number[];
	lang?: Language;
};
