import { LogLevel } from '@nestjs/common/services';

export interface DatabaseConfig {
	host: string;
	port: number;
	username: string;
	password: string;
	db: string;
	dialect: string;
	schema: string;
	enableSSL: boolean;
}

export interface AzureADConfig {
	authority: string;
	tennantId: string;
	clientId: string;
	clientSecret: string;
	version: string;
	discovery: string;
	audience: string;
	graphApiUrl: string;
	graphApiVersion: string;
	scope: string[];
}

export interface B2CAzureConfig {
	authority: string;
	tennantId: string;
	clientId: string;
	clientSecret: string;
	version: string;
	discovery: string;
	audience: string;
	graphApiUrl: string;
	graphApiVersion: string;
	issuer: string;
	scope: string[];
	login: {
		authority: string;
		policyName: string;
		scope: string[];
		issuer: string;
	};
}

export interface SwaggerConfig {
	user: string;
	password: string;
}

export interface MicroserviceConfig {
	url: string;
	tennantId?: string;
	appId?: string;
	Authorization?: string;
}

export interface MicroservicesConfig {
	adminApi: MicroserviceConfig;
	requestApi: MicroserviceConfig;
	notificationApi: MicroserviceConfig;
	afeApi: MicroserviceConfig & { apiKey: string };
}

export interface AppConfig {
	database: DatabaseConfig;
	azureAD: AzureADConfig;
	swagger: SwaggerConfig;
	microservices: MicroservicesConfig;
	uiClient: {
		baseUrl: string;
		task: TaskConfig;
	};
	businessEntityLevelForProjectReferenceNumber: string;
	webClientConfig: WebClientConfig;
	logLevel: LogLevel[];
	environment?: string;
	apiKey: string;
	groupId: number;
	defaultLangauge: string;
	googleTranslationKey: string;
	azureOpenAI: AzureOpenAIConfig;
	navex: NavexConfig;
}

export interface NavexConfig {
	baseUrl: string;
	clientId: string;
	clientSecret: string;
	backfillFrom: string;
	watermarkOverlapDays: number;
	searchWindowDays: number;
	detailConcurrency: number;
	batchSize: number;
	dryRun: boolean;
}

export interface AzureOpenAIConfig {
	endpoint: string;
	apiKey: string;
	deployment: string;
}

export interface TaskConfig {
	relativeUrl: string;
}

export interface WebClientConfig {
	apiBaseUrl: string;
	msDetail: MsDetail;
	version: string;
}

export interface MsDetail {
	authority: string;
	clientId: string;
	redirectUrl: string;
	scope: string[];
	graphUrl: string;
	graphScope: string[];
}
