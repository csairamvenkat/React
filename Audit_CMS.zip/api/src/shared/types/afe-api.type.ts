export interface AfeProposalSearchRequest {
	afeNumber: string;
}

export interface AfeProposal {
	afeLink: string;
	afeNumber: string;
	currency: string;
	amount: number;
}

export type AfeProposalSearchResponse = AfeProposal[];
