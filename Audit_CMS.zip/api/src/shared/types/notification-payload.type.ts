import { NOTIFICATION_TYPE } from '../enums';

export interface NotificationPayload {
	title: string;
	description?: string;
	url: string;
	expireAt: Date;
	type: NOTIFICATION_TYPE;
	subscribers: string[];
}
