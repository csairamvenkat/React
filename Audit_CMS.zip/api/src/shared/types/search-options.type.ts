import { Includeable, OrderItem } from 'sequelize';
import { Col, Fn, Literal } from 'sequelize/types/utils';

export type SearchOptions = {
	limit?: number;
	startId?: number;
	order?: Fn | Col | Literal | OrderItem[];
	include?: Includeable[];
};
