export interface GenerateNextSequenceNumberRequest {
	prefix: string;
	meta_data_1?: string;
	meta_data_2?: string;
	meta_data_3?: string;
}

export interface GenerateNextSequenceNumberRequest {
	prefix: string;
	meta_data_1?: string;
	meta_data_2?: string;
	meta_data_3?: string;
}

interface AdditionalInfo {
	filter_param?: {
		request_type_id?: number;
	};
}

export interface AddNewDelegationRequest {
	delegate_for_username: string;
	delegate_to_username: string;
	delegate_from_date: Date;
	delegate_to_date: Date;
	created_by: string;
	type?: 'default' | 'representative';
	additional_info?: AdditionalInfo;
}

export interface UpdateDelegationRequest {
	id: number;
	delegate_to_username: string;
	delegate_from_date: string;
	delegate_to_date: string;
	created_by: string;
	additional_info?: AdditionalInfo;
}

export interface DeleteDelegationRequest {
	id: number;
	created_by: string;
}

export interface RemoveAllDelegationRequest {
	user_name: string;
	created_by: string;
}

export interface UpcomingDelegationRequest {
	user_name: string;
	type?: DelegationType;
}

export type DelegationType = 'default' | 'representative' | 'all';
