type JSONValue = string | number | boolean | JSON | JSONArray;

export interface JSONObject {
	[x: string]: JSONValue;
}

export interface JSONArray extends Array<JSONValue> {}
