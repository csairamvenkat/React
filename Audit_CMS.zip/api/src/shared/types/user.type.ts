export interface UserType {
	id: string;
	mail: string;
	surname: string;
	jobTitle: string;
	givenName: string;
	displayName: string;
	userPrincipalName: string;
	loginId: string;
	userType: string;
}
