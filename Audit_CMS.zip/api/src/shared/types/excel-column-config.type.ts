export type ExcelColumnConfig = {
	columnName: string;
	key: string;
	width?: number;
	outlineLevel?: number;
	numFmt?: string;
};
