export type ADUserDetails = {
	id: string;
	givenName: string;
	jobTitle: string;
	surname: string;
	mail: string;
	userPrincipalName: string;
	userType: string;
	displayName: string;
};
