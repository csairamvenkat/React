export interface Parameters {
	throwException?: boolean;
}

export interface FindParameters extends Parameters {
	includeDeleted?: boolean;
	includeInactive?: boolean;
}

export interface MutationParameters extends Parameters {
	includeDeleted?: boolean;
	includeInactive?: boolean;
}
