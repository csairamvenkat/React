export type UserDetails = {
	userId: string;
	firstName: string;
	lastName: string;
	email?: string;
};
