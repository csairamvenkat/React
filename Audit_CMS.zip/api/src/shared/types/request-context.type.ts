import { Request } from 'express';
import { CurrentContext } from './current-context.type';

export type RequestContext = Request & { currentContext: CurrentContext };
