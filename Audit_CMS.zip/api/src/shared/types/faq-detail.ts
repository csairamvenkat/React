interface FaqQuestionAnswer {
	question: string;
	answer: string;
}

export interface FaqDetail {
	[language: string]: FaqQuestionAnswer;
}
