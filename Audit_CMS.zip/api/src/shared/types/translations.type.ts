import { Language } from './language-keys.type';

export type Translations = {
	[key in Language]: string;
};
