export interface HttpResponse {
	data;
	headers: any;
	status: number;
}
