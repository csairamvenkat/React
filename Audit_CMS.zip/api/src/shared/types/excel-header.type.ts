export type ExcelHeader = {
	headerName: string;
	key: string;
	width?: number;
	outlineLevel?: number;
};
