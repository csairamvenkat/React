export type PermissionType = string & { checkEntity: boolean };
