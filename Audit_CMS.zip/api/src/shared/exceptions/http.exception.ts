import { HttpException as Exception } from '@nestjs/common';

export class HttpException extends Exception {
	constructor(message: string, status: number) {
		super(message, status);
	}
}
