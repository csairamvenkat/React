export * from './base-repo.interface';
