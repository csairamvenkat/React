import { Injectable } from '@nestjs/common';
import { AdminApiClient, TaskApiClient } from '../clients';
import { CurrentContext } from '../types';

@Injectable()
export class CommonService {
	constructor(
		private readonly adminApiClient: AdminApiClient,
		private readonly taskApiClient: TaskApiClient,
	) {}

	public async validateTask(taskId: number, currentContext: CurrentContext) {
		if (taskId) {
			var task = await this.taskApiClient.getTaskById(taskId);
			const { assigned_to, is_group_assignment, entity_id, business_entity_id } = task;
			if (task.task_status === 'Not Started') {
				if (is_group_assignment) {
					const isUserInGroup = await this.adminApiClient.hasUserRole(
						currentContext.user.username,
						assigned_to,
						business_entity_id,
					);
					if (!isUserInGroup) {
						return { task: task, valid: false };
					}
				} else if (assigned_to?.toLowerCase() !== currentContext.user.username.toLowerCase()) {
					return { task: task, valid: false };
				}
				return { task: task, valid: true };
			}
		}
		return { task: task, valid: false };
	}
}
