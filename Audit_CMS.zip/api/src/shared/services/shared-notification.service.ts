import { Injectable } from '@nestjs/common';
import { AdminApiClient, NotificationApiClient } from '../clients';
import { templatePlaceholderReplacer } from '../helpers/template-placeholder-replacer.helper';
import { AttachmentData, SendNotificationRequest } from '../types';
import { currentDateInDDMMYYYY } from '../helpers';

@Injectable()
export class SharedNotificationService {
	constructor(
		private readonly adminApiClient: AdminApiClient,
		private readonly notificationApiClient: NotificationApiClient,
	) {}

	/**
	 * Send notification
	 * @param schedulerId
	 * @param recipients
	 * @param templateName
	 * @param placeholderValues
	 */
	public async sendNotification(
		entityId: number,
		entityType: string,
		recipients: { to: string[]; cc?: string[]; bcc?: string[] },
		templateName: string,
		placeholderValues: { [key: string]: any },
		isApprovalEmail: boolean = false,
		approvalTaskId?: number,
		subjectPrefix: string = '',
		attachments?: AttachmentData[],
	): Promise<void> {
		const { to, cc, bcc } = recipients;
		const templateDetails = await this.adminApiClient.getNotificationTemplate(templateName);
		const { body, subject } = templateDetails;
		placeholderValues = { ...placeholderValues, current_date: currentDateInDDMMYYYY() };

		const subjectWithReplacedPlaceholderValues = templatePlaceholderReplacer(
			subject,
			placeholderValues,
		);

		const bodyWithReplacedPlaceholderValues = templatePlaceholderReplacer(body, placeholderValues);
		const payload: SendNotificationRequest = {
			entity_id: entityId,
			entity_type: entityType,
			subject: subjectPrefix + subjectWithReplacedPlaceholderValues,
			is_approval_email: isApprovalEmail,
			receiver: to.join(';'),
			...(!!cc && { cc: cc.join(';') }),
			...(!!bcc && { bcc: bcc.join(';') }),
			...(!!approvalTaskId && { approval_task_id: approvalTaskId }),
			body: bodyWithReplacedPlaceholderValues,
			attachments,
		};
		await this.notificationApiClient.sendNotification(payload);
	}

	/**
	 * Send the calendar invite.
	 * @param entityId
	 * @param entityType
	 * @param recipients
	 * @param templateName
	 * @param duration
	 * @param isTeamsMeeting
	 * @param placeholderValues
	 */
	public async sendCalendarInvite(
		entityId: number,
		entityType: string,
		recipients: { to: string[]; cc?: string[]; bcc?: string[] },
		templateName: string,
		duration: { from: Date; to: Date },
		placeholderValues: { [key: string]: string },
		attachments?: AttachmentData[],
		isTeamsMeeting: boolean = false,
	): Promise<void> {
		const { to, cc, bcc } = recipients;
		const templateDetails = await this.adminApiClient.getNotificationTemplate(templateName);
		const { body, subject } = templateDetails;
		placeholderValues = { ...placeholderValues, current_date: currentDateInDDMMYYYY() };

		const subjectWithReplacedPlaceholderValues = templatePlaceholderReplacer(
			subject,
			placeholderValues,
		);

		const bodyWithReplacedPlaceholderValues = templatePlaceholderReplacer(body, placeholderValues);
		const payload: SendNotificationRequest = {
			subject: subjectWithReplacedPlaceholderValues,
			is_approval_email: false,
			entity_id: entityId,
			entity_type: entityType,
			receiver: to.join(';'),
			...(!!cc && { cc: cc.join(';') }),
			...(!!bcc && { bcc: bcc.join(';') }),
			body: bodyWithReplacedPlaceholderValues,
			is_calendar_invite: true,
			is_teams_meeting: isTeamsMeeting,
			start_date: duration.from,
			end_date: duration.to,
			attachments,
		};
		await this.notificationApiClient.sendNotification(payload);
	}
}
