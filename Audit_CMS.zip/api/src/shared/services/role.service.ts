import { Injectable } from '@nestjs/common';
import { AdminApiClient, MSGraphApiClient } from '../clients';
import { ADUserDetails } from '../types';

@Injectable()
export class RoleService {
	constructor(
		private readonly adminApiClient: AdminApiClient,
		private readonly mSGraphApiClient: MSGraphApiClient,
	) {}

	/**
	 * Get users email by role.
	 * @param role
	 * @param entityId
	 * @returns
	 */
	public async getUsersIdsByRoleAndEntityId(role: string, entityId: number): Promise<string[]> {
		const users = await this.adminApiClient.getUsersByRoleOfAnEntity(role, entityId);
		return users?.map(user => user.user_name.toLowerCase());
	}

	/**
	 * Get users emails by user ids.
	 * @param role
	 * @param entityId
	 * @returns
	 */
	public async getEmailsByUserIds(ids: string[]): Promise<string[]> {
		const approversAdDetails = ids.length ? await this.mSGraphApiClient.getUsersDetails(ids) : [];
		return approversAdDetails?.map(user => user.mail);
	}

	/**
	 * Get users email by role.
	 * @param role
	 * @param entityId
	 * @returns
	 */
	public async getUsersEmailByRoleAndEntityId(role: string, entityId: number): Promise<string[]> {
		const userEmails: string[] = [];
		const userAdDetails = await this.getUsersDetailsByRoleAndEntityId(role, entityId);
		userEmails.push(...userAdDetails.map(user => user.mail));
		return userEmails;
	}

	/**
	 * Get users details by role.
	 * @param role
	 * @param entityId
	 * @returns
	 */
	public async getUsersDetailsByRoleAndEntityId(
		role: string,
		entityId: number,
	): Promise<ADUserDetails[]> {
		const users = await this.adminApiClient.getUsersByRoleOfAnEntity(role, entityId);
		const approverIds = users?.map(user => user.user_name.toLowerCase());
		const approversAdDetails = approverIds.length
			? await this.mSGraphApiClient.getUsersDetails(approverIds)
			: [];
		return approversAdDetails;
	}

	/**
	 * Get user details for everyone holding `role` that is EFFECTIVE for the given entity —
	 * i.e. assigned at the entity itself or any of its ancestors. Role authority is inherited
	 * down the hierarchy, but `getUsersByRoleOfAnEntity` only returns users assigned directly
	 * at the queried entity, so this unions the results across the entity's ancestor chain.
	 * @param role
	 * @param entityId
	 */
	public async getUsersDetailsByRoleForEntityHierarchy(
		role: string,
		entityId: number,
	): Promise<{ loginIds: string[]; users: ADUserDetails[] }> {
		const chain = await this.adminApiClient.getParentIdsOfEntity(entityId).catch(() => []);
		const entityIds = chain?.length ? [...new Set([...chain, entityId])] : [entityId];
		const perLevel = await Promise.all(
			entityIds.map(eid =>
				this.adminApiClient.getUsersByRoleOfAnEntity(role, eid).catch(() => [] as { user_name: string }[]),
			),
		);
		const loginIds = [
			...new Set(perLevel.flat().map(u => u?.user_name?.toLowerCase()).filter(Boolean)),
		] as string[];
		const users = loginIds.length ? await this.mSGraphApiClient.getUsersDetails(loginIds) : [];
		return { loginIds, users };
	}

	/* Get users email by role and entity ids.
	 * @param role
	 * @param entityIds
	 * @returns
	 */
	public async getUsersIdsByRoleAndEntityIds(role: string, entityIds: number[]): Promise<string[]> {
		const allUsers = [];
		for (const entityId of entityIds) {
			const users = await this.adminApiClient.getUsersByRoleOfAnEntity(role, entityId);
			allUsers.push(...users);
		}
		return allUsers?.map(user => user.user_name.toLowerCase());
	}
}
