import { Injectable } from '@nestjs/common';
import { ExcelSheetService } from './excel-sheet.service';

@Injectable()
export class ReportService {
	constructor(private readonly excelSheetService: ExcelSheetService) { }

	public async returnReportExcel(selectedColumns: string[], reportData, sheetName: string) {
		if (selectedColumns?.length) {
			reportData = reportData.map(item => {
				return Object.fromEntries(
					Object.entries(item).filter(([key]) => selectedColumns.includes(key)),
				);
			});
		} else {
			reportData = reportData.map(item => {
				return Object.fromEntries(Object.entries(item));
			});
		}
		const report = await this.excelSheetService.createExcelSheet(reportData, sheetName);
		return { report, filename: sheetName };
	}
}
