import { Injectable } from '@nestjs/common';
import * as Excel from 'exceljs';

@Injectable()
export class ExcelSheetService {
	constructor() { }

	/**
	 * Configures a workbook to prevent macros
	 * This ensures the workbook is created in a macro-free format (.xlsx, not .xlsm)
	 */
	private configureSecureWorkbook(workbook: Excel.Workbook): void {
		// Set workbook properties to disable macros
		workbook.properties = {
			...workbook.properties,
			// Ensure no VBA project is created
			// ExcelJS creates .xlsx files by default which don't support macros
		};

		// Remove any VBA project if it somehow exists
		delete (workbook as any).vbaProject;
		delete (workbook as any).vba;
	}

	/**
	 * Validates that a formula is safe and doesn't contain macro-related functions
	 * @param formula - The formula to validate
	 * @returns True if the formula is safe, false otherwise
	 */
	private isSafeFormula(formula: string): boolean {
		if (!formula || typeof formula !== 'string') {
			return true;
		}

		// List of dangerous Excel functions that can execute external code or macros
		const dangerousFunctions = [
			'CALL',
			'REGISTER.ID',
			'REGISTER',
			'EXEC',
			'EVALUATE',
			'GET.WORKSPACE',
			'GET.DOCUMENT',
			'GET.WORKBOOK',
			'GET.WINDOW',
			'GET.CELL',
			'DDEEXECUTE',
			'DDEAUTO',
			'DDETERMINATE',
			'DDEINITIATE',
			'DDEPOKE',
			'DDEREQUEST',
		];

		const formulaUpper = formula.toUpperCase();

		// Check for dangerous functions
		for (const func of dangerousFunctions) {
			if (formulaUpper.includes(func)) {
				return false;
			}
		}

		// Check for external references (links to other workbooks)
		if (formula.includes('[') && formula.includes(']')) {
			return false;
		}

		return true;
	}

	/**
	 * Sanitizes a formula to ensure it's safe
	 * @param formula - The formula to sanitize
	 * @returns Sanitized formula or empty string if unsafe
	 */
	private sanitizeFormula(formula: string): string {
		if (!this.isSafeFormula(formula)) {
			return '';
		}
		return formula;
	}

	/**
	 * Sanitizes a value to prevent Excel injection attacks.
	 * If value starts with =, +, @, or - (non-numeric), prepends a single quote.
	 */
	private sanitizeForExcel(value: any): any {
		// If value is not a string, return it as is
		if (typeof value !== 'string') {
			return value;
		}

		// If value starts with =, +, @, return with prepended single quote
		if (value.startsWith('=') || value.startsWith('+') || value.startsWith('@')) {
			return "'" + value;
		}

		// If value starts with -
		if (value.startsWith('-')) {
			// Check if it is a valid number
			const numValue = Number(value);
			if (!isNaN(numValue)) {
				// It's a valid number, return as is
				return value;
			} else {
				// Not a valid number, prepend single quote
				return "'" + value;
			}
		}

		return value;
	}

	public async createExcelSheet(
		data: { [key: string]: any }[],
		sheetName: string,
		dataValidations: {
			column: string;
			dataList: any[];
			startRow?: number;
			lastRow?: number;
			allowBlank?: boolean;
		}[] = [],
	): Promise<Excel.Buffer> {
		const workbook = new Excel.Workbook();
		this.configureSecureWorkbook(workbook);
		const worksheet = workbook.addWorksheet(sheetName);

		// Get the keys of the first JSON object as column names
		const columns = Object.keys(data[0]);

		// Add the columns to the worksheet
		columns.forEach((column, index) => {
			worksheet.getColumn(index + 1).values = [column];
			const headerCell = worksheet.getCell(1, index + 1);
			headerCell.value = column;
			headerCell.fill = {
				type: 'pattern',
				pattern: 'solid',
				fgColor: { argb: '120553' },
				bgColor: { argb: '120553' },
			};
			headerCell.font = {
				color: { argb: 'FFFFFF' },
				bold: true,
			};
		});

		// Add the values to the worksheet
		data.forEach((data, index) => {
			columns.forEach((column, colIndex) => {
				worksheet.getCell(index + 2, colIndex + 1).value = this.sanitizeForExcel(data[column]);
			});
		});

		//Adjust the column width.
		worksheet.columns.forEach((column, _) => {
			let maxLength = 0;
			column['eachCell']({ includeEmpty: true }, cell => {
				// Set border of each cell
				cell.border = {
					top: { style: 'thin' },
					left: { style: 'thin' },
					bottom: { style: 'thin' },
					right: { style: 'thin' },
				};
				const columnLength = cell.value ? cell.value.toString().length : 5;
				if (columnLength > maxLength) {
					maxLength = columnLength;
				}
			});
			column.width = maxLength < 15 ? 15 : maxLength;
		});

		dataValidations.forEach(dataValidation => {
			for (let i = dataValidation?.startRow || 2; i <= (dataValidation?.lastRow || 100); i++) {
				worksheet.getCell(dataValidation.column + i).dataValidation = {
					type: 'list',
					allowBlank: dataValidation?.allowBlank || true,
					formulae: [`"${dataValidation.dataList.join(',')}"`],
				};
			}
		});

		return workbook.xlsx.writeBuffer();
	}
}
