import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsOptional } from 'class-validator';

export class AttachmentResponseDto {
	@ApiProperty({ type: Number })
	@Expose()
	public id: number;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public attachment_name?: string;

	@ApiProperty({ type: Number })
	@Expose()
	public entity_id: number;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public meta_data_1?: string;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public meta_data_2?: string;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public meta_data_3?: string;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public description?: string;

	@ApiProperty({ type: Object })
	@Expose()
	@IsOptional()
	public additional_info?: object;

	@ApiProperty({ type: String })
	@Expose()
	@IsOptional()
	public file_id?: string;

	@ApiProperty({ type: Buffer })
	@Expose()
	public contents: Buffer;

	@ApiProperty({ type: String })
	@Expose()
	public attachment_content_type: string;

	@ApiProperty({ type: String })
	@Expose()
	public created_by: string;

	@ApiProperty({ type: Date })
	@Expose()
	public created_on: Date;

	@ApiProperty({ type: Boolean })
	@Expose()
	@IsOptional()
	public IsNew?: boolean;

	@ApiProperty({ type: Boolean })
	@Expose()
	@IsOptional()
	public IsEdited?: boolean;
}
