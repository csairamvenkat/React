import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsOptional } from 'class-validator';

export class MessageResponseDto {
	@Expose()
	@ApiProperty()
	public message: string;

	@Expose()
	@ApiProperty()
	@IsOptional()
	public data?: any;
}
