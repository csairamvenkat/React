import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class DropDownItemDTO {
	@ApiProperty()
	@IsNotEmpty()
	public id: string;

	@ApiProperty()
	@IsNotEmpty()
	public value: string;
}
