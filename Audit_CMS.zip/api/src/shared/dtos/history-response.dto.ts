import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { HISTORY_ACTION_TYPE } from 'src/shared/enums';

export class HistoryResponseDto {
	@ApiProperty({ name: 'actionPerformed' })
	@Expose({ name: 'actionPerformed' })
	action_performed: string;

	@ApiProperty({ name: 'actionComments' })
	@Expose({ name: 'actionComments' })
	action_comments: string;

	@ApiProperty({ name: 'actionDate' })
	@Expose({ name: 'actionDate' })
	action_date: Date;

	@ApiProperty({ name: 'additionalInfo' })
	@Expose({ name: 'additionalInfo' })
	additional_info: any;

	@ApiProperty({ name: 'createdBy' })
	@Expose({ name: 'createdBy' })
	created_by: string;

	constructor(partial: Partial<HistoryResponseDto> = {}) {
		Object.assign(this, partial);
	}
}
