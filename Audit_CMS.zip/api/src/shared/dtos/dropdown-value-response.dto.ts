import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DropwDownValueResponseDTO {
	@ApiProperty()
	@Expose()
	public id: number;

	@ApiProperty()
	@Expose()
	public value: string;
}
