import { Column, DataType, Model } from 'sequelize-typescript';

export abstract class BaseModel<T> extends Model<T> {
	@Column({ type: DataType.BIGINT, autoIncrement: true, primaryKey: true })
	public id: number;
}
