export const templatePlaceholderReplacer = (
	str: string,
	replacements: { [key: string]: string },
) => {
	return str.replace(/{{(.*?)}}/g, (placeholderWithDelimiters, placeholderWithoutDelimiters) =>
		replacements.hasOwnProperty(placeholderWithoutDelimiters)
			? replacements[placeholderWithoutDelimiters]
			: placeholderWithDelimiters,
	);
};
