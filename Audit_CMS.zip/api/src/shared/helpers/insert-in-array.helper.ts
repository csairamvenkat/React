export function insert<T>(arr: T[], index: number, item: T) {
	arr.splice(index, 0, item);
	return arr;
}
