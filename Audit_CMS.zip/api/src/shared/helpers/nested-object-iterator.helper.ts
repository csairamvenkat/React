export interface INestedIterator<T> {
	getChildren(): T[];
}

export class NestedIterator {
	public static forEach<T extends INestedIterator<T>>(obj: T, fn: (obj: T) => void): void {
		fn(obj);
		if (obj.getChildren().length) {
			for (const item of obj.getChildren()) {
				NestedIterator.forEach(item, fn);
			}
		}
	}
}
