import { BusinessEntity, BusinessEntityWithChildren } from '../types';

export const findEntityDetailsById = (
	hierarchy: BusinessEntityWithChildren,
	id: number,
): BusinessEntity | null => {
	if (Number(hierarchy.id) === Number(id)) {
		return hierarchy;
	}

	if (hierarchy.children && hierarchy.children.length > 0) {
		for (let i = 0; i < hierarchy.children.length; i++) {
			const foundObject = findEntityDetailsById(hierarchy.children[i], id);
			if (foundObject) {
				return foundObject;
			}
		}
	}
	return null;
};
