export const formatCamelCaseLabel = (label: string): string => {
	return label
		.replace(/([a-z])([A-Z])/g, '$1 $2')
		.replace(/^\w/, c => c.toUpperCase());
};
