export const replaceUrlVariable = (url: string, variables: any) => {
	Object.keys(variables).forEach((variableKey: string) => {
		const re = new RegExp('{' + variableKey + '}', 'g');
		url = url.replace(re, variables[variableKey]);
	});
	return url;
};
