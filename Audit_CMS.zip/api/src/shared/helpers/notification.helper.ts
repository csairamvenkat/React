import moment from 'moment';
export const getNotificationExpiryDate = () => moment().add(7, 'days').toDate();
