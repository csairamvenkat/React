export const formatDateString = (dateStr: string | Date): string => {
	const date = new Date(dateStr);
	const formattedDate = date.toLocaleString('en-US', {
		month: 'short',
		day: 'numeric',
		year: 'numeric',
	});
	return formattedDate;
};

export const formatDateStringDDMMYY = (dateStr: string | Date): string => {
	if (!dateStr) return '';

	const date = new Date(dateStr);
	const day = date.getDate();
	const month = date.getMonth() + 1;
	const year = date.getFullYear();

	return (day < 10 ? '0' : '') + day + '-' + (month < 10 ? '0' : '') + month + '-' + year;
};

export const currentDateInDDMMYYYY = (): string => {
	const currentDate = new Date();
	const day = currentDate.getDate();
	const month = currentDate.getMonth() + 1;
	const year = currentDate.getFullYear();
	return (day < 10 ? '0' : '') + day + '/' + (month < 10 ? '0' : '') + month + '/' + year;
};
