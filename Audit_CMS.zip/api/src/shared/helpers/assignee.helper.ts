export interface AssigneeRef {
	email_id: string;
	full_name: string;
}

function tryParseRef(value: string): AssigneeRef | null {
	const trimmed = value.trim();
	if (!trimmed.startsWith('{')) return null;
	try {
		const obj = JSON.parse(trimmed);
		const email = obj?.email_id ?? obj?.emailId ?? obj?.email ?? null;
		if (!email) return null;
		return {
			email_id: String(email),
			full_name: String(obj?.full_name ?? obj?.fullName ?? email),
		};
	} catch {
		return null;
	}
}

export function parseAssignee(stored: unknown): AssigneeRef | null {
	if (stored == null || stored === '') return null;
	if (typeof stored === 'object') {
		const obj = stored as Record<string, unknown>;
		const email = (obj.email_id ?? obj.emailId ?? obj.email ?? '') as string;
		if (!email) return null;
		return { email_id: String(email), full_name: String(obj.full_name ?? obj.fullName ?? email) };
	}
	const raw = String(stored);
	const ref = tryParseRef(raw);
	if (ref) return ref;
	return { email_id: raw, full_name: raw };
}

export function buildAssignee(input: unknown, name?: string | null): string | null {
	if (input == null || input === '') return null;
	let email: string;
	let full: string;
	if (typeof input === 'object') {
		const ref = parseAssignee(input);
		if (!ref) return null;
		email = ref.email_id;
		full = name ?? ref.full_name;
	} else {
		const raw = String(input);
		const ref = tryParseRef(raw);
		if (ref) {
			email = ref.email_id;
			full = name ?? ref.full_name;
		} else {
			email = raw;
			full = name ?? raw;
		}
	}
	if (!email) return null;
	return JSON.stringify({ email_id: email, full_name: full || email });
}

export function assigneeEmail(stored: unknown): string {
	return (parseAssignee(stored)?.email_id ?? '').toLowerCase();
}
