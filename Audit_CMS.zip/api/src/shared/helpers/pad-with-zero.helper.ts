export const padWithZeros = (num: number, desiredLength: number) => {
	const numString = num.toString();

	if (numString.length < desiredLength) {
		const zerosToAdd = desiredLength - numString.length;
		return '0'.repeat(zerosToAdd) + numString;
	} else {
		return numString;
	}
};
