import { Inject, Injectable } from '@nestjs/common';
import { INTERNAL_API } from '../constants';
import { HttpService } from '../services/http.service';
import {
	AddNewDelegationRequest,
	DeleteDelegationRequest,
	GenerateNextSequenceNumberRequest,
	RemoveAllDelegationRequest,
	UpcomingDelegationRequest,
	UpdateDelegationRequest,
} from '../types';

@Injectable()
export class RequestApiClient {
	constructor(
		@Inject(INTERNAL_API.REQUEST_API_PROVIDER) private readonly requestApiProvider: HttpService,
	) {}

	public async generateNextSequenceNumber(
		payload: GenerateNextSequenceNumberRequest,
	): Promise<number> {
		const { data } = await this.requestApiProvider.post('/request/generateNextSequence', payload);
		return data;
	}

	public async getUpcomingDelegations(payload: UpcomingDelegationRequest) {
		const { data } = await this.requestApiProvider.post(
			'/delegate/getUpcomingDelegations',
			payload,
		);
		return data;
	}

	public async getUpcomingDelegationById(id: number) {
		const { data } = await this.requestApiProvider.post('/delegate/getbyid', {
			id,
		});
		return data;
	}

	public async addNewDelegation(payload: AddNewDelegationRequest): Promise<number> {
		const { data } = await this.requestApiProvider.post('/delegate/add', payload);
		return data;
	}

	public async updateDelegation(payload: UpdateDelegationRequest) {
		const { data } = await this.requestApiProvider.post('/delegate/update', payload);
		return data;
	}

	public async deleteDelegation(payload: DeleteDelegationRequest) {
		const { data } = await this.requestApiProvider.post('/delegate/delete', payload);
		return data;
	}

	public async removeAllDelegations(payload: RemoveAllDelegationRequest) {
		const { data } = await this.requestApiProvider.post('/delegate/removeAll', payload);
		return data;
	}
}
