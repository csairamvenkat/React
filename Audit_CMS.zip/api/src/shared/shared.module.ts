import { Global, Module } from '@nestjs/common';
import {
	AdminApiClient,
	AttachmentApiClient,
	NotificationApiClient,
	TaskApiClient,
	MSGraphApiClient,
	RequestApiClient,
	HistoryApiClient,
} from './clients';
import {
	EntityService,
	SharedPermissionService,
	SharedAttachmentService,
	ExcelSheetService,
	RoleService,
	ReportService,
} from './services';
import { SharedNotificationService } from './services/shared-notification.service';
import { CommonService } from './services/common.service';

const repositories = [];

@Global()
@Module({
	providers: [
		AdminApiClient,
		EntityService,
		MSGraphApiClient,
		AttachmentApiClient,
		SharedAttachmentService,
		TaskApiClient,
		NotificationApiClient,
		RequestApiClient,
		HistoryApiClient,
		SharedPermissionService,
		SharedNotificationService,
		ExcelSheetService,
		RoleService,
		ReportService,
		CommonService,
		...repositories,
	],
	exports: [
		AdminApiClient,
		EntityService,
		MSGraphApiClient,
		AttachmentApiClient,
		SharedAttachmentService,
		TaskApiClient,
		NotificationApiClient,
		RequestApiClient,
		HistoryApiClient,
		SharedPermissionService,
		SharedNotificationService,
		ExcelSheetService,
		RoleService,
		ReportService,
		CommonService,
		...repositories,
	],
})
export class SharedModule {}
