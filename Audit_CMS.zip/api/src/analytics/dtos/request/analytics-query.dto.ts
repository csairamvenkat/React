import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsDateString, IsInt, IsOptional, IsString } from 'class-validator';

const emptyToUndefined = ({ value }: { value: unknown }) => (value === '' ? undefined : value);
export class AnalyticsQueryDto {
	@ApiPropertyOptional()
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	dateFrom?: string;

	@ApiPropertyOptional()
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	dateTo?: string;

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	classification?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	region?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	country?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	businessPillar?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	businessUnit?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	department?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	currentStage?: string[];

	@ApiPropertyOptional({ type: [String] })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	intakeChannel?: string[];

	@ApiPropertyOptional({ description: 'Incident Response KPI benchmark, in days. Defaults to 120.' })
	@IsOptional()
	@IsInt()
	benchmarkDays?: number;

	@ApiPropertyOptional({ description: 'Recommendation Closure KPI date-range start (createdOn)' })
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	recommendationFromDate?: string;

	@ApiPropertyOptional({ description: 'Recommendation Closure KPI date-range end (createdOn)' })
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	recommendationToDate?: string;
}
