import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsDateString, IsOptional, IsString } from 'class-validator';

const emptyToUndefined = ({ value }: { value: unknown }) => (value === '' ? undefined : value);

export class CpeHoursQueryDto {
	@ApiPropertyOptional({ type: [String], description: 'Member emails to scope to; omit for all members' })
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	members?: string[];

	@ApiPropertyOptional()
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	fromDate?: string;

	@ApiPropertyOptional()
	@Transform(emptyToUndefined)
	@IsOptional()
	@IsDateString()
	toDate?: string;
}
