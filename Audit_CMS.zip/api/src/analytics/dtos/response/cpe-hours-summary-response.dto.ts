import { ApiProperty } from '@nestjs/swagger';
import { NameValueDto } from './analytics-summary-response.dto';

export class CpeHoursEntryDto {
	@ApiProperty() date: string;
	@ApiProperty() hours: number;
	@ApiProperty({ nullable: true }) description: string | null;
}

export class CpeMemberLogDto {
	@ApiProperty() name: string;
	@ApiProperty() email: string;
	@ApiProperty() totalHours: number;
	@ApiProperty({ type: [CpeHoursEntryDto] }) entries: CpeHoursEntryDto[];
}

export class CpeHoursSummaryResponseDto {
	@ApiProperty() totalHours: number;
	@ApiProperty() membersTracked: number;
	@ApiProperty() avgHoursPerMember: number;
	@ApiProperty({ type: [NameValueDto] }) perMember: NameValueDto[];
	@ApiProperty({ type: [CpeMemberLogDto] }) logs: CpeMemberLogDto[];
}
