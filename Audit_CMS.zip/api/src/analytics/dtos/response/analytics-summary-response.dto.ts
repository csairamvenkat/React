import { ApiProperty } from '@nestjs/swagger';

export class NameValueDto {
	@ApiProperty() name: string;
	@ApiProperty() value: number;
}

export class OverviewStatsDto {
	@ApiProperty() totalCases: number;
	@ApiProperty() pendingReview: number;
}

export class VolumeIntakeStatsDto {
	@ApiProperty() thisYearCount: number;
	@ApiProperty() lastYearCount: number;
	@ApiProperty() yoyPercent: number;
	@ApiProperty() fraudCount: number;
	@ApiProperty() nonFraudCount: number;
	@ApiProperty({ type: NameValueDto, nullable: true }) topChannel: NameValueDto | null;
	@ApiProperty({ type: [NameValueDto] }) channelBreakdown: NameValueDto[];
	@ApiProperty({ type: [NameValueDto] }) pillarBreakdown: NameValueDto[];
	@ApiProperty() anonymousCount: number;
	@ApiProperty() namedCount: number;
}

export class CaseStatusStatsDto {
	@ApiProperty() closedCount: number;
	@ApiProperty() openCount: number;
	@ApiProperty() avgClosureTime: number;
	@ApiProperty() referred: number;
	@ApiProperty() intakeClosed: number;
	@ApiProperty({ type: [NameValueDto] }) outcomesBreakdown: NameValueDto[];
}

export class OldestOpenCaseDto {
	@ApiProperty() irNumber: string;
	@ApiProperty() businessUnit: string;
	@ApiProperty() currentStage: string;
	@ApiProperty() ageDays: number;
}

export class AgingStatsDto {
	@ApiProperty({ type: [NameValueDto] }) buckets: NameValueDto[];
	@ApiProperty() avgAge: number;
	@ApiProperty({ type: [OldestOpenCaseDto] }) oldestOpen: OldestOpenCaseDto[];
}

export class ThemeGrowthDto {
	@ApiProperty() name: string;
	@ApiProperty() lastYearCount: number;
	@ApiProperty() growthPercent: number;
}

export class ThemeOutcomeDto {
	@ApiProperty() name: string;
	@ApiProperty() total: number;
	@ApiProperty() substantiated: number;
	@ApiProperty() substantiationRate: number;
}

export class ThematicStatsDto {
	@ApiProperty({ type: [NameValueDto] }) byIssue: NameValueDto[];
	@ApiProperty({ type: NameValueDto, nullable: true }) topIssueType: NameValueDto | null;
	@ApiProperty() largestThemePercent: number;
	@ApiProperty({ type: ThemeGrowthDto, nullable: true }) fastestGrowing: ThemeGrowthDto | null;
	@ApiProperty({ type: [ThemeOutcomeDto] }) outcomesPerTheme: ThemeOutcomeDto[];
}

export class ThematicBreakdownResponseDto {
	@ApiProperty({ type: ThematicStatsDto }) all: ThematicStatsDto;
	@ApiProperty({ type: ThematicStatsDto }) fraud: ThematicStatsDto;
	@ApiProperty({ type: ThematicStatsDto }) nonFraud: ThematicStatsDto;
}

export class RegionTableRowDto {
	@ApiProperty() region: string;
	@ApiProperty() count: number;
	@ApiProperty() percentOfTotal: number;
	@ApiProperty() fraud: number;
	@ApiProperty() nonFraud: number;
	@ApiProperty() yoyPercent: number;
}

export class RegionalStatsDto {
	@ApiProperty({ type: [NameValueDto] }) byRegion: NameValueDto[];
	@ApiProperty({ type: [NameValueDto] }) byCountry: NameValueDto[];
	@ApiProperty({ type: NameValueDto, nullable: true }) topRegion: NameValueDto | null;
	@ApiProperty({ type: NameValueDto, nullable: true }) topCountry: NameValueDto | null;
	@ApiProperty() fraudCount: number;
	@ApiProperty() nonFraudCount: number;
	@ApiProperty({ type: [RegionTableRowDto] }) regionTable: RegionTableRowDto[];
}

export class DepartmentTableRowDto {
	@ApiProperty() department: string;
	@ApiProperty() count: number;
	@ApiProperty() substantiationRate: number;
	@ApiProperty() fraud: number;
	@ApiProperty() nonFraud: number;
	@ApiProperty() avgOpenAge: number;
	@ApiProperty() yoyPercent: number;
}

export class DepartmentStatsDto {
	@ApiProperty({ type: [NameValueDto] }) byDept: NameValueDto[];
	@ApiProperty({ type: [DepartmentTableRowDto] }) deptTable: DepartmentTableRowDto[];
	@ApiProperty({ type: DepartmentTableRowDto, nullable: true }) highestSubstantiation: DepartmentTableRowDto | null;
	@ApiProperty({ type: NameValueDto, nullable: true }) mostCasesDept: NameValueDto | null;
}

export class BenchmarkStatsDto {
	@ApiProperty() reportsPer100: number;
	@ApiProperty() internalBenchmark: number;
	@ApiProperty() marketBenchmark: number;
	@ApiProperty() lastFullYear: number;
	@ApiProperty() lastFullYearCount: number;
}

export class TrendStatsDto {
	@ApiProperty({ type: [NameValueDto] }) series: NameValueDto[];
	@ApiProperty() yoyPercent: number;
	@ApiProperty() cagr: number;
	@ApiProperty() rollingWindowYears: number;
}

export class IncidentResponseKpiDto {
	@ApiProperty() avgDaysToClose: number;
	@ApiProperty() benchmarkDays: number;
	@ApiProperty() excludedCount: number;
}

export class RecommendationClosureKpiDto {
	@ApiProperty() percentClosed: number;
	@ApiProperty() totalInRange: number;
	@ApiProperty() stillOpen: number;
	@ApiProperty({ type: [NameValueDto] }) closureRateTrend: NameValueDto[];
}

export class RecentActivityItemDto {
	@ApiProperty() irNumber: string;
	@ApiProperty({ enum: ['created', 'updated', 'closed'] }) type: string;
	@ApiProperty() at: string;
}

export class LandingStatsDto {
	@ApiProperty() openCount: number;
	@ApiProperty() openFraudCount: number;
	@ApiProperty() openNonFraudCount: number;
	@ApiProperty() newThisMonth: number;
	@ApiProperty() newThisMonthFraudCount: number;
	@ApiProperty() newThisMonthNonFraudCount: number;
	@ApiProperty() closedThisMonth: number;
	@ApiProperty() closedThisMonthFraudCount: number;
	@ApiProperty() closedThisMonthNonFraudCount: number;
	@ApiProperty() myCases: number;
	@ApiProperty() myCasesFraudCount: number;
	@ApiProperty() myCasesNonFraudCount: number;
	@ApiProperty({ type: [RecentActivityItemDto] }) recentActivity: RecentActivityItemDto[];
}

export class AnalyticsSummaryResponseDto {
	@ApiProperty({ type: OverviewStatsDto }) overview: OverviewStatsDto;
	@ApiProperty({ type: LandingStatsDto }) landing: LandingStatsDto;
	@ApiProperty({ type: VolumeIntakeStatsDto }) volumeIntake: VolumeIntakeStatsDto;
	@ApiProperty({ type: CaseStatusStatsDto }) caseStatus: CaseStatusStatsDto;
	@ApiProperty({ type: AgingStatsDto }) aging: AgingStatsDto;
	@ApiProperty({ type: ThematicBreakdownResponseDto }) thematic: ThematicBreakdownResponseDto;
	@ApiProperty({ type: RegionalStatsDto }) regional: RegionalStatsDto;
	@ApiProperty({ type: DepartmentStatsDto }) department: DepartmentStatsDto;
	@ApiProperty({ type: BenchmarkStatsDto }) benchmark: BenchmarkStatsDto;
	@ApiProperty({ type: TrendStatsDto }) trend: TrendStatsDto;
	@ApiProperty({ type: IncidentResponseKpiDto }) incidentResponse: IncidentResponseKpiDto;
	@ApiProperty({ type: RecommendationClosureKpiDto }) recommendationClosure: RecommendationClosureKpiDto;
}
