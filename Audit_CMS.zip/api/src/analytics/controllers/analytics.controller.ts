import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RequestContext } from 'src/shared/types';
import { AnalyticsService } from '../services/analytics.service';
import { AnalyticsQueryDto, AnalyticsSummaryResponseDto, CpeHoursQueryDto, CpeHoursSummaryResponseDto } from '../dtos';

@ApiTags('Analytics APIs')
@ApiBearerAuth()
@UseGuards(AuthGuard('oauth-bearer'))
@Controller('analytics')
export class AnalyticsController {
	constructor(private readonly analyticsService: AnalyticsService) {}

	@ApiResponse({ status: 200, type: AnalyticsSummaryResponseDto })
	@Post('summary')
	public getSummary(
		@Body() query: AnalyticsQueryDto,
		@Req() request: RequestContext,
	): Promise<AnalyticsSummaryResponseDto> {
		return this.analyticsService.getSummary(query, request.currentContext?.user?.username);
	}

	@ApiResponse({ status: 200 })
	@Get('filter-options')
	public getFilterOptions(@Req() request: RequestContext) {
		return this.analyticsService.getFilterOptions(request.currentContext?.user?.username);
	}

	@ApiResponse({ status: 200, type: CpeHoursSummaryResponseDto })
	@Post('cpe-hours/summary')
	public getCpeHoursSummary(@Body() query: CpeHoursQueryDto): Promise<CpeHoursSummaryResponseDto> {
		return this.analyticsService.getCpeHoursSummary(query);
	}
}
