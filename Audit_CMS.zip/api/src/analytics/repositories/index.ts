export { CpeHoursLogRepository } from './cpe-hours-log.repository';
