import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CpeHoursLog } from '../models';

@Injectable()
export class CpeHoursLogRepository extends BaseRepository<CpeHoursLog> {
	constructor() {
		super(CpeHoursLog);
	}
}
