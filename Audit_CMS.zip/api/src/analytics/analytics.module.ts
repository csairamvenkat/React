import { Module } from '@nestjs/common';
import { SharedModule } from 'src/shared/shared.module';
import { CaseModule } from '../case/case.module';
import { AnalyticsController } from './controllers';
import { AnalyticsAggregationService, AnalyticsService } from './services';
import { CpeHoursLogRepository } from './repositories';

@Module({
	imports: [SharedModule, CaseModule],
	controllers: [AnalyticsController],
	providers: [AnalyticsService, AnalyticsAggregationService, CpeHoursLogRepository],
})
export class AnalyticsModule {}
