import { Injectable } from '@nestjs/common';
import { Case, CaseClassification, CaseStatus, AnalysisResult } from '@/case/models';
import { isCaseClosed } from '@/case/constants/case.constant';
import { BENCHMARK_CONFIG } from '../constants/benchmark.constant';

const DAY_MS = 86_400_000;
const NOT_SET = 'Not Set';

interface NameValue {
	name: string;
	value: number;
}

interface CpeMemberLog {
	name: string;
	email: string;
	totalHours: number;
	entries: { date: string; hours: number; description: string | null }[];
}

function round(n: number, dp = 1): number {
	const f = 10 ** dp;
	return Math.round(n * f) / f;
}

function pct(part: number, total: number): number {
	return total === 0 ? 0 : round((part / total) * 100);
}

function avg(nums: number[]): number {
	if (!nums.length) return 0;
	return round(nums.reduce((s, n) => s + n, 0) / nums.length);
}

function yearOf(dateIso: string): number {
	return new Date(dateIso).getFullYear();
}

function groupCount<T>(items: T[], keyFn: (item: T) => string | null | undefined): NameValue[] {
	const map = new Map<string, number>();
	items.forEach(item => {
		const key = keyFn(item) || NOT_SET;
		map.set(key, (map.get(key) ?? 0) + 1);
	});
	return Array.from(map.entries())
		.map(([name, value]) => ({ name, value }))
		.sort((a, b) => b.value - a.value);
}

function daysToClose(c: Case): number | null {
	if (!c.closedOn || !c.createdOn) return null;
	return Math.floor((new Date(c.closedOn).getTime() - new Date(c.createdOn).getTime()) / DAY_MS);
}

@Injectable()
export class AnalyticsAggregationService {
	getOverviewStats(cases: Case[]) {
		return {
			totalCases: cases.length,
			pendingReview: cases.filter(c => c.currentStage === CaseStatus.CASE_CREATED).length,
		};
	}

	getLandingStats(cases: Case[], username?: string) {
		const now = new Date();
		const m = now.getMonth();
		const y = now.getFullYear();
		const inThisMonth = (d?: string | Date | null) => {
			if (!d) return false;
			const dt = new Date(d);
			return dt.getMonth() === m && dt.getFullYear() === y;
		};

		const u = username?.toLowerCase();
		const isMine = (val?: string | null) => !!u && !!val && String(val).toLowerCase().includes(u);
		const isFraud = (c: Case) => c.classification === CaseClassification.FRAUD;

		const recentActivity = [...cases]
			.sort((a, b) => new Date(b.updatedOn ?? b.createdOn).getTime() - new Date(a.updatedOn ?? a.createdOn).getTime())
			.slice(0, 5)
			.map(c => {
				const created = new Date(c.createdOn).getTime();
				const updated = new Date(c.updatedOn ?? c.createdOn).getTime();
				const type = isCaseClosed(c.status) ? 'closed' : updated - created < 60_000 ? 'created' : 'updated';
				return { irNumber: c.irNumber, type, at: (c.updatedOn ?? c.createdOn) as unknown as string };
			});

		const open = cases.filter(c => !isCaseClosed(c.status));
		const newThisMonth = cases.filter(c => inThisMonth(c.createdOn) || inThisMonth(c.dateOfReport));
		const closedThisMonth = cases.filter(c => isCaseClosed(c.status) && inThisMonth(c.closedOn));
		const myCases = cases.filter(c => isMine(c.caseLead) || isMine(c.assignedTo));

		return {
			openCount: open.length,
			openFraudCount: open.filter(isFraud).length,
			openNonFraudCount: open.filter(c => !isFraud(c)).length,
			newThisMonth: newThisMonth.length,
			newThisMonthFraudCount: newThisMonth.filter(isFraud).length,
			newThisMonthNonFraudCount: newThisMonth.filter(c => !isFraud(c)).length,
			closedThisMonth: closedThisMonth.length,
			closedThisMonthFraudCount: closedThisMonth.filter(isFraud).length,
			closedThisMonthNonFraudCount: closedThisMonth.filter(c => !isFraud(c)).length,
			myCases: myCases.length,
			myCasesFraudCount: myCases.filter(isFraud).length,
			myCasesNonFraudCount: myCases.filter(c => !isFraud(c)).length,
			recentActivity,
		};
	}

	getVolumeIntakeStats(cases: Case[]) {
		const today = new Date();
		const thisYear = today.getFullYear();
		const lastYear = thisYear - 1;
		const thisYearCount = cases.filter(c => yearOf(c.dateOfReport) === thisYear).length;
		const lastYearCount = cases.filter(c => yearOf(c.dateOfReport) === lastYear).length;
		const yoyPercent = lastYearCount === 0 ? 0 : pct(thisYearCount - lastYearCount, lastYearCount);

		const fraudCount = cases.filter(c => c.classification === CaseClassification.FRAUD).length;
		const nonFraudCount = cases.length - fraudCount;

		const channelBreakdown = groupCount(cases, c => c.intakeChannel);
		const pillarBreakdown = groupCount(cases, c => c.businessPillar);

		const anonymousCount = cases.filter(c => c.isAnonymous === true).length;
		const namedCount = cases.length - anonymousCount;

		return {
			thisYearCount,
			lastYearCount,
			yoyPercent,
			fraudCount,
			nonFraudCount,
			topChannel: channelBreakdown[0] ?? null,
			channelBreakdown,
			pillarBreakdown,
			anonymousCount,
			namedCount,
		};
	}

	getCaseStatusStats(cases: Case[]) {
		const closed = cases.filter(c => isCaseClosed(c.status));
		const open = cases.filter(c => !isCaseClosed(c.status));

		const closureDays = closed.map(daysToClose).filter((d): d is number => d !== null);
		const avgClosureTime = avg(closureDays);
		const referred = closed.filter(c => !!c.routingType).length;
		const intakeClosed = closed.length - referred;

		const outcomesBreakdown = groupCount(
			closed.filter(c => !!c.overallAnalysisResult),
			c => c.overallAnalysisResult as AnalysisResult,
		);

		return {
			closedCount: closed.length,
			openCount: open.length,
			avgClosureTime,
			referred,
			intakeClosed,
			outcomesBreakdown,
		};
	}

	getAgingStats(cases: Case[]) {
		const today = new Date();
		const open = cases.filter(c => !isCaseClosed(c.status));
		const withAge = open.map(c => ({
			case: c,
			ageDays: Math.floor((today.getTime() - new Date(c.dateOfReport).getTime()) / DAY_MS),
		}));

		const buckets = { '0–30 days': 0, '31–60 days': 0, '61–90 days': 0, '90+ days': 0 };
		withAge.forEach(({ ageDays }) => {
			if (ageDays <= 30) buckets['0–30 days'] += 1;
			else if (ageDays <= 60) buckets['31–60 days'] += 1;
			else if (ageDays <= 90) buckets['61–90 days'] += 1;
			else buckets['90+ days'] += 1;
		});

		const avgAge = avg(withAge.map(w => w.ageDays));

		const oldestOpen = [...withAge]
			.sort((a, b) => b.ageDays - a.ageDays)
			.slice(0, 10)
			.map(({ case: c, ageDays }) => ({
				irNumber: c.irNumber,
				businessUnit: c.businessUnit,
				currentStage: c.currentStage,
				ageDays,
			}));

		return {
			buckets: Object.entries(buckets).map(([name, value]) => ({ name, value })),
			avgAge,
			oldestOpen,
		};
	}

	getThematicStats(cases: Case[]) {
		const today = new Date();
		const byIssue = groupCount(cases, c => c.primaryIssue);
		const total = cases.length;
		const topIssueType = byIssue[0] ?? null;
		const largestThemePercent = topIssueType ? pct(topIssueType.value, total) : 0;

		const thisYear = today.getFullYear();
		const lastYear = thisYear - 1;
		const growthByIssue = byIssue
			.map(({ name }) => {
				const thisYearCount = cases.filter(c => (c.primaryIssue || NOT_SET) === name && yearOf(c.dateOfReport) === thisYear).length;
				const lastYearCount = cases.filter(c => (c.primaryIssue || NOT_SET) === name && yearOf(c.dateOfReport) === lastYear).length;
				return { name, lastYearCount, growthPercent: pct(thisYearCount - lastYearCount, lastYearCount) };
			})
			.filter(g => g.lastYearCount > 0);
		const fastestGrowing = growthByIssue.length
			? growthByIssue.reduce((max, g) => (g.growthPercent > max.growthPercent ? g : max))
			: null;

		const outcomesPerTheme = byIssue.slice(0, 6).map(({ name }) => {
			const themeCases = cases.filter(c => (c.primaryIssue || NOT_SET) === name);
			const closedThemeCases = themeCases.filter(c => isCaseClosed(c.status));
			const substantiated = closedThemeCases.filter(c => c.overallAnalysisResult === AnalysisResult.SUBSTANTIATED).length;
			return {
				name,
				total: themeCases.length,
				substantiated,
				substantiationRate: pct(substantiated, closedThemeCases.length || 1),
			};
		});

		return { byIssue, topIssueType, largestThemePercent, fastestGrowing, outcomesPerTheme };
	}

	getThematicBreakdown(cases: Case[]) {
		return {
			all: this.getThematicStats(cases),
			fraud: this.getThematicStats(cases.filter(c => c.classification === CaseClassification.FRAUD)),
			nonFraud: this.getThematicStats(cases.filter(c => c.classification === CaseClassification.NON_FRAUD)),
		};
	}

	getRegionalStats(cases: Case[]) {
		const today = new Date();
		const byRegion = groupCount(cases, c => c.region);
		const byCountry = groupCount(cases, c => c.country);
		const total = cases.length;

		const thisYear = today.getFullYear();
		const lastYear = thisYear - 1;

		const regionTable = byRegion.map(({ name, value }) => {
			const regionCases = cases.filter(c => (c.region || NOT_SET) === name);
			const fraud = regionCases.filter(c => c.classification === CaseClassification.FRAUD).length;
			const thisYearCount = regionCases.filter(c => yearOf(c.dateOfReport) === thisYear).length;
			const lastYearCount = regionCases.filter(c => yearOf(c.dateOfReport) === lastYear).length;
			return {
				region: name,
				count: value,
				percentOfTotal: pct(value, total),
				fraud,
				nonFraud: value - fraud,
				yoyPercent: lastYearCount === 0 ? 0 : pct(thisYearCount - lastYearCount, lastYearCount),
			};
		});

		return {
			byRegion,
			byCountry,
			topRegion: byRegion[0] ?? null,
			topCountry: byCountry[0] ?? null,
			fraudCount: cases.filter(c => c.classification === CaseClassification.FRAUD).length,
			nonFraudCount: cases.filter(c => c.classification === CaseClassification.NON_FRAUD).length,
			regionTable,
		};
	}

	getDepartmentStats(cases: Case[]) {
		const today = new Date();
		const byDept = groupCount(cases, c => c.departmentOfAccused);
		const thisYear = today.getFullYear();
		const lastYear = thisYear - 1;

		const deptTable = byDept.map(({ name, value }) => {
			const deptCases = cases.filter(c => (c.departmentOfAccused || NOT_SET) === name);
			const closed = deptCases.filter(c => isCaseClosed(c.status));
			const substantiated = closed.filter(c => c.overallAnalysisResult === AnalysisResult.SUBSTANTIATED).length;
			const fraud = deptCases.filter(c => c.classification === CaseClassification.FRAUD).length;
			const openCases = deptCases.filter(c => !isCaseClosed(c.status));
			const avgOpenAge = avg(
				openCases.map(c => Math.floor((today.getTime() - new Date(c.dateOfReport).getTime()) / DAY_MS)),
			);
			const thisYearCount = deptCases.filter(c => yearOf(c.dateOfReport) === thisYear).length;
			const lastYearCount = deptCases.filter(c => yearOf(c.dateOfReport) === lastYear).length;

			return {
				department: name,
				count: value,
				substantiationRate: pct(substantiated, closed.length || 1),
				fraud,
				nonFraud: value - fraud,
				avgOpenAge,
				yoyPercent: lastYearCount === 0 ? 0 : pct(thisYearCount - lastYearCount, lastYearCount),
			};
		});

		const highestSubstantiation = [...deptTable].sort((a, b) => b.substantiationRate - a.substantiationRate)[0] ?? null;

		return { byDept, deptTable, highestSubstantiation, mostCasesDept: byDept[0] ?? null };
	}

	getBenchmarkStats(cases: Case[]) {
		const today = new Date();
		const lastFullYear = today.getFullYear() - 1;
		const lastFullYearCount = cases.filter(c => yearOf(c.dateOfReport) === lastFullYear).length;
		const reportsPer100 = round((lastFullYearCount / BENCHMARK_CONFIG.employeeHeadcount) * 100, 3);

		return {
			reportsPer100,
			internalBenchmark: BENCHMARK_CONFIG.internalBenchmarkPer100,
			marketBenchmark: BENCHMARK_CONFIG.marketBenchmarkPer100,
			lastFullYear,
			lastFullYearCount,
		};
	}

	getTrendStats(cases: Case[]) {
		const byYear = new Map<number, number>();
		cases.forEach(c => {
			const y = yearOf(c.dateOfReport);
			byYear.set(y, (byYear.get(y) ?? 0) + 1);
		});
		const years = Array.from(byYear.keys()).sort();
		const series = years.map(year => ({ name: String(year), value: byYear.get(year) ?? 0 }));

		const lastIdx = years.length - 1;
		const yoyPercent = lastIdx >= 1 ? pct(series[lastIdx].value - series[lastIdx - 1].value, series[lastIdx - 1].value) : 0;

		const fullYears = series.filter((_, idx) => idx < lastIdx || new Date().getMonth() === 11);
		const cagrSeries = fullYears.length >= 2 ? fullYears : series;
		const first = cagrSeries[0];
		const last = cagrSeries[cagrSeries.length - 1];
		const periods = cagrSeries.length - 1;
		const cagr = periods > 0 && first?.value > 0 ? round(((last.value / first.value) ** (1 / periods) - 1) * 100) : 0;

		return { series, yoyPercent, cagr, rollingWindowYears: years.length };
	}

	getIncidentResponseKpi(cases: Case[], benchmarkDays = BENCHMARK_CONFIG.closureBenchmarkDays) {
		const isCriticalAlert = (s?: string) => s === 'Critical' || s === 'State Alert';
		const eligible = cases.filter(c => isCaseClosed(c.status) && !isCriticalAlert(c.alertStatus) && !c.posncdpqFlag);
		const excluded = cases.filter(c => isCaseClosed(c.status) && (isCriticalAlert(c.alertStatus) || c.posncdpqFlag));

		const closureDays = eligible.map(daysToClose).filter((d): d is number => d !== null);

		return {
			avgDaysToClose: avg(closureDays),
			benchmarkDays,
			excludedCount: excluded.length,
		};
	}

	getRecommendationClosureKpi(items: { status: string; createdOn: Date }[], fromDate?: string, toDate?: string) {
		const inRange = items.filter(item => {
			if (!fromDate || !toDate) return true;
			const created = new Date(item.createdOn).toISOString().slice(0, 10);
			return created >= fromDate && created <= toDate;
		});

		const closed = inRange.filter(item => item.status === 'Implemented');
		const percentClosed = pct(closed.length, inRange.length);

		const monthly = new Map<string, { closed: number; total: number }>();
		inRange.forEach(item => {
			const label = new Date(item.createdOn).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
			const entry = monthly.get(label) ?? { closed: 0, total: 0 };
			entry.total += 1;
			if (item.status === 'Implemented') entry.closed += 1;
			monthly.set(label, entry);
		});
		const closureRateTrend = Array.from(monthly.entries()).map(([name, { closed: c, total }]) => ({
			name,
			value: pct(c, total),
		}));

		return {
			percentClosed,
			totalInRange: inRange.length,
			stillOpen: inRange.length - closed.length,
			closureRateTrend,
		};
	}

	getCpeHoursKpi(logs: CpeMemberLog[]) {
		const totalHours = logs.reduce((sum, l) => sum + l.totalHours, 0);
		return {
			totalHours,
			membersTracked: logs.length,
			avgHoursPerMember: avg(logs.map(l => l.totalHours)),
			perMember: logs.map(l => ({ name: l.name, value: l.totalHours })),
		};
	}
}
