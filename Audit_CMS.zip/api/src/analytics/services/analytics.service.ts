import { Injectable } from '@nestjs/common';
import { Op, literal } from 'sequelize';
import { AdminApiClient } from 'src/shared/clients';
import { PERMISSIONS } from 'src/shared/enums';
import { CaseRepository } from '@/case/repositories';
import { CaseRecommendationItem } from '@/case/models';
import { CpeHoursLogRepository } from '../repositories';
import { AnalyticsQueryDto, AnalyticsSummaryResponseDto, CpeHoursQueryDto, CpeHoursSummaryResponseDto } from '../dtos';
import { AnalyticsAggregationService } from './analytics-aggregation.service';
import {
	buildAnalyticsWhereClause,
	FILTER_DB_COLUMN,
	MULTI_FILTER_KEYS,
	MultiFilterKey,
	toFilterOptions,
} from '../helpers/analytics-filter.helper';

const SUMMARY_CASE_ATTRIBUTES = [
	'id',
	'irNumber',
	'businessUnit',
	'classification',
	'currentStage',
	'primaryIssue',
	'dateOfReport',
	'closedOn',
	'createdOn',
	'updatedOn',
	'caseLead',
	'assignedTo',
	'intakeChannel',
	'businessPillar',
	'isAnonymous',
	'routingType',
	'overallAnalysisResult',
	'region',
	'country',
	'departmentOfAccused',
	'alertStatus',
	'posncdpqFlag',
];

@Injectable()
export class AnalyticsService {
	constructor(
		private readonly caseRepository: CaseRepository,
		private readonly cpeHoursLogRepository: CpeHoursLogRepository,
		private readonly aggregation: AnalyticsAggregationService,
		private readonly adminApiClient: AdminApiClient,
	) {}

	private async scopedWhere(query: Partial<AnalyticsQueryDto>, username?: string) {
		const where = buildAnalyticsWhereClause(query);
		if (!username) return where;

		const locations = await this.adminApiClient.getLocationByUserPermissions(PERMISSIONS.CASE_VIEW, username);
		if (!locations?.length) return where;

		return { [Op.and]: [where, { businessEntityId: { [Op.in]: locations } }] };
	}

	async getSummary(query: AnalyticsQueryDto, username?: string): Promise<AnalyticsSummaryResponseDto> {
		const where = await this.scopedWhere(query, username);
		const cases = await this.caseRepository.findAll({
			where,
			attributes: SUMMARY_CASE_ATTRIBUTES,
			include: [
				{
					model: CaseRecommendationItem,
					required: false,
					separate: true,
					attributes: ['status', 'createdOn'],
				},
			],
		});

		const recommendationItems = cases.flatMap(c => c.recommendationItems ?? []);

		return {
			overview: this.aggregation.getOverviewStats(cases),
			landing: this.aggregation.getLandingStats(cases, username),
			volumeIntake: this.aggregation.getVolumeIntakeStats(cases),
			caseStatus: this.aggregation.getCaseStatusStats(cases),
			aging: this.aggregation.getAgingStats(cases),
			thematic: this.aggregation.getThematicBreakdown(cases),
			regional: this.aggregation.getRegionalStats(cases),
			department: this.aggregation.getDepartmentStats(cases),
			benchmark: this.aggregation.getBenchmarkStats(cases),
			trend: this.aggregation.getTrendStats(cases),
			incidentResponse: this.aggregation.getIncidentResponseKpi(cases, query.benchmarkDays),
			recommendationClosure: this.aggregation.getRecommendationClosureKpi(
				recommendationItems,
				query.recommendationFromDate,
				query.recommendationToDate,
			),
		};
	}

	async getFilterOptions(username?: string): Promise<Record<MultiFilterKey, string[]>> {
		const where = await this.scopedWhere({} as AnalyticsQueryDto, username);
		const [row] = await this.caseRepository.findAll({
			where,
			attributes: MULTI_FILTER_KEYS.map(key => [
				literal(`ARRAY_AGG(DISTINCT "${FILTER_DB_COLUMN[key]}")`),
				key,
			]),
			raw: true,
		});
		return toFilterOptions((row ?? {}) as Record<string, unknown>);
	}

	async getCpeHoursSummary(query: CpeHoursQueryDto): Promise<CpeHoursSummaryResponseDto> {
		const where: Record<string, unknown> = {};
		if (query.members?.length) where.memberEmail = { [Op.in]: query.members };
		if (query.fromDate) where.entryDate = { ...(where.entryDate as object), [Op.gte]: query.fromDate };
		if (query.toDate) where.entryDate = { ...(where.entryDate as object), [Op.lte]: query.toDate };

		const rows = await this.cpeHoursLogRepository.findAll({ where, order: [['entryDate', 'ASC']] });

		const byMember = new Map<string, { name: string; email: string; totalHours: number; entries: { date: string; hours: number; description: string | null }[] }>();
		rows.forEach(row => {
			const entry = byMember.get(row.memberEmail) ?? {
				name: row.memberName,
				email: row.memberEmail,
				totalHours: 0,
				entries: [],
			};
			entry.totalHours += Number(row.hours);
			entry.entries.push({ date: row.entryDate, hours: Number(row.hours), description: row.description ?? null });
			byMember.set(row.memberEmail, entry);
		});
		const logs = Array.from(byMember.values());

		return { ...this.aggregation.getCpeHoursKpi(logs), logs };
	}
}
