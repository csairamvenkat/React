import { Column, CreatedAt, DataType, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';

@Table({ tableName: 'cpe_hours_logs' })
export class CpeHoursLog extends BaseModel<CpeHoursLog> {
	@Column({ field: 'member_name', type: DataType.STRING(255), allowNull: false })
	public memberName: string;

	@Column({ field: 'member_email', type: DataType.STRING(255), allowNull: false })
	public memberEmail: string;

	@Column({ field: 'entry_date', type: DataType.DATEONLY, allowNull: false })
	public entryDate: string;

	@Column({ field: 'hours', type: DataType.DECIMAL(5, 2), allowNull: false })
	public hours: number;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: true })
	public description: string;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
