import { Op, WhereOptions } from 'sequelize';
import { AnalyticsQueryDto } from '../dtos';

export type MultiFilterKey =
	| 'classification'
	| 'region'
	| 'country'
	| 'businessPillar'
	| 'businessUnit'
	| 'department'
	| 'currentStage'
	| 'intakeChannel';

const FIELD_COLUMN: Record<MultiFilterKey, string> = {
	classification: 'classification',
	region: 'region',
	country: 'country',
	businessPillar: 'businessPillar',
	businessUnit: 'businessUnit',
	department: 'departmentOfAccused',
	currentStage: 'currentStage',
	intakeChannel: 'intakeChannel',
};

export const MULTI_FILTER_KEYS = Object.keys(FIELD_COLUMN) as MultiFilterKey[];

export function buildAnalyticsWhereClause(query: Partial<AnalyticsQueryDto>): WhereOptions {
	const and: WhereOptions[] = [];

	if (query.dateFrom) and.push({ dateOfReport: { [Op.gte]: query.dateFrom } });
	if (query.dateTo) and.push({ dateOfReport: { [Op.lte]: query.dateTo } });

	MULTI_FILTER_KEYS.forEach(key => {
		const values = query[key];
		if (values?.length) and.push({ [FIELD_COLUMN[key]]: { [Op.in]: values } });
	});

	return and.length ? { [Op.and]: and } : {};
}

export const FILTER_DB_COLUMN: Record<MultiFilterKey, string> = {
	classification: 'classification',
	region: 'region',
	country: 'country',
	businessPillar: 'business_pillar',
	businessUnit: 'business_unit',
	department: 'department_of_accused',
	currentStage: 'current_stage',
	intakeChannel: 'intake_channel',
};

export function toFilterOptions(row: Record<string, unknown>): Record<MultiFilterKey, string[]> {
	const result = {} as Record<MultiFilterKey, string[]>;

	MULTI_FILTER_KEYS.forEach(key => {
		const values = (row?.[key] as (string | null)[] | null) ?? [];
		result[key] = values
			.filter((v): v is string => !!v)
			.sort((a, b) => a.localeCompare(b));
	});

	return result;
}
