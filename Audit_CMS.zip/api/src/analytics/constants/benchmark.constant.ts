export const BENCHMARK_CONFIG = {
	employeeHeadcount: 111_000,
	internalBenchmarkPer100: 0.18,
	marketBenchmarkPer100: 0.25,
	closureBenchmarkDays: 120,
};
