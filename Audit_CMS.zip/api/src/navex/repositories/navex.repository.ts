import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/sequelize';
import { QueryTypes } from 'sequelize';
import { Sequelize } from 'sequelize-typescript';
import { ConfigService } from '@/config/config.service';

/**
 * How long an open `cronjob_runs` row stays believable. Matches `activeDeadlineSeconds: 10800`
 * in `cronjobs/navex-sync/k8s/cronjob.yaml` — k8s kills the pod at that point, so a row still
 * open past it belongs to a process that no longer exists. Treating it as finished lets the page
 * recover on its own instead of showing "Sync in progress" until someone clears the row by hand.
 */
const STALE_RUN_AFTER = '3 hours';

@Injectable()
export class NavexRepository {
	private readonly schema: string;

	constructor(
		@InjectConnection() private readonly sequelize: Sequelize,
		configService: ConfigService,
	) {
		this.schema = `"${configService.getAppConfig().database.schema.replace(/"/g, '""')}"`;
	}

	private table(name: string): string {
		return `${this.schema}.${name}`;
	}

	private async select<T>(query: string, replacements: Record<string, unknown> = {}): Promise<T[]> {
		const rows = await this.sequelize.query(query, {
			type: QueryTypes.SELECT,
			replacements,
		});

		return rows as T[];
	}

	public async getSyncState(): Promise<NavexSyncStateRow | null> {
		const [row] = await this.select<NavexSyncStateRow>(`
			SELECT watermark, last_run_id AS "lastRunId", last_run_on AS "lastRunOn",
			       last_run_status AS "lastRunStatus", last_error AS "lastError",
			       cases_seen AS "casesSeen", cases_imported AS "casesImported",
			       cases_updated AS "casesUpdated", cases_unchanged AS "casesUnchanged",
			       cases_failed AS "casesFailed", updated_on AS "updatedOn"
			FROM   ${this.table('navex_sync_state')}
			WHERE  id = 1`);

		return row ?? null;
	}

	public getRuns(limit: number): Promise<CronjobRunRow[]> {
		return this.select<CronjobRunRow>(
			`SELECT id, job_name AS "jobName", status, rows_read AS "rowsRead",
			        rows_written AS "rowsWritten", detail,
			        started_on AS "startedOn", finished_on AS "finishedOn"
			 FROM   ${this.table('cronjob_runs')}
			 WHERE  job_name = 'navex-sync'
			 ORDER  BY started_on DESC
			 LIMIT  :limit`,
			{ limit },
		);
	}

	public async getRun(runId: string): Promise<CronjobRunRow | null> {
		const [row] = await this.select<CronjobRunRow>(
			`SELECT id, job_name AS "jobName", status, rows_read AS "rowsRead",
			        rows_written AS "rowsWritten", detail,
			        started_on AS "startedOn", finished_on AS "finishedOn"
			 FROM   ${this.table('cronjob_runs')}
			 WHERE  id = :runId`,
			{ runId },
		);

		return row ?? null;
	}

	public async isRunInProgress(): Promise<boolean> {
		const [row] = await this.select<{ inProgress: boolean }>(
			`SELECT EXISTS (
				SELECT 1 FROM ${this.table('cronjob_runs')}
				WHERE  job_name = 'navex-sync'
				  AND  status = 'started'
				  AND  finished_on IS NULL
				  AND  started_on > CURRENT_TIMESTAMP - CAST(:staleAfter AS INTERVAL)
			) AS "inProgress"`,
			{ staleAfter: STALE_RUN_AFTER },
		);

		return Boolean(row?.inProgress);
	}

	/**
	 * Close every open `navex-sync` run row.
	 *
	 * This closes the *ledger*, not the work. A run whose process is genuinely alive keeps
	 * going and overwrites the row when it reaches `ledger.finish()` — the advisory lock in
	 * `destination/lock.ts`, not this table, is what stops two syncs overlapping. The reason to
	 * reach for this is the opposite case: the process is long gone and only the row is left,
	 * wedging the page and refusing every new trigger.
	 */
	public abortRuns(abortedBy: string, reason: string): Promise<AbortedRunRow[]> {
		return this.select<AbortedRunRow>(
			`UPDATE ${this.table('cronjob_runs')}
			 SET    status      = 'aborted',
			        finished_on = CURRENT_TIMESTAMP,
			        detail      = COALESCE(detail, '{}'::jsonb) || jsonb_build_object(
			                          'abortedBy', CAST(:abortedBy AS TEXT),
			                          'abortReason', CAST(:reason AS TEXT)
			                      )
			 WHERE  job_name = 'navex-sync'
			   AND  status = 'started'
			   AND  finished_on IS NULL
			 RETURNING id, started_on AS "startedOn"`,
			{ abortedBy, reason },
		);
	}

	private buildWhere(
		filter: NavexReportFilter,
		except?: NavexFacet,
	): {
		clause: string;
		replacements: Record<string, unknown>;
	} {
		const where: string[] = [];

		if (filter.search) {
			where.push(`(
				r.report_number ILIKE :search
				OR r.primary_issue ILIKE :search
				OR r.location_name ILIKE :search
				OR r.location_data->>'organizationName' ILIKE :search
				OR r.country ILIKE :search
				OR CAST(r.id AS TEXT) ILIKE :search
			)`);
		}

		if (filter.linked === 'linked') where.push('c.id IS NOT NULL');
		if (filter.linked === 'unlinked') where.push('c.id IS NULL');

		if (filter.status && except !== 'status') where.push('r.status = :status');
		if (filter.alertLevel && except !== 'alertLevel') {
			where.push("LOWER(COALESCE(r.alert_level, 'none')) = LOWER(:alertLevel)");
		}
		if (filter.primaryIssue && except !== 'primaryIssue') where.push('r.primary_issue = :primaryIssue');
		if (filter.country && except !== 'country') where.push('r.country = :country');
		if (filter.caseType && except !== 'caseType') where.push('r.case_type = :caseType');

		if (filter.updatedFrom) where.push('r.updated_date >= CAST(:updatedFrom AS DATE)');
		if (filter.updatedTo) where.push("r.updated_date < CAST(:updatedTo AS DATE) + INTERVAL '1 day'");

		return {
			clause: where.length ? `WHERE ${where.join(' AND ')}` : '',
			replacements: {
				search: `%${filter.search ?? ''}%`,
				status: filter.status,
				alertLevel: filter.alertLevel,
				primaryIssue: filter.primaryIssue,
				country: filter.country,
				caseType: filter.caseType,
				updatedFrom: filter.updatedFrom,
				updatedTo: filter.updatedTo,
			},
		};
	}

	public async findReports(filter: NavexReportFilter): Promise<{ rows: NavexReportRow[]; total: number }> {
		const { clause, replacements } = this.buildWhere(filter);
		const order = buildOrderBy(filter);

		const rows = await this.select<NavexReportRow>(
			`SELECT r.id   AS "navexCaseId",
			        r.report_number   AS "reportNumber",
			        r.status,
			        r.alert_level     AS "alertLevel",
			        r.case_type       AS "caseType",
			        r.primary_issue   AS "primaryIssue",
			        r.secondary_issues AS "secondaryIssues",
			        r.classification,
			        r.location_data->>'organizationName' AS "organizationName",
			        r.location_name   AS "locationName",
			        r.country,
			        r.region,
			        r.days_open       AS "daysOpen",
			        r.opened_date     AS "openedDate",
			        r.reported_date   AS "reportedDate",
			        r.updated_date    AS "updatedDate",
			        r.closed_date     AS "closedDate",
			        r.first_synced_on AS "firstSyncedOn",
			        r.last_synced_on  AS "lastSyncedOn",
			        r.last_synced_run_id AS "lastSyncedRunId",
			        c.id              AS "cmsCaseId",
			        c.ir_number       AS "cmsIrNumber",
			        jsonb_array_length(COALESCE(r.files, '[]'::jsonb))        AS "fileCount",
			        jsonb_array_length(COALESCE(r.participants, '[]'::jsonb)) AS "participantCount"
			 FROM   ${this.table('navex_case_reports')} r
			 LEFT   JOIN ${this.table('cases')} c ON c.navex_case_id = r.id AND c.deleted = FALSE
			 ${clause}
			 ${order}
			 LIMIT  :limit OFFSET :offset`,
			{ ...replacements, limit: filter.limit, offset: filter.offset },
		);

		const [count] = await this.select<{ total: string }>(
			`SELECT COUNT(*)::text AS total
			 FROM   ${this.table('navex_case_reports')} r
			 LEFT   JOIN ${this.table('cases')} c ON c.navex_case_id = r.id AND c.deleted = FALSE
			 ${clause}`,
			replacements,
		);

		return { rows, total: Number(count?.total ?? 0) };
	}

	public async getFilterOptions(filter: NavexReportFilter): Promise<NavexFilterOptions> {
		const distinct = async (facet: NavexFacet, column: string): Promise<NavexFilterOption[]> => {
			const { clause, replacements } = this.buildWhere(filter, facet);

			return this.select<NavexFilterOption>(
				`SELECT ${column} AS "value", COUNT(*)::int AS "count"
				 FROM   ${this.table('navex_case_reports')} r
				 LEFT   JOIN ${this.table('cases')} c
				        ON c.navex_case_id = r.id AND c.deleted = FALSE
				 ${clause} ${clause ? 'AND' : 'WHERE'} ${column} IS NOT NULL AND ${column} <> ''
				 GROUP  BY ${column}
				 ORDER  BY COUNT(*) DESC, ${column} ASC`,
				replacements,
			);
		};

		const [statuses, alertLevels, primaryIssues, countries, caseTypes] = await Promise.all([
			distinct('status', 'r.status'),
			distinct('alertLevel', 'r.alert_level'),
			distinct('primaryIssue', 'r.primary_issue'),
			distinct('country', 'r.country'),
			distinct('caseType', 'r.case_type'),
		]);

		return { statuses, alertLevels, primaryIssues, countries, caseTypes };
	}

	/** Counts for the page's stat cards, in one pass rather than four queries. */
	public async getReportSummary(): Promise<NavexReportSummary> {
		const [row] = await this.select<NavexReportSummary>(`
			SELECT COUNT(*)::int                                                        AS "total",
			       COUNT(*) FILTER (WHERE c.id IS NULL)::int                            AS "notInCms",
			       COUNT(*) FILTER (WHERE c.id IS NOT NULL)::int                        AS "inCms",
			       COUNT(*) FILTER (WHERE LOWER(r.alert_level) = 'red')::int            AS "redAlerts",
			       COUNT(*) FILTER (WHERE r.last_synced_on > NOW() - INTERVAL '24 hours')::int AS "syncedLast24h"
			FROM   ${this.table('navex_case_reports')} r
			LEFT   JOIN ${this.table('cases')} c ON c.navex_case_id = r.id AND c.deleted = FALSE`);

		return row ?? { total: 0, notInCms: 0, inCms: 0, redAlerts: 0, syncedLast24h: 0 };
	}

	/** The untouched Navex payload, for the preview panel. */
	/**
	 * One synced report, as every column the row holds.
	 *
	 * Migration 026 dropped `original_payload`, so the Navex-shaped object the preview
	 * renders is reassembled from these columns by `toNavexPayload` in the service — the
	 * nested objects and collections are all still here, just flattened across columns.
	 */
	public async getReportRow(navexCaseId: number): Promise<Record<string, unknown> | null> {
		const [row] = await this.select<Record<string, unknown>>(
			`SELECT r.*, c.id AS "cmsCaseId"
			 FROM   ${this.table('navex_case_reports')} r
			 LEFT   JOIN ${this.table('cases')} c ON c.navex_case_id = r.id AND c.deleted = FALSE
			 WHERE  r.id = :navexCaseId`,
			{ navexCaseId },
		);

		return row ?? null;
	}
}

const SORTABLE_COLUMNS = {
	reportNumber: 'r.report_number',
	navexCaseId: 'r.id',
	status: 'r.status',
	alertLevel: 'r.alert_level',
	primaryIssue: 'r.primary_issue',
	locationName: 'r.location_name',
	country: 'r.country',
	daysOpen: 'r.days_open',
	openedDate: 'r.opened_date',
	reportedDate: 'r.reported_date',
	updatedDate: 'r.updated_date',
	closedDate: 'r.closed_date',
	lastSyncedOn: 'r.last_synced_on',
	cmsCaseId: 'c.id',
} as const;

export type NavexSortBy = keyof typeof SORTABLE_COLUMNS;
export type NavexSortDir = 'asc' | 'desc';

export const NAVEX_SORTABLE_COLUMNS = Object.keys(SORTABLE_COLUMNS) as NavexSortBy[];

export function isNavexSortBy(value: unknown): value is NavexSortBy {
	return typeof value === 'string' && value in SORTABLE_COLUMNS;
}

function buildOrderBy(filter: NavexReportFilter): string {
	const column = isNavexSortBy(filter.sortBy) ? SORTABLE_COLUMNS[filter.sortBy] : SORTABLE_COLUMNS.updatedDate;
	const direction = filter.sortDir === 'asc' ? 'ASC' : 'DESC';
	const nulls = direction === 'ASC' ? 'NULLS LAST' : 'NULLS LAST';
	return `ORDER BY ${column} ${direction} ${nulls}, r.id DESC`;
}

/** The filters that offer a value list. Each is counted excluding its own selection. */
export type NavexFacet = 'status' | 'alertLevel' | 'primaryIssue' | 'country' | 'caseType';

export interface NavexFilterOption {
	value: string;
	count: number;
}

export interface NavexFilterOptions {
	statuses: NavexFilterOption[];
	alertLevels: NavexFilterOption[];
	primaryIssues: NavexFilterOption[];
	countries: NavexFilterOption[];
	caseTypes: NavexFilterOption[];
}

export interface NavexSyncStateRow {
	watermark: Date | null;
	lastRunId: string | null;
	lastRunOn: Date | null;
	lastRunStatus: string | null;
	lastError: string | null;
	casesSeen: number;
	casesImported: number;
	casesUpdated: number;
	casesUnchanged: number;
	casesFailed: number;
	updatedOn: Date;
}

export interface AbortedRunRow {
	id: string;
	startedOn: Date;
}

export interface CronjobRunRow {
	id: string;
	jobName: string;
	status: string;
	rowsRead: number;
	rowsWritten: number;
	detail: Record<string, unknown> | null;
	startedOn: Date;
	finishedOn: Date | null;
}

export interface NavexReportFilter {
	search?: string;
	status?: string;
	alertLevel?: string;
	primaryIssue?: string;
	country?: string;
	caseType?: string;
	linked?: 'linked' | 'unlinked';
	/** `YYYY-MM-DD`, inclusive both ends, applied to `updated_date`. */
	updatedFrom?: string;
	updatedTo?: string;
	sortBy?: string;
	sortDir?: NavexSortDir;
	limit: number;
	offset: number;
}

export interface NavexReportRow {
	navexCaseId: string;
	reportNumber: string | null;
	status: string | null;
	alertLevel: string | null;
	caseType: string | null;
	primaryIssue: string | null;
	secondaryIssues: string[] | null;
	classification: string | null;
	organizationName: string | null;
	locationName: string | null;
	country: string | null;
	region: string | null;
	daysOpen: number | null;
	openedDate: Date | null;
	reportedDate: Date | null;
	updatedDate: Date | null;
	closedDate: Date | null;
	firstSyncedOn: Date;
	lastSyncedOn: Date;
	lastSyncedRunId: string | null;
	cmsCaseId: string | null;
	cmsIrNumber: string | null;
	fileCount: number;
	participantCount: number;
}

export interface NavexReportSummary {
	total: number;
	notInCms: number;
	inCms: number;
	redAlerts: number;
	syncedLast24h: number;
}

export interface NavexReportPayload {
	navexCaseId: string;
	reportNumber: string | null;
	payload: Record<string, unknown>;
	firstSyncedOn: Date;
	lastSyncedOn: Date;
	cmsCaseId: string | null;
}
