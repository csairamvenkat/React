import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class NavexSyncCountersDto {
	@ApiProperty() seen: number;
	@ApiProperty() fetched?: number;
	@ApiProperty() imported: number;
	@ApiProperty() updated: number;
	@ApiProperty() unchanged: number;
	@ApiProperty() failed: number;
}

/**
 * What a run did to `cases`, which is not what it did to the mirror.
 *
 * A report is refreshed in full every time Navex changes it; the CMS case behind it is
 * written once and then only its follow-ups move. So a run that updates ten reports can
 * legitimately report zero case updates, which is why the two sets of numbers are separate.
 */
export class NavexSyncCaseCountersDto {
	@ApiProperty({ description: 'Cases created in CMS from a report not imported before' })
	created: number;
	@ApiProperty({ description: 'Existing cases whose follow-ups moved' }) followupsUpdated: number;
	@ApiProperty({ description: 'Existing cases left alone: already current, edited or deleted' })
	skipped: number;
}

export class NavexReportSummaryDto {
	@ApiProperty() total: number;
	@ApiProperty({ description: 'Synced reports with no CMS case yet' }) notInCms: number;
	@ApiProperty() inCms: number;
	@ApiProperty() redAlerts: number;
	@ApiProperty() syncedLast24h: number;
}

export class NavexSyncFailureDto {
	@ApiProperty() caseId: number;
	@ApiProperty() error: string;
}

export class NavexSyncRunResponseDto {
	@ApiProperty({ description: 'Ledger id, e.g. run_navex-sync_7f3a…' }) id: string;
	@ApiProperty({ enum: ['started', 'completed', 'partial', 'failed', 'aborted'] }) status: string;
	@ApiProperty() rowsRead: number;
	@ApiProperty() rowsWritten: number;
	@ApiProperty() startedOn: string;
	@ApiPropertyOptional({ description: 'Null while the run is still going — or if it was killed' })
	finishedOn: string | null;
	@ApiPropertyOptional() durationMs: number | null;
	@ApiPropertyOptional({ description: 'The date the run resumed from' }) since: string | null;
	@ApiProperty() dryRun: boolean;
	@ApiProperty({ type: NavexSyncCountersDto }) counters: NavexSyncCountersDto;
	@ApiPropertyOptional({
		type: NavexSyncCaseCountersDto,
		description: 'Null for runs from before the cases side was recorded',
	})
	cases: NavexSyncCaseCountersDto | null;
	@ApiPropertyOptional() watermark: string | null;
	@ApiPropertyOptional({ description: 'Set when the run could not see a whole window' })
	watermarkHeldAt: string | null;
	@ApiProperty({ type: [NavexSyncFailureDto] }) failures: NavexSyncFailureDto[];
	@ApiPropertyOptional() error: string | null;
}

export class NavexSyncStatusResponseDto {
	@ApiProperty({ description: 'False when this environment has no Navex credentials' })
	configured: boolean;
	@ApiPropertyOptional() baseUrl: string | null;
	@ApiProperty({ description: 'A run is open in the ledger right now' }) inProgress: boolean;
	@ApiPropertyOptional({ description: 'Highest Navex updatedDate ingested' }) watermark: string | null;
	@ApiPropertyOptional() lastRunId: string | null;
	@ApiPropertyOptional() lastRunOn: string | null;
	@ApiPropertyOptional() lastRunStatus: string | null;
	@ApiPropertyOptional() lastError: string | null;
	@ApiProperty({ type: NavexSyncCountersDto }) counters: NavexSyncCountersDto;
	@ApiProperty({ type: NavexReportSummaryDto }) summary: NavexReportSummaryDto;
	@ApiPropertyOptional({ type: NavexSyncRunResponseDto }) latestRun: NavexSyncRunResponseDto | null;
}

export class NavexCaseReportResponseDto {
	@ApiProperty() navexCaseId: string;
	@ApiPropertyOptional() reportNumber: string | null;
	@ApiPropertyOptional({ description: "Navex's own status, e.g. In Process" }) status: string | null;
	@ApiPropertyOptional({ description: 'none | green | yellow | red' }) alertLevel: string | null;
	@ApiPropertyOptional() caseType: string | null;
	@ApiPropertyOptional() primaryIssue: string | null;
	@ApiProperty({ type: [String] }) secondaryIssues: string[];
	@ApiPropertyOptional({ description: 'Navex Cat 0-5 tier, not the CMS classification' })
	classification: string | null;
	@ApiPropertyOptional() organizationName: string | null;
	@ApiPropertyOptional() locationName: string | null;
	@ApiPropertyOptional() country: string | null;
	@ApiPropertyOptional() region: string | null;
	@ApiPropertyOptional() daysOpen: number | null;
	@ApiPropertyOptional() openedDate: string | null;
	@ApiPropertyOptional() reportedDate: string | null;
	@ApiPropertyOptional() updatedDate: string | null;
	@ApiPropertyOptional() closedDate: string | null;
	@ApiProperty() firstSyncedOn: string;
	@ApiProperty() lastSyncedOn: string;
	@ApiPropertyOptional() lastSyncedRunId: string | null;
	@ApiPropertyOptional({ description: 'Null when no CMS case has been opened for this report' })
	cmsCaseId: number | null;
	@ApiPropertyOptional() cmsIrNumber: string | null;
	@ApiProperty() fileCount: number;
	@ApiProperty() participantCount: number;
}

export class NavexReportListResponseDto {
	@ApiProperty({ type: [NavexCaseReportResponseDto] }) records: NavexCaseReportResponseDto[];
	@ApiProperty({ description: 'Rows matching the filter, across all pages' }) total: number;
	@ApiProperty({ description: 'Rows on this page' }) pageTotal: number;
	@ApiProperty() page: number;
	@ApiProperty() limit: number;
	@ApiProperty({ description: 'Total pages for the current filter and limit' }) pages: number;
	@ApiProperty({ description: 'Sort actually applied, after the allow-list' }) sortBy: string;
	@ApiProperty({ enum: ['asc', 'desc'] }) sortDir: string;
	@ApiProperty({
		type: NavexReportSummaryDto,
		description: 'Counts across the whole table, not the filtered page — these are the stat cards',
	})
	summary: NavexReportSummaryDto;
}

export class NavexFilterOptionDto {
	@ApiProperty() value: string;
	@ApiProperty({ description: 'Rows that would match if this value were selected' }) count: number;
}

export class NavexFilterOptionsResponseDto {
	@ApiProperty({ type: [NavexFilterOptionDto] }) statuses: NavexFilterOptionDto[];
	@ApiProperty({ type: [NavexFilterOptionDto] }) alertLevels: NavexFilterOptionDto[];
	@ApiProperty({ type: [NavexFilterOptionDto] }) primaryIssues: NavexFilterOptionDto[];
	@ApiProperty({ type: [NavexFilterOptionDto] }) countries: NavexFilterOptionDto[];
	@ApiProperty({ type: [NavexFilterOptionDto] }) caseTypes: NavexFilterOptionDto[];
	@ApiProperty({ type: [String], description: 'Column keys accepted by sortBy' })
	sortable: string[];
}

export class NavexReportPayloadResponseDto {
	@ApiProperty() navexCaseId: string;
	@ApiPropertyOptional() reportNumber: string | null;
	@ApiPropertyOptional() cmsCaseId: number | null;
	@ApiPropertyOptional() firstSyncedOn: string | null;
	@ApiPropertyOptional() lastSyncedOn: string | null;
	@ApiProperty({ description: 'The untouched GET /incidents/v1/cases/{caseId} response' })
	payload: Record<string, unknown>;
}

export class AbortSyncResponseDto {
	@ApiProperty({ description: 'How many open run rows were closed' }) aborted: number;
	@ApiProperty({ type: [String] }) runIds: string[];
	@ApiProperty({
		description:
			'True when the pipeline is still alive on this instance — the record was cleared but the work continues',
	})
	stillRunning: boolean;
	@ApiProperty() message: string;
}

export class TriggerSyncResponseDto {
	@ApiPropertyOptional({ description: 'Poll GET /navex/sync/runs/{runId} with this' })
	runId: string | null;
	@ApiProperty() message: string;
}
