import { Controller, Get, Param, ParseIntPipe, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiOperation, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import type { RequestContext } from '@/shared/types';
import {
	AbortSyncResponseDto,
	NavexCaseReportResponseDto,
	NavexFilterOptionsResponseDto,
	NavexReportListResponseDto,
	NavexReportPayloadResponseDto,
	NavexSyncRunResponseDto,
	NavexSyncStatusResponseDto,
	TriggerSyncResponseDto,
} from '../dtos';
import { NavexService, type NavexReportQueryParams } from '../services/navex.service';

@ApiTags('Navex Integration APIs')
@ApiBearerAuth()
@UseGuards(AuthGuard('oauth-bearer'))
@Controller('navex')
export class NavexController {
	constructor(private readonly navexService: NavexService) {}

	@ApiOperation({
		summary: 'Sync status',
		description: 'Watermark, last run, whether a run is in flight, and the report counts.',
	})
	@ApiResponse({ status: 200, type: NavexSyncStatusResponseDto })
	@Get('sync/status')
	public getSyncStatus(): Promise<NavexSyncStatusResponseDto> {
		return this.navexService.getSyncStatus();
	}

	@ApiOperation({ summary: 'Sync history', description: 'Recent runs, newest first.' })
	@ApiQuery({ name: 'limit', type: Number, required: false, description: 'Default 20, max 100.' })
	@ApiResponse({ status: 200, type: [NavexSyncRunResponseDto] })
	@Get('sync/runs')
	public getSyncRuns(@Query('limit') limit?: string): Promise<NavexSyncRunResponseDto[]> {
		return this.navexService.getSyncRuns(Number(limit ?? 20));
	}

	@ApiOperation({
		summary: 'One sync run',
		description: 'Poll this after starting a sync to watch it finish.',
	})
	@ApiResponse({ status: 200, type: NavexSyncRunResponseDto })
	@Get('sync/runs/:runId')
	public getSyncRun(@Param('runId') runId: string): Promise<NavexSyncRunResponseDto> {
		return this.navexService.getSyncRun(runId);
	}

	@ApiOperation({
		summary: 'Start a sync now',
		description: 'Starts the same job the nightly CronJob runs and returns immediately.',
	})
	@ApiResponse({ status: 201, type: TriggerSyncResponseDto })
	@ApiResponse({ status: 409, description: 'A sync is already running, or Navex is not configured' })
	@Post('sync/run')
	public triggerSync(@Req() request: RequestContext): Promise<TriggerSyncResponseDto> {
		return this.navexService.triggerSync(request.currentContext?.user?.username ?? 'unknown');
	}

	@ApiOperation({
		summary: 'Force-stop the sync',
		description:
			'Closes the open run record so the page unblocks and a new sync can be started. Use it when a run was killed mid-flight and the ledger row was left open. It clears the record, it does not kill a live pipeline — see stillRunning on the response.',
	})
	@ApiResponse({ status: 201, type: AbortSyncResponseDto })
	@Post('sync/abort')
	public abortSync(@Req() request: RequestContext): Promise<AbortSyncResponseDto> {
		return this.navexService.abortSync(request.currentContext?.user?.username ?? 'unknown');
	}

	@ApiOperation({
		summary: 'Synced Navex reports',
		description:
			'Server-side filtered, sorted and paged. One row per synced report, with the CMS case it is linked to if there is one.',
	})
	@ApiQuery({ name: 'search', required: false, description: 'IR number, issue, location, country or Navex id' })
	@ApiQuery({ name: 'status', required: false, description: "Navex status, e.g. 'In Process'" })
	@ApiQuery({ name: 'alertLevel', required: false, description: 'none | green | yellow | red' })
	@ApiQuery({ name: 'primaryIssue', required: false })
	@ApiQuery({ name: 'country', required: false })
	@ApiQuery({ name: 'caseType', required: false })
	@ApiQuery({ name: 'linked', required: false, enum: ['linked', 'unlinked'] })
	@ApiQuery({ name: 'updatedFrom', required: false, description: 'YYYY-MM-DD, inclusive' })
	@ApiQuery({ name: 'updatedTo', required: false, description: 'YYYY-MM-DD, inclusive' })
	@ApiQuery({
		name: 'sortBy',
		required: false,
		description: 'Column key — see sortable[] on case-reports/filters. Unknown values fall back to updatedDate.',
	})
	@ApiQuery({ name: 'sortDir', required: false, enum: ['asc', 'desc'] })
	@ApiQuery({ name: 'page', required: false, type: Number, description: '1-based. Default 1.' })
	@ApiQuery({ name: 'limit', required: false, type: Number, description: 'Default 25, max 200.' })
	@ApiResponse({ status: 200, type: NavexReportListResponseDto })
	@Get('case-reports')
	public getReports(@Query() query: NavexReportQueryParams): Promise<NavexReportListResponseDto> {
		return this.navexService.getReports(query);
	}

	@ApiOperation({
		summary: 'Filter options',
		description:
			'The values each filter can take and how many rows carry each, counted against the other active filters. Takes the same query parameters as the list.',
	})
	@ApiResponse({ status: 200, type: NavexFilterOptionsResponseDto })
	@Get('case-reports/filters')
	public getFilterOptions(
		@Query() query: NavexReportQueryParams,
	): Promise<NavexFilterOptionsResponseDto> {
		return this.navexService.getFilterOptions(query);
	}

	@ApiOperation({
		summary: 'The raw Navex report',
		description: 'The untouched detail response, for the preview panel.',
	})
	@ApiResponse({ status: 200, type: NavexReportPayloadResponseDto })
	@ApiResponse({ status: 404, description: 'That Navex case has not been synced' })
	@Get('case-reports/:navexCaseId')
	public getReportPayload(
		@Param('navexCaseId', ParseIntPipe) navexCaseId: number,
	): Promise<NavexReportPayloadResponseDto> {
		return this.navexService.getReportPayload(navexCaseId);
	}
}

export type { NavexCaseReportResponseDto };
