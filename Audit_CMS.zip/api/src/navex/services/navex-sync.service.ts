import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@/config/config.service';
import { NavexRepository } from '../repositories/navex.repository';

const NAVEX_SYNC_PACKAGE = 'navex-sync';

/**
 * The slice of `cronjobs/navex-sync/src/run.ts` this service calls. Declared here rather than
 * taken from `typeof import('navex-sync')` so the API builds without that package installed.
 */
interface NavexSyncPackage {
	startSync(options: { closeConnection?: boolean }): Promise<{
		runId: string;
		status: 'started' | 'skipped';
		completed: Promise<NavexRunReport>;
	}>;
	close(): Promise<void>;
}

interface NavexRunReport {
	status: string;
	seen: number;
	imported: number;
	updated: number;
	failed: number;
}

@Injectable()
export class NavexSyncService implements OnModuleDestroy {
	private readonly logger = new Logger(NavexSyncService.name);
	private syncPackage: Promise<NavexSyncPackage> | null = null;
	private inFlight: Promise<unknown> | null = null;

	constructor(
		private readonly configService: ConfigService,
		private readonly navexRepository: NavexRepository,
	) {}

	private loadSyncPackage(): Promise<NavexSyncPackage> {
		if (this.syncPackage) return this.syncPackage;

		const { database, navex } = this.configService.getAppConfig();

		const env: Record<string, string> = {
			CMS_DATABASE_URL: `postgres://${encodeURIComponent(database.username)}:${encodeURIComponent(
				database.password,
			)}@${database.host}:${database.port}/${database.db}`,
			CMS_DATABASE_SCHEMA: database.schema,
			CMS_DATABASE_SSL: String(database.enableSSL),
			NAVEX_API_BASE_URL: navex.baseUrl,
			NAVEX_CLIENT_ID: navex.clientId,
			NAVEX_CLIENT_SECRET: navex.clientSecret,
			NAVEX_BACKFILL_FROM: navex.backfillFrom,
			NAVEX_WATERMARK_OVERLAP_DAYS: String(navex.watermarkOverlapDays),
			NAVEX_SEARCH_WINDOW_DAYS: String(navex.searchWindowDays),
			NAVEX_DETAIL_CONCURRENCY: String(navex.detailConcurrency),
			BATCH_SIZE: String(navex.batchSize),
			DRY_RUN: String(navex.dryRun),
		};

		for (const [key, value] of Object.entries(env)) {
			if (!process.env[key]?.trim() && value) process.env[key] = value;
		}

		this.syncPackage = (import(NAVEX_SYNC_PACKAGE) as Promise<NavexSyncPackage>).catch(error => {
			this.syncPackage = null;
			throw error;
		});

		return this.syncPackage;
	}

	/** True when this API instance has the credentials the sync needs. */
	public isConfigured(): boolean {
		const { navex } = this.configService.getAppConfig();

		return Boolean(
			(process.env.NAVEX_CLIENT_ID?.trim() || navex?.clientId?.trim()) &&
				(process.env.NAVEX_CLIENT_SECRET?.trim() || navex?.clientSecret?.trim()),
		);
	}
	/** True while this instance is still awaiting a sync it started. */
	public hasRunInFlight(): boolean {
		return this.inFlight !== null;
	}

	public async trigger(triggeredBy: string): Promise<TriggerResult> {
		if (!this.isConfigured()) {
			return {
				started: false,
				runId: null,
				reason: 'Navex API credentials are not configured on this environment.',
			};
		}

		if (await this.navexRepository.isRunInProgress()) {
			return { started: false, runId: null, reason: 'A sync is already running.' };
		}

		let sync: NavexSyncPackage;

		try {
			sync = await this.loadSyncPackage();
		} catch (error) {
			this.logger.error(
				'navex-sync is not installed — run `npm ci && npm run build` in cronjobs/navex-sync, then restart the API',
				error instanceof Error ? error.stack : String(error),
			);

			return {
				started: false,
				runId: null,
				reason: 'Navex sync is not installed on this environment.',
			};
		}

		const started = await sync.startSync({ closeConnection: false });

		if (started.status === 'skipped') {
			started.completed.catch(() => undefined);

			return { started: false, runId: null, reason: 'A sync is already running.' };
		}

		const runId = started.runId;

		this.logger.log(`Navex sync ${runId} triggered manually by ${triggeredBy}`);
		this.inFlight = started.completed
			.then((report) => {
				this.logger.log(
					`Navex sync ${runId} ${report.status}: read ${report.seen}, wrote ${
						report.imported + report.updated
					}, failed ${report.failed}`,
				);
			})
			.catch((error) => {
				this.logger.error(`Navex sync ${runId} threw outside the pipeline`, error?.stack ?? error);
			})
			.finally(() => {
				this.inFlight = null;
			});

		return { started: true, runId, reason: null };
	}

	public async onModuleDestroy(): Promise<void> {
		if (!this.syncPackage) return;

		try {
			await this.inFlight;
			await (await this.syncPackage).close();
		} catch (error) {
			this.logger.warn(`Could not close the Navex sync connection: ${error}`);
		}
	}
}

export interface TriggerResult {
	started: boolean;
	runId: string | null;
	reason: string | null;
}
