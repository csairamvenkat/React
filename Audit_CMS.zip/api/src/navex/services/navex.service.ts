import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@/config/config.service';
import { HttpStatus } from '@/shared/enums';
import { HttpException } from '@/shared/exceptions';
import {
	NavexRepository,
	type CronjobRunRow,
	type NavexReportFilter,
	type NavexReportRow,
	NAVEX_SORTABLE_COLUMNS,
	isNavexSortBy,
} from '../repositories/navex.repository';
import { NavexSyncService } from './navex-sync.service';
import type {
	AbortSyncResponseDto,
	NavexCaseReportResponseDto,
	NavexFilterOptionsResponseDto,
	NavexReportListResponseDto,
	NavexReportPayloadResponseDto,
	NavexSyncRunResponseDto,
	NavexSyncStatusResponseDto,
} from '../dtos';

const MAX_PAGE_SIZE = 200;
const DEFAULT_PAGE_SIZE = 25;

/** A date-only string, as the filter inputs produce. Anything else is ignored. */
function isDateOnly(value?: string): value is string {
	return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.trim());
}

export interface NavexReportQueryParams {
	search?: string;
	status?: string;
	alertLevel?: string;
	primaryIssue?: string;
	country?: string;
	caseType?: string;
	linked?: string;
	updatedFrom?: string;
	updatedTo?: string;
	sortBy?: string;
	sortDir?: string;
	/** Arrive as strings on the wire; coerced in `getReports`. */
	page?: number | string;
	limit?: number | string;
}

@Injectable()
export class NavexService {
	private readonly logger = new Logger(NavexService.name);

	constructor(
		private readonly navexRepository: NavexRepository,
		private readonly navexSyncService: NavexSyncService,
		private readonly configService: ConfigService,
	) {}

	public async getSyncStatus(): Promise<NavexSyncStatusResponseDto> {
		const { navex } = this.configService.getAppConfig();
		const [state, inProgress, summary, [latest]] = await Promise.all([
			this.navexRepository.getSyncState(),
			this.navexRepository.isRunInProgress(),
			this.navexRepository.getReportSummary(),
			this.navexRepository.getRuns(1),
		]);

		return {
			configured: this.navexSyncService.isConfigured(),
			baseUrl: navex?.baseUrl ?? null,
			inProgress,
			watermark: toIso(state?.watermark),
			lastRunId: state?.lastRunId ?? null,
			lastRunOn: toIso(state?.lastRunOn),
			lastRunStatus: state?.lastRunStatus ?? null,
			lastError: state?.lastError ?? null,
			counters: {
				seen: state?.casesSeen ?? 0,
				imported: state?.casesImported ?? 0,
				updated: state?.casesUpdated ?? 0,
				unchanged: state?.casesUnchanged ?? 0,
				failed: state?.casesFailed ?? 0,
			},
			summary,
			latestRun: latest ? toRunDto(latest) : null,
		};
	}

	public async getSyncRuns(limit: number): Promise<NavexSyncRunResponseDto[]> {
		const runs = await this.navexRepository.getRuns(clamp(limit, 1, 100));

		return runs.map(toRunDto);
	}

	public async getSyncRun(runId: string): Promise<NavexSyncRunResponseDto> {
		const run = await this.navexRepository.getRun(runId);

		if (!run) throw new HttpException(`No sync run ${runId}`, HttpStatus.NOT_FOUND);

		return toRunDto(run);
	}

	public async triggerSync(triggeredBy: string): Promise<{ runId: string | null; message: string }> {
		const result = await this.navexSyncService.trigger(triggeredBy);

		if (!result.started) {
			throw new HttpException(result.reason ?? 'Could not start the sync.', HttpStatus.CONFLICT);
		}

		return { runId: result.runId, message: 'Sync started.' };
	}

	/**
	 * Force-close whatever the ledger still thinks is running.
	 *
	 * The common case is an orphan: the API restarted while a triggered sync was in flight, so
	 * `ledger.finish()` never ran and the row stayed open, pinning the page on "Sync in progress"
	 * and refusing every new trigger. Closing the row releases the page.
	 *
	 * It cannot kill a live pipeline. If this instance still holds the run, the work carries on in
	 * the background and will overwrite the row when it finishes — so say that plainly rather than
	 * reporting a stop that did not happen.
	 */
	public async abortSync(abortedBy: string): Promise<AbortSyncResponseDto> {
		const liveHere = this.navexSyncService.hasRunInFlight();
		const reason = liveHere
			? `Force-stopped by ${abortedBy} while the pipeline was still running on this instance`
			: `Force-stopped by ${abortedBy}`;

		const aborted = await this.navexRepository.abortRuns(abortedBy, reason);

		if (!aborted.length) {
			return { aborted: 0, runIds: [], stillRunning: liveHere, message: 'No sync was open — nothing to stop.' };
		}

		this.logger.warn(
			`Navex sync force-stopped by ${abortedBy}: ${aborted.map((run) => run.id).join(', ')}`,
		);

		return {
			aborted: aborted.length,
			runIds: aborted.map((run) => run.id),
			stillRunning: liveHere,
			message: liveHere
				? 'Sync unblocked. The pipeline was still running here and will finish in the background — its result will land in Sync history.'
				: 'Sync unblocked. The run was already dead; only the stuck record was left.',
		};
	}

	/** Turns a raw query string into a filter the repository can trust. */
	private toFilter(query: NavexReportQueryParams, page: number, limit: number): NavexReportFilter {
		return {
			search: query.search?.trim() || undefined,
			status: query.status?.trim() || undefined,
			alertLevel: query.alertLevel?.trim() || undefined,
			primaryIssue: query.primaryIssue?.trim() || undefined,
			country: query.country?.trim() || undefined,
			caseType: query.caseType?.trim() || undefined,
			linked: query.linked === 'linked' || query.linked === 'unlinked' ? query.linked : undefined,
			updatedFrom: isDateOnly(query.updatedFrom) ? query.updatedFrom : undefined,
			updatedTo: isDateOnly(query.updatedTo) ? query.updatedTo : undefined,
			sortBy: isNavexSortBy(query.sortBy) ? query.sortBy : 'updatedDate',
			sortDir: query.sortDir === 'asc' ? 'asc' : 'desc',
			limit,
			offset: (page - 1) * limit,
		};
	}

	public async getReports(query: NavexReportQueryParams): Promise<NavexReportListResponseDto> {
		const limit = clamp(toNumber(query.limit, DEFAULT_PAGE_SIZE), 1, MAX_PAGE_SIZE);
		const page = clamp(toNumber(query.page, 1), 1, Number.MAX_SAFE_INTEGER);
		const filter = this.toFilter(query, page, limit);

		const [{ rows, total }, summary] = await Promise.all([
			this.navexRepository.findReports(filter),
			this.navexRepository.getReportSummary(),
		]);

		return {
			records: rows.map(toReportDto),
			total,
			pageTotal: rows.length,
			page,
			limit,
			pages: Math.max(Math.ceil(total / limit), 1),
			sortBy: filter.sortBy as string,
			sortDir: filter.sortDir as string,
			summary,
		};
	}

	public async getFilterOptions(
		query: NavexReportQueryParams,
	): Promise<NavexFilterOptionsResponseDto> {
		const options = await this.navexRepository.getFilterOptions(
			this.toFilter(query, 1, DEFAULT_PAGE_SIZE),
		);

		return { ...options, sortable: NAVEX_SORTABLE_COLUMNS };
	}

	public async getReportPayload(navexCaseId: number): Promise<NavexReportPayloadResponseDto> {
		const row = await this.navexRepository.getReportRow(navexCaseId);

		if (!row) {
			throw new HttpException(
				`Navex case ${navexCaseId} has not been synced into the CMS`,
				HttpStatus.NOT_FOUND,
			);
		}

		return {
			navexCaseId: String(row.id),
			reportNumber: (row.report_number as string) ?? null,
			cmsCaseId: row.cmsCaseId ? Number(row.cmsCaseId) : null,
			firstSyncedOn: toIso(row.first_synced_on as Date),
			lastSyncedOn: toIso(row.last_synced_on as Date),
			payload: toNavexPayload(row),
		};
	}
}

function clamp(value: number, min: number, max: number): number {
	if (!Number.isFinite(value)) return min;

	return Math.min(Math.max(Math.trunc(value), min), max);
}

function toNumber(value: unknown, fallback: number): number {
	if (value === undefined || value === null || value === '') return fallback;

	const parsed = Number(value);

	return Number.isFinite(parsed) ? parsed : fallback;
}

function toIso(value: Date | null | undefined): string | null {
	return value ? new Date(value).toISOString() : null;
}

function toRunDto(run: CronjobRunRow): NavexSyncRunResponseDto {
	const detail = (run.detail ?? {}) as {
		counters?: Record<string, number>;
		cases?: { created?: number; followupsUpdated?: number; skipped?: number };
		failures?: { caseId: number; error: string }[];
		watermark?: string | null;
		watermarkHeldAt?: string | null;
		dryRun?: boolean;
		error?: unknown;
		since?: string | null;
	};

	return {
		id: run.id,
		status: run.status,
		rowsRead: run.rowsRead,
		rowsWritten: run.rowsWritten,
		startedOn: toIso(run.startedOn)!,
		finishedOn: toIso(run.finishedOn),
		durationMs: run.finishedOn
			? new Date(run.finishedOn).getTime() - new Date(run.startedOn).getTime()
			: null,
		since: detail.since ?? null,
		dryRun: Boolean(detail.dryRun),
		counters: {
			seen: detail.counters?.seen ?? run.rowsRead ?? 0,
			fetched: detail.counters?.fetched ?? 0,
			imported: detail.counters?.imported ?? 0,
			updated: detail.counters?.updated ?? 0,
			unchanged: detail.counters?.unchanged ?? 0,
			failed: detail.counters?.failed ?? 0,
		},
		// Left null rather than zeroed for a run that predates this block: "no case was
		// created" and "nobody was counting" are different answers, and the page says so.
		cases: detail.cases
			? {
					created: detail.cases.created ?? 0,
					followupsUpdated: detail.cases.followupsUpdated ?? 0,
					skipped: detail.cases.skipped ?? 0,
				}
			: null,
		watermark: detail.watermark ?? null,
		watermarkHeldAt: detail.watermarkHeldAt ?? null,
		failures: detail.failures ?? [],
		error: detail.error ? String((detail.error as { message?: string }).message ?? detail.error) : null,
	};
}

function toReportDto(row: NavexReportRow): NavexCaseReportResponseDto {
	return {
		navexCaseId: String(row.navexCaseId),
		reportNumber: row.reportNumber,
		status: row.status,
		alertLevel: row.alertLevel,
		caseType: row.caseType,
		primaryIssue: row.primaryIssue,
		secondaryIssues: row.secondaryIssues ?? [],
		classification: row.classification,
		organizationName: row.organizationName,
		locationName: row.locationName,
		country: row.country,
		region: row.region,
		daysOpen: row.daysOpen,
		openedDate: toIso(row.openedDate),
		reportedDate: toIso(row.reportedDate),
		updatedDate: toIso(row.updatedDate),
		closedDate: toIso(row.closedDate),
		firstSyncedOn: toIso(row.firstSyncedOn)!,
		lastSyncedOn: toIso(row.lastSyncedOn)!,
		lastSyncedRunId: row.lastSyncedRunId,
		cmsCaseId: row.cmsCaseId ? Number(row.cmsCaseId) : null,
		cmsIrNumber: row.cmsIrNumber,
		fileCount: row.fileCount ?? 0,
		participantCount: row.participantCount ?? 0,
	};
}

/**
 * Rebuilds the Navex-shaped detail object from the stored columns.
 *
 * Migration 026 dropped `original_payload` once every field it held had a column of its
 * own. This puts the shape back for the Case Report preview — the nested objects Navex
 * sends (`status`, `type`, `location`, `reporter`) are reassembled from the columns they
 * were flattened into, and the collections are returned as stored.
 *
 * Fields Navex adds in future will not appear here until they are given a column, because
 * the sync no longer keeps a catch-all copy.
 */
function toNavexPayload(row: Record<string, any>): Record<string, unknown> {
	const lookup = (name: unknown, id: unknown) =>
		name === null && id === null ? null : { id: id ?? null, name: name ?? null };

	// The Location and Reporter Information blocks are one JSONB column each (migration 034);
	// `location_name`, `country`, reporter middle name / country / badge and the visit and
	// follow-up counts are still columns of their own.
	// Keys are stripped when null, so read through a helper that puts the null back — the
	// payload is meant to look exactly as Navex sent it.
	const blob = (value: unknown) => {
		const held = (value ?? {}) as Record<string, unknown>;

		return (key: string) => held[key] ?? null;
	};
	const location = blob(row.location_data);
	const reporter = blob(row.reporter_data);

	return {
		id: Number(row.id),
		reportNumber: row.report_number,
		reportKey: row.report_key,
		caseCreator: row.case_creator,
		intakeSpecialistName: row.intake_specialist_name,

		status: lookup(row.status, row.status_id),
		type: lookup(row.case_type, row.case_type_id),
		source: lookup(row.source_name, row.source_id),
		company: lookup(row.company_name, row.company_id),
		language: lookup(row.language, row.language_id),

		alertLevel: row.alert_level,
		openedDate: row.opened_date,
		reportedDate: row.reported_date,
		updatedDate: row.updated_date,
		closedDate: row.closed_date,
		dueDate: row.due_date,
		editedDate: row.edited_date,
		resolvedDate: row.resolved_date,
		reporterInputDisabledDate: row.reporter_input_disabled_date,
		allegedIncidentDate: row.alleged_incident_date,
		daysOpen: row.days_open,

		summary: row.summary,
		synopsis: row.synopsis,
		potentialNextSteps: row.potential_next_steps,
		details: row.details,
		translatedDetails: row.translated_details,

		isHotlineCase: row.is_hotline_case,
		isContactCenter: row.is_contact_center,
		isDataPrivacy: row.is_data_privacy,
		isViolation: row.is_violation,
		isAssigneeOnly: row.is_assignee_only,
		isEdited: row.is_edited,
		hasOriginal: row.has_original,
		isReporterAnonymous: row.is_reporter_anonymous,
		dataPrivacyReason: row.data_privacy_reason,
		dataPrivacyLocation: row.data_privacy_location,

		organizationName: location('organizationName'),
		locationName: row.location_name,
		branchNumber: location('branchNumber'),
		location: {
			address: location('address'),
			city: location('city'),
			state: location('state'),
			zip: location('zip'),
			country: row.country,
			customLocations: row.custom_locations,
			customLocationFields: row.custom_location_fields,
		},

		reporter: {
			firstName: reporter('reporterFirstName'),
			middleName: row.reporter_middle_name,
			lastName: reporter('reporterLastName'),
			email: reporter('reporterEmail'),
			phoneNumber: reporter('reporterPhoneNumber'),
			country: row.reporter_country,
			availability: reporter('reporterAvailability'),
			isReporterEmployee: reporter('reporterIsEmployee'),
			reporterVisit: row.reporter_visit_count,
			reporterLastVisitDate: row.reporter_last_visit_date,
		},
		reporterIDCode: reporter('reporterIdCode'),
		reporterBadge: row.reporter_badge,
		reporterFollowupCount: row.reporter_followup_count,
		userFollowupCount: row.user_followup_count,

		legacyCaseNumber: row.legacy_case_number,
		legacyEnteredBy: row.legacy_entered_by,
		legacyEnteredDate: row.legacy_entered_date,
		legacyClosedDate: row.legacy_closed_date,
		legacyReceivedDate: row.legacy_received_date,

		participants: row.participants,
		items: row.items,
		agencies: row.agencies,
		files: row.files,
		tasks: row.tasks,
		comments: row.comments,
		investigatorNotes: row.investigator_notes,
		notes: row.notes,
		ReporterFollowups: row.reporter_followups,
		followupQuestions: row.followup_questions,
		customQuestions: row.custom_questions,
		relatedCases: row.related_cases,
		infoContributors: row.info_contributors,
		originalResponses: row.original_responses,
		customFields: row.custom_fields,
		issueTypes: row.issue_types,
		issueTypeLayers: row.issue_type_layers,
		outcomes: row.outcomes,
		correctiveAction: row.corrective_actions,
		assignmentsAndAccess: row.assignments_and_access,
	};
}
