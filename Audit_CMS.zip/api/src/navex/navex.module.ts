import { Module } from '@nestjs/common';
import { ConfigModule } from '@/config/config.module';
import { NavexController } from './controllers/navex.controller';
import { NavexRepository } from './repositories/navex.repository';
import { NavexService } from './services/navex.service';
import { NavexSyncService } from './services/navex-sync.service';

@Module({
	imports: [ConfigModule],
	controllers: [NavexController],
	providers: [NavexService, NavexSyncService, NavexRepository],
	exports: [NavexService],
})
export class NavexModule {}
