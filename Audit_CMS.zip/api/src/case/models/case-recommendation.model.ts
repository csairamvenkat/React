import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { Case } from './case.model';

@Table({ tableName: 'case_recommendations' })
export class CaseRecommendation extends BaseModel<CaseRecommendation> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'lessons_learned', type: DataType.TEXT, allowNull: true })
	public lessonsLearned: string;

	@Column({ field: 'recommendations', type: DataType.TEXT, allowNull: true })
	public recommendations: string;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
