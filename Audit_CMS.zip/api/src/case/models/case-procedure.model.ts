import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { ProcedureStatus } from '../enums/procedure-status.enum';
import { Case } from './case.model';
import { CaseAllegation } from './case-allegation.model';

export { ProcedureStatus } from '../enums/procedure-status.enum';

@Table({ tableName: 'case_procedures' })
export class CaseProcedure extends BaseModel<CaseProcedure> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@ForeignKey(() => CaseAllegation)
	@Column({ field: 'allegation_id', type: DataType.BIGINT, allowNull: true })
	public allegationId: number;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: false })
	public description: string;

	@Column({ field: 'status', type: DataType.STRING(20), allowNull: false, defaultValue: ProcedureStatus.PENDING })
	public status: ProcedureStatus;

	@Column({ field: 'action_by', type: DataType.STRING(255), allowNull: false })
	public actionBy: string;

	@Column({ field: 'action_by_user_id', type: DataType.STRING(255), allowNull: true })
	public actionByUserId: string;

	@Column({ field: 'action_by_email', type: DataType.STRING(255), allowNull: true })
	public actionByEmail: string;

	@Column({ field: 'deadline', type: DataType.DATEONLY, allowNull: false })
	public deadline: string;

	@Column({ field: 'completed_date', type: DataType.DATEONLY, allowNull: true })
	public completedDate: string;

	@Column({ field: 'work_performed', type: DataType.TEXT, allowNull: true })
	public workPerformed: string;

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@BelongsTo(() => Case)
	public case: Case;

	@BelongsTo(() => CaseAllegation)
	public allegation: CaseAllegation;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
