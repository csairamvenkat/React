import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, HasOne, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { Case } from './case.model';
import { CaseResult } from './case-result.model';
import { CaseAllegation } from './case-allegation.model';

@Table({ tableName: 'case_scope_items' })
export class CaseScopeItem extends BaseModel<CaseScopeItem> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@ForeignKey(() => CaseAllegation)
	@Column({ field: 'allegation_id', type: DataType.BIGINT, allowNull: true })
	public allegationId: number;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: false })
	public description: string;

	@Column({ field: 'assigned_user_id', type: DataType.STRING(255), allowNull: true })
	public assignedUserId: string;

	@Column({ field: 'assigned_user_name', type: DataType.STRING(255), allowNull: true })
	public assignedUserName: string;

	@Column({ field: 'assigned_user_email', type: DataType.STRING(255), allowNull: true })
	public assignedUserEmail: string;

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@BelongsTo(() => Case)
	public case: Case;

	@BelongsTo(() => CaseAllegation)
	public allegation: CaseAllegation;

	@HasOne(() => CaseResult)
	public result: CaseResult;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
