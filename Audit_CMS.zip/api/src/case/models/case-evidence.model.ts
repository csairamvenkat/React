import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { EvidenceCategory } from '../enums/evidence-category.enum';
import { Case } from './case.model';

export { EvidenceCategory } from '../enums/evidence-category.enum';

@Table({ tableName: 'case_evidence' })
export class CaseEvidence extends BaseModel<CaseEvidence> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'allegation_id', type: DataType.BIGINT, allowNull: true })
	public allegationId: number;

	@Column({ field: 'procedure_id', type: DataType.BIGINT, allowNull: true })
	public procedureId: number;

	@Column({ field: 'category', type: DataType.STRING(50), allowNull: false })
	public category: EvidenceCategory;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: true })
	public description: string;

	@Column({ field: 'file_name', type: DataType.STRING(500), allowNull: false })
	public fileName: string;

	@Column({ field: 'file_path', type: DataType.STRING(1000), allowNull: false })
	public filePath: string;

	@Column({ field: 'file_size', type: DataType.BIGINT, allowNull: true })
	public fileSize: number;

	@Column({ field: 'mime_type', type: DataType.STRING(255), allowNull: true })
	public mimeType: string;

	@Column({ field: 'uploaded_by', type: DataType.STRING(255), allowNull: false })
	public uploadedBy: string;

	@Column({ field: 'is_key_evidence', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public isKeyEvidence: boolean;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
