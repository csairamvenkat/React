import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { Case } from './case.model';
import { CaseScopeItem } from './case-scope-item.model';
import { AnalysisResult } from './case.model';

@Table({ tableName: 'case_results' })
export class CaseResult extends BaseModel<CaseResult> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@ForeignKey(() => CaseScopeItem)
	@Column({ field: 'scope_item_id', type: DataType.BIGINT, allowNull: false })
	public scopeItemId: number;

	@Column({ field: 'date_completed', type: DataType.DATEONLY, allowNull: true })
	public dateCompleted: string;

	@Column({ field: 'analysis_result', type: DataType.STRING(50), allowNull: true })
	public analysisResult: AnalysisResult;

	@Column({ field: 'detailed_analysis', type: DataType.TEXT, allowNull: true })
	public detailedAnalysis: string;

	@BelongsTo(() => Case)
	public case: Case;

	@BelongsTo(() => CaseScopeItem)
	public scopeItem: CaseScopeItem;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
