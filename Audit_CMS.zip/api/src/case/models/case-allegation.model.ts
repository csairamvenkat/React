import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { AllegationOutcome } from '../enums/allegation-outcome.enum';
import { CaseClassification } from '../enums/case-classification.enum';
import { Case } from './case.model';

export { AllegationOutcome } from '../enums/allegation-outcome.enum';

@Table({ tableName: 'case_allegations' })
export class CaseAllegation extends BaseModel<CaseAllegation> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'label', type: DataType.STRING(100), allowNull: false })
	public label: string;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: false })
	public description: string;

	@Column({ field: 'incident_type_code', type: DataType.STRING(10), allowNull: true })
	public incidentTypeCode: string;

	@Column({ field: 'classification', type: DataType.STRING(20), allowNull: true })
	public classification: CaseClassification;

	@Column({ field: 'outcome', type: DataType.STRING(50), allowNull: true })
	public outcome: AllegationOutcome;

	@Column({ field: 'detailed_analysis', type: DataType.TEXT, allowNull: true })
	public detailedAnalysis: string;

	@Column({ field: 'loss_amount', type: DataType.DECIMAL(18, 2), allowNull: true })
	public lossAmount: number;

	@Column({ field: 'recovered_amount', type: DataType.DECIMAL(18, 2), allowNull: true })
	public recoveredAmount: number;

	@Column({ field: 'currency', type: DataType.STRING(10), allowNull: false, defaultValue: 'USD' })
	public currency: string;

	@Column({ field: 'loss_notes', type: DataType.TEXT, allowNull: true })
	public lossNotes: string;

	@Column({ field: 'outcome_confirmed', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public outcomeConfirmed: boolean;

	@Column({ field: 'outcome_confirmed_by', type: DataType.STRING(255), allowNull: true })
	public outcomeConfirmedBy: string;

	@Column({ field: 'outcome_confirmed_on', type: 'TIMESTAMP', allowNull: true })
	public outcomeConfirmedOn: Date;

	@Column({ field: 'allegation_manager_id', type: DataType.STRING(255), allowNull: true })
	public allegationManagerId: string;

	@Column({ field: 'allegation_manager_name', type: DataType.STRING(255), allowNull: true })
	public allegationManagerName: string;

	@Column({
		field: 'sub_assignees',
		type: DataType.TEXT,
		allowNull: true,
		get() {
			const raw = this.getDataValue('sub_assignees');
			if (!raw) return [];
			try { return JSON.parse(raw); } catch { return []; }
		},
		set(value: any[]) {
			this.setDataValue('sub_assignees', JSON.stringify(value ?? []));
		},
	})
	public subAssignees: any[];

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@Column({ field: 'scope_review_needed', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public scopeReviewNeeded: boolean;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
