import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { Case } from './case.model';

@Table({ tableName: 'case_user_permissions' })
export class CaseUserPermission extends BaseModel<CaseUserPermission> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'user_id', type: DataType.STRING(255), allowNull: false })
	public userId: string;

	@Column({ field: 'user_name', type: DataType.STRING(255), allowNull: true })
	public userName: string;

	@Column({ field: 'user_email', type: DataType.STRING(255), allowNull: true })
	public userEmail: string;

	@Column({ field: 'role', type: DataType.STRING(100), allowNull: true })
	public role: string;

	@Column({ field: 'source_type', type: DataType.STRING(50), allowNull: true })
	public sourceType: string | null;

	@Column({ field: 'source_id', type: DataType.BIGINT, allowNull: true })
	public sourceId: number | null;

	@Column({
		field: 'sections',
		type: DataType.TEXT,
		allowNull: true,
		get() {
			const raw = this.getDataValue('sections');
			if (!raw) return [];
			try { return JSON.parse(raw); } catch { return []; }
		},
		set(value: string[]) {
			this.setDataValue('sections', JSON.stringify(value ?? []));
		},
	})
	public sections: string[];

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
