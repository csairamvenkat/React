import {
	BelongsTo,
	Column,
	CreatedAt,
	DataType,
	HasMany,
	HasOne,
	Sequelize,
	Table,
	UpdatedAt,
} from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { CaseScopeItem } from './case-scope-item.model';
import { CaseProcedure } from './case-procedure.model';
import { CaseRemediationAction } from './case-remediation-action.model';
import { CaseRecommendation } from './case-recommendation.model';
import { CaseRecommendationItem } from './case-recommendation-item.model';
import { CaseEvidence } from './case-evidence.model';
import { CaseAllegation } from './case-allegation.model';
import { CaseFraudRisk } from './case-fraud-risk.model';
import { CaseStatus } from '../enums/case-status.enum';
import { CaseClassification } from '../enums/case-classification.enum';
import { CaseSourceType } from '../enums/case-source-type.enum';
import { AnalysisResult } from '../enums/analysis-result.enum';

export { CaseStatus } from '../enums/case-status.enum';
export { CaseClassification } from '../enums/case-classification.enum';
export { CaseSourceType } from '../enums/case-source-type.enum';
export { AnalysisResult } from '../enums/analysis-result.enum';

@Table({ tableName: 'cases' })
export class Case extends BaseModel<Case> {
	@Column({ field: 'ir_number', type: DataType.STRING(100), allowNull: false })
	public irNumber: string;

	@Column({ field: 'business_unit', type: DataType.STRING(255), allowNull: false })
	public businessUnit: string;

	@Column({ field: 'business_entity_id', type: DataType.BIGINT, allowNull: true })
	public businessEntityId: number;

	@Column({ field: 'business_entity_code', type: DataType.STRING(100), allowNull: true })
	public businessEntityCode: string;

	@Column({ field: 'assigned_to', type: DataType.STRING(255), allowNull: true })
	public assignedTo: string;

	@Column({ field: 'source_type', type: DataType.STRING(20), allowNull: false, defaultValue: CaseSourceType.CMS })
	public sourceType: CaseSourceType;

	@Column({ field: 'mode', type: DataType.STRING(255), allowNull: true })
	public mode: string;

	@Column({ field: 'source_details', type: DataType.TEXT, allowNull: true })
	public sourceDetails: string;

	@Column({ field: 'classification', type: DataType.STRING(20), allowNull: true })
	public classification: CaseClassification;

	@Column({ field: 'category', type: DataType.STRING(10), allowNull: true })
	public category: string;

	@Column({ field: 'primary_issue', type: DataType.STRING(255), allowNull: true })
	public primaryIssue: string;

	@Column({ field: 'secondary_issues', type: DataType.TEXT, allowNull: true })
	public secondaryIssues: string;

	@Column({ field: 'date_of_report', type: DataType.DATEONLY, allowNull: false })
	public dateOfReport: string;

	@Column({ field: 'current_stage', type: DataType.STRING(50), allowNull: false, defaultValue: CaseStatus.CASE_CREATED })
	public currentStage: CaseStatus;

	@Column({ field: 'rejection_reason', type: DataType.TEXT, allowNull: true })
	public rejectionReason: string;

	@Column({ field: 'overall_analysis_result', type: DataType.STRING(50), allowNull: true })
	public overallAnalysisResult: AnalysisResult;

	@Column({ field: 'conclusion', type: DataType.TEXT, allowNull: true })
	public conclusion: string;

	@Column({ field: 'synopsis', type: DataType.TEXT, allowNull: true })
	public synopsis: string;

	@Column({ field: 'department_of_accused', type: DataType.STRING(255), allowNull: true })
	public departmentOfAccused: string;

	@Column({ field: 'region', type: DataType.STRING(100), allowNull: true })
	public region: string;

	@Column({ field: 'country', type: DataType.STRING(100), allowNull: true })
	public country: string;

	@Column({ field: 'business_pillar', type: DataType.STRING(255), allowNull: true })
	public businessPillar: string;

	@Column({ field: 'business_vertical', type: DataType.STRING(255), allowNull: true })
	public businessVertical: string;

	@Column({ field: 'intake_channel', type: DataType.STRING(100), allowNull: true })
	public intakeChannel: string;

	@Column({ field: 'is_anonymous', type: DataType.BOOLEAN, allowNull: true })
	public isAnonymous: boolean;

	@Column({ field: 'closed_on', type: 'TIMESTAMP', allowNull: true })
	public closedOn: Date;

	@Column({ field: 'alert_status', type: DataType.STRING(50), allowNull: true })
	public alertStatus: string;

	@Column({ field: 'fmf_classification', type: DataType.STRING(20), allowNull: true })
	public fmfClassification: string;

	@Column({ field: 'investigation_required', type: DataType.BOOLEAN, allowNull: true })
	public investigationRequired: boolean;

	@Column({ field: 'no_investigation_reason', type: DataType.TEXT, allowNull: true })
	public noInvestigationReason: string;

	@Column({ field: 'case_lead', type: DataType.STRING(255), allowNull: true })
	public caseLead: string;

	@Column({ field: 'linked_ir_number', type: DataType.STRING(100), allowNull: true })
	public linkedIrNumber: string;

	@Column({ field: 'routing_type', type: DataType.STRING(50), allowNull: true })
	public routingType: string;

	@Column({ field: 'posnco_cdpq_flag', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public posncdpqFlag: boolean;

	@Column({ field: 'remediation_not_applicable', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public remediationNotApplicable: boolean;

	@Column({ field: 'remediation_confirmed_by', type: DataType.STRING(255), allowNull: true })
	public remediationConfirmedBy: string;

	@Column({ field: 'remediation_confirmed_on', type: 'TIMESTAMP', allowNull: true })
	public remediationConfirmedOn: Date;

	@Column({ field: 'recommendations_not_applicable', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public recommendationsNotApplicable: boolean;

	@Column({ field: 'recommendations_confirmed_by', type: DataType.STRING(255), allowNull: true })
	public recommendationsConfirmedBy: string;

	@Column({ field: 'recommendations_confirmed_on', type: 'TIMESTAMP', allowNull: true })
	public recommendationsConfirmedOn: Date;

	@Column({ field: 'approval_task_ids', type: DataType.TEXT, allowNull: true })
	public approvalTaskIds: string;

	@Column({ field: 'is_deactivated', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public isDeactivated: boolean;

	@Column({ field: 'deactivated_by', type: DataType.STRING(255), allowNull: true })
	public deactivatedBy: string;

	@Column({ field: 'deactivated_on', type: 'TIMESTAMP', allowNull: true })
	public deactivatedOn: Date;

	@Column({ field: 'status', type: DataType.STRING(50), allowNull: true })
	public status: string;

	@Column({ field: 'navex_case_id', type: DataType.BIGINT, allowNull: true })
	public navexCaseId: number;

	@Column({ field: 'report_key', type: DataType.STRING(100), allowNull: true })
	public reportKey: string;

	@Column({ field: 'case_creator', type: DataType.STRING(255), allowNull: true })
	public caseCreator: string;

	@Column({ field: 'intake_specialist_name', type: DataType.STRING(255), allowNull: true })
	public intakeSpecialistName: string;

	@Column({ field: 'days_open', type: DataType.INTEGER, allowNull: true })
	public daysOpen: number;

	@Column({ field: 'alert_level', type: DataType.STRING(20), allowNull: true })
	public alertLevel: string;

	@Column({ field: 'due_date', type: 'TIMESTAMP', allowNull: true })
	public dueDate: Date;

	@Column({ field: 'resolved_date', type: 'TIMESTAMP', allowNull: true })
	public resolvedDate: Date;

	@Column({ field: 'reporter_input_disabled_date', type: 'TIMESTAMP', allowNull: true })
	public reporterInputDisabledDate: Date;

	@Column({ field: 'alleged_incident_date', type: 'TIMESTAMP', allowNull: true })
	public allegedIncidentDate: Date;

	@Column({ field: 'case_type', type: DataType.STRING(100), allowNull: true })
	public caseType: string;

	@Column({ field: 'corrective_action', type: DataType.STRING(255), allowNull: true })
	public correctiveAction: string;

	@Column({ field: 'summary', type: DataType.TEXT, allowNull: true })
	public summary: string;

	@Column({ field: 'details', type: DataType.TEXT, allowNull: true })
	public details: string;

	@Column({ field: 'translated_details', type: DataType.TEXT, allowNull: true })
	public translatedDetails: string;

	@Column({ field: 'language', type: DataType.STRING(100), allowNull: true })
	public language: string;

	@Column({ field: 'assigned_tier', type: DataType.STRING(255), allowNull: true })
	public assignedTier: string;

	/**
	 * Case Report ▸ Location, as one blob — organizationName, branchNumber, address, city,
	 * state, zip. `country` and `businessUnit` stay their own columns: Analytics filters on
	 * country in SQL, and businessUnit is used across the whole app.
	 */
	@Column({ field: 'location_data', type: DataType.JSONB, allowNull: true })
	public locationData: Record<string, unknown>;

	/**
	 * Case Report ▸ Reporter Information, as one blob — reporterFirstName, reporterLastName,
	 * reporterEmail, reporterPhoneNumber, reporterIdCode, reporterAvailability,
	 * reporterIsEmployee. `isAnonymous` stays its own column; Analytics aggregates on it.
	 */
	@Column({ field: 'reporter_data', type: DataType.JSONB, allowNull: true })
	public reporterData: Record<string, unknown>;

	@Column({ field: 'argus_unique_id', type: DataType.STRING(100), allowNull: true })
	public argusUniqueId: string;

	@Column({ field: 'incident_address', type: DataType.TEXT, allowNull: true })
	public incidentAddress: string;

	@Column({ field: 'is_hotline_case', type: DataType.BOOLEAN, allowNull: true })
	public isHotlineCase: boolean;

	@Column({ field: 'is_contact_center', type: DataType.BOOLEAN, allowNull: true })
	public isContactCenter: boolean;

	@Column({ field: 'is_data_privacy', type: DataType.BOOLEAN, allowNull: true })
	public isDataPrivacy: boolean;

	@Column({ field: 'data_privacy_reason', type: DataType.STRING(100), allowNull: true })
	public dataPrivacyReason: string;

	@Column({ field: 'data_privacy_location', type: DataType.STRING(255), allowNull: true })
	public dataPrivacyLocation: string;

	@Column({ field: 'is_violation', type: DataType.BOOLEAN, allowNull: true })
	public isViolation: boolean;

	@Column({ field: 'is_assignee_only', type: DataType.BOOLEAN, allowNull: true })
	public isAssigneeOnly: boolean;

	@Column({ field: 'is_edited', type: DataType.BOOLEAN, allowNull: true })
	public isEdited: boolean;

	@Column({ field: 'has_original', type: DataType.BOOLEAN, allowNull: true })
	public hasOriginal: boolean;

	// The panel's Reporter Information fields now live in `reporterData`. These three are not
	// part of that section and keep their own columns.
	@Column({ field: 'reporter_middle_name', type: DataType.STRING(255), allowNull: true })
	public reporterMiddleName: string;

	@Column({ field: 'reporter_country', type: DataType.STRING(100), allowNull: true })
	public reporterCountry: string;

	@Column({ field: 'reporter_badge', type: DataType.STRING(100), allowNull: true })
	public reporterBadge: string;

	@Column({ field: 'reporter_followup_count', type: DataType.INTEGER, allowNull: true })
	public reporterFollowupCount: number;

	@Column({ field: 'user_followup_count', type: DataType.INTEGER, allowNull: true })
	public userFollowupCount: number;

	@Column({ field: 'legacy_case_number', type: DataType.STRING(100), allowNull: true })
	public legacyCaseNumber: string;

	@Column({ field: 'legacy_entered_by', type: DataType.STRING(255), allowNull: true })
	public legacyEnteredBy: string;

	@Column({ field: 'legacy_entered_date', type: 'TIMESTAMP', allowNull: true })
	public legacyEnteredDate: Date;

	@Column({ field: 'legacy_closed_date', type: 'TIMESTAMP', allowNull: true })
	public legacyClosedDate: Date;

	@Column({ field: 'legacy_received_date', type: 'TIMESTAMP', allowNull: true })
	public legacyReceivedDate: Date;

	@Column({ field: 'partial_report', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public partialReport: boolean;

	@Column({ field: 'navex_participants', type: DataType.JSONB, allowNull: true })
	public navexParticipants: Record<string, unknown>[];

	@Column({ field: 'navex_files', type: DataType.JSONB, allowNull: true })
	public navexFiles: Record<string, unknown>[];

	@Column({ field: 'navex_comments', type: DataType.JSONB, allowNull: true })
	public navexComments: Record<string, unknown>[];

	@Column({ field: 'navex_custom_questions', type: DataType.JSONB, allowNull: true })
	public navexCustomQuestions: Record<string, unknown>[];

	@Column({ field: 'navex_related_cases', type: DataType.JSONB, allowNull: true })
	public navexRelatedCases: Record<string, unknown>[];

	@Column({ field: 'navex_issue_type_layers', type: DataType.JSONB, allowNull: true })
	public navexIssueTypeLayers: Record<string, unknown>[];

	@Column({ field: 'navex_notes', type: DataType.JSONB, allowNull: true })
	public navexNotes: Record<string, unknown>[];

	@Column({ field: 'navex_followup_questions', type: DataType.JSONB, allowNull: true })
	public navexFollowupQuestions: Record<string, unknown>[];

	@Column({ field: 'case_report_edited', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public caseReportEdited: boolean;

	@Column({ field: 'case_report_saved_at', type: 'TIMESTAMP', allowNull: true })
	public caseReportSavedAt: Date;

	@Column({ field: 'case_report_saved_by', type: DataType.STRING(255), allowNull: true })
	public caseReportSavedBy: string;

	@HasMany(() => CaseScopeItem)
	public scopeItems: CaseScopeItem[];

	@HasMany(() => CaseProcedure)
	public procedures: CaseProcedure[];

	@HasMany(() => CaseRemediationAction)
	public remediationActions: CaseRemediationAction[];

	@HasOne(() => CaseRecommendation)
	public recommendation: CaseRecommendation;

	@HasMany(() => CaseRecommendationItem)
	public recommendationItems: CaseRecommendationItem[];

	@HasMany(() => CaseEvidence)
	public evidence: CaseEvidence[];

	@HasMany(() => CaseAllegation)
	public allegations: CaseAllegation[];

	@HasMany(() => CaseFraudRisk)
	public fraudRisks: CaseFraudRisk[];

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
