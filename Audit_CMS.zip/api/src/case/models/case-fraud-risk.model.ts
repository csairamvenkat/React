import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { Case } from './case.model';

@Table({ tableName: 'case_fraud_risks' })
export class CaseFraudRisk extends BaseModel<CaseFraudRisk> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'risk_category', type: DataType.STRING(255), allowNull: false })
	public riskCategory: string;

	@Column({ field: 'risk_subcategory', type: DataType.STRING(255), allowNull: true })
	public riskSubcategory: string;

	@Column({ field: 'risk_description', type: DataType.TEXT, allowNull: true })
	public riskDescription: string;

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
