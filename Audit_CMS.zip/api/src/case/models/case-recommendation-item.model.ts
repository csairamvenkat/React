import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { RecommendationItemType } from '../enums/recommendation-item-type.enum';
import { RecommendationItemStatus } from '../enums/recommendation-item-status.enum';
import { Case } from './case.model';

export { RecommendationItemType } from '../enums/recommendation-item-type.enum';
export { RecommendationItemStatus } from '../enums/recommendation-item-status.enum';

@Table({ tableName: 'case_recommendation_items' })
export class CaseRecommendationItem extends BaseModel<CaseRecommendationItem> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'issue_title', type: DataType.STRING(500), allowNull: false })
	public issueTitle: string;

	@Column({ field: 'issue_description', type: DataType.TEXT, allowNull: true })
	public issueDescription: string;

	@Column({ field: 'action_details', type: DataType.TEXT, allowNull: true })
	public actionDetails: string;

	@Column({ field: 'implementation_deadline', type: DataType.DATEONLY, allowNull: true })
	public implementationDeadline: string;

	@Column({ field: 'recommendation_type', type: DataType.STRING(100), allowNull: true })
	public recommendationType: RecommendationItemType;

	@Column({ field: 'recommendation_owner', type: DataType.STRING(255), allowNull: true })
	public recommendationOwner: string;

	@Column({ field: 'recommendation_owner_email', type: DataType.STRING(255), allowNull: true })
	public recommendationOwnerEmail: string;

	@Column({ field: 'implementation_notes', type: DataType.TEXT, allowNull: true })
	public implementationNotes: string;

	@Column({ field: 'status', type: DataType.STRING(20), allowNull: false, defaultValue: RecommendationItemStatus.PENDING })
	public status: RecommendationItemStatus;

	@Column({ field: 'arms_transferred', type: DataType.BOOLEAN, allowNull: false, defaultValue: false })
	public armsTransferred: boolean;

	@Column({ field: 'arms_transferred_at', type: DataType.DATE, allowNull: true })
	public armsTransferredAt: Date;

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
