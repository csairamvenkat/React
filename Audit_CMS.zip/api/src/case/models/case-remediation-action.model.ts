import { BelongsTo, Column, CreatedAt, DataType, ForeignKey, Sequelize, Table, UpdatedAt } from 'sequelize-typescript';
import { BaseModel } from 'src/shared/models';
import { RemediationActionType } from '../enums/remediation-action-type.enum';
import { RemediationStatus } from '../enums/remediation-status.enum';
import { Case } from './case.model';

export { RemediationActionType } from '../enums/remediation-action-type.enum';
export { RemediationStatus } from '../enums/remediation-status.enum';

@Table({ tableName: 'case_remediation_actions' })
export class CaseRemediationAction extends BaseModel<CaseRemediationAction> {
	@ForeignKey(() => Case)
	@Column({ field: 'case_id', type: DataType.BIGINT, allowNull: false })
	public caseId: number;

	@Column({ field: 'action_type', type: DataType.STRING(100), allowNull: false })
	public actionType: RemediationActionType;

	@Column({ field: 'description', type: DataType.TEXT, allowNull: true })
	public description: string;

	@Column({ field: 'responsible_party', type: DataType.STRING(255), allowNull: true })
	public responsibleParty: string;

	@Column({ field: 'responsible_email', type: DataType.STRING(255), allowNull: true })
	public responsibleEmail: string;

	@Column({ field: 'status', type: DataType.STRING(20), allowNull: false, defaultValue: RemediationStatus.PENDING })
	public status: RemediationStatus;

	@Column({ field: 'sort_order', type: DataType.INTEGER, allowNull: false, defaultValue: 0 })
	public sortOrder: number;

	@BelongsTo(() => Case)
	public case: Case;

	@Column({ field: 'active', type: DataType.BOOLEAN, defaultValue: true, allowNull: false })
	public active: boolean;

	@Column({ field: 'deleted', type: DataType.BOOLEAN, defaultValue: false, allowNull: false })
	public deleted: boolean;

	@CreatedAt
	@Column({ field: 'created_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public createdOn: Date;

	@Column({ field: 'created_by', type: DataType.STRING, allowNull: false })
	public createdBy: string;

	@UpdatedAt
	@Column({ field: 'updated_on', allowNull: false, type: 'TIMESTAMP', defaultValue: Sequelize.literal('CURRENT_TIMESTAMP(6)') })
	public updatedOn: Date;

	@Column({ field: 'updated_by', type: DataType.STRING, allowNull: false })
	public updatedBy: string;
}
