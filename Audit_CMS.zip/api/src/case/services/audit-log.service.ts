import { Injectable } from '@nestjs/common';
import { HistoryApiClient } from 'src/shared/clients';
import { HISTORY_ENTITY_TYPE } from 'src/shared/enums';
import { AddHistoryRequest, HistoryResponse } from 'src/shared/types';
import { CurrentContext } from 'src/shared/types';

export const CMS_AUDIT_ACTION = {
	CASE_CREATED: 'CASE_CREATED',
	CASE_UPDATED: 'CASE_UPDATED',
	CASE_DELETED: 'CASE_DELETED',
	CASE_DEACTIVATED: 'CASE_DEACTIVATED',
	CASE_CLOSED: 'CASE_CLOSED',
	STAGE_ADVANCED: 'STAGE_ADVANCED',
	STAGE_REJECTED: 'STAGE_REJECTED',
	CASE_RECLASSIFIED: 'CASE_RECLASSIFIED',
	CASE_REPORT_SAVED: 'CASE_REPORT_SAVED',
	CASE_REPORT_RESET: 'CASE_REPORT_RESET',
	ALLEGATION_CREATED: 'ALLEGATION_CREATED',
	ALLEGATION_UPDATED: 'ALLEGATION_UPDATED',
	ALLEGATION_DELETED: 'ALLEGATION_DELETED',
	ALLEGATION_RECLASSIFIED: 'ALLEGATION_RECLASSIFIED',
	INCIDENT_TYPE_CHANGED: 'INCIDENT_TYPE_CHANGED',
	SCOPE_ITEM_CREATED: 'SCOPE_ITEM_CREATED',
	SCOPE_ITEM_UPDATED: 'SCOPE_ITEM_UPDATED',
	SCOPE_ITEM_DELETED: 'SCOPE_ITEM_DELETED',
	PROCEDURE_CREATED: 'PROCEDURE_CREATED',
	PROCEDURE_UPDATED: 'PROCEDURE_UPDATED',
	PROCEDURE_COMPLETED: 'PROCEDURE_COMPLETED',
	PROCEDURE_DELETED: 'PROCEDURE_DELETED',
	RESULTS_SAVED: 'RESULTS_SAVED',
	OUTCOME_CONFIRMED: 'OUTCOME_CONFIRMED',
	OUTCOME_UNCONFIRMED: 'OUTCOME_UNCONFIRMED',
	REMEDIATION_CREATED: 'REMEDIATION_CREATED',
	REMEDIATION_UPDATED: 'REMEDIATION_UPDATED',
	REMEDIATION_DELETED: 'REMEDIATION_DELETED',
	RECOMMENDATION_SAVED: 'RECOMMENDATION_SAVED',
	RECOMMENDATION_ITEM_CREATED: 'RECOMMENDATION_ITEM_CREATED',
	RECOMMENDATION_ITEM_UPDATED: 'RECOMMENDATION_ITEM_UPDATED',
	RECOMMENDATION_ITEM_DELETED: 'RECOMMENDATION_ITEM_DELETED',
	ARMS_TRANSFER: 'ARMS_TRANSFER',
	FRAUD_RISK_CREATED: 'FRAUD_RISK_CREATED',
	FRAUD_RISK_UPDATED: 'FRAUD_RISK_UPDATED',
	FRAUD_RISK_DELETED: 'FRAUD_RISK_DELETED',
	EVIDENCE_UPLOADED: 'EVIDENCE_UPLOADED',
	EVIDENCE_UPDATED: 'EVIDENCE_UPDATED',
	EVIDENCE_DELETED: 'EVIDENCE_DELETED',
	ACCESS_GRANTED: 'ACCESS_GRANTED',
	ACCESS_REVOKED: 'ACCESS_REVOKED',
	ROLE_ASSIGNED: 'ROLE_ASSIGNED',
	ROLE_REMOVED: 'ROLE_REMOVED',
	TASK_CREATED: 'TASK_CREATED',
	TASK_APPROVED: 'TASK_APPROVED',
	TASK_REJECTED: 'TASK_REJECTED',
} as const;

export type CmsAuditAction = (typeof CMS_AUDIT_ACTION)[keyof typeof CMS_AUDIT_ACTION];

export interface CmsLogPayload {
	caseId: number;
	action: CmsAuditAction;
	comments: string;
	additionalInfo?: Record<string, any>;
}

const FIELD_LABEL: Record<string, string> = {
	irNumber: 'IR Number',
	businessUnit: 'Business Unit',
	classification: 'Classification',
	category: 'Category',
	primaryIssue: 'Primary Issue',
	secondaryIssues: 'Secondary Issues',
	dateOfReport: 'Date of Report',
	synopsis: 'Synopsis',
	departmentOfAccused: 'Department of Accused',
	alertStatus: 'Alert Status',
	fmfClassification: 'FMF Classification',
	investigationRequired: 'Investigation Required',
	noInvestigationReason: 'No Investigation Reason',
	caseLead: 'Case Lead',
	linkedIrNumber: 'Linked IR Number',
	routingType: 'Routing Type',
	overallAnalysisResult: 'Overall Analysis Result',
	conclusion: 'Conclusion',
	label: 'Label',
	description: 'Description',
	incidentTypeCode: 'Incident Type',
	outcome: 'Outcome',
	detailedAnalysis: 'Detailed Analysis',
	lossAmount: 'Loss Amount',
	recoveredAmount: 'Recovered Amount',
	currency: 'Currency',
	allegationManagerName: 'Allegation Manager',
	scopeReviewNeeded: 'Scope Review Needed',
	actionBy: 'Action By',
	deadline: 'Deadline',
	status: 'Status',
	actionType: 'Action Type',
	responsibleParty: 'Responsible Party',
	riskCategory: 'Risk Category',
	riskSubcategory: 'Risk Subcategory',
	riskDescription: 'Risk Description',
	issueTitle: 'Issue Title',
	isKeyEvidence: 'Key Evidence',
};

@Injectable()
export class AuditLogService {
	constructor(private readonly historyApiClient: HistoryApiClient) {}

	public log(payload: CmsLogPayload, currentContext: CurrentContext): void {
		const request: AddHistoryRequest = {
			created_by: currentContext.user?.username ?? 'system',
			entity_id: payload.caseId,
			entity_type: HISTORY_ENTITY_TYPE.CMS_CASE,
			action_performed: payload.action,
			comments: payload.comments,
			additional_info: payload.additionalInfo ?? null,
		};
		this.historyApiClient.addRequestHistory(request);
	}

	public logFieldDiffs(
		caseId: number,
		entityLabel: string,
		action: CmsAuditAction,
		diffs: { field: string; oldValue: any; newValue: any }[],
		currentContext: CurrentContext,
	): void {
		for (const diff of diffs) {
			if (diff.oldValue === diff.newValue) continue;
			if (diff.oldValue == null && diff.newValue == null) continue;
			const label = FIELD_LABEL[diff.field] ?? diff.field;
			const oldStr = diff.oldValue != null ? String(diff.oldValue) : '(empty)';
			const newStr = diff.newValue != null ? String(diff.newValue) : '(empty)';

			const resolvedAction =
				diff.field === 'incidentTypeCode' ? CMS_AUDIT_ACTION.INCIDENT_TYPE_CHANGED :
				diff.field === 'classification'
					? action === CMS_AUDIT_ACTION.ALLEGATION_UPDATED
						? CMS_AUDIT_ACTION.ALLEGATION_RECLASSIFIED
						: CMS_AUDIT_ACTION.CASE_RECLASSIFIED :
				action;

			this.log(
				{
					caseId,
					action: resolvedAction,
					comments: `${entityLabel} — ${label} changed: "${oldStr}" → "${newStr}"`,
					additionalInfo: { field: diff.field, oldValue: diff.oldValue, newValue: diff.newValue },
				},
				currentContext,
			);
		}
	}

	public async getAuditLogs(caseId: number): Promise<HistoryResponse[]> {
		return this.historyApiClient.getRequestHistory(caseId, HISTORY_ENTITY_TYPE.CMS_CASE);
	}
}
