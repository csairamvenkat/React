import { Injectable, Logger } from '@nestjs/common';
import { CurrentContext } from 'src/shared/types';
import { UNSCOPED_ENTITY_ID } from 'src/shared/constants';
import { HttpStatus } from 'src/shared/enums';
import { HttpException } from 'src/shared/exceptions';
import { MessageResponseDto } from 'src/shared/dtos';
import { singleObjectToInstance } from 'src/shared/helpers/response-serializer.helper';
import { assigneeEmail, buildAssignee, parseAssignee } from 'src/shared/helpers/assignee.helper';
import { Pagination } from 'src/core/pagination/pagination';
import {
	CaseRepository,
	CaseScopeItemRepository,
	CaseProcedureRepository,
	CaseRemediationActionRepository,
	CaseRecommendationRepository,
	CaseRecommendationItemRepository,
	CaseEvidenceRepository,
	CaseAllegationRepository,
	CaseFraudRiskRepository,
	CaseUserPermissionRepository,
	CaseWorkItemRepository,
} from '../repositories';
import type { WorkItemQuery, WorkItemRow } from '../repositories/case-work-item.repository';
import { AuditLogService, CMS_AUDIT_ACTION } from './audit-log.service';
import { CaseAssignmentTaskService, AssignmentTaskView } from './case-assignment-task.service';
import { CaseApprovalTaskService, CaseTaskView } from './case-approval-task.service';
import { CaseNotificationService } from './case-notification.service';
import {
	Case,
	CaseScopeItem,
	CaseProcedure,
	CaseRemediationAction,
	CaseRecommendation,
	CaseRecommendationItem,
	CaseEvidence,
	CaseAllegation,
	CaseFraudRisk,
	CaseStatus,
	CaseClassification,
	CaseSourceType,
	ProcedureStatus,
	RemediationStatus,
	RecommendationItemStatus,
} from '../models';
import {
	CreateCaseRequestDto,
	UpdateCaseRequestDto,
	CaseListFilterRequestDto,
	CreateScopeItemRequestDto,
	UpdateScopeItemRequestDto,
	CreateProcedureRequestDto,
	UpdateProcedureRequestDto,
	CompleteProcedureRequestDto,
	SaveResultsRequestDto,
	CreateRemediationActionRequestDto,
	UpdateRemediationActionRequestDto,
	SaveRecommendationRequestDto,
	NextStageRequestDto,
	CaseDetailResponseDto,
	CaseListingResponseDto,
	CreateAllegationRequestDto,
	UpdateAllegationRequestDto,
	CreateRecommendationItemRequestDto,
	UpdateRecommendationItemRequestDto,
	CreateFraudRiskRequestDto,
	UpdateFraudRiskRequestDto,
	SetUserPermissionRequestDto,
	CaseUserPermissionResponseDto,
	MyAccessResponseDto,
	MyCasePermissionsResponseDto,
	CreateCaseTaskRequestDto,
	ResolveCaseTaskRequestDto,
	DelegateRequestDto,
	CaseTaskResponseDto,
	AssignmentTaskResponseDto,
	AssignmentTaskDetailResponseDto,
	TaskProcedureResponseDto,
	CaseApproverResponseDto,
	SaveCaseReportRequestDto,
	CaseReportResponseDto,
	CaseStatsResponseDto,
	WorkListFilterRequestDto,
	WorkStatsFilterRequestDto,
	WorkItemResponseDto,
	WorkStatsResponseDto,
	WORK_ITEM_TYPES,
} from '../dtos';
import type { WorkItemType } from '../dtos';
import {
	AccessTier,
	ItemOrigin,
	AssignmentType,
	AssignmentTaskStatus,
	CaseAssignmentRole,
	PermissionSourceType,
	CaseTaskType,
	CaseTaskStatus,
	CaseTriageSection,
	CmsUserRole,
	WorkStatusFilter,
	mapAdminRoleName,
} from '../enums';
import { AdminApiClient } from '@/shared/clients';
import { CommonService } from '@/shared/services/common.service';
import { RoleService } from '@/shared/services/role.service';
import {
	STATUS_ORDER,
	ALLEGATION_MANAGER_SECTIONS,
	PROCEDURE_ASSIGNEE_SECTIONS,
	LOCATION_JSON_FIELDS,
	REPORTER_JSON_FIELDS,
	SCOPE_FRAUD_RESTRICTED_MESSAGE,
	PROCEDURE_ASSIGNEE_LOCKED_MESSAGE,
	RESULTS_ALLEGATION_RESTRICTED_MESSAGE,
	RESULTS_CASE_SUMMARY_RESTRICTED_MESSAGE,
	RESULTS_CONFIRMED_LOCKED_MESSAGE,
	CASE_RECORD_STATUS_CLOSED,
	isCaseClosed,
	resolveStage,
} from '../constants/case.constant';

export interface UploadEvidencePayload {
	caseId: number;
	allegationId?: number;
	procedureId?: number;
	category: string;
	description?: string;
	fileName: string;
	filePath: string;
	fileSize?: number;
	mimeType?: string;
	isKeyEvidence?: boolean;
}

interface WorkItemAssignee {
	userId: string | null;
	name: string | null;
	email: string | null;
}

export interface OpenActionItem {
	type: 'procedure' | 'remediation';
	id: number;
	caseId: number;
	irNumber: string;
	businessUnit: string;
	description: string;
	actionBy: string;
	deadline?: string;
	status: string;
	daysOverdue?: number;
}

@Injectable()
export class CaseService {
	private readonly logger = new Logger(CaseService.name);

	constructor(
		private readonly caseRepository: CaseRepository,
		private readonly scopeItemRepository: CaseScopeItemRepository,
		private readonly procedureRepository: CaseProcedureRepository,
		private readonly remediationActionRepository: CaseRemediationActionRepository,
		private readonly recommendationRepository: CaseRecommendationRepository,
		private readonly recommendationItemRepository: CaseRecommendationItemRepository,
		private readonly evidenceRepository: CaseEvidenceRepository,
		private readonly allegationRepository: CaseAllegationRepository,
		private readonly fraudRiskRepository: CaseFraudRiskRepository,
		private readonly userPermissionRepository: CaseUserPermissionRepository,
		private readonly workItemRepository: CaseWorkItemRepository,
		private readonly assignmentTaskService: CaseAssignmentTaskService,
		private readonly approvalTaskService: CaseApprovalTaskService,
		private readonly roleService: RoleService,
		private readonly auditLogService: AuditLogService,
		private readonly adminApiClient: AdminApiClient,
		private readonly commonService: CommonService,
		private readonly caseNotificationService: CaseNotificationService,
	) {}

	public async getCaseList(
		limit: number,
		page: number,
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
		sortBy?: string,
		sortDir?: string,
	): Promise<Pagination<CaseListingResponseDto>> {
		const hfrsPathwayMatchIds = await this._resolveHfrsPathwayMatchIds(
			searchTerm,
			filters,
			currentUsername,
		);
		const result = await this.caseRepository.getPaginatedCases(
			limit,
			page,
			searchTerm,
			filters,
			currentUsername,
			sortBy,
			sortDir,
			hfrsPathwayMatchIds,
		);
		const triageProgress = await this._getTriageProgress(result.rows);
		const records = result.rows.map(r =>
			singleObjectToInstance(CaseListingResponseDto, { ...r, ...triageProgress.get(r.id) }),
		);
		return new Pagination({ records, total: result.count });
	}

	private async _getTriageProgress(
		rows: (Case & { allegationsReady?: boolean | null })[],
	): Promise<Map<number, Pick<CaseListingResponseDto, 'triageSection' | 'hfrsApprovalPending'>>> {
		const triageRows = rows.filter(
			r => r.currentStage === CaseStatus.CASE_CREATED && r.status !== CASE_RECORD_STATUS_CLOSED,
		);
		const taskIds = triageRows
			.filter(r => r.allegationsReady && this._pathwayTaskType(r))
			.flatMap(r => this.caseRepository.parseApprovalTaskIds(r.approvalTaskIds));
		const tasks = await this.approvalTaskService.getByTaskIds(taskIds);

		return new Map(
			triageRows.map(r => {
				const caseTasks = tasks.filter(
					t => Number(t.caseId) === Number(r.id) && !this._isStalePathwayTask(t, r),
				);
				const allTasks = [...caseTasks, ...this._synthesizeApprovedApprovals(r, caseTasks)];

				return [r.id, this._triageProgress(r, allTasks)];
			}),
		);
	}

	private _pathwayTaskType(record: Case): CaseTaskType | null {
		if (record.investigationRequired === false) return CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE;
		if (record.investigationRequired && record.classification === CaseClassification.FRAUD) {
			return CaseTaskType.HFRS_FRAUD_INVESTIGATION;
		}
		return null;
	}

	private _triageProgress(
		record: Case & { allegationsReady?: boolean | null },
		tasks: CaseTaskView[],
	): Pick<CaseListingResponseDto, 'triageSection' | 'hfrsApprovalPending'> {
		if (!record.allegationsReady) {
			return { triageSection: CaseTriageSection.ALLEGATIONS, hfrsApprovalPending: false };
		}

		const pathwayType = this._pathwayTaskType(record);
		const hasPathwayTask = (status: CaseTaskStatus) =>
			tasks.some(t => t.taskType === pathwayType && t.status === status);
		const signedOff = pathwayType
			? hasPathwayTask(CaseTaskStatus.APPROVED)
			: record.investigationRequired === true;

		return {
			triageSection: signedOff ? CaseTriageSection.FINALIZATION : CaseTriageSection.CLASSIFICATION,
			hfrsApprovalPending: !signedOff && !!pathwayType && hasPathwayTask(CaseTaskStatus.PENDING),
		};
	}

	/** Stat-card counts for the list, under the same filters and access scoping. */
	public async getCaseStats(
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
	): Promise<CaseStatsResponseDto> {
		const hfrsPathwayMatchIds = await this._resolveHfrsPathwayMatchIds(
			searchTerm,
			filters,
			currentUsername,
		);
		return this.caseRepository.getCaseStats(searchTerm, filters, currentUsername, hfrsPathwayMatchIds);
	}

	private async _resolveHfrsPathwayMatchIds(
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
	): Promise<number[] | undefined> {
		if (!filters?.triageSection || filters.triageSection === CaseTriageSection.ALLEGATIONS) {
			return undefined;
		}

		const candidates = await this.caseRepository.getHfrsPathwayTriageCases(
			searchTerm,
			filters,
			currentUsername,
		);
		const progress = await this._getTriageProgress(candidates);

		return candidates
			.filter(c => {
				const p = progress.get(c.id);
				return (
					p?.triageSection === filters.triageSection &&
					(filters.hfrsApprovalPending === undefined ||
						p.hfrsApprovalPending === filters.hfrsApprovalPending)
				);
			})
			.map(c => c.id);
	}

	public async getCaseById(
		id: number,
		currentContext?: CurrentContext,
	): Promise<CaseDetailResponseDto> {
		if (currentContext) {
			await this._assertCanViewCase(id, currentContext);
		}
		const caseRecord = await this.caseRepository.getCaseByIdWithRelations(id);
		if (!caseRecord) {
			throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);
		}
		return this._withItemOrigins(caseRecord);
	}

	public async getCaseByTaskId(
		taskId: number,
		currentContext: CurrentContext,
	): Promise<CaseDetailResponseDto> {
		var valid_task = await this.commonService.validateTask(taskId, currentContext);

		if (!valid_task || !valid_task.task || !valid_task.valid) {
			throw new HttpException(
				`User doesn't has permission to perform this action.`,
				HttpStatus.FORBIDDEN,
			);
		}

		const caseRecord = await this.caseRepository.getCaseByIdWithRelations(
			valid_task.task.entity_id,
		);
		if (!caseRecord) {
			throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);
		}
		return this._withItemOrigins(caseRecord);
	}

	/**
	 * Scope items and procedures carry who added them, so the Case Lead and the Allegation Manager
	 * can each tell their own work from the other's in the shared panels.
	 */
	private async _withItemOrigins(caseRecord: Case): Promise<CaseDetailResponseDto> {
		const dto = singleObjectToInstance(CaseDetailResponseDto, caseRecord);
		const scopeItems = caseRecord.scopeItems ?? [];
		const procedures = caseRecord.procedures ?? [];
		if (scopeItems.length === 0 && procedures.length === 0) return dto;

		const originOf = await this._itemOriginResolver(caseRecord.id, [
			...scopeItems.map(i => i.createdBy),
			...procedures.map(p => p.createdBy),
		]);
		const stamp = (
			targets: { id: number; addedByRole: string | null }[],
			sources: { id: number; createdBy: string; allegationId: number }[],
		) => {
			const byId = new Map(sources.map(source => [Number(source.id), source]));
			for (const target of targets) {
				const source = byId.get(Number(target.id));
				target.addedByRole = originOf(source?.createdBy, source?.allegationId);
			}
		};
		stamp(dto.scopeItems ?? [], scopeItems);
		stamp(dto.procedures ?? [], procedures);
		return dto;
	}

	private async _assertCanViewCase(caseId: number, currentContext: CurrentContext): Promise<void> {
		const username = currentContext.user?.username?.toLowerCase();
		if (!username) {
			throw new HttpException('You do not have access to this case.', HttpStatus.FORBIDDEN);
		}
		if (await this._isCaseConfigUser(caseId, username)) return;
		if (await this._userHasGlobalViewRole(username)) return;
		if (await this.caseRepository.userHasCaseScopedRoleOnAnyCase(username)) return;
		if (await this.userPermissionRepository.getByUserAndCase(caseId, username)) return;
		const caseTasks = await this.approvalTaskService.getByCase(caseId);
		if (caseTasks.some(t => t.assignedTo?.toLowerCase() === username)) return;
		throw new HttpException('You do not have access to this case.', HttpStatus.FORBIDDEN);
	}

	public async createCase(
		dto: CreateCaseRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const businessEntity = await this._resolveSelectedBusinessEntity(dto, currentContext.entityId);
		const newCase = Case.build({
			irNumber: dto.irNumber,
			businessUnit: dto.businessUnit,
			businessEntityId: businessEntity.id,
			businessEntityCode: businessEntity.code,
			classification: dto.classification ?? null,
			category: dto.category ?? null,
			primaryIssue: dto.primaryIssue ?? null,
			secondaryIssues: dto.secondaryIssues ? JSON.stringify(dto.secondaryIssues) : null,
			dateOfReport: dto.dateOfReport,
			currentStage: CaseStatus.CASE_CREATED,
			investigationRequired: null,
			sourceType: CaseSourceType.CMS,
			mode: dto.mode ?? null,
			sourceDetails: dto.sourceDetails ?? null,

			caseType: dto.caseType ?? null,
			partialReport: dto.partialReport ?? null,

			country: dto.country ?? null,
			region: dto.region ?? null,
			businessPillar: dto.businessPillar ?? null,
			argusUniqueId: dto.argusUniqueId ?? null,
			incidentAddress: dto.incidentAddress ?? null,
			isAnonymous: dto.isAnonymous ?? null,
			alertStatus: dto.alertStatus ?? null,
			details: dto.details ?? null,
			translatedDetails: dto.translatedDetails ?? null,
			navexCustomQuestions: dto.navexCustomQuestions ?? null,

			// NOT flat columns — bundled into the locationData JSONB blob
			locationData: {
				organizationName: dto.organizationName ?? null,
				branchNumber: dto.branchNumber ?? null,
				address: dto.address ?? null,
				city: dto.city ?? null,
				state: dto.state ?? null,
				zip: dto.zip ?? null,
			},

			// NOT flat columns (except isAnonymous, already above) — bundled into reporterData
			reporterData: {
				reporterFirstName: dto.reporterFirstName ?? null,
				reporterLastName: dto.reporterLastName ?? null,
				reporterEmail: dto.reporterEmail ?? null,
				reporterPhoneNumber: dto.reporterPhoneNumber ?? null,
				reporterIdCode: dto.reporterIdCode ?? null,
				reporterAvailability: dto.reporterAvailability ?? null,
				reporterIsEmployee: dto.reporterIsEmployee ?? null,
			},
		} as any);

		const created = await this.caseRepository.createCase(newCase, currentContext);
		this.auditLogService.log(
			{
				caseId: created.id,
				action: CMS_AUDIT_ACTION.CASE_CREATED,
				comments: `Case created: ${newCase.irNumber}`,
			},
			currentContext,
		);
		return { message: 'Case has been created successfully.', data: { id: created.id } };
	}

	private async _resolveSelectedBusinessEntity(
		dto: { businessEntityId?: number; businessEntityCode?: string; businessUnit?: string },
		entityId?: number,
	): Promise<{ id: number | null; code: string | null }> {
		if (dto.businessEntityId || dto.businessEntityCode) {
			return {
				id: dto.businessEntityId ?? null,
				code: dto.businessEntityCode ?? dto.businessUnit ?? null,
			};
		}
		if (!entityId) return { id: null, code: null };
		try {
			const entity = await this.adminApiClient.getBusinessEntityDetailsById(entityId);
			return { id: entityId, code: entity?.code ?? null };
		} catch {
			return { id: entityId, code: null };
		}
	}

	public async updateCase(
		dto: UpdateCaseRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const existing = await this._beginCaseMutation(dto.id, currentContext);
		const updateData: any = {};
		if (dto.irNumber !== undefined) updateData.irNumber = dto.irNumber;
		if (dto.businessUnit !== undefined) updateData.businessUnit = dto.businessUnit;
		if (dto.businessEntityId !== undefined) updateData.businessEntityId = dto.businessEntityId;
		if (dto.businessEntityCode !== undefined)
			updateData.businessEntityCode = dto.businessEntityCode;
		if (dto.assignedTo !== undefined) updateData.assignedTo = buildAssignee(dto.assignedTo);
		if (dto.classification !== undefined) updateData.classification = dto.classification;
		if (dto.category !== undefined) updateData.category = dto.category;
		if (dto.primaryIssue !== undefined) updateData.primaryIssue = dto.primaryIssue;
		if (dto.secondaryIssues !== undefined)
			updateData.secondaryIssues = JSON.stringify(dto.secondaryIssues);
		if (dto.dateOfReport !== undefined) updateData.dateOfReport = dto.dateOfReport;
		if (dto.synopsis !== undefined) updateData.synopsis = dto.synopsis;
		if (dto.departmentOfAccused !== undefined)
			updateData.departmentOfAccused = dto.departmentOfAccused;
		if (dto.alertStatus !== undefined) updateData.alertStatus = dto.alertStatus;
		if (dto.fmfClassification !== undefined) updateData.fmfClassification = dto.fmfClassification;
		if (dto.investigationRequired !== undefined)
			updateData.investigationRequired = dto.investigationRequired;
		if (dto.noInvestigationReason !== undefined)
			updateData.noInvestigationReason = dto.noInvestigationReason;
		if (dto.caseLead !== undefined) updateData.caseLead = buildAssignee(dto.caseLead);
		if (dto.linkedIrNumber !== undefined) updateData.linkedIrNumber = dto.linkedIrNumber;
		if (dto.routingType !== undefined) updateData.routingType = dto.routingType;
		if (dto.posncdpqFlag !== undefined) updateData.posncdpqFlag = dto.posncdpqFlag;
		if (dto.remediationNotApplicable !== undefined)
			updateData.remediationNotApplicable = dto.remediationNotApplicable;
		if (dto.recommendationsNotApplicable !== undefined)
			updateData.recommendationsNotApplicable = dto.recommendationsNotApplicable;
		if (dto.overallAnalysisResult !== undefined)
			updateData.overallAnalysisResult = dto.overallAnalysisResult;
		if (dto.conclusion !== undefined) updateData.conclusion = dto.conclusion;
		if (dto.status !== undefined) updateData.status = dto.status;

		const isReclassified =
			dto.classification !== undefined &&
			existing.classification != null &&
			dto.classification !== existing.classification;
		if (isReclassified) {
			if (dto.investigationRequired === undefined) updateData.investigationRequired = null;

			if (dto.noInvestigationReason === undefined) updateData.noInvestigationReason = null;

			if (dto.caseLead === undefined) updateData.caseLead = null;

			if (dto.routingType === undefined) updateData.routingType = null;

			if (dto.alertStatus === undefined) updateData.alertStatus = null;

			if (dto.category === undefined) updateData.category = null;

			await this.approvalTaskService.cancelByCaseAndTypes(
				dto.id,
				[
					CaseTaskType.HFRS_FRAUD_INVESTIGATION,
					//CaseTaskType.HFRS_CASE_LEAD_NOMINATION,
					CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE,
				],
				currentContext,
			);
			this.auditLogService.log(
				{
					caseId: dto.id,
					action: CMS_AUDIT_ACTION.CASE_RECLASSIFIED,
					comments: `Case reclassified from "${existing.classification}" to "${dto.classification}" — triage investigation and finalization details reset, pending HFRS triage approvals voided`,
				},
				currentContext,
			);
		}

		await this.caseRepository.updateCase(dto.id, updateData, currentContext);
		const diffFields = Object.keys(updateData).map(field => ({
			field,
			oldValue: (existing as any)[field],
			newValue: (updateData as any)[field],
		}));
		this.auditLogService.logFieldDiffs(
			dto.id,
			'Case',
			CMS_AUDIT_ACTION.CASE_UPDATED,
			diffFields,
			currentContext,
		);

		if (!isReclassified) {
			if (updateData.caseLead !== undefined) {
				const newEmail = assigneeEmail(updateData.caseLead);
				if (newEmail && newEmail !== assigneeEmail(existing.caseLead)) {
					await this.caseNotificationService.notifyWorkAssigned({
						caseId: dto.id,
						userId: newEmail,
						userName: parseAssignee(updateData.caseLead)?.full_name ?? null,
						userEmail: newEmail,
						role: 'Case Lead',
					});
				}
			}
		}
		return { message: 'Case has been updated successfully.' };
	}

	public async deleteCase(id: number, currentContext: CurrentContext): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(id, currentContext);
		const [allegations, procedures, recommendationItems] = await Promise.all([
			this.allegationRepository.getByCaseId(id),
			this.procedureRepository.getByCaseId(id),
			this.recommendationItemRepository.getByCaseId(id),
		]);
		await this.caseRepository.deleteCase(id, currentContext);
		await this.approvalTaskService.cancelByCase(id, currentContext);
		await this.assignmentTaskService.cancelAllForCase(
			id,
			allegations.map(a => a.id),
			procedures.map(p => p.id),
			currentContext,
			recommendationItems.map(r => r.id),
		);
		this.auditLogService.log(
			{
				caseId: id,
				action: CMS_AUDIT_ACTION.CASE_DELETED,
				comments: `Case deleted: ${caseRecord.irNumber}`,
			},
			currentContext,
		);
		return { message: 'Case has been deleted successfully.' };
	}

	public async deactivateCase(id: number, currentContext: CurrentContext): Promise<MessageResponseDto> {
		const caseRecord = await this._assertCanDeactivateCase(id, currentContext);
		if (caseRecord.isDeactivated) {
			throw new HttpException('Case is already deactivated.', HttpStatus.BAD_REQUEST);
		}
		const user = currentContext.user?.username?.toLowerCase() ?? null;
		await this.caseRepository.updateCase(
			id,
			{ isDeactivated: true, deactivatedBy: user, deactivatedOn: new Date() } as any,
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: id,
				action: CMS_AUDIT_ACTION.CASE_DEACTIVATED,
				comments: `Case deactivated by ${user ?? 'unknown'}: ${caseRecord.irNumber}`,
			},
			currentContext,
		);
		return { message: 'Case has been deactivated.' };
	}

	/**
	 * Closing is not a stage: the case keeps whichever stage it reached and carries the closed
	 * record status instead, so a case closed during Triage still reads as a Triage case.
	 */
	public async closeCase(id: number, currentContext: CurrentContext): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(id, currentContext);
		if (isCaseClosed(caseRecord.status)) {
			throw new HttpException('This case is already closed.', HttpStatus.BAD_REQUEST);
		}

		await this.caseRepository.updateCase(
			id,
			{ status: CASE_RECORD_STATUS_CLOSED, rejectionReason: null } as any,
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: id,
				action: CMS_AUDIT_ACTION.CASE_CLOSED,
				comments: `Case closed at stage "${caseRecord.currentStage}"`,
				additionalInfo: { closedAtStage: caseRecord.currentStage },
			},
			currentContext,
		);
		return { message: 'Case has been closed.' };
	}

	public async advanceToNextStage(
		id: number,
		dto: NextStageRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(id, currentContext);
		if (isCaseClosed(caseRecord.status)) {
			throw new HttpException('This case is closed.', HttpStatus.BAD_REQUEST);
		}

		const currentIndex = STATUS_ORDER.indexOf(resolveStage(caseRecord.currentStage));
		if (currentIndex === -1) {
			throw new HttpException('Case is in an invalid state.', HttpStatus.BAD_REQUEST);
		}
		if (currentIndex >= STATUS_ORDER.length - 1) {
			throw new HttpException(
				'This is the final stage — close the case instead of advancing it.',
				HttpStatus.BAD_REQUEST,
			);
		}

		if (
			dto.approved !== false &&
			caseRecord.currentStage === CaseStatus.REMEDIATION_ACTIONS &&
			!caseRecord.remediationNotApplicable &&
			!caseRecord.remediationConfirmedBy
		) {
			throw new HttpException(
				'Confirm the remediation actions (Case Lead) before advancing to Recommendations.',
				HttpStatus.BAD_REQUEST,
			);
		}

		if (dto.approved === false) {
			await this.caseRepository.updateCase(
				id,
				{ rejectionReason: dto.rejectionReason } as any,
				currentContext,
			);
			this.auditLogService.log(
				{
					caseId: id,
					action: CMS_AUDIT_ACTION.STAGE_REJECTED,
					comments: `Stage advancement rejected at "${caseRecord.currentStage}"${
						dto.rejectionReason ? ': ' + dto.rejectionReason : ''
					}`,
				},
				currentContext,
			);
			return { message: 'Case stage advancement has been rejected.' };
		}

		const nextStatus = STATUS_ORDER[currentIndex + 1];
		await this.caseRepository.updateCase(
			id,
			{ currentStage: nextStatus, rejectionReason: null } as any,
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: id,
				action: CMS_AUDIT_ACTION.STAGE_ADVANCED,
				comments: `Stage advanced from "${caseRecord.currentStage}" to "${nextStatus}"`,
				additionalInfo: { from: caseRecord.currentStage, to: nextStatus },
			},
			currentContext,
		);
		return { message: `Case moved to stage: ${nextStatus}` };
	}

	public async getScopeItems(caseId: number): Promise<CaseScopeItem[]> {
		return this.scopeItemRepository.getByCaseId(caseId);
	}

	public async createScopeItem(
		dto: CreateScopeItemRequestDto,
		currentContext: CurrentContext,
	): Promise<{ message: string; data: { id: number } }> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		await this._assertCanWriteScope(dto.caseId, dto.allegationId, currentContext);
		const item = CaseScopeItem.build({
			caseId: dto.caseId,
			allegationId: dto.allegationId ?? null,
			description: dto.description,
			assignedUserId: dto.assignedUserId ?? null,
			assignedUserName: dto.assignedUserName ?? null,
			assignedUserEmail: dto.assignedUserEmail ?? null,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		const saved = await this.scopeItemRepository.createItem(item, currentContext);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.SCOPE_ITEM_CREATED,
				comments: `Scope item created: "${dto.description}"`,
			},
			currentContext,
		);
		return { message: 'Scope item added successfully.', data: { id: saved.id } };
	}

	public async updateScopeItem(
		dto: UpdateScopeItemRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.scopeItemRepository.getById(dto.id);
		if (!item) throw new HttpException('Scope item not found.', HttpStatus.BAD_REQUEST);
		await this._assertCanModifyScopeItem(item, currentContext, 'edit');
		await this.caseRepository.touchCase(item.caseId, currentContext);
		const { id, ...updateData } = dto;
		await this.scopeItemRepository.updateItem(id, updateData as any, currentContext);
		const diffs = Object.keys(updateData).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (updateData as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Scope item "${item.description}"`,
			CMS_AUDIT_ACTION.SCOPE_ITEM_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Scope item updated successfully.' };
	}

	public async deleteScopeItem(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.scopeItemRepository.getById(id);
		if (!item) throw new HttpException('Scope item not found.', HttpStatus.BAD_REQUEST);
		await this._assertCanModifyScopeItem(item, currentContext, 'delete');
		await this.caseRepository.touchCase(item.caseId, currentContext);
		await this.scopeItemRepository.deleteItem(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.SCOPE_ITEM_DELETED,
				comments: `Scope item deleted: "${item.description}"`,
			},
			currentContext,
		);
		return { message: 'Scope item deleted successfully.' };
	}

	public async getProcedures(caseId: number): Promise<CaseProcedure[]> {
		return this.procedureRepository.getByCaseId(caseId);
	}

	public async createProcedure(
		dto: CreateProcedureRequestDto,
		currentContext: CurrentContext,
	): Promise<{ message: string; data: { id: number } }> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		const procedure = CaseProcedure.build({
			caseId: dto.caseId,
			allegationId: dto.allegationId ?? null,
			description: dto.description,
			actionBy: dto.actionBy,
			actionByUserId: dto.actionByUserId ?? null,
			actionByEmail: dto.actionByEmail ?? null,
			deadline: dto.deadline,
			status: ProcedureStatus.PENDING,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		const saved = await this.procedureRepository.createProcedure(procedure, currentContext);
		if (dto.actionByUserId) {
			await this.assignmentTaskService.upsertTask(
				{
					caseId: dto.caseId,
					assignmentType: AssignmentType.PROCEDURE_ASSIGNEE,
					sourceId: saved.id,
					assigneeUserId: dto.actionByUserId,
					assigneeName: dto.actionBy ?? null,
					assigneeEmail: dto.actionByEmail ?? null,
					status: AssignmentTaskStatus.PENDING,
				} as any,
				currentContext,
			);
		}
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.PROCEDURE_CREATED,
				comments: `Procedure created: "${dto.description}"`,
			},
			currentContext,
		);
		return { message: 'Procedure added successfully.', data: { id: saved.id } };
	}

	public async updateProcedure(
		dto: UpdateProcedureRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.procedureRepository.getById(dto.id);
		if (!item) throw new HttpException('Procedure not found.', HttpStatus.BAD_REQUEST);
		const username = currentContext.user?.username?.toLowerCase();
		if (
			!(await this._canModifyAssigneeItem(item.caseId, item.allegationId, item.createdBy, username))
		) {
			throw new HttpException(
				'You can only edit procedures you or your allegation added.',
				HttpStatus.FORBIDDEN,
			);
		}
		await this.caseRepository.touchCase(item.caseId, currentContext);
		const { id, ...updateData } = dto;
		await this.procedureRepository.updateProcedure(id, updateData as any, currentContext);
		if (
			dto.actionByUserId !== undefined &&
			dto.actionByUserId?.toLowerCase() !== item.actionByUserId?.toLowerCase()
		) {
			if (item.actionByUserId) {
				await this.assignmentTaskService.softDeleteForAssigneeAndSource(
					item.caseId,
					AssignmentType.PROCEDURE_ASSIGNEE,
					item.id,
					item.actionByUserId,
					currentContext,
				);
			}
			if (dto.actionByUserId) {
				await this.assignmentTaskService.upsertTask(
					{
						caseId: item.caseId,
						assignmentType: AssignmentType.PROCEDURE_ASSIGNEE,
						sourceId: item.id,
						assigneeUserId: dto.actionByUserId,
						assigneeName: dto.actionBy ?? item.actionBy ?? null,
						assigneeEmail: dto.actionByEmail ?? null,
						status: AssignmentTaskStatus.PENDING,
					} as any,
					currentContext,
				);
			}
		}
		const diffs = Object.keys(updateData).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (updateData as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Procedure "${item.description}"`,
			CMS_AUDIT_ACTION.PROCEDURE_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Procedure updated successfully.' };
	}

	public async completeProcedure(
		dto: CompleteProcedureRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.procedureRepository.getById(dto.id);
		if (!item) throw new HttpException('Procedure not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.procedureRepository.updateProcedure(
			dto.id,
			{
				status: ProcedureStatus.COMPLETE,
				completedDate: dto.completedDate,
				...(dto.workPerformed !== undefined && { workPerformed: dto.workPerformed }),
			} as any,
			currentContext,
		);
		await this._completeProcedureAssignmentTasks(item, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.PROCEDURE_COMPLETED,
				comments: `Procedure completed: "${item.description}"`,
			},
			currentContext,
		);
		await this._createAmProcedureReviewTask(item, dto, currentContext);
		return { message: 'Procedure marked as complete.' };
	}

	private async _createAmProcedureReviewTask(
		procedure: CaseProcedure,
		dto: CompleteProcedureRequestDto,
		currentContext: CurrentContext,
	): Promise<void> {
		if (!procedure.allegationId) return;
		const allegation = await this.allegationRepository.getById(procedure.allegationId);
		const amId = allegation?.allegationManagerId?.trim();
		if (!amId) return;

		const completedBy = currentContext.user?.username?.toLowerCase();
		if (completedBy && amId.toLowerCase() === completedBy) return;

		const existing = await this.approvalTaskService.getByCase(procedure.caseId);
		const alreadyPending = existing.some(
			t =>
				t.taskType === CaseTaskType.AM_PROCEDURE_REVIEW &&
				t.status === CaseTaskStatus.PENDING &&
				Number(t.payload?.procedureId) === Number(procedure.id),
		);
		if (alreadyPending) return;

		const caseRecord = await this.caseRepository.getCaseById(procedure.caseId);
		const completedByName =
			(currentContext.user as any)?.name ?? currentContext.user?.username ?? procedure.actionBy ?? null;

		await this.approvalTaskService.create(
			{
				caseId: procedure.caseId,
				taskType: CaseTaskType.AM_PROCEDURE_REVIEW,
				assignedTo: amId,
				assignedToName: allegation?.allegationManagerName ?? null,
				title: `Review completed procedure — ${caseRecord?.irNumber ?? 'case'}`,
				payload: {
					procedureId: procedure.id,
					allegationId: procedure.allegationId,
					allegationLabel: allegation?.label ?? null,
					irNumber: caseRecord?.irNumber ?? null,
					procedureDescription: procedure.description,
					workPerformed: dto.workPerformed ?? procedure.workPerformed ?? null,
					completedDate: dto.completedDate ?? procedure.completedDate ?? null,
					deadline: procedure.deadline ?? null,
					completedByName,
					assigneeName: procedure.actionBy ?? null,
				},
			},
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: procedure.caseId,
				action: CMS_AUDIT_ACTION.TASK_CREATED,
				comments: `Procedure review requested for Allegation Manager: "${procedure.description}"`,
			},
			currentContext,
		);
	}

	private async _reopenProcedureForRevision(
		procedureId: number,
		currentContext: CurrentContext,
	): Promise<void> {
		const procedure = await this.procedureRepository.getById(procedureId);
		if (!procedure) return;
		await this.procedureRepository.updateProcedure(
			procedureId,
			{ status: ProcedureStatus.PENDING, completedDate: null } as any,
			currentContext,
		);
		for (const uid of await this._procedureAssigneeIds(procedure)) {
			await this.assignmentTaskService.upsertTask(
				{
					caseId: procedure.caseId,
					assignmentType: AssignmentType.PROCEDURE_ASSIGNEE,
					sourceId: procedure.id,
					assigneeUserId: uid,
					assigneeName: procedure.actionBy ?? null,
					assigneeEmail: procedure.actionByEmail ?? null,
					status: AssignmentTaskStatus.PENDING,
				} as any,
				currentContext,
			);
		}
	}

	private async _procedureAssigneeIds(procedure: CaseProcedure): Promise<string[]> {
		const assigneeUserIds = new Set<string>();
		if (procedure.actionByUserId) assigneeUserIds.add(procedure.actionByUserId.toLowerCase());
		const grants = await this.userPermissionRepository.getProcedureGrants(
			procedure.caseId,
			procedure.id,
		);
		for (const grant of grants) assigneeUserIds.add(grant.userId.toLowerCase());
		return [...assigneeUserIds];
	}

	private async _completeProcedureAssignmentTasks(
		procedure: CaseProcedure,
		currentContext: CurrentContext,
	): Promise<void> {
		for (const uid of await this._procedureAssigneeIds(procedure)) {
			const task = await this.assignmentTaskService.getForAssigneeAndSource(
				procedure.caseId,
				AssignmentType.PROCEDURE_ASSIGNEE,
				procedure.id,
				uid,
			);
			if (task) {
				await this.assignmentTaskService.updateTask(
					task.id,
					{ status: AssignmentTaskStatus.COMPLETED },
					currentContext,
				);
			}
		}
	}

	public async deleteProcedure(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.procedureRepository.getById(id);
		if (!item) throw new HttpException('Procedure not found.', HttpStatus.BAD_REQUEST);
		const username = currentContext.user?.username?.toLowerCase();
		if (
			!(await this._canModifyAssigneeItem(item.caseId, item.allegationId, item.createdBy, username))
		) {
			throw new HttpException(
				'You can only delete procedures you or your allegation added.',
				HttpStatus.FORBIDDEN,
			);
		}
		await this.caseRepository.touchCase(item.caseId, currentContext);
		await this.procedureRepository.deleteProcedure(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.PROCEDURE_DELETED,
				comments: `Procedure deleted: "${item.description}"`,
			},
			currentContext,
		);
		return { message: 'Procedure deleted successfully.' };
	}

	public async saveResults(
		dto: SaveResultsRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);

		const existingById = new Map(
			(
				await this.allegationRepository.getByIds(dto.results.map(r => Number(r.allegationId)))
			).map(a => [Number(a.id), a]),
		);
		await this._assertCanSaveResults(dto, existingById, currentContext);

		for (const result of dto.results) {
			const updateData: Partial<CaseAllegation> = {};
			if (result.outcome !== undefined) updateData.outcome = result.outcome as any;
			if (result.detailedAnalysis !== undefined)
				updateData.detailedAnalysis = result.detailedAnalysis;
			if (result.lossAmount !== undefined) updateData.lossAmount = result.lossAmount;
			if (result.recoveredAmount !== undefined) updateData.recoveredAmount = result.recoveredAmount;
			if (result.currency !== undefined) updateData.currency = result.currency;
			if (result.lossNotes !== undefined) updateData.lossNotes = result.lossNotes;

			if (result.outcome !== undefined) {
				const existing = existingById.get(Number(result.allegationId));
				if (existing?.outcomeConfirmed && existing.outcome !== (result.outcome as any)) {
					updateData.outcomeConfirmed = false;
					updateData.outcomeConfirmedBy = null;
					updateData.outcomeConfirmedOn = null;
				}
			}

			if (Object.keys(updateData).length > 0) {
				await this.allegationRepository.updateAllegation(
					Number(result.allegationId),
					updateData,
					currentContext,
				);
			}
		}

		const overallUpdate: any = {};
		if (dto.overallAnalysisResult !== undefined)
			overallUpdate.overallAnalysisResult = dto.overallAnalysisResult;
		if (dto.conclusion !== undefined) overallUpdate.conclusion = dto.conclusion;
		if (Object.keys(overallUpdate).length > 0) {
			await this.caseRepository.updateCase(dto.caseId, overallUpdate, currentContext);
		}

		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.RESULTS_SAVED,
				comments: `Results saved for ${dto.results.length} allegation(s)`,
			},
			currentContext,
		);
		return { message: 'Results saved successfully.' };
	}

	public async confirmAllegationOutcome(
		allegationId: number,
		confirmed: boolean,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const allegation = await this.allegationRepository.getById(allegationId);
		if (!allegation) {
			throw new HttpException('Allegation not found.', HttpStatus.BAD_REQUEST);
		}
		const caseId = Number(allegation.caseId);
		const caseRecord = await this._beginCaseMutation(caseId, currentContext);

		const username = currentContext.user?.username?.toLowerCase();
		const isCaseLead = !!username && assigneeEmail(caseRecord.caseLead) === username;
		const isConfig =
			!isCaseLead && !!username && (await this._isConfigUserOnCase(caseRecord, username));
		if (!isCaseLead && !isConfig) {
			throw new HttpException(
				'Only the Case Lead can confirm the allegation outcome.',
				HttpStatus.FORBIDDEN,
			);
		}

		if (confirmed && !allegation.outcome) {
			throw new HttpException(
				'Set the allegation outcome before confirming it.',
				HttpStatus.BAD_REQUEST,
			);
		}

		await this.allegationRepository.updateAllegation(
			allegationId,
			confirmed
				? {
						outcomeConfirmed: true,
						outcomeConfirmedBy: username,
						outcomeConfirmedOn: new Date(),
				  }
				: {
						outcomeConfirmed: false,
						outcomeConfirmedBy: null,
						outcomeConfirmedOn: null,
				  },
			currentContext,
		);

		this.auditLogService.log(
			{
				caseId,
				action: confirmed
					? CMS_AUDIT_ACTION.OUTCOME_CONFIRMED
					: CMS_AUDIT_ACTION.OUTCOME_UNCONFIRMED,
				comments: `${
					confirmed ? 'Confirmed' : 'Withdrew confirmation of'
				} outcome for allegation "${allegation.label}"`,
			},
			currentContext,
		);

		return {
			message: confirmed
				? 'Allegation outcome confirmed.'
				: 'Allegation outcome confirmation withdrawn.',
		};
	}

	public async submitResultsForConfirmation(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(caseId, currentContext);

		if (caseRecord.currentStage !== CaseStatus.REPORT_RESULTS) {
			throw new HttpException(
				'Results can only be submitted for confirmation during the Report Results stage.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const username = currentContext.user?.username?.toLowerCase();
		const isCaseLead = !!username && assigneeEmail(caseRecord.caseLead) === username;
		const isConfig =
			!isCaseLead && !!username && (await this._isConfigUserOnCase(caseRecord, username));
		if (!isCaseLead && !isConfig) {
			throw new HttpException(
				'Only the Case Lead can submit results for confirmation.',
				HttpStatus.FORBIDDEN,
			);
		}

		const caseLeadEmail = assigneeEmail(caseRecord.caseLead);
		if (!caseLeadEmail) {
			throw new HttpException(
				'Assign a Case Lead before submitting results for confirmation.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const allegations = await this.allegationRepository.getByCaseId(caseId);
		if (allegations.length === 0) {
			throw new HttpException('There are no allegations to confirm.', HttpStatus.BAD_REQUEST);
		}
		if (allegations.some(a => !a.outcome)) {
			throw new HttpException(
				'Set an outcome for every allegation before submitting for confirmation.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const existing = await this.approvalTaskService.getByCase(caseId);
		const alreadyPending = existing.find(
			t =>
				t.taskType === CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION &&
				t.status === CaseTaskStatus.PENDING,
		);
		if (alreadyPending) {
			throw new HttpException(
				'Results have already been submitted — a Case Lead confirmation is already pending.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const caseLeadName = parseAssignee(caseRecord.caseLead)?.full_name ?? caseLeadEmail;
		await this.approvalTaskService.create(
			{
				caseId,
				taskType: CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION,
				assignedTo: caseLeadEmail,
				assignedToName: caseLeadName,
				title: `Confirm investigation results — ${caseRecord.irNumber ?? 'case'}`,
				payload: {
					irNumber: caseRecord.irNumber,
					classification: caseRecord.classification,
					businessUnit: caseRecord.businessUnit,
					allegations: allegations
						.slice()
						.sort((a, b) => a.sortOrder - b.sortOrder)
						.map(a => ({
							label: a.label,
							incidentTypeCode: a.incidentTypeCode ?? null,
							classification: a.classification ?? null,
							outcome: a.outcome ?? null,
							lossAmount: a.lossAmount ?? null,
							recoveredAmount: a.recoveredAmount ?? null,
							currency: a.currency ?? null,
						})),
				},
			},
			currentContext,
		);

		this.auditLogService.log(
			{
				caseId,
				action: CMS_AUDIT_ACTION.TASK_CREATED,
				comments: `Results submitted for Case Lead confirmation (assigned to ${caseLeadName})`,
			},
			currentContext,
		);

		return { message: 'Results submitted for Case Lead confirmation.' };
	}

	public async confirmRemediation(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(caseId, currentContext);

		if (caseRecord.currentStage !== CaseStatus.REMEDIATION_ACTIONS) {
			throw new HttpException(
				'Remediation can only be confirmed during the Remediation Actions stage.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const actions = await this.remediationActionRepository.getByCaseId(caseId);
		if (actions.length === 0) {
			throw new HttpException(
				'Add at least one remediation action, or mark the stage Not Applicable, before confirming.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const confirmedBy = currentContext.user?.username?.toLowerCase() ?? null;
		await this.caseRepository.updateCase(
			caseId,
			{ remediationConfirmedBy: confirmedBy, remediationConfirmedOn: new Date() } as any,
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId,
				action: CMS_AUDIT_ACTION.OUTCOME_CONFIRMED,
				comments: `Remediation actions confirmed by Case Lead (${
					confirmedBy ?? 'unknown'
				}) — cleared to advance to Recommendations`,
			},
			currentContext,
		);
		return { message: 'Remediation actions confirmed. You can now advance to Recommendations.' };
	}

	public async getRemediationActions(caseId: number): Promise<CaseRemediationAction[]> {
		return this.remediationActionRepository.getByCaseId(caseId);
	}

	public async createRemediationAction(
		dto: CreateRemediationActionRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		const action = CaseRemediationAction.build({
			caseId: dto.caseId,
			actionType: dto.actionType,
			description: dto.description,
			responsibleParty: dto.responsibleParty,
			responsibleEmail: dto.responsibleEmail,
			status: RemediationStatus.PENDING,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		await this.remediationActionRepository.createAction(action, currentContext);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.REMEDIATION_CREATED,
				comments: `Remediation action created: "${dto.actionType}${
					dto.description ? ': ' + dto.description : ''
				}"`,
			},
			currentContext,
		);
		return { message: 'Remediation action added successfully.' };
	}

	public async updateRemediationAction(
		dto: UpdateRemediationActionRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.remediationActionRepository.getById(dto.id);
		if (!item) throw new HttpException('Remediation action not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		const { id, ...updateData } = dto;
		await this.remediationActionRepository.updateAction(id, updateData as any, currentContext);
		const diffs = Object.keys(updateData).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (updateData as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Remediation "${item.actionType}"`,
			CMS_AUDIT_ACTION.REMEDIATION_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Remediation action updated successfully.' };
	}

	public async deleteRemediationAction(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.remediationActionRepository.getById(id);
		if (!item) throw new HttpException('Remediation action not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.remediationActionRepository.deleteAction(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.REMEDIATION_DELETED,
				comments: `Remediation action deleted: "${item.actionType}"`,
			},
			currentContext,
		);
		return { message: 'Remediation action deleted successfully.' };
	}

	public async getRecommendation(caseId: number): Promise<CaseRecommendation | null> {
		return this.recommendationRepository.getByCaseId(caseId);
	}

	public async saveRecommendation(
		dto: SaveRecommendationRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		await this.recommendationRepository.upsertByCaseId(
			dto.caseId,
			{ lessonsLearned: dto.lessonsLearned, recommendations: dto.recommendations },
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.RECOMMENDATION_SAVED,
				comments: 'Case recommendations/lessons learned updated',
			},
			currentContext,
		);
		return { message: 'Recommendation saved successfully.' };
	}

	public async getEvidence(caseId: number): Promise<CaseEvidence[]> {
		return this.evidenceRepository.getByCaseId(caseId);
	}

	public async getKeyEvidence(caseId: number): Promise<CaseEvidence[]> {
		return this.evidenceRepository.getKeyEvidenceByCaseId(caseId);
	}

	public async getEvidenceById(id: number): Promise<CaseEvidence> {
		const item = await this.evidenceRepository.getById(id);
		if (!item) throw new HttpException('Evidence not found.', HttpStatus.BAD_REQUEST);
		return item;
	}

	public async addEvidence(
		payload: UploadEvidencePayload,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(payload.caseId, currentContext);
		const { username } = currentContext.user;
		const evidence = CaseEvidence.build({
			caseId: payload.caseId,
			allegationId: payload.allegationId ?? null,
			procedureId: payload.procedureId ?? null,
			category: payload.category,
			description: payload.description,
			fileName: payload.fileName,
			filePath: payload.filePath,
			fileSize: payload.fileSize,
			mimeType: payload.mimeType,
			uploadedBy: username,
			isKeyEvidence: payload.isKeyEvidence ?? false,
		} as any);
		const created = await this.evidenceRepository.createEvidence(evidence, currentContext);
		this.auditLogService.log(
			{
				caseId: payload.caseId,
				action: CMS_AUDIT_ACTION.EVIDENCE_UPLOADED,
				comments: `Evidence uploaded: "${payload.fileName}"`,
			},
			currentContext,
		);
		return { message: 'Evidence uploaded successfully.', data: { id: created.id } };
	}

	public async updateEvidence(
		id: number,
		data: Partial<{ category: string; description: string; isKeyEvidence: boolean }>,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.evidenceRepository.getById(id);
		if (!item) throw new HttpException('Evidence not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.evidenceRepository.updateEvidence(id, data as any, currentContext);
		const diffs = Object.keys(data).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (data as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Evidence "${item.fileName}"`,
			CMS_AUDIT_ACTION.EVIDENCE_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Evidence updated successfully.' };
	}

	public async deleteEvidence(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.evidenceRepository.getById(id);
		if (!item) throw new HttpException('Evidence not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.evidenceRepository.deleteEvidence(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.EVIDENCE_DELETED,
				comments: `Evidence deleted: "${item.fileName}"`,
			},
			currentContext,
		);
		return { message: 'Evidence deleted successfully.' };
	}

	public async getOpenActions(
		assignedUser?: string,
		caseId?: number,
		actionType?: 'procedure' | 'remediation',
	): Promise<OpenActionItem[]> {
		const wantProcedures = !actionType || actionType === 'procedure';
		const wantRemediations = !actionType || actionType === 'remediation';
		const scopedCaseId = Number(caseId) || undefined;

		const [procedures, actions] = await Promise.all([
			wantProcedures
				? this.procedureRepository.getOutstandingProcedures({
						caseId: scopedCaseId,
						actionBy: assignedUser,
				  })
				: Promise.resolve([]),
			wantRemediations
				? this.remediationActionRepository.getOutstandingActions({
						caseId: scopedCaseId,
						responsibleParty: assignedUser,
				  })
				: Promise.resolve([]),
		]);

		const caseById = await this._loadCasesByIds([
			...procedures.map(p => p.caseId),
			...actions.map(a => a.caseId),
		]);

		const result: OpenActionItem[] = [];
		const today = new Date();

		for (const p of procedures) {
			const caseRecord = caseById.get(Number(p.caseId));
			const deadlineDate = p.deadline ? new Date(p.deadline) : null;
			const daysOverdue =
				deadlineDate && deadlineDate < today
					? Math.floor((today.getTime() - deadlineDate.getTime()) / (1000 * 60 * 60 * 24))
					: 0;
			result.push({
				type: 'procedure',
				id: p.id,
				caseId: p.caseId,
				irNumber: caseRecord?.irNumber ?? '',
				businessUnit: caseRecord?.businessUnit ?? '',
				description: p.description,
				actionBy: p.actionBy,
				deadline: p.deadline,
				status: p.status,
				daysOverdue,
			});
		}

		for (const a of actions) {
			const caseRecord = caseById.get(Number(a.caseId));
			result.push({
				type: 'remediation',
				id: a.id,
				caseId: a.caseId,
				irNumber: caseRecord?.irNumber ?? '',
				businessUnit: caseRecord?.businessUnit ?? '',
				description: `${a.actionType}${a.description ? ': ' + a.description : ''}`,
				actionBy: a.responsibleParty ?? '—',
				status: a.status,
			});
		}

		return result;
	}

	private async _loadCasesByIds(ids: number[]): Promise<Map<number, Case>> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return new Map();
		const records = (await this.caseRepository.findByIds(unique)) ?? [];
		return new Map(records.map(record => [Number(record.id), record]));
	}

	public async getAllegations(caseId: number): Promise<CaseAllegation[]> {
		return this.allegationRepository.getByCaseId(caseId);
	}

	private static readonly CASE_REPORT_FIELDS = [
		'status',
		'alertLevel',
		'alertStatus',
		'caseType',
		'intakeChannel',
		'daysOpen',
		'partialReport',
		'primaryIssue',
		'summary',
		'details',
		'translatedDetails',
		'language',
		'allegedIncidentDate',
		'dateOfReport',
		'businessUnit',
		'assignedTier',
		'country',
		'region',
		'businessPillar',
		'businessVertical',
		'argusUniqueId',
		'incidentAddress',
		'isAnonymous',
		'navexParticipants',
		'navexFiles',
		'navexComments',
		'navexCustomQuestions',
		'navexRelatedCases',
		'navexIssueTypeLayers',
		'navexNotes',
		'navexFollowupQuestions',
	] as const;

	/** `cases` columns that are NOT NULL — the report panel must never clear these to null. */
	private static readonly CASE_REPORT_REQUIRED_FIELDS = ['dateOfReport', 'businessUnit'] as const;

	/**
	 * Picks the JSON-backed fields the request actually supplied, keyed as they are stored.
	 * Returns null when it supplied none, so an untouched section leaves its blob alone
	 * rather than being rewritten with its own contents.
	 */
	private static _jsonPatch(
		dto: SaveCaseReportRequestDto,
		fields: readonly string[],
	): Record<string, unknown> | null {
		const patch: Record<string, unknown> = {};

		for (const field of fields) {
			const value = (dto as any)[field];

			if (value !== undefined) patch[field] = value;
		}

		return Object.keys(patch).length ? patch : null;
	}

	public async getCaseReport(caseId: number): Promise<CaseReportResponseDto> {
		const record = await this.caseRepository.getCaseById(caseId);

		if (!record) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);

		return singleObjectToInstance(CaseReportResponseDto, {
			caseId: record.id,
			navexCaseId: record.navexCaseId != null ? String(record.navexCaseId) : null,
			isEdited: !!record.caseReportEdited,
			lastSavedAt: record.caseReportSavedAt ? new Date(record.caseReportSavedAt).toISOString() : null,
			lastSavedBy: record.caseReportSavedBy ?? null,
			importedOn: record.createdOn ? new Date(record.createdOn).toISOString() : null,
		});
	}

	public async saveCaseReport(
		caseId: number,
		dto: SaveCaseReportRequestDto,
		currentContext: CurrentContext,
	): Promise<CaseReportResponseDto> {
		await this._beginCaseMutation(caseId, currentContext);

		const record = await this.caseRepository.getCaseById(caseId);

		if (!record) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);

		const updateData: any = {};

		for (const field of CaseService.CASE_REPORT_FIELDS) {
			const value = (dto as any)[field];

			if (value === undefined) continue;
			if (value === null && (CaseService.CASE_REPORT_REQUIRED_FIELDS as readonly string[]).includes(field)) continue;

			updateData[field] = value;
		}

		// Location and Reporter Information live in one JSONB column each. The request still
		// carries them flat, so fold whichever keys it supplied into the stored blob — merged,
		// not replaced, since the panel sends only what changed.
		const locationPatch = CaseService._jsonPatch(dto, LOCATION_JSON_FIELDS);
		const reporterPatch = CaseService._jsonPatch(dto, REPORTER_JSON_FIELDS);

		if (locationPatch) updateData.locationData = { ...(record.locationData ?? {}), ...locationPatch };
		if (reporterPatch) updateData.reporterData = { ...(record.reporterData ?? {}), ...reporterPatch };

		if (dto.secondaryIssues !== undefined) {
			updateData.secondaryIssues = JSON.stringify(dto.secondaryIssues);
		}

		const username = currentContext.user?.username ?? 'system';

		updateData.caseReportEdited = !dto.reset;
		updateData.caseReportSavedAt = dto.reset ? null : new Date();
		updateData.caseReportSavedBy = dto.reset ? null : username;

		await this.caseRepository.updateCase(caseId, updateData, currentContext);

		this.auditLogService.log(
			{
				caseId,
				action: dto.reset ? CMS_AUDIT_ACTION.CASE_REPORT_RESET : CMS_AUDIT_ACTION.CASE_REPORT_SAVED,
				comments: dto.reset
					? 'Case Report reverted to the Navex import'
					: 'Case Report saved',
			},
			currentContext,
		);

		return this.getCaseReport(caseId);
	}

	public async createAllegation(
		dto: CreateAllegationRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(dto.caseId, currentContext);
		const allegation = CaseAllegation.build({
			caseId: dto.caseId,
			label: dto.label,
			description: dto.description,
			incidentTypeCode: dto.incidentTypeCode,
			classification: dto.classification ?? caseRecord?.classification ?? null,
			outcome: dto.outcome,
			detailedAnalysis: dto.detailedAnalysis,
			lossAmount: dto.lossAmount,
			recoveredAmount: dto.recoveredAmount,
			currency: dto.currency ?? 'USD',
			allegationManagerId: dto.allegationManagerId,
			allegationManagerName: dto.allegationManagerName,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		await this.allegationRepository.createAllegation(allegation, currentContext);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.ALLEGATION_CREATED,
				comments: `Allegation created: "${dto.label}"`,
			},
			currentContext,
		);
		return { message: 'Allegation added successfully.' };
	}

	public async updateAllegation(
		dto: UpdateAllegationRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.allegationRepository.getById(dto.id);
		if (!item) throw new HttpException('Allegation not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		const { id, ...updateData } = dto;
		if (
			dto.description !== undefined &&
			dto.description !== item.description &&
			dto.scopeReviewNeeded === undefined
		) {
			(updateData as any).scopeReviewNeeded = true;
		}
		await this.allegationRepository.updateAllegation(id, updateData as any, currentContext);
		const diffFields = Object.keys(updateData).map(field => ({
			field,
			oldValue: (item as any)[field],
			newValue: (updateData as any)[field],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Allegation "${item.label}"`,
			CMS_AUDIT_ACTION.ALLEGATION_UPDATED,
			diffFields,
			currentContext,
		);
		return { message: 'Allegation updated successfully.' };
	}

	public async checkDuplicates(caseId: number) {
		const current = await this.caseRepository.getCaseByIdWithRelations(caseId);
		if (!current) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);

		const currentAllegations = (current as any).allegations ?? [];

		const others = await this.caseRepository.findDuplicateCandidates({
			excludeId: caseId,
			businessUnit: current.businessUnit,
			primaryIssue: current.primaryIssue,
			incidentTypeCodes: [
				...new Set(
					currentAllegations.map((a: any) => a.incidentTypeCode).filter(Boolean) as string[],
				),
			],
			allegationDescriptions: [
				...new Set(
					currentAllegations
						.map((a: any) => a.description?.trim().toLowerCase())
						.filter(Boolean) as string[],
				),
			],
		});

		const results: any[] = [];

		for (const other of others) {
			const otherAllegations = (other as any).allegations ?? [];
			const reasons: string[] = [];
			let matchType: 'exact' | 'similar' | null = null;
			const matchedAllegations: { label: string; description: string }[] = [];

			for (const mine of currentAllegations) {
				const myDesc = mine.description?.trim().toLowerCase();
				if (!myDesc) continue;
				for (const theirs of otherAllegations) {
					if (myDesc === theirs.description?.trim().toLowerCase()) {
						matchType = 'exact';
						if (!reasons.some(r => r.startsWith('Exact wording'))) {
							reasons.push(`Exact wording match on "${mine.label}"`);
						}
						matchedAllegations.push({ label: theirs.label, description: theirs.description });
					}
				}
			}

			if (current.businessUnit && current.businessUnit === other.businessUnit) {
				if (!matchType) matchType = 'similar';
				reasons.push('Same business unit');
			}

			if (current.primaryIssue && current.primaryIssue === other.primaryIssue) {
				if (!matchType) matchType = 'similar';
				reasons.push('Same primary issue');
			}

			const myCodes = currentAllegations.map((a: any) => a.incidentTypeCode).filter(Boolean);
			const otherCodes = otherAllegations.map((a: any) => a.incidentTypeCode).filter(Boolean);
			const shared = myCodes.filter((c: string) => otherCodes.includes(c));
			if (shared.length > 0) {
				if (!matchType) matchType = 'similar';
				reasons.push(`Shared incident type${shared.length > 1 ? 's' : ''}: ${shared.join(', ')}`);
			}

			if (matchType) {
				results.push({
					matchType,
					reasons,
					caseId: other.id,
					irNumber: other.irNumber,
					businessUnit: other.businessUnit,
					primaryIssue: other.primaryIssue,
					dateOfReport: other.dateOfReport,
					currentStage: other.currentStage,
					matchedAllegations,
				});
			}
		}

		results.sort((a, b) =>
			a.matchType === 'exact' && b.matchType !== 'exact'
				? -1
				: b.matchType === 'exact' && a.matchType !== 'exact'
				? 1
				: 0,
		);
		return results;
	}

	public async deleteAllegation(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.allegationRepository.getById(id);
		if (!item) throw new HttpException('Allegation not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.allegationRepository.deleteAllegation(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.ALLEGATION_DELETED,
				comments: `Allegation deleted: "${item.label}"`,
			},
			currentContext,
		);
		return { message: 'Allegation deleted successfully.' };
	}

	public async getRecommendationItems(caseId: number): Promise<CaseRecommendationItem[]> {
		return this.recommendationItemRepository.getByCaseId(caseId);
	}

	private async _assertRecommendationOwnerOutsideTeam(
		caseId: number,
		ownerEmail: string | undefined | null,
	): Promise<void> {
		const owner = ownerEmail?.trim().toLowerCase();
		if (!owner) return;
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		if (!caseRecord) return;
		const grants = await this.userPermissionRepository.getByCaseId(caseId);
		const team = new Set(
			[
				caseRecord.createdBy,
				assigneeEmail(caseRecord.caseLead),
				assigneeEmail(caseRecord.assignedTo),
				...grants.flatMap(g => [g.userId, g.userEmail]),
			]
				.filter(Boolean)
				.map(v => String(v).toLowerCase()),
		);
		if (team.has(owner)) {
			throw new HttpException(
				'The recommendation owner must be outside the case access team — pick a DP World Employee who is not part of this case.',
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	private async _recommendationsConfirmed(caseId: number): Promise<boolean> {
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		return !!caseRecord?.recommendationsConfirmedBy;
	}

	private async _assignRecommendationOwnerTask(
		item: CaseRecommendationItem,
		currentContext: CurrentContext,
	): Promise<void> {
		if (!item.recommendationOwnerEmail) return;
		await this.assignmentTaskService.upsertTask(
			{
				caseId: item.caseId,
				assignmentType: AssignmentType.RECOMMENDATION_OWNER,
				sourceId: item.id,
				assigneeUserId: item.recommendationOwnerEmail,
				assigneeName: item.recommendationOwner ?? null,
				assigneeEmail: item.recommendationOwnerEmail,
				status: AssignmentTaskStatus.PENDING,
				title: item.issueTitle,
			} as any,
			currentContext,
		);
	}

	public async createRecommendationItem(
		dto: CreateRecommendationItemRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		await this._assertRecommendationOwnerOutsideTeam(dto.caseId, dto.recommendationOwnerEmail);
		const item = CaseRecommendationItem.build({
			caseId: dto.caseId,
			issueTitle: dto.issueTitle,
			issueDescription: dto.issueDescription,
			actionDetails: dto.actionDetails,
			implementationDeadline: dto.implementationDeadline,
			recommendationType: dto.recommendationType,
			recommendationOwner: dto.recommendationOwner,
			recommendationOwnerEmail: dto.recommendationOwnerEmail,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		const saved = await this.recommendationItemRepository.createItem(item, currentContext);
		if (saved.recommendationOwnerEmail && (await this._recommendationsConfirmed(dto.caseId))) {
			await this._assignRecommendationOwnerTask(saved, currentContext);
		}
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.RECOMMENDATION_ITEM_CREATED,
				comments: `Recommendation item created: "${dto.issueTitle}"`,
			},
			currentContext,
		);
		return { message: 'Recommendation item added successfully.' };
	}

	public async updateRecommendationItem(
		dto: UpdateRecommendationItemRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.recommendationItemRepository.getById(dto.id);
		if (!item) throw new HttpException('Recommendation item not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		if (dto.recommendationOwnerEmail !== undefined) {
			await this._assertRecommendationOwnerOutsideTeam(item.caseId, dto.recommendationOwnerEmail);
		}
		const { id, ...updateData } = dto;
		await this.recommendationItemRepository.updateItem(id, updateData as any, currentContext);
		if (
			dto.recommendationOwnerEmail !== undefined &&
			dto.recommendationOwnerEmail?.toLowerCase() !== item.recommendationOwnerEmail?.toLowerCase() &&
			(await this._recommendationsConfirmed(item.caseId))
		) {
			if (item.recommendationOwnerEmail) {
				await this.assignmentTaskService.softDeleteForAssigneeAndSource(
					item.caseId,
					AssignmentType.RECOMMENDATION_OWNER,
					item.id,
					item.recommendationOwnerEmail,
					currentContext,
				);
			}
			if (dto.recommendationOwnerEmail) {
				await this.assignmentTaskService.upsertTask(
					{
						caseId: item.caseId,
						assignmentType: AssignmentType.RECOMMENDATION_OWNER,
						sourceId: item.id,
						assigneeUserId: dto.recommendationOwnerEmail,
						assigneeName: dto.recommendationOwner ?? item.recommendationOwner ?? null,
						assigneeEmail: dto.recommendationOwnerEmail,
						status: AssignmentTaskStatus.PENDING,
						title: dto.issueTitle ?? item.issueTitle,
					} as any,
					currentContext,
				);
			}
		}
		const diffs = Object.keys(updateData).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (updateData as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Recommendation "${item.issueTitle}"`,
			CMS_AUDIT_ACTION.RECOMMENDATION_ITEM_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Recommendation item updated successfully.' };
	}

	public async deleteRecommendationItem(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.recommendationItemRepository.getById(id);
		if (!item) throw new HttpException('Recommendation item not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.recommendationItemRepository.deleteItem(id, currentContext);
		if (item.recommendationOwnerEmail) {
			await this.assignmentTaskService.softDeleteForAssigneeAndSource(
				item.caseId,
				AssignmentType.RECOMMENDATION_OWNER,
				item.id,
				item.recommendationOwnerEmail,
				currentContext,
			);
		}
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.RECOMMENDATION_ITEM_DELETED,
				comments: `Recommendation item deleted: "${item.issueTitle}"`,
			},
			currentContext,
		);
		return { message: 'Recommendation item deleted successfully.' };
	}

	public async confirmRecommendations(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(caseId, currentContext);

		if (caseRecord.currentStage !== CaseStatus.RECOMMENDATIONS) {
			throw new HttpException(
				'Recommendations can only be confirmed during the Recommendations stage.',
				HttpStatus.BAD_REQUEST,
			);
		}
		const items = await this.recommendationItemRepository.getByCaseId(caseId);
		if (items.length === 0) {
			throw new HttpException(
				'Add at least one recommendation, or mark the stage Not Applicable, before confirming.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const confirmedBy = currentContext.user?.username?.toLowerCase() ?? null;
		await this.caseRepository.updateCase(
			caseId,
			{ recommendationsConfirmedBy: confirmedBy, recommendationsConfirmedOn: new Date() } as any,
			currentContext,
		);
		for (const it of items) {
			await this._assignRecommendationOwnerTask(it, currentContext);
		}
		this.auditLogService.log(
			{
				caseId,
				action: CMS_AUDIT_ACTION.RECOMMENDATION_SAVED,
				comments: `Recommendations confirmed by Case Lead (${
					confirmedBy ?? 'unknown'
				}) — owners assigned and cleared for ARMS transfer`,
			},
			currentContext,
		);
		return { message: 'Recommendations confirmed and owners assigned. You can now transfer them to ARMS.' };
	}

	public async transferRecommendationItemsToArms(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const caseRecord = await this._beginCaseMutation(caseId, currentContext);

		if (!caseRecord.recommendationsConfirmedBy) {
			throw new HttpException(
				'Confirm the recommendations (Case Lead) before transferring to ARMS.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const items = await this.recommendationItemRepository.getByCaseId(caseId);
		const pending = items.filter(i => !i.armsTransferred);
		await this.recommendationItemRepository.markTransferredToArms(
			pending.map(i => i.id),
			currentContext,
		);
		if (pending.length > 0) {
			this.auditLogService.log(
				{
					caseId,
					action: CMS_AUDIT_ACTION.ARMS_TRANSFER,
					comments: `${pending.length} recommendation(s) transferred to ARMS`,
				},
				currentContext,
			);
			const notified = new Set<string>();
			for (const item of pending) {
				const email = item.recommendationOwnerEmail?.trim().toLowerCase();
				if (!email || notified.has(email)) continue;
				notified.add(email);
				await this.caseNotificationService.notifyWorkAssigned({
					caseId,
					userId: email,
					userName: item.recommendationOwner ?? null,
					userEmail: email,
					role: 'Recommendation Owner',
				});
			}
		}
		return { message: `${pending.length} recommendation(s) transferred to ARMS successfully.` };
	}

	public async markRecommendationImplemented(
		id: number,
		implemented: boolean,
		currentContext: CurrentContext,
		notes?: string,
	): Promise<MessageResponseDto> {
		const item = await this.recommendationItemRepository.getById(id);
		if (!item) throw new HttpException('Recommendation item not found.', HttpStatus.BAD_REQUEST);
		const username = currentContext.user?.username?.toLowerCase();
		const isOwner = !!username && item.recommendationOwnerEmail?.trim().toLowerCase() === username;
		if (!isOwner) {
			await this._beginCaseMutation(item.caseId, currentContext);
		}
		await this.recommendationItemRepository.updateItem(
			id,
			{
				status: implemented
					? RecommendationItemStatus.IMPLEMENTED
					: RecommendationItemStatus.PENDING,
				...(notes !== undefined && { implementationNotes: notes }),
			} as any,
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.RECOMMENDATION_ITEM_UPDATED,
				comments: `Recommendation "${item.issueTitle}" marked ${
					implemented ? 'Implemented' : 'Pending'
				} by ${username ?? 'unknown'}`,
			},
			currentContext,
		);
		return {
			message: `Recommendation marked ${implemented ? 'Implemented' : 'Pending'}.`,
		};
	}

	public async getFraudRisks(caseId: number): Promise<CaseFraudRisk[]> {
		return this.fraudRiskRepository.getByCaseId(caseId);
	}

	public async createFraudRisk(
		dto: CreateFraudRiskRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		const risk = CaseFraudRisk.build({
			caseId: dto.caseId,
			riskCategory: dto.riskCategory,
			riskSubcategory: dto.riskSubcategory,
			riskDescription: dto.riskDescription,
			sortOrder: dto.sortOrder ?? 0,
		} as any);
		await this.fraudRiskRepository.createRisk(risk, currentContext);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.FRAUD_RISK_CREATED,
				comments: `Fraud risk created: "${dto.riskCategory}${
					dto.riskSubcategory ? ' / ' + dto.riskSubcategory : ''
				}"`,
			},
			currentContext,
		);
		return { message: 'Fraud risk added successfully.' };
	}

	public async updateFraudRisk(
		dto: UpdateFraudRiskRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.fraudRiskRepository.getById(dto.id);
		if (!item) throw new HttpException('Fraud risk not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		const { id, ...updateData } = dto;
		await this.fraudRiskRepository.updateRisk(id, updateData as any, currentContext);
		const diffs = Object.keys(updateData).map(f => ({
			field: f,
			oldValue: (item as any)[f],
			newValue: (updateData as any)[f],
		}));
		this.auditLogService.logFieldDiffs(
			item.caseId,
			`Fraud risk "${item.riskCategory}"`,
			CMS_AUDIT_ACTION.FRAUD_RISK_UPDATED,
			diffs,
			currentContext,
		);
		return { message: 'Fraud risk updated successfully.' };
	}

	public async deleteFraudRisk(
		id: number,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const item = await this.fraudRiskRepository.getById(id);
		if (!item) throw new HttpException('Fraud risk not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(item.caseId, currentContext);
		await this.fraudRiskRepository.deleteRisk(id, currentContext);
		this.auditLogService.log(
			{
				caseId: item.caseId,
				action: CMS_AUDIT_ACTION.FRAUD_RISK_DELETED,
				comments: `Fraud risk deleted: "${item.riskCategory}"`,
			},
			currentContext,
		);
		return { message: 'Fraud risk deleted successfully.' };
	}

	public async getUserPermissions(caseId: number): Promise<CaseUserPermissionResponseDto[]> {
		const records = await this.userPermissionRepository.getByCaseId(caseId);
		return records.map(r => ({
			id: r.id,
			caseId: r.caseId,
			userId: r.userId,
			userName: r.userName,
			userEmail: r.userEmail,
			role: r.role,
			sourceType: r.sourceType ?? null,
			sourceId: r.sourceId ?? null,
			sections: r.sections ?? [],
		}));
	}

	public async setUserPermission(
		dto: SetUserPermissionRequestDto,
		currentContext: CurrentContext,
	): Promise<{ message: string; data: CaseUserPermissionResponseDto }> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		if (dto.sourceType === PermissionSourceType.ALLEGATION) {
			await this._assertCanConfigureCase(dto.caseId, currentContext);
		}
		if (dto.sourceType === PermissionSourceType.PROCEDURE) {
			const username = currentContext.user?.username?.toLowerCase();
			const isConfigUser = await this._isCaseConfigUser(dto.caseId, username);
			const allowed =
				isConfigUser ||
				(dto.sourceId
					? await this._isAllegationManagerOfProcedure(dto.caseId, dto.sourceId, username)
					: false);
			if (!allowed) {
				throw new HttpException(
					'Only FRS, the Case Lead, or the allegation’s Manager may assign procedure assignees.',
					HttpStatus.FORBIDDEN,
				);
			}
			if (!isConfigUser && dto.sourceId) {
				await this._assertCanReplaceProcedureAssignee(dto.caseId, dto.sourceId, dto.userId);
			}
		}
		const sections = this._sectionsForSource(dto.sourceType ?? null, dto.sections);
		const priorGrant = await this.userPermissionRepository.getByUserCaseAndSource(
			dto.caseId,
			dto.userId,
			dto.sourceType ?? null,
			dto.sourceId ?? null,
		);
		const record = await this.userPermissionRepository.upsertPermission(
			dto.caseId,
			dto.userId,
			{
				userName: dto.userName,
				userEmail: dto.userEmail,
				role: dto.role,
				sourceType: dto.sourceType ?? null,
				sourceId: dto.sourceId ?? null,
				sections,
			} as any,
			currentContext,
		);
		const assignmentType = this._assignmentTypeForSource(dto.sourceType ?? null);
		const isSelfAssignment =
			!!dto.userId &&
			dto.userId.toLowerCase() === currentContext.user?.username?.toLowerCase();

		// Anyone handed something to work on gets a My Tasks entry, whatever their role on the case.
		if (assignmentType && dto.sourceId) {
			await this.assignmentTaskService.upsertTask(
				{
					caseId: dto.caseId,
					assignmentType,
					sourceId: dto.sourceId,
					assigneeUserId: dto.userId,
					assigneeName: dto.userName ?? null,
					assigneeEmail: dto.userEmail ?? null,
				} as any,
				currentContext,
			);

			if (
				assignmentType === AssignmentType.ALLEGATION_MANAGER ||
				assignmentType === AssignmentType.PROCEDURE_ASSIGNEE
			) {
				await this.assignmentTaskService.softDeleteForSourceExcept(
					dto.caseId,
					assignmentType,
					dto.sourceId,
					dto.userId,
					currentContext,
				);
			}
			if (assignmentType === AssignmentType.PROCEDURE_ASSIGNEE) {
				await this._removeOtherProcedureGrants(
					dto.caseId,
					dto.sourceId,
					dto.userId,
					currentContext,
				);
			}
		}
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.ACCESS_GRANTED,
				comments: `Access granted to ${dto.userName ?? dto.userId} as ${dto.role}`,
			},
			currentContext,
		);
		if (!priorGrant && !isSelfAssignment) {
			await this.caseNotificationService.notifyWorkAssigned({
				caseId: dto.caseId,
				userId: dto.userId,
				userName: dto.userName ?? null,
				userEmail: dto.userEmail ?? null,
				role: dto.role,
				sourceType: dto.sourceType ?? null,
				sourceId: dto.sourceId ?? null,
			});
		}
		return {
			message: 'User permissions updated successfully.',
			data: {
				id: record.id,
				caseId: record.caseId,
				userId: record.userId,
				userName: record.userName,
				userEmail: record.userEmail,
				role: record.role,
				sourceType: record.sourceType ?? null,
				sourceId: record.sourceId ?? null,
				sections: record.sections ?? [],
			},
		};
	}

	public async deleteUserPermission(
		id: number,
		currentContext: CurrentContext,
	): Promise<{ message: string }> {
		const perm = await this.userPermissionRepository.getById(id);
		if (!perm) throw new HttpException('Permission record not found.', HttpStatus.BAD_REQUEST);
		await this._beginCaseMutation(perm.caseId, currentContext);
		if (perm.sourceType === PermissionSourceType.PROCEDURE && perm.sourceId) {
			await this._assertCanModifyProcedureGrant(
				perm.caseId,
				Number(perm.sourceId),
				perm.createdBy,
				currentContext.user?.username?.toLowerCase(),
			);
		}
		await this.userPermissionRepository.deletePermission(id, currentContext);
		const assignmentType = this._assignmentTypeForSource(perm.sourceType ?? null);
		if (assignmentType && perm.sourceId) {
			await this.assignmentTaskService.softDeleteForAssigneeAndSource(
				perm.caseId,
				assignmentType,
				Number(perm.sourceId),
				perm.userId,
				currentContext,
			);
		}
		this.auditLogService.log(
			{
				caseId: perm.caseId,
				action: CMS_AUDIT_ACTION.ACCESS_REVOKED,
				comments: `Access revoked from ${perm.userName ?? perm.userId}`,
			},
			currentContext,
		);
		return { message: 'User permission removed.' };
	}

	public async getMyPermissions(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<MyCasePermissionsResponseDto> {
		const unrestricted: MyCasePermissionsResponseDto = {
			sections: null,
			allegationIds: null,
			procedureIds: null,
			scopeWritableAllegationIds: null,
			editableScopeItemIds: null,
		};
		const username = currentContext.user?.username?.toLowerCase();
		if (!username) return unrestricted;
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		if (!caseRecord) return unrestricted;
		// FRS / the Case Lead: nothing is restricted, scope of work included.
		if (await this._isConfigUserOnCase(caseRecord, username)) return unrestricted;
		if (await this._userHasGlobalViewRole(username)) return unrestricted;

		const perm = await this.userPermissionRepository.getByUserAndCase(caseId, username);
		if (!perm) {
			return {
				...unrestricted,
				sections: [],
				scopeWritableAllegationIds: [],
				editableScopeItemIds: [],
			};
		}

		const [allegationRecords, procedureRecords] = await Promise.all([
			this.userPermissionRepository.getAllegationRecordsByUser(caseId, username),
			this.userPermissionRepository.getProcedureRecordsByUser(caseId, username),
		]);
		const grantedAllegationIds = allegationRecords.map(r => Number(r.sourceId)).filter(Boolean);
		const managedAllegationIds = allegationRecords
			.filter(r => r.sourceType === PermissionSourceType.ALLEGATION)
			.map(r => Number(r.sourceId))
			.filter(Boolean);
		const scope = await this._scopeCapabilities(caseId, grantedAllegationIds, managedAllegationIds);

		const allegationIds =
			allegationRecords.length > 0
				? allegationRecords.map(r => Number(r.sourceId)).filter(Boolean)
				: null;
		const procedureIds =
			procedureRecords.length > 0
				? procedureRecords.map(r => Number(r.sourceId)).filter(Boolean)
				: null;
		const sections = perm.sections ?? [];
		return {
			...scope,
			sections: sections.length > 0 ? sections : null,
			allegationIds,
			procedureIds,
		};
	}

	/**
	 * Scope-of-work capability for someone who is not FRS / the Case Lead, mirroring the checks in
	 * create/update/deleteScopeItem: they may add on any granted allegation that is not Fraud, and
	 * edit only what FRS / the Case Lead did not write, on an allegation they actually manage.
	 */
	private async _scopeCapabilities(
		caseId: number,
		grantedAllegationIds: number[],
		managedAllegationIds: number[],
	): Promise<{ scopeWritableAllegationIds: number[]; editableScopeItemIds: number[] }> {
		if (grantedAllegationIds.length === 0) {
			return { scopeWritableAllegationIds: [], editableScopeItemIds: [] };
		}
		const allegations = await this.allegationRepository.getByIds(grantedAllegationIds);
		const nonFraud = new Set(
			allegations.filter(a => a.classification !== CaseClassification.FRAUD).map(a => Number(a.id)),
		);
		const scopeWritableAllegationIds = [...nonFraud];
		const managed = new Set(managedAllegationIds.filter(id => nonFraud.has(id)));
		if (managed.size === 0) {
			return { scopeWritableAllegationIds, editableScopeItemIds: [] };
		}
		const items = (await this.scopeItemRepository.getByCaseId(caseId)).filter(i =>
			managed.has(Number(i.allegationId)),
		);
		const ownerCreator = await this._scopeOwnerCreatorMap(
			caseId,
			items.map(i => i.createdBy),
		);
		const editableScopeItemIds = items
			.filter(i => !ownerCreator.get((i.createdBy ?? '').toLowerCase()))
			.map(i => Number(i.id));
		return { scopeWritableAllegationIds, editableScopeItemIds };
	}

	public async getMyAccess(currentContext: CurrentContext): Promise<MyAccessResponseDto> {
		const username = currentContext.user?.username?.toLowerCase();
		if (!username) {
			return {
				tier: AccessTier.TASK_ONLY,
				hasCaseScopedRole: false,
				roles: [],
				isHfrs: false,
				isAdmin: false,
				isFrs: false,
				receivesApprovals: false,
			};
		}
		const [roles, hasCaseScopedRole, hasGrant] = await Promise.all([
			this._getUserRoles(username),
			this.caseRepository.userHasCaseScopedRoleOnAnyCase(username),
			this.userPermissionRepository.hasAnyCaseLevelGrant(username),
		]);
		const isHfrs = roles.has(CmsUserRole.HFRS);
		const isAdmin = roles.has(CmsUserRole.ADMIN);
		const isFrs = roles.has(CmsUserRole.FRS);
		const hasCaseConfig = isHfrs || isAdmin;
		const hasCaseLevelGrant = hasGrant || isFrs;
		const tier = hasCaseConfig
			? AccessTier.CONFIG
			: hasCaseLevelGrant
			? AccessTier.CASE_ACCESS
			: AccessTier.TASK_ONLY;
		return {
			tier,
			hasCaseScopedRole,
			roles: [...roles],
			isHfrs,
			isAdmin,
			isFrs,
			receivesApprovals: isHfrs,
		};
	}

	private async _getUserRoles(username?: string, entityId?: number): Promise<Set<CmsUserRole>> {
		const user = username?.toLowerCase();
		const roles = new Set<CmsUserRole>();
		if (!user) return roles;
		const assigned = await this.adminApiClient.getUserRoles(user);
		for (const record of assigned ?? []) {
			const role = mapAdminRoleName(record.roleName);
			if (!role) continue;
			if (entityId != null && !(record.locations ?? []).map(String).includes(String(entityId))) {
				continue;
			}
			roles.add(role);
		}
		return roles;
	}

	private async _userHasConfigRole(username?: string, entityId?: number): Promise<boolean> {
		const roles = await this._getUserRoles(username, entityId);
		return roles.has(CmsUserRole.HFRS) || roles.has(CmsUserRole.ADMIN);
	}

	/** Any mapped CMS role — HFRS, Admin or FRS — sees every case, and so every case's work. */
	private async _userHasGlobalViewRole(username?: string): Promise<boolean> {
		const roles = await this._getUserRoles(username);
		return roles.size > 0;
	}

	private async _isConfigUserOnCase(caseRecord: Case | null, username?: string): Promise<boolean> {
		const user = username?.toLowerCase();
		if (!user || !caseRecord) return false;
		if (
			caseRecord.createdBy?.toLowerCase() === user ||
			assigneeEmail(caseRecord.caseLead) === user
		) {
			return true;
		}
		return this._userHasConfigRole(user, caseRecord.businessEntityId);
	}

	private async _isCaseConfigUser(caseId: number, username?: string): Promise<boolean> {
		if (!username) return false;
		return this._isConfigUserOnCase(await this.caseRepository.getCaseById(caseId), username);
	}

	private async _canActOnLoadedCase(caseRecord: Case, username?: string): Promise<boolean> {
		const user = username?.toLowerCase();
		if (!user) return false;
		if (await this._isConfigUserOnCase(caseRecord, user)) return true;
		return this.userPermissionRepository.hasAnyGrantForCase(caseRecord.id, user);
	}

	private async _assertCanActOnCase(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<Case> {
		const caseRecord = await this._loadActionableCase(caseId);
		if (!(await this._canActOnLoadedCase(caseRecord, currentContext.user?.username))) {
			throw new HttpException(
				'You can only perform actions on your own cases.',
				HttpStatus.FORBIDDEN,
			);
		}
		return caseRecord;
	}

	/**
	 * The gate for any write to a case. Checks the caller may act, then stamps the case as touched
	 * so the "Last Updated" sort reflects work on its allegations, scope items and procedures — all
	 * of which live in their own tables and would otherwise leave `cases.updated_on` untouched.
	 * Stamped up front, so an edit that is rejected further down still counts as activity.
	 */
	private async _beginCaseMutation(caseId: number, currentContext: CurrentContext): Promise<Case> {
		const caseRecord = await this._assertCanActOnCase(caseId, currentContext);
		await this.caseRepository.touchCase(caseId, currentContext);
		return caseRecord;
	}

	private async _assertCanConfigureCase(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<Case> {
		const caseRecord = await this._loadActionableCase(caseId);
		if (!(await this._isConfigUserOnCase(caseRecord, currentContext.user?.username))) {
			throw new HttpException(
				'Only FRS or the Case Lead may configure user assignments on this case.',
				HttpStatus.FORBIDDEN,
			);
		}
		return caseRecord;
	}

	private async _loadActionableCase(caseId: number): Promise<Case> {
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		if (!caseRecord) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);
		if (caseRecord.isDeactivated) {
			throw new HttpException(
				'This case has been deactivated and can no longer be acted on.',
				HttpStatus.FORBIDDEN,
			);
		}
		return caseRecord;
	}

	private async _assertCanDeactivateCase(caseId: number, currentContext: CurrentContext): Promise<Case> {
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		if (!caseRecord) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);
		const user = currentContext.user?.username?.toLowerCase();
		const isHfrs = !!user && (await this._getUserRoles(user)).has(CmsUserRole.HFRS);
		const isCaseLead = !!user && assigneeEmail(caseRecord.caseLead) === user;
		if (!isHfrs && !isCaseLead) {
			throw new HttpException(
				'Only HFRS or the Case Lead can deactivate this case.',
				HttpStatus.FORBIDDEN,
			);
		}
		return caseRecord;
	}

	private _assignmentTypeForSource(sourceType: string | null): AssignmentType | null {
		switch (sourceType) {
			case PermissionSourceType.ALLEGATION:
				return AssignmentType.ALLEGATION_MANAGER;
			case PermissionSourceType.SUB_ASSIGNEE:
				return AssignmentType.SUB_ASSIGNEE;
			case PermissionSourceType.PROCEDURE:
				return AssignmentType.PROCEDURE_ASSIGNEE;
			default:
				return null;
		}
	}

	private _sectionsForSource(sourceType: string | null, requested?: string[]): string[] {
		switch (sourceType) {
			case PermissionSourceType.ALLEGATION:
				return [...ALLEGATION_MANAGER_SECTIONS];
			case PermissionSourceType.PROCEDURE:
				return [...PROCEDURE_ASSIGNEE_SECTIONS];
			default:
				return requested ?? [];
		}
	}

	private async _removeOtherProcedureGrants(
		caseId: number,
		procedureId: number,
		keepUserId: string,
		currentContext: CurrentContext,
	): Promise<void> {
		await this.userPermissionRepository.deleteOtherProcedureGrants(
			caseId,
			procedureId,
			keepUserId,
			currentContext,
		);
	}

	private async _assertCanReplaceProcedureAssignee(
		caseId: number,
		procedureId: number,
		keepUserId: string,
	): Promise<void> {
		const keep = keepUserId.toLowerCase();
		const displaced = (
			await this.userPermissionRepository.getProcedureGrants(caseId, procedureId)
		).filter(grant => grant.userId.toLowerCase() !== keep);
		const configCreator = await this._configCreatorMap(
			caseId,
			displaced.map(grant => grant.createdBy),
		);
		if (displaced.some(grant => configCreator.get((grant.createdBy ?? '').toLowerCase()))) {
			throw new HttpException(PROCEDURE_ASSIGNEE_LOCKED_MESSAGE, HttpStatus.FORBIDDEN);
		}
	}

	private async _assertCanModifyProcedureGrant(
		caseId: number,
		procedureId: number,
		grantCreatedBy: string | null | undefined,
		username?: string,
	): Promise<void> {
		const procedure = await this.procedureRepository.getById(procedureId);
		if (
			!(await this._canModifyAssigneeItem(caseId, procedure?.allegationId, grantCreatedBy, username))
		) {
			throw new HttpException(PROCEDURE_ASSIGNEE_LOCKED_MESSAGE, HttpStatus.FORBIDDEN);
		}
	}

	/**
	 * Report Results is allegation-level work. FRS / the Case Lead write any of it; everyone else
	 * writes only the allegations they manage, and never over an outcome the Case Lead has confirmed.
	 * The overall analysis and conclusion describe the whole case, so they stay with FRS / the Case Lead.
	 */
	private async _assertCanSaveResults(
		dto: SaveResultsRequestDto,
		existingById: Map<number, CaseAllegation>,
		currentContext: CurrentContext,
	): Promise<void> {
		const username = currentContext.user?.username?.toLowerCase();
		if (await this._isCaseConfigUser(dto.caseId, username)) return;

		if (dto.overallAnalysisResult !== undefined || dto.conclusion !== undefined) {
			throw new HttpException(RESULTS_CASE_SUMMARY_RESTRICTED_MESSAGE, HttpStatus.FORBIDDEN);
		}

		const managedAllegationIds = new Set(
			(await this.userPermissionRepository.getAllegationRecordsByUser(dto.caseId, username ?? ''))
				.filter(grant => grant.sourceType === PermissionSourceType.ALLEGATION)
				.map(grant => Number(grant.sourceId)),
		);
		for (const result of dto.results) {
			const allegationId = Number(result.allegationId);
			const allegation = existingById.get(allegationId);
			if (!managedAllegationIds.has(allegationId) || Number(allegation?.caseId) !== Number(dto.caseId)) {
				throw new HttpException(RESULTS_ALLEGATION_RESTRICTED_MESSAGE, HttpStatus.FORBIDDEN);
			}
			if (allegation?.outcomeConfirmed) {
				throw new HttpException(RESULTS_CONFIRMED_LOCKED_MESSAGE, HttpStatus.FORBIDDEN);
			}
		}
	}

	private async _isAllegationManagerOf(
		caseId: number,
		allegationId: number | null | undefined,
		username?: string,
	): Promise<boolean> {
		const user = username?.toLowerCase();
		if (!user || !allegationId) return false;
		const amPerm = await this.userPermissionRepository.getByUserCaseAndSource(
			caseId,
			user,
			PermissionSourceType.ALLEGATION,
			allegationId,
		);
		return !!amPerm;
	}

	private async _isAllegationManagerOfProcedure(
		caseId: number,
		procedureId: number,
		username?: string,
	): Promise<boolean> {
		const proc = await this.procedureRepository.getById(procedureId);
		if (!proc?.allegationId) return false;
		return this._isAllegationManagerOf(caseId, proc.allegationId, username);
	}

	private async _isFraudAllegation(allegationId: number | null | undefined): Promise<boolean> {
		if (!allegationId) return false;
		const allegation = await this.allegationRepository.getById(allegationId);
		return allegation?.classification === CaseClassification.FRAUD;
	}

	/**
	 * Scope of work belongs to FRS / the Case Lead: a config user on the case, or anyone holding a
	 * CMS role (HFRS, Admin or FRS team). Someone can be both this and the Allegation Manager — an
	 * FRS member assigned an allegation keeps their scope rights, on every allegation.
	 */
	private async _ownsScopeOfWork(caseId: number, username?: string): Promise<boolean> {
		if (await this._isCaseConfigUser(caseId, username)) return true;
		return this._userHasGlobalViewRole(username);
	}

	/**
	 * Everyone else — an Allegation Manager or sub-assignee from outside the FRS team — may define
	 * scope only on a Non-Fraud allegation.
	 */
	private async _canWriteScopeForAllegation(
		caseId: number,
		allegationId: number | null | undefined,
		username?: string,
	): Promise<boolean> {
		if (await this._ownsScopeOfWork(caseId, username)) return true;
		return !(await this._isFraudAllegation(allegationId));
	}

	private async _assertCanWriteScope(
		caseId: number,
		allegationId: number | null | undefined,
		currentContext: CurrentContext,
	): Promise<void> {
		const allowed = await this._canWriteScopeForAllegation(
			caseId,
			allegationId,
			currentContext.user?.username,
		);
		if (!allowed) {
			throw new HttpException(SCOPE_FRAUD_RESTRICTED_MESSAGE, HttpStatus.FORBIDDEN);
		}
	}

	private async _assertCanModifyScopeItem(
		item: CaseScopeItem,
		currentContext: CurrentContext,
		action: 'edit' | 'delete',
	): Promise<void> {
		const username = currentContext.user?.username?.toLowerCase();
		if (await this._ownsScopeOfWork(item.caseId, username)) return;
		if (await this._isFraudAllegation(item.allegationId)) {
			throw new HttpException(SCOPE_FRAUD_RESTRICTED_MESSAGE, HttpStatus.FORBIDDEN);
		}
		const creator = (item.createdBy ?? '').toLowerCase();
		const isManager = await this._isAllegationManagerOf(item.caseId, item.allegationId, username);
		const writtenByOwner = !creator || (await this._ownsScopeOfWork(item.caseId, creator));
		if (!isManager || writtenByOwner) {
			throw new HttpException(
				`You can only ${action} scope items you or your allegation added.`,
				HttpStatus.FORBIDDEN,
			);
		}
	}

	/**
	 * Resolves who added an item, per (author, allegation). Everything it needs is fetched once, so
	 * a whole case's scope items and procedures cost the same as a single one.
	 */
	private async _itemOriginResolver(
		caseId: number,
		creators: (string | null | undefined)[],
	): Promise<(createdBy?: string | null, allegationId?: number | null) => ItemOrigin | null> {
		const unique = [...new Set(creators.map(c => (c ?? '').toLowerCase()).filter(Boolean))];
		if (unique.length === 0) return () => null;

		const [caseRecord, grants, ownerFlags] = await Promise.all([
			this.caseRepository.getCaseById(caseId),
			this.userPermissionRepository.getByCaseId(caseId),
			Promise.all(unique.map(user => this._ownsScopeOfWork(caseId, user))),
		]);
		const caseLead = assigneeEmail(caseRecord?.caseLead);
		const ownsScope = new Map(unique.map((user, i) => [user, ownerFlags[i]]));
		const managedAllegations = new Set(
			grants
				.filter(g => g.sourceType === PermissionSourceType.ALLEGATION)
				.map(g => `${g.userId.toLowerCase()}:${Number(g.sourceId)}`),
		);

		return (createdBy, allegationId) => {
			const user = (createdBy ?? '').toLowerCase();
			if (!user) return null;
			if (caseLead && user === caseLead) return ItemOrigin.CASE_LEAD;
			if (allegationId && managedAllegations.has(`${user}:${Number(allegationId)}`)) {
				return ItemOrigin.ALLEGATION_MANAGER;
			}
			return ownsScope.get(user) ? ItemOrigin.FRS : null;
		};
	}

	/** Which of these scope-item authors are FRS / the Case Lead — whose items nobody else edits. */
	private async _scopeOwnerCreatorMap(
		caseId: number,
		creators: (string | null | undefined)[],
	): Promise<Map<string, boolean>> {
		const map = await this._configCreatorMap(caseId, creators);
		const unresolved = [...map.entries()].filter(([creator, isOwner]) => creator && !isOwner);
		const widened = await Promise.all(
			unresolved.map(
				async ([creator]) => [creator, await this._userHasGlobalViewRole(creator)] as const,
			),
		);
		for (const [creator, isFrs] of widened) {
			if (isFrs) map.set(creator, true);
		}
		return map;
	}

	private async _canModifyAssigneeItem(
		caseId: number,
		allegationId: number | null | undefined,
		itemCreatedBy: string | null | undefined,
		username?: string,
	): Promise<boolean> {
		const user = username?.toLowerCase();
		if (!user) return false;
		if (await this._isCaseConfigUser(caseId, user)) return true;
		if (!(await this._isAllegationManagerOf(caseId, allegationId, user))) return false;
		const creator = (itemCreatedBy ?? '').toLowerCase();
		if (!creator) return false;
		return !(await this._isCaseConfigUser(caseId, creator));
	}

	private async _configCreatorMap(
		caseId: number,
		creators: (string | null | undefined)[],
	): Promise<Map<string, boolean>> {
		const unique = [...new Set(creators.map(c => (c ?? '').toLowerCase()))];
		if (unique.length === 0) return new Map();

		const caseRecord = await this.caseRepository.getCaseById(caseId);
		const resolved = await Promise.all(
			unique.map(async creator => [
				creator,
				creator ? await this._isConfigUserOnCase(caseRecord, creator) : true,
			] as const),
		);
		return new Map(resolved);
	}

	public async getAllegationProcedures(
		allegationId: number,
		currentContext: CurrentContext,
	): Promise<TaskProcedureResponseDto[]> {
		const allegation = await this.allegationRepository.getById(allegationId);
		if (!allegation) throw new HttpException('Allegation not found.', HttpStatus.BAD_REQUEST);
		await this._resolveWorkItemViewer(
			AssignmentType.ALLEGATION_MANAGER,
			allegation,
			allegationId,
			currentContext,
		);

		const [allegProcs, perms] = await Promise.all([
			this.procedureRepository.getByAllegationId(allegationId),
			this.userPermissionRepository.getByCaseId(allegation.caseId),
		]);
		const username = currentContext.user?.username?.toLowerCase();
		const procedureCreators = allegProcs.map(p => p.createdBy);
		const procedureGrants = perms.filter(gr => gr.sourceType === PermissionSourceType.PROCEDURE);
		const [configCreator, originOf] = await Promise.all([
			this._configCreatorMap(allegation.caseId, [
				...procedureCreators,
				...procedureGrants.map(gr => gr.createdBy),
				username,
			]),
			this._itemOriginResolver(allegation.caseId, procedureCreators),
		]);
		const viewerIsConfig = !!username && !!configCreator.get(username);
		return allegProcs.map(p => {
			const assignees = procedureGrants
				.filter(gr => Number(gr.sourceId) === Number(p.id))
				.map(gr => ({
					permissionId: gr.id,
					userId: gr.userId,
					userName: gr.userName ?? gr.userId,
					userEmail: gr.userEmail ?? gr.userId,
					canModify: viewerIsConfig || !configCreator.get((gr.createdBy ?? '').toLowerCase()),
				}));
			return {
				id: p.id,
				description: p.description,
				actionBy: p.actionBy ?? null,
				actionByEmail: p.actionByEmail ?? null,
				deadline: p.deadline ?? null,
				status: p.status,
				workPerformed: p.workPerformed ?? null,
				completedDate: p.completedDate ?? null,
				createdBy: p.createdBy ?? '',
				addedByRole: originOf(p.createdBy, p.allegationId),
				canDelete: !configCreator.get((p.createdBy ?? '').toLowerCase()),
				assignees,
			};
		});
	}

	private async _resolveTaskTitle(type: AssignmentType, sourceId: number): Promise<string> {
		if (type === AssignmentType.PROCEDURE_ASSIGNEE) {
			const proc = await this.procedureRepository.getById(sourceId);
			return proc?.description ?? 'Procedure';
		}
		if (type === AssignmentType.RECOMMENDATION_OWNER) {
			const rec = await this.recommendationItemRepository.getById(sourceId);
			return rec?.issueTitle ?? 'Recommendation';
		}
		const alleg = await this.allegationRepository.getById(sourceId);
		return alleg?.label ?? 'Allegation';
	}

	/**
	 * Every allegation, procedure or recommendation in the system, one page at a time.
	 *
	 * Only FRS/HFRS/Admin see work beyond their own; everyone else keeps reading their assignments
	 * from `getMyAssignmentTasks`. The filters, the derived status and the paging all run in SQL —
	 * these tables grow with every case, so no unfiltered read of them ever reaches memory.
	 */
	public async getWorkList(
		limit: number,
		page: number,
		filters: WorkListFilterRequestDto,
		searchTerm: string | undefined,
		currentContext: CurrentContext,
	): Promise<Pagination<WorkItemResponseDto>> {
		const username = await this._assertCanBrowseAllWork(currentContext);
		const result = await this.workItemRepository.getPaginatedWorkItems(
			filters.assignmentType,
			limit,
			page,
			this._workItemQuery(filters, searchTerm, username),
		);
		const records = result.rows.map(row => this._toWorkItem(row, filters.assignmentType, username));

		return new Pagination({ records, total: result.count });
	}

	/** Tab counts for the same scope, under every filter but the status one. */
	public async getWorkStats(
		filters: WorkStatsFilterRequestDto,
		searchTerm: string | undefined,
		currentContext: CurrentContext,
	): Promise<WorkStatsResponseDto> {
		const username = await this._assertCanBrowseAllWork(currentContext);
		const query = this._workItemQuery(filters, searchTerm, username);
		const [allegations, procedures, recommendations] = await Promise.all(
			WORK_ITEM_TYPES.map(type => this.workItemRepository.countWorkItems(type, query)),
		);

		return { allegations, procedures, recommendations };
	}

	private async _assertCanBrowseAllWork(currentContext: CurrentContext): Promise<string> {
		const username = currentContext.user?.username?.toLowerCase();
		if (!(await this._userHasGlobalViewRole(username))) {
			throw new HttpException('You do not have access to case-wide work.', HttpStatus.FORBIDDEN);
		}
		return username!;
	}

	private _workItemQuery(
		filters: WorkListFilterRequestDto | WorkStatsFilterRequestDto,
		searchTerm: string | undefined,
		username: string,
	): WorkItemQuery {
		return {
			status: (filters as WorkListFilterRequestDto).status ?? WorkStatusFilter.ALL,
			assignedToMe: filters.assignedToMe,
			searchTerm: searchTerm?.trim() || undefined,
			username,
		};
	}

	private _toWorkItem(row: WorkItemRow, type: WorkItemType, username: string): WorkItemResponseDto {
		return {
			id: row.id,
			caseId: row.caseId,
			irNumber: row.irNumber,
			assignmentType: type,
			title: row.title,
			status: row.isCompleted ? AssignmentTaskStatus.COMPLETED : AssignmentTaskStatus.PENDING,
			assigneeName: row.assigneeName ?? row.assigneeUserId,
			classification: row.classification ?? null,
			incidentTypeCode: row.incidentTypeCode ?? null,
			assignedToMe: row.assigneeUserId?.toLowerCase() === username,
			createdBy: row.createdBy,
			createdOn: row.createdOn,
		};
	}

	public async getMyAssignmentTasks(username: string): Promise<AssignmentTaskResponseDto[]> {
		const active = await this.assignmentTaskService.getByAssignee(username);
		const sourceIdsFor = (type: AssignmentType) =>
			active.filter(t => t.assignmentType === type).map(t => t.sourceId);

		const [procedures, recommendations, allegations] = await Promise.all([
			this.procedureRepository.getByIds(sourceIdsFor(AssignmentType.PROCEDURE_ASSIGNEE)),
			this.recommendationItemRepository.getByIds(
				sourceIdsFor(AssignmentType.RECOMMENDATION_OWNER),
			),
			this.allegationRepository.getByIds([
				...sourceIdsFor(AssignmentType.ALLEGATION_MANAGER),
				...sourceIdsFor(AssignmentType.SUB_ASSIGNEE),
			]),
		]);

		const procedureById = new Map(procedures.map(p => [Number(p.id), p]));
		const recommendationById = new Map(recommendations.map(r => [Number(r.id), r]));
		const allegationById = new Map(allegations.map(a => [Number(a.id), a]));

		const pending: AssignmentTaskResponseDto[] = active.map(t => {
			let status = t.status;
			let title: string;
			let allegation: CaseAllegation | undefined;

			if (t.assignmentType === AssignmentType.PROCEDURE_ASSIGNEE) {
				title = procedureById.get(Number(t.sourceId))?.description ?? 'Procedure';
			} else if (t.assignmentType === AssignmentType.RECOMMENDATION_OWNER) {
				const rec = recommendationById.get(Number(t.sourceId));
				title = rec?.issueTitle ?? 'Recommendation';
				if (rec?.status === RecommendationItemStatus.IMPLEMENTED) {
					status = AssignmentTaskStatus.COMPLETED;
				}
			} else {
				allegation = allegationById.get(Number(t.sourceId));
				title = allegation?.label ?? 'Allegation';
			}

			return {
				id: t.id,
				caseId: t.caseId,
				irNumber: null,
				assignmentType: t.assignmentType,
				sourceId: t.sourceId,
				title,
				status,
				assigneeName: t.assigneeName ?? null,
				classification: allegation?.classification ?? null,
				incidentTypeCode: allegation?.incidentTypeCode ?? null,
				createdBy: t.createdBy,
				createdByName: t.createdByName,
				createdOn: t.createdOn,
			};
		});
		const completed = await this._completedProcedureTasks(username);
		const byKey = new Map<string, AssignmentTaskResponseDto>();
		const keyFor = (t: AssignmentTaskResponseDto) =>
			t.assignmentType === AssignmentType.PROCEDURE_ASSIGNEE
				? `proc:${t.sourceId}`
				: `task:${t.id}`;
		for (const t of [...pending, ...completed]) {
			const key = keyFor(t);
			const existing = byKey.get(key);
			if (!existing || t.status === AssignmentTaskStatus.COMPLETED) byKey.set(key, t);
		}
		const merged = [...byKey.values()];
		const activeCases = await this.caseRepository.getActiveCaseRefs(merged.map(t => t.caseId));
		return merged
			.filter(t => activeCases.has(Number(t.caseId)))
			.map(t => ({ ...t, irNumber: activeCases.get(Number(t.caseId))?.irNumber ?? null }))
			.sort((a, b) => new Date(b.createdOn).getTime() - new Date(a.createdOn).getTime());
	}

	private async _completedProcedureTasks(username: string): Promise<AssignmentTaskResponseDto[]> {
		const user = username.toLowerCase();
		try {
			const [byAction, grants] = await Promise.all([
				this.procedureRepository.getCompletedByActionUser(user),
				this.userPermissionRepository.getProcedureGrantsByUser(user),
			]);
			const procById = new Map<number, CaseProcedure>();
			for (const p of byAction) procById.set(p.id, p);
			const grantByProc = new Map<number, typeof grants[number]>();
			for (const g of grants) {
				const pid = Number(g.sourceId);
				if (pid) grantByProc.set(pid, g);
			}
			const missing = [...grantByProc.keys()].filter(id => !procById.has(id));
			const loaded = await Promise.all(missing.map(id => this.procedureRepository.getById(id)));
			for (const p of loaded) {
				if (p && !p.deleted && p.status === ProcedureStatus.COMPLETE) procById.set(p.id, p);
			}
			return [...procById.values()].map(proc => {
				const grant = grantByProc.get(proc.id);
				return {
					id: proc.id,
					caseId: proc.caseId,
					irNumber: null,
					assignmentType: AssignmentType.PROCEDURE_ASSIGNEE,
					sourceId: proc.id,
					title: proc.description,
					status: AssignmentTaskStatus.COMPLETED,
					assigneeName: grant?.userName ?? proc.actionBy ?? null,
					classification: null,
					incidentTypeCode: null,
					createdBy: grant?.createdBy ?? proc.createdBy ?? '',
					createdByName: null,
					createdOn: grant?.createdOn ?? proc.createdOn ?? new Date(),
				} as AssignmentTaskResponseDto;
			});
		} catch {
			return [];
		}
	}

	public async getAssignmentTaskDetail(
		taskId: number,
		currentContext: CurrentContext,
	): Promise<AssignmentTaskDetailResponseDto> {
		const username = currentContext.user?.username?.toLowerCase();
		const task = await this.assignmentTaskService.getById(taskId);
		if (!task) throw new HttpException('Task not found.', HttpStatus.BAD_REQUEST);
		const isAssignee = task.assigneeUserId?.toLowerCase() === username;
		if (!isAssignee && !(await this._userHasGlobalViewRole(username))) {
			throw new HttpException('You do not have access to this task.', HttpStatus.FORBIDDEN);
		}
		return this._buildAssignmentTaskDetail(task, {
			canAct: isAssignee,
			hasLiveTask: true,
			viewerUsername: username,
		});
	}

	public async getWorkItemDetail(
		type: WorkItemType,
		sourceId: number,
		currentContext: CurrentContext,
	): Promise<AssignmentTaskDetailResponseDto> {
		const record = await this._loadWorkItemRecord(type, sourceId);
		if (!record) throw new HttpException('Task not found.', HttpStatus.BAD_REQUEST);

		const { canAct, assignee } = await this._resolveWorkItemViewer(
			type,
			record,
			sourceId,
			currentContext,
		);
		const liveTask = await this._findLiveAssignmentTask(type, record.caseId, sourceId, assignee.userId);
		const task = liveTask ?? this._synthesiseAssignmentTask(type, record, assignee);

		return this._buildAssignmentTaskDetail(task, {
			canAct,
			hasLiveTask: !!liveTask,
			viewerUsername: currentContext.user?.username,
		});
	}

	private async _loadWorkItemRecord(
		type: WorkItemType,
		sourceId: number,
	): Promise<CaseProcedure | CaseRecommendationItem | CaseAllegation | null> {
		if (type === AssignmentType.PROCEDURE_ASSIGNEE) return this.procedureRepository.getById(sourceId);
		if (type === AssignmentType.RECOMMENDATION_OWNER) {
			return this.recommendationItemRepository.getById(sourceId);
		}
		return this.allegationRepository.getById(sourceId);
	}

	private async _workItemAssignee(
		type: AssignmentType,
		record: any,
		sourceId: number,
	): Promise<WorkItemAssignee> {
		if (type === AssignmentType.RECOMMENDATION_OWNER) {
			return {
				userId: record.recommendationOwnerEmail ?? null,
				name: record.recommendationOwner ?? null,
				email: record.recommendationOwnerEmail ?? null,
			};
		}

		const onRecord =
			type === AssignmentType.PROCEDURE_ASSIGNEE
				? {
						userId: record.actionByUserId ?? null,
						name: record.actionBy ?? null,
						email: record.actionByEmail ?? null,
				  }
				: {
						userId: record.allegationManagerId ?? null,
						name: record.allegationManagerName ?? null,
						email: record.allegationManagerId ?? null,
				  };

		const sourceType = this._sourceTypeForAssignment(type);
		const grant = sourceType
			? await this.userPermissionRepository.getSourceAssignmentGrant(
					record.caseId,
					sourceType,
					sourceId,
			  )
			: null;

		return grant
			? {
					userId: grant.userId,
					name: grant.userName ?? onRecord.name,
					email: grant.userEmail ?? onRecord.email,
			  }
			: onRecord;
	}

	private async _resolveWorkItemViewer(
		type: AssignmentType,
		record: any,
		sourceId: number,
		currentContext: CurrentContext,
	): Promise<{ canAct: boolean; assignee: WorkItemAssignee }> {
		const username = currentContext.user?.username?.toLowerCase();
		const assignee = await this._workItemAssignee(type, record, sourceId);
		if (username && assignee.userId?.toLowerCase() === username) return { canAct: true, assignee };

		const sourceType = this._sourceTypeForAssignment(type);
		const grant =
			username && sourceType
				? await this.userPermissionRepository.getByUserCaseAndSource(
						record.caseId,
						username,
						sourceType,
						sourceId,
				  )
				: null;
		if (grant) {
			return {
				canAct: true,
				assignee: {
					userId: username!,
					name: grant.userName ?? assignee.name,
					email: grant.userEmail ?? assignee.email,
				},
			};
		}

		if (await this._userHasGlobalViewRole(username)) return { canAct: false, assignee };
		throw new HttpException('You do not have access to this task.', HttpStatus.FORBIDDEN);
	}

	private async _findLiveAssignmentTask(
		type: AssignmentType,
		caseId: number,
		sourceId: number,
		assigneeUserId: string | null,
	): Promise<AssignmentTaskView | null> {
		if (!assigneeUserId) return null;
		try {
			return await this.assignmentTaskService.getForAssigneeAndSource(
				caseId,
				type,
				sourceId,
				assigneeUserId,
			);
		} catch {
			return null;
		}
	}
	
	private _synthesiseAssignmentTask(
		type: AssignmentType,
		record: any,
		assignee: WorkItemAssignee,
	): AssignmentTaskView {
		return {
			id: Number(record.id),
			caseId: Number(record.caseId),
			assignmentType: type,
			sourceId: Number(record.id),
			assigneeUserId: assignee.userId ?? '',
			assigneeName: assignee.name,
			assigneeEmail: assignee.email,
			status: AssignmentTaskStatus.PENDING,
			redelegatedFromUserId: null,
			createdBy: record.createdBy ?? '',
			createdByName: null,
			createdOn: record.createdOn ?? new Date(),
		};
	}

	private async _buildAssignmentTaskDetail(
		task: AssignmentTaskView,
		options: { canAct: boolean; hasLiveTask: boolean; viewerUsername?: string },
	): Promise<AssignmentTaskDetailResponseDto> {
		let title: string;
		let description: string | null;
		let allegationIdForScope: number | null = null;
		let incidentTypeCode: string | null = null;
		let classification: string | null = null;
		let recommendationImplemented = false;
		let allegationRecord: CaseAllegation | null = null;
		let procedure: {
			id: number;
			description: string;
			deadline: string | null;
			status: string;
			workPerformed: string | null;
			completedDate: string | Date | null;
		} | null = null;
		let recommendation: {
			id: number;
			issueTitle: string;
			actionDetails: string | null;
			implementationDeadline: string | null;
			status: string;
			implementationNotes: string | null;
		} | null = null;

		if (task.assignmentType === AssignmentType.PROCEDURE_ASSIGNEE) {
			const proc = await this.procedureRepository.getById(task.sourceId);
			title = proc?.description ?? 'Procedure';
			description = null;
			allegationIdForScope = proc?.allegationId ?? null;
			if (allegationIdForScope) {
				const parentAlleg = await this.allegationRepository.getById(allegationIdForScope);
				classification = parentAlleg?.classification ?? null;
			}
			procedure = proc
				? {
						id: proc.id,
						description: proc.description,
						deadline: proc.deadline ?? null,
						status: proc.status,
						workPerformed: proc.workPerformed ?? null,
						completedDate: proc.completedDate ?? null,
				  }
				: null;
		} else if (task.assignmentType === AssignmentType.RECOMMENDATION_OWNER) {
			const rec = await this.recommendationItemRepository.getById(task.sourceId);
			title = rec?.issueTitle ?? 'Recommendation';
			description = rec?.actionDetails ?? rec?.issueDescription ?? null;
			recommendationImplemented = rec?.status === RecommendationItemStatus.IMPLEMENTED;
			recommendation = rec
				? {
						id: rec.id,
						issueTitle: rec.issueTitle,
						actionDetails: rec.actionDetails ?? null,
						implementationDeadline: rec.implementationDeadline ?? null,
						status: rec.status,
						implementationNotes: rec.implementationNotes ?? null,
				  }
				: null;
		} else {
			const alleg = await this.allegationRepository.getById(task.sourceId);
			allegationRecord = alleg;
			title = alleg?.label ?? 'Allegation';
			description = alleg?.description ?? null;
			incidentTypeCode = alleg?.incidentTypeCode ?? null;
			classification = alleg?.classification ?? null;
			allegationIdForScope = task.sourceId;
		}

		const caseRecord = await this.caseRepository.getCaseById(task.caseId);
		const viewerOwnsScope = await this._ownsScopeOfWork(task.caseId, options.viewerUsername);
		const canWriteScope = allegationIdForScope
			? viewerOwnsScope || !(await this._isFraudAllegation(allegationIdForScope))
			: false;

		const isAllegationManagerTask = task.assignmentType === AssignmentType.ALLEGATION_MANAGER;
		const attachmentRecords =
			isAllegationManagerTask && allegationIdForScope
				? await this.evidenceRepository.getAllegationAttachments(allegationIdForScope)
				: [];
		const result =
			isAllegationManagerTask && allegationRecord
				? {
						outcome: allegationRecord.outcome ?? null,
						detailedAnalysis: allegationRecord.detailedAnalysis ?? null,
						lossAmount:
							allegationRecord.lossAmount != null ? Number(allegationRecord.lossAmount) : null,
						recoveredAmount:
							allegationRecord.recoveredAmount != null
								? Number(allegationRecord.recoveredAmount)
								: null,
						currency: allegationRecord.currency ?? null,
						lossNotes: allegationRecord.lossNotes ?? null,
						outcomeConfirmed: !!allegationRecord.outcomeConfirmed,
						outcomeConfirmedBy: allegationRecord.outcomeConfirmedBy ?? null,
						outcomeConfirmedOn: allegationRecord.outcomeConfirmedOn ?? null,
				  }
				: null;
		const canWriteResults =
			!!result &&
			!result.outcomeConfirmed &&
			!caseRecord?.isDeactivated &&
			!isCaseClosed(caseRecord?.status);

		let scopeOfWork: {
			id: number;
			description: string;
			createdBy: string;
			addedByRole: string | null;
			canDelete: boolean;
		}[] = [];
		if (allegationIdForScope) {
			const items = await this.scopeItemRepository.getByAllegationId(allegationIdForScope);
			const creators = items.map(i => i.createdBy);
			const [ownerCreator, originOf] = await Promise.all([
				this._scopeOwnerCreatorMap(task.caseId, creators),
				this._itemOriginResolver(task.caseId, creators),
			]);
			scopeOfWork = items.map(i => {
				const writtenByScopeOwner = !!ownerCreator.get((i.createdBy ?? '').toLowerCase());
				return {
					id: i.id,
					description: i.description,
					createdBy: i.createdBy ?? '',
					addedByRole: originOf(i.createdBy, i.allegationId),
					canDelete: canWriteScope && (viewerOwnsScope || !writtenByScopeOwner),
				};
			});
		}

		let effectiveStatus: AssignmentTaskStatus;
		if (task.assignmentType === AssignmentType.PROCEDURE_ASSIGNEE) {
			effectiveStatus =
				procedure?.status === ProcedureStatus.COMPLETE
					? AssignmentTaskStatus.COMPLETED
					: task.status;
		} else if (task.assignmentType === AssignmentType.RECOMMENDATION_OWNER) {
			effectiveStatus = recommendationImplemented
				? AssignmentTaskStatus.COMPLETED
				: task.status;
		} else {
			effectiveStatus = task.status;
		}

		const isRecommendationOwner = task.assignmentType === AssignmentType.RECOMMENDATION_OWNER;
		const canDelegate =
			options.canAct &&
			options.hasLiveTask &&
			!isRecommendationOwner &&
			(effectiveStatus === AssignmentTaskStatus.PENDING ||
				effectiveStatus === AssignmentTaskStatus.IN_PROGRESS);

		const perm = isRecommendationOwner
			? null
			: await this.userPermissionRepository.getByUserCaseAndSource(
					task.caseId,
					task.assigneeUserId,
					this._sourceTypeForAssignment(task.assignmentType),
					task.sourceId,
			  );

		return {
			id: task.id,
			caseId: task.caseId,
			assignmentType: task.assignmentType,
			allegationId: allegationIdForScope,
			incidentTypeCode,
			classification,
			irNumber: caseRecord?.irNumber ?? null,
			procedure,
			recommendation,
			status: effectiveStatus,
			title,
			description,
			canDelegate,
			canAct: options.canAct,
			canWriteScope,
			canWriteResults,
			scopeOfWork,
			result,
			attachments: attachmentRecords.map(item => ({
				id: item.id,
				fileName: item.fileName,
				category: item.category,
				description: item.description ?? null,
				uploadedBy: item.uploadedBy,
				createdOn: item.createdOn,
			})),
			role: perm?.role ?? null,
			sections: perm?.sections ?? [],
			assigneeName: task.assigneeName ?? task.assigneeUserId ?? null,
			assignedBy: task.createdBy,
			assignedOn: task.createdOn,
			redelegatedFromUserId: task.redelegatedFromUserId ?? null,
		};
	}

	private _sourceTypeForAssignment(type: AssignmentType): PermissionSourceType | null {
		switch (type) {
			case AssignmentType.ALLEGATION_MANAGER:
				return PermissionSourceType.ALLEGATION;
			case AssignmentType.PROCEDURE_ASSIGNEE:
				return PermissionSourceType.PROCEDURE;
			case AssignmentType.SUB_ASSIGNEE:
				return PermissionSourceType.SUB_ASSIGNEE;
			default:
				return null;
		}
	}

	public async requestDelegation(
		taskId: number,
		dto: DelegateRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const username = currentContext.user?.username?.toLowerCase();
		const task = await this.assignmentTaskService.getById(taskId);
		if (!task) throw new HttpException('Task not found.', HttpStatus.BAD_REQUEST);
		if (task.assigneeUserId?.toLowerCase() !== username) {
			throw new HttpException('You do not have access to this task.', HttpStatus.FORBIDDEN);
		}
		if (dto.toUserId.toLowerCase() === task.assigneeUserId.toLowerCase()) {
			throw new HttpException(
				'Cannot delegate a task to its current assignee.',
				HttpStatus.BAD_REQUEST,
			);
		}

		const caseRecord = await this.caseRepository.getCaseById(task.caseId);
		await this.caseRepository.touchCase(task.caseId, currentContext);
		const payload = {
			assignmentTaskId: task.id,
			caseId: task.caseId,
			irNumber: caseRecord?.irNumber ?? null,
			businessUnit: caseRecord?.businessUnit ?? null,
			assignmentType: task.assignmentType,
			sourceId: task.sourceId,
			fromUserId: task.assigneeUserId,
			fromUserName: task.assigneeName ?? null,
			toUserId: dto.toUserId,
			toUserName: dto.toUserName ?? null,
			toUserEmail: dto.toUserEmail ?? null,
			title: await this._resolveTaskTitle(task.assignmentType, task.sourceId),
		};

		await this._transferAssignment(payload, currentContext);
		this.auditLogService.log(
			{
				caseId: task.caseId,
				action: CMS_AUDIT_ACTION.ACCESS_GRANTED,
				comments: `Delegated: "${payload.title}" transferred from ${
					payload.fromUserName ?? payload.fromUserId
				} to ${dto.toUserName ?? dto.toUserId}`,
			},
			currentContext,
		);
		await this.caseNotificationService.notifyDelegationTransferred({
			caseId: task.caseId,
			toUserId: payload.toUserEmail ?? payload.toUserId,
			toUserName: payload.toUserName ?? null,
			fromUserName: payload.fromUserName ?? payload.fromUserId ?? null,
			taskTitle: payload.title ?? null,
		});
		return { message: 'Task delegated successfully. The task has been transferred.' };
	}

	private async _transferAssignment(
		payload: Record<string, any>,
		currentContext: CurrentContext,
	): Promise<void> {
		const caseId = Number(payload.caseId);
		const assignmentType = payload.assignmentType as AssignmentType;
		const sourceId = Number(payload.sourceId);
		const fromUserId = String(payload.fromUserId ?? '').toLowerCase();
		const toUserId = String(payload.toUserId ?? '');
		const toUserName = payload.toUserName ?? null;
		const toUserEmail = payload.toUserEmail ?? null;
		const sourceType = this._sourceTypeForAssignment(assignmentType);

		const oldPerm = await this.userPermissionRepository.getByUserCaseAndSource(
			caseId,
			fromUserId,
			sourceType,
			sourceId,
		);
		const sections = oldPerm
			? oldPerm.sections ?? []
			: this._defaultSectionsForAssignment(assignmentType);
		const role = oldPerm?.role ?? null;
		const oldCaseGrant = await this.userPermissionRepository.getByUserAndCase(caseId, fromUserId);

		await this.userPermissionRepository.upsertPermission(
			caseId,
			toUserId,
			{ userName: toUserName, userEmail: toUserEmail, role, sourceType, sourceId, sections } as any,
			currentContext,
		);
		if (oldCaseGrant) {
			const existingCaseGrant = await this.userPermissionRepository.getByUserAndCase(
				caseId,
				toUserId,
			);
			const mergedSections = existingCaseGrant
				? this._unionSections(existingCaseGrant.sections ?? [], oldCaseGrant.sections ?? [])
				: oldCaseGrant.sections ?? [];
			await this.userPermissionRepository.upsertPermission(
				caseId,
				toUserId,
				{
					userName: toUserName,
					userEmail: toUserEmail,
					role,
					sourceType: null,
					sourceId: null,
					sections: mergedSections,
				} as any,
				currentContext,
			);
		}

		if (assignmentType === AssignmentType.ALLEGATION_MANAGER) {
			await this.allegationRepository.updateAllegation(
				sourceId,
				{ allegationManagerId: toUserId, allegationManagerName: toUserName } as any,
				currentContext,
			);
		} else if (assignmentType === AssignmentType.PROCEDURE_ASSIGNEE) {
			await this.procedureRepository.updateProcedure(
				sourceId,
				{ actionByUserId: toUserId, actionBy: toUserName, actionByEmail: toUserEmail } as any,
				currentContext,
			);
		}

		await this.assignmentTaskService.softDeleteForAssigneeAndSource(
			caseId,
			assignmentType,
			sourceId,
			fromUserId,
			currentContext,
		);
		await this.assignmentTaskService.upsertTask(
			{
				caseId,
				assignmentType,
				sourceId,
				assigneeUserId: toUserId,
				assigneeName: toUserName,
				assigneeEmail: toUserEmail,
				status: AssignmentTaskStatus.PENDING,
				redelegatedFromUserId: fromUserId,
			} as any,
			currentContext,
		);

		if (oldPerm) {
			await this.userPermissionRepository.deletePermission(oldPerm.id, currentContext);
		}
		const remainingAlleg = await this.userPermissionRepository.getAllegationRecordsByUser(
			caseId,
			fromUserId,
		);
		const remainingProc = await this.userPermissionRepository.getProcedureRecordsByUser(
			caseId,
			fromUserId,
		);
		const keepsFullCase = [...remainingAlleg, ...remainingProc].some(
			g => (g.sections ?? []).length === 0,
		);
		if (!keepsFullCase) {
			const caseGrant = await this.userPermissionRepository.getByUserAndCase(caseId, fromUserId);
			if (caseGrant && this._isAssignmentRole(caseGrant.role)) {
				await this.userPermissionRepository.deletePermission(caseGrant.id, currentContext);
			}
		}
	}

	private _isAssignmentRole(role: string | null | undefined): boolean {
		return (
			role === CaseAssignmentRole.ALLEGATION_MANAGER ||
			role === CaseAssignmentRole.SUB_ASSIGNEE ||
			role === CaseAssignmentRole.PROCEDURE_INVESTIGATOR
		);
	}

	private _unionSections(a: string[], b: string[]): string[] {
		if (a.length === 0 || b.length === 0) return [];
		return Array.from(new Set([...a, ...b]));
	}

	private _defaultSectionsForAssignment(type: AssignmentType): string[] {
		switch (type) {
			case AssignmentType.PROCEDURE_ASSIGNEE:
				return ['perform'];
			case AssignmentType.ALLEGATION_MANAGER:
			case AssignmentType.SUB_ASSIGNEE:
			default:
				return ['scope', 'procedures', 'results'];
		}
	}

	public getPrimaryIssues(): string[] {
		return [
			'Accurate Books & Records',
			'Anti-Bribery',
			'Anti-Trust and Competition',
			'Auditing and Accounting',
			'Compliance',
			'Conflict of Interest',
			'Data Privacy',
			'Environmental',
			'Financial Misconduct',
			'Human Rights',
			'Insider Trading',
			'Money Laundering',
			'Safety',
			'Sexual Harassment',
			'Tax Evasion',
			'Theft / Fraud',
			'Workplace Violence',
			'Other',
		];
	}

	public getCaseStatusList(): string[] {
		return Object.values(CaseStatus);
	}

	public async createCaseTask(
		dto: CreateCaseTaskRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		await this._beginCaseMutation(dto.caseId, currentContext);
		await this.approvalTaskService.create(
			{
				caseId: dto.caseId,
				taskType: dto.taskType,
				assignedTo: dto.assignedTo,
				assignedToName: dto.assignedToName ?? null,
				payload: this._parseTaskPayload(dto.payload),
			},
			currentContext,
		);
		this.auditLogService.log(
			{
				caseId: dto.caseId,
				action: CMS_AUDIT_ACTION.TASK_CREATED,
				comments: `Task created: "${dto.taskType}" assigned to ${
					dto.assignedToName ?? dto.assignedTo
				}`,
			},
			currentContext,
		);
		return { message: 'Task created successfully.' };
	}

	public async getMyTasks(currentUser: string): Promise<CaseTaskResponseDto[]> {
		const tasks = (await this._canReviewAllApprovals(currentUser))
			? await this.approvalTaskService.getAllForUser(currentUser)
			: await this.approvalTaskService.getByAssignee(currentUser);
		const caseRefs = await this.caseRepository.getActiveCaseRefs(tasks.map(t => t.caseId));
		return tasks.map(t =>
			singleObjectToInstance(CaseTaskResponseDto, { ...t, ...caseRefs.get(Number(t.caseId)) }),
		);
	}

	public async getMyPendingTasks(currentUser: string): Promise<CaseTaskResponseDto[]> {
		const tasks = (await this._canReviewAllApprovals(currentUser))
			? await this.approvalTaskService.getAllPendingForUser(currentUser)
			: await this.approvalTaskService.getPendingByAssignee(currentUser);
		return tasks.map(t => singleObjectToInstance(CaseTaskResponseDto, t));
	}

	private async _canReviewAllApprovals(username?: string): Promise<boolean> {
		const user = username?.toLowerCase();
		if (!user) return false;
		const roles = await this._getUserRoles(user);
		return roles.has(CmsUserRole.HFRS) || roles.has(CmsUserRole.ADMIN);
	}

	public async getTasksForCase(caseId: number): Promise<CaseTaskResponseDto[]> {
		const [record, all] = await Promise.all([
			this.caseRepository.getCaseById(caseId),
			this.approvalTaskService.getByCase(caseId),
		]);
		if (!record) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);

		const tasks = all.filter(t => !this._isStalePathwayTask(t, record));
		const synthesized = this._synthesizeApprovedApprovals(record, tasks);
		return [...tasks, ...synthesized].map(t => singleObjectToInstance(CaseTaskResponseDto, t));
	}

	private _isStalePathwayTask(task: CaseTaskView, record: Case | null): boolean {
		const PATHWAY_TYPES: CaseTaskType[] = [
			CaseTaskType.HFRS_FRAUD_INVESTIGATION,
			CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE,
		];
		if (!record?.classification || !PATHWAY_TYPES.includes(task.taskType)) return false;

		const raisedUnder = this._parseTaskPayload(task.payload as any)?.classification;

		return !!raisedUnder && raisedUnder !== record.classification;
	}

	private _synthesizeApprovedApprovals(record: Case, existing: CaseTaskView[]): CaseTaskView[] {
		if (record.classification !== CaseClassification.FRAUD) return [];
		const present = (type: CaseTaskType) => existing.some(t => t.taskType === type);
		const out: CaseTaskView[] = [];
		if (!present(CaseTaskType.HFRS_FRAUD_INVESTIGATION) && assigneeEmail(record.caseLead)) {
			out.push(
				this._syntheticApproved(record.id, CaseTaskType.HFRS_FRAUD_INVESTIGATION, record),
			);
		}

		return out;
	}

	private _syntheticApproved(caseId: number, taskType: CaseTaskType, record: Case): CaseTaskView {
		const lead = parseAssignee(record.caseLead);
		return {
			id: 0,
			caseId,
			taskType,
			status: CaseTaskStatus.APPROVED,
			assignedTo: '',
			assignedToName: null,
			payload: {
				irNumber: record.irNumber,
				businessUnit: record.businessUnit,
				classification: record.classification,
				caseLead: lead?.email_id ?? null,
				caseLeadName: lead?.full_name ?? null,
			},
			rejectionReason: null,
			resolvedAt: record.updatedOn ?? null,
			resolvedBy: null,
			createdOn: record.updatedOn ?? new Date(),
			createdBy: '',
			createdByName: null,
		};
	}

	private _parseTaskPayload(raw?: string | null): Record<string, any> | null {
		if (!raw) return null;
		if (typeof raw !== 'string') return raw as Record<string, any>;
		try {
			return JSON.parse(raw);
		} catch {
			return null;
		}
	}

	public async resolveTask(
		taskId: number,
		dto: ResolveCaseTaskRequestDto,
		currentContext: CurrentContext,
	): Promise<MessageResponseDto> {
		const task = await this.approvalTaskService.getById(taskId);
		if (!task) throw new HttpException('Task not found.', HttpStatus.BAD_REQUEST);
		if (task.status !== CaseTaskStatus.PENDING) {
			throw new HttpException('Task has already been resolved.', HttpStatus.BAD_REQUEST);
		}

		const resolved = await this.approvalTaskService.resolve(
			taskId,
			{ approved: dto.approved, rejectionReason: dto.rejectionReason },
			currentContext,
		);
		if (!resolved) {
			throw new HttpException('Task could not be resolved.', HttpStatus.BAD_REQUEST);
		}
		await this.caseRepository.touchCase(task.caseId, currentContext);
		this.auditLogService.log(
			{
				caseId: task.caseId,
				action: dto.approved ? CMS_AUDIT_ACTION.TASK_APPROVED : CMS_AUDIT_ACTION.TASK_REJECTED,
				comments: dto.approved
					? `Task approved: "${task.taskType}"`
					: `Task rejected: "${task.taskType}"${
							dto.rejectionReason ? ' — ' + dto.rejectionReason : ''
					  }`,
			},
			currentContext,
		);

		if (dto.approved && task.taskType === CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE) {
			await this.caseRepository.updateCase(
				task.caseId,
				{ status: CASE_RECORD_STATUS_CLOSED, rejectionReason: null } as any,
				currentContext,
			);
			return { message: 'Task approved. Case has been closed — no investigation required.' };
		}

		if (dto.approved && task.taskType === CaseTaskType.HFRS_FRAUD_INVESTIGATION) {
			let payload: Record<string, any> = {};
			try {
				payload = task.payload
					? JSON.parse(
							typeof task.payload === 'string' ? task.payload : JSON.stringify(task.payload),
					  )
					: {};
			} catch {}

			const update: Record<string, any> = {};
			const nominee: string | undefined = payload.caseLead ?? payload.frsInvestigator;
			const nomineeName: string | undefined = payload.caseLeadName ?? payload.frsInvestigatorName;

			if (nominee) update.caseLead = buildAssignee(nominee, nomineeName);

			if (payload.fmfClassification) update.fmfClassification = payload.fmfClassification;

			if (Object.keys(update).length > 0) {
				await this.caseRepository.updateCase(task.caseId, update as any, currentContext);
			}

			if (nominee) {
				await this.caseNotificationService.notifyWorkAssigned({
					caseId: task.caseId,
					userId: nominee,
					userName: nomineeName ?? null,
					userEmail: nominee,
					role: 'Case Lead',
				});
			}

			return { message: 'Task approved. Investigation and Case Lead nomination confirmed.' };
		}

		// if (dto.approved && task.taskType === CaseTaskType.HFRS_CASE_LEAD_NOMINATION) {
		// 	let payload: Record<string, any> = {};
		// 	try {
		// 		payload = task.payload
		// 			? JSON.parse(
		// 					typeof task.payload === 'string' ? task.payload : JSON.stringify(task.payload),
		// 			  )
		// 			: {};
		// 	} catch {}

		// 	if (payload.caseLead) {
		// 		await this.caseRepository.updateCase(
		// 			task.caseId,
		// 			{ caseLead: buildAssignee(payload.caseLead, payload.caseLeadName) } as any,
		// 			currentContext,
		// 		);
		// 		await this.caseNotificationService.notifyWorkAssigned({
		// 			caseId: task.caseId,
		// 			userId: payload.caseLead,
		// 			userName: payload.caseLeadName ?? null,
		// 			userEmail: payload.caseLead,
		// 			role: 'Case Lead',
		// 		});
		// 	}
		// 	return { message: 'Task approved. Case lead has been assigned.' };
		// }

		if (task.taskType === CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION) {
			if (!dto.approved) {
				await this.caseRepository.updateCase(
					task.caseId,
					{ rejectionReason: dto.rejectionReason ?? null } as any,
					currentContext,
				);
				return {
					message: 'Results confirmation rejected. Sent back to the case team to revise.',
				};
			}
			const resolvedBy = currentContext.user?.username?.toLowerCase() ?? null;
			await this.allegationRepository.confirmAllOutcomesForCase(
				task.caseId,
				resolvedBy,
				currentContext,
			);
			const record = await this.caseRepository.getCaseById(task.caseId);
			if (record?.currentStage === CaseStatus.REPORT_RESULTS) {
				await this.caseRepository.updateCase(
					task.caseId,
					{ currentStage: CaseStatus.REMEDIATION_ACTIONS, rejectionReason: null } as any,
					currentContext,
				);
			}
			return { message: 'Results confirmed. The case has advanced to Remediation.' };
		}

		if (task.taskType === CaseTaskType.AM_PROCEDURE_REVIEW) {
			let payload: Record<string, any> = {};
			try {
				payload = task.payload
					? JSON.parse(
							typeof task.payload === 'string' ? task.payload : JSON.stringify(task.payload),
					  )
					: {};
			} catch {}
			const procedureId = Number(payload.procedureId);
			if (!dto.approved && procedureId) {
				await this._reopenProcedureForRevision(procedureId, currentContext);
				return { message: 'Sent back to the assignee for revision.' };
			}
			return { message: 'Procedure completion reviewed and marked as reviewed.' };
		}

		return { message: dto.approved ? 'Task approved successfully.' : 'Task rejected.' };
	}

	/**
	 * The HFRS users who may approve on this case.
	 *
	 * Entity resolution is case → caller → `UNSCOPED_ENTITY_ID`. A Navex-imported case has no
	 * `business_entity_id` (the sync never sets one) and the caller has none until a Business
	 * Unit is picked, so without the last step this returned [] and the UI disabled
	 * "Request HFRS approval" as unconfigured — while the task that button creates would
	 * have been made quite happily against the caller's entity.
	 *
	 * The `[APPROVERS]` log below records which entity was actually used and how many users
	 * came back, which is the quickest way to see whether an unscoped lookup resolves anyone.
	 */
	public async getCaseApprovers(
		caseId: number,
		currentContext?: CurrentContext,
	): Promise<CaseApproverResponseDto[]> {
		const caseRecord = await this.caseRepository.getCaseById(caseId);
		if (!caseRecord) throw new HttpException('Case not found.', HttpStatus.BAD_REQUEST);
		const entityId =
			Number(caseRecord.businessEntityId) ||
			Number(currentContext?.entityId) ||
			UNSCOPED_ENTITY_ID;
		const { loginIds, users } = await this.roleService.getUsersDetailsByRoleForEntityHierarchy(
			CmsUserRole.HFRS,
			entityId,
		);
		this.logger.log(
			`[APPROVERS] case ${caseId} entity ${entityId} hfrsLogins=${JSON.stringify(
				loginIds,
			)} resolved=${users.length}`,
		);
		return (users ?? []).map(u => ({
			userUpn: (u.userPrincipalName ?? u.mail ?? '').toLowerCase(),
			userName: u.displayName ?? [u.givenName, u.surname].filter(Boolean).join(' '),
			userEmail: u.mail ?? u.userPrincipalName ?? '',
			userJobTitle: u.jobTitle ?? '',
		}));
	}

}
