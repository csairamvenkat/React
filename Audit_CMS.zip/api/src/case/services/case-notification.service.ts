import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from 'src/config/config.service';
import { MSGraphApiClient } from 'src/shared/clients';
import { APP_URL, NOTIFICATION_ENTITY_TYPE, NOTIFICATION_TEMPLATES } from 'src/shared/enums';
import { SharedNotificationService } from 'src/shared/services/shared-notification.service';
import {
	CaseAllegationRepository,
	CaseProcedureRepository,
	CaseRepository,
} from '../repositories';
import { CaseTaskType, PermissionSourceType } from '../enums';
import type { CaseTaskView } from './case-approval-task.service';

const CMS_ENTITY = NOTIFICATION_ENTITY_TYPE.CMS_CASE;

const SENDING_ENABLED = false;

const TASK_LABELS: Record<CaseTaskType, string> = {
	[CaseTaskType.HFRS_FRAUD_INVESTIGATION]: 'Investigation & FRS assignment approval',
	[CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE]: 'No-investigation closure approval',
	[CaseTaskType.HFRS_NON_FRAUD_REPORTING_SIGNOFF]: 'Non-fraud reporting sign-off',
	[CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION]: 'Report Results confirmation',
	[CaseTaskType.DELEGATION_REQUEST]: 'Delegation request',
	[CaseTaskType.AM_PROCEDURE_REVIEW]: 'Procedure completion review',
};

export interface WorkAssignmentNotification {
	caseId: number;
	userId: string;
	userName?: string | null;
	userEmail?: string | null;
	role: string;
	sourceType?: string | null;
	sourceId?: number | null;
}

export interface DelegationTransferNotification {
	caseId: number;
	toUserId: string;
	toUserName?: string | null;
	fromUserName?: string | null;
	taskTitle?: string | null;
}
@Injectable()
export class CaseNotificationService {
	private readonly logger = new Logger(CaseNotificationService.name);

	constructor(
		private readonly sharedNotificationService: SharedNotificationService,
		private readonly mSGraphApiClient: MSGraphApiClient,
		private readonly caseRepository: CaseRepository,
		private readonly allegationRepository: CaseAllegationRepository,
		private readonly procedureRepository: CaseProcedureRepository,
		private readonly config: ConfigService,
	) {}

	public async notifyTaskAssigned(task: CaseTaskView): Promise<void> {
		const label = TASK_LABELS[task.taskType] ?? 'Approval task';
		this.logger.log(
			`[CMS-NOTIFY] task-assigned triggered | type=${task.taskType} taskId=${task.id} caseId=${task.caseId} → assignedTo="${task.assignedTo}"`,
		);
		if (!SENDING_ENABLED) return;

		const to = await this.resolveEmail(task.assignedTo);
		if (!to) {
			this.logger.warn(
				`[CMS-NOTIFY] task-assigned SKIPPED — no recipient mailbox (taskId=${task.id}, type=${task.taskType})`,
			);
			return;
		}
		const caseRecord = await this.getCaseSafe(task.caseId);
		const caseRef = this.caseRef(caseRecord, task.caseId);

		// await this.send(
		// 	NOTIFICATION_TEMPLATES.CMS_TASK_ASSIGNED,
		// 	to,
		// 	task.caseId,
		// 	{
		// 		RecipientName: task.assignedToName ?? to,
		// 		TaskType: label,
		// 		CaseRef: caseRef,
		// 		BusinessUnit: caseRecord?.businessUnit ?? '',
		// 		ViewUrl: this.link(APP_URL.CMS_TASK_REVIEW, task.id),
		// 	},
		// 	{ isApprovalEmail: true, approvalTaskId: task.id },
		// );
	}

	public async notifyWorkAssigned(data: WorkAssignmentNotification): Promise<void> {
		this.logger.log(
			`[CMS-NOTIFY] work-assigned triggered | role="${data.role}" caseId=${data.caseId} source=${
				data.sourceType ?? 'case'
			}:${data.sourceId ?? '-'} → user="${data.userEmail ?? data.userId}"`,
		);
		if (!SENDING_ENABLED) return;

		const to = await this.resolveEmail(data.userEmail ?? data.userId);
		if (!to) {
			this.logger.warn(
				`[CMS-NOTIFY] work-assigned SKIPPED — no recipient mailbox (role="${data.role}", caseId=${data.caseId})`,
			);
			return;
		}
		const caseRecord = await this.getCaseSafe(data.caseId);
		const caseRef = this.caseRef(caseRecord, data.caseId);
		const scope = await this.describeScope(data.sourceType ?? null, data.sourceId ?? null);

		// await this.send(NOTIFICATION_TEMPLATES.CMS_WORK_ASSIGNED, to, data.caseId, {
		// 	RecipientName: data.userName ?? to,
		// 	Role: data.role,
		// 	CaseRef: caseRef,
		// 	Scope: scope,
		// 	ViewUrl: this.link(APP_URL.CMS_CASE_DETAIL, data.caseId),
		// });
	}

	public async notifyDelegationTransferred(data: DelegationTransferNotification): Promise<void> {
		this.logger.log(
			`[CMS-NOTIFY] delegation-transfer triggered | caseId=${data.caseId} task="${
				data.taskTitle ?? ''
			}" → user="${data.toUserId}"`,
		);
		if (!SENDING_ENABLED) return;

		const to = await this.resolveEmail(data.toUserId);
		if (!to) {
			this.logger.warn(
				`[CMS-NOTIFY] delegation-transfer SKIPPED — no recipient mailbox (caseId=${data.caseId})`,
			);
			return;
		}
		const caseRecord = await this.getCaseSafe(data.caseId);
		const caseRef = this.caseRef(caseRecord, data.caseId);

		// await this.send(NOTIFICATION_TEMPLATES.CMS_DELEGATION, to, data.caseId, {
		// 	RecipientName: data.toUserName ?? to,
		// 	TaskTitle: data.taskTitle ?? 'A task',
		// 	CaseRef: caseRef,
		// 	FromUser: data.fromUserName ?? '',
		// 	ViewUrl: this.link(APP_URL.CMS_CASE_DETAIL, data.caseId),
		// });
	}

	// ---------------------------------------------------------------- helpers

	// private async send(
	// 	template: NOTIFICATION_TEMPLATES,
	// 	to: string,
	// 	caseId: number,
	// 	placeholders: Record<string, string>,
	// 	opts: { isApprovalEmail?: boolean; approvalTaskId?: number } = {},
	// ): Promise<void> {
	// 	const started = Date.now();
	// 	this.logger.log(
	// 		`[CMS-NOTIFY] → sendNotification | template=${template} to="${to}" caseId=${caseId} approvalEmail=${!!opts.isApprovalEmail} taskId=${
	// 			opts.approvalTaskId ?? '-'
	// 		}`,
	// 	);
	// 	try {
	// 		await this.sharedNotificationService.sendNotification(
	// 			caseId,
	// 			CMS_ENTITY,
	// 			{ to: [to] },
	// 			template,
	// 			placeholders,
	// 			!!opts.isApprovalEmail,
	// 			opts.approvalTaskId,
	// 		);
	// 		this.logger.log(
	// 			`[CMS-NOTIFY] ✓ queued to "${to}" in ${Date.now() - started}ms | template=${template}`,
	// 		);
	// 	} catch (err: any) {
	// 		this.logger.error(
	// 			`[CMS-NOTIFY] ✗ FAILED to "${to}" after ${Date.now() - started}ms | template=${template} | status=${
	// 				err?.response?.status ?? '-'
	// 			} | error=${err?.message ?? err} | data=${JSON.stringify(err?.response?.data ?? {})}`,
	// 			err?.stack,
	// 		);
	// 	}
	// }

	private async resolveEmail(userId?: string | null): Promise<string> {
		const raw = (userId ?? '').trim();
		if (!raw) return '';
		try {
			const details = await this.mSGraphApiClient.getUsersDetails([raw]);
			const mail = details?.[0]?.mail || (details?.[0] as any)?.userPrincipalName;
			if (mail) return mail;
			this.logger.warn(`[CMS-NOTIFY] MS Graph returned no mailbox for "${raw}"; falling back to id`);
		} catch (err: any) {
			this.logger.warn(
				`[CMS-NOTIFY] MS Graph lookup failed for "${raw}" (${err?.message ?? err}); falling back to id`,
			);
		}
		return raw;
	}

	private async getCaseSafe(caseId: number) {
		try {
			return await this.caseRepository.getCaseById(caseId);
		} catch (err) {
			this.logger.error(`[CMS-NOTIFY] could not load case ${caseId}`, err as any);
			return null;
		}
	}

	private caseRef(caseRecord: { irNumber?: string } | null, caseId: number): string {
		return caseRecord?.irNumber || `case #${caseId}`;
	}

	private link(url: APP_URL, id: number | string): string {
		const base = (this.config.getAppConfig()?.uiClient?.baseUrl ?? '').replace(/\/$/, '');
		const path = String(url).replace('{#id#}', String(id)).replace(/^\//, '');
		return base ? `${base}/${path}` : path;
	}

	private async describeScope(sourceType: string | null, sourceId: number | null): Promise<string> {
		if (!sourceType || !sourceId) return 'Full case';
		try {
			if (sourceType === PermissionSourceType.ALLEGATION) {
				const a = await this.allegationRepository.getById(sourceId);
				return a ? `Allegation — ${a.label}` : 'An allegation';
			}
			if (sourceType === PermissionSourceType.PROCEDURE) {
				const p = await this.procedureRepository.getById(sourceId);
				const desc = p?.description ?? '';
				return p ? `Procedure — ${desc.length > 80 ? desc.slice(0, 80) + '…' : desc}` : 'A procedure';
			}
		} catch (err) {
			this.logger.error(
				`[CMS-NOTIFY] could not resolve scope ${sourceType}:${sourceId}`,
				err as any,
			);
		}
		return '';
	}
}
