import { Injectable } from '@nestjs/common';
import { ConfigService } from 'src/config/config.service';
import { TaskApiClient } from 'src/shared/clients';
import { CMS_TASK_TERMINAL_STATUSES, UNSCOPED_ENTITY_ID } from 'src/shared/constants';
import { CMS_TASK_ENTITY_TYPE } from 'src/shared/enums';
import { CmsAssignmentTaskInfo, CreateTask, CurrentContext, TaskData } from 'src/shared/types';
import { mapWithConcurrency } from '../helpers/concurrency.helper';
import { CaseRepository } from '../repositories';
import { AssignmentTaskStatus, AssignmentType } from '../enums';

const TASK_LOOKUP_CONCURRENCY = 8;

export interface AssignmentTaskView {
	id: number;
	caseId: number;
	assignmentType: AssignmentType;
	sourceId: number;
	assigneeUserId: string;
	assigneeName: string | null;
	assigneeEmail: string | null;
	status: AssignmentTaskStatus;
	redelegatedFromUserId: string | null;
	createdBy: string;
	createdByName: string | null;
	createdOn: Date;
}

export interface AssignmentTaskUpsertInput {
	caseId: number;
	assignmentType: AssignmentType;
	sourceId: number;
	assigneeUserId: string;
	assigneeName?: string | null;
	assigneeEmail?: string | null;
	status?: AssignmentTaskStatus;
	redelegatedFromUserId?: string | null;
	title?: string;
}

@Injectable()
export class CaseAssignmentTaskService {
	constructor(
		private readonly taskApi: TaskApiClient,
		private readonly caseRepository: CaseRepository,
		private readonly config: ConfigService,
	) {}

	public async getById(id: number): Promise<AssignmentTaskView | null> {
		const task = await this.taskApi.getTaskById(id);
		return task ? this.toView(task) : null;
	}

	public async getByAssignee(assigneeUserId: string): Promise<AssignmentTaskView[]> {
		const tasks = await this.taskApi.getAllPendingUserTasks(assigneeUserId.toLowerCase());
		return (tasks ?? [])
			.filter(t => this.isAssignmentTask(t))
			.map(t => this.toView(t))
			.sort((a, b) => b.createdOn.getTime() - a.createdOn.getTime());
	}

	private isAssignmentTask(task: TaskData): boolean {
		const assignmentTypes: string[] = [
			CMS_TASK_ENTITY_TYPE.ALLEGATION_MANAGER,
			CMS_TASK_ENTITY_TYPE.PROCEDURE_ASSIGNEE,
			CMS_TASK_ENTITY_TYPE.SUB_ASSIGNEE,
			CMS_TASK_ENTITY_TYPE.RECOMMENDATION_OWNER,
		];
		return assignmentTypes.includes(task.entity_type as string);
	}

	public async getForAssigneeAndSource(
		caseId: number,
		assignmentType: AssignmentType,
		sourceId: number,
		assigneeUserId: string,
	): Promise<AssignmentTaskView | null> {
		const active = await this.fetchActiveBySource(assignmentType, sourceId, caseId);
		const user = assigneeUserId.toLowerCase();
		const match = active.find(t => this.normalizeAssignedTo(t.assigned_to) === user);
		return match ? this.toView(match) : null;
	}

	public async upsertTask(
		data: AssignmentTaskUpsertInput,
		currentContext: CurrentContext,
	): Promise<AssignmentTaskView> {
		const user = (data.assigneeUserId ?? '').toLowerCase();
		const active = await this.fetchActiveBySource(data.assignmentType, data.sourceId, data.caseId);
		const existing = active.find(t => this.normalizeAssignedTo(t.assigned_to) === user);
		if (existing) {
			return this.toView(existing);
		}

		const status = data.status ?? AssignmentTaskStatus.PENDING;
		const businessEntityId = await this.resolveBusinessEntityId(data.caseId, currentContext);
		const appConfig = this.config.getAppConfig();
		const createdBy = currentContext?.user?.username ?? null;
		const createdByName = currentContext?.user?.name ?? null;
		const createdOn = new Date();
		const info: CmsAssignmentTaskInfo = {
			caseId: data.caseId,
			assignmentType: data.assignmentType,
			sourceId: data.sourceId,
			assigneeName: data.assigneeName ?? null,
			assigneeEmail: data.assigneeEmail ?? null,
			cmsStatus: status,
			redelegatedFromUserId: data.redelegatedFromUserId ?? null,
			createdBy,
			createdByName,
			createdOn: createdOn.toISOString(),
		};
		const payload: CreateTask = {
			assigned_to: user,
			entity_type: this.entityTypeFor(data.assignmentType),
			entity_id: String(data.sourceId),
			is_group_assignemnt: false,
			business_entity_id: businessEntityId,
			title: data.title ?? this.defaultTitle(data.assignmentType),
			base_url: appConfig?.uiClient?.baseUrl,
			rel_url: appConfig?.uiClient?.task?.relativeUrl,
			additional_info: info,
			created_by: currentContext?.user?.username,
		};
		const res = await this.taskApi.createTaskWithoutUseDelegation(payload);

		return {
			id: Number((res as { task_id?: number })?.task_id ?? 0),
			caseId: data.caseId,
			assignmentType: data.assignmentType,
			sourceId: data.sourceId,
			assigneeUserId: user,
			assigneeName: data.assigneeName ?? null,
			assigneeEmail: data.assigneeEmail ?? null,
			status,
			redelegatedFromUserId: data.redelegatedFromUserId ?? null,
			createdBy: createdBy ?? '',
			createdByName,
			createdOn,
		};
	}

	public async updateTask(
		id: number,
		data: { status?: AssignmentTaskStatus },
		currentContext: CurrentContext,
	): Promise<void> {
		if (data.status === AssignmentTaskStatus.COMPLETED) {
			await this.taskApi.completeTask({
				id,
				outcome: AssignmentTaskStatus.COMPLETED,
				created_by: currentContext?.user?.username,
			});
		} else if (data.status === AssignmentTaskStatus.CLOSED) {
			await this.taskApi.cancelTask({ id, created_by: currentContext?.user?.username });
		}
	}

	public async softDeleteForAssigneeAndSource(
		caseId: number,
		assignmentType: AssignmentType,
		sourceId: number,
		assigneeUserId: string,
		currentContext: CurrentContext,
	): Promise<void> {
		const active = await this.fetchActiveBySource(assignmentType, sourceId, caseId);
		const user = assigneeUserId.toLowerCase();
		const targets = active.filter(t => this.normalizeAssignedTo(t.assigned_to) === user);
		await this.cancelAll(targets, currentContext);
	}

	public async softDeleteForSourceExcept(
		caseId: number,
		assignmentType: AssignmentType,
		sourceId: number,
		keepAssigneeUserId: string,
		currentContext: CurrentContext,
	): Promise<void> {
		const active = await this.fetchActiveBySource(assignmentType, sourceId, caseId);
		const keep = keepAssigneeUserId.toLowerCase();
		const targets = active.filter(t => this.normalizeAssignedTo(t.assigned_to) !== keep);
		await this.cancelAll(targets, currentContext);
	}

	public async cancelAllForCase(
		caseId: number,
		allegationIds: number[],
		procedureIds: number[],
		currentContext: CurrentContext,
		recommendationItemIds: number[] = [],
	): Promise<void> {
		const lookups: Array<{ type: AssignmentType; sourceId: number }> = [
			...allegationIds.map(sourceId => ({ type: AssignmentType.ALLEGATION_MANAGER, sourceId })),
			...allegationIds.map(sourceId => ({ type: AssignmentType.SUB_ASSIGNEE, sourceId })),
			...procedureIds.map(sourceId => ({ type: AssignmentType.PROCEDURE_ASSIGNEE, sourceId })),
			...recommendationItemIds.map(sourceId => ({
				type: AssignmentType.RECOMMENDATION_OWNER,
				sourceId,
			})),
		];

		const perSource = await mapWithConcurrency(lookups, TASK_LOOKUP_CONCURRENCY, ({ type, sourceId }) =>
			this.fetchActiveBySource(type, sourceId, caseId),
		);
		await this.cancelAll(perSource.flat(), currentContext);
	}

	private async fetchActiveBySource(
		assignmentType: AssignmentType,
		sourceId: number,
		caseId?: number,
	): Promise<TaskData[]> {
		const tasks = await this.taskApi.getAllTasks(sourceId, this.entityTypeFor(assignmentType));
		return (tasks ?? []).filter(t => {
			if (!this.isActive(t)) return false;
			if (caseId != null) {
				const info = this.parseInfo(t.additional_info);
				if (info.caseId != null && Number(info.caseId) !== Number(caseId)) return false;
			}
			return true;
		});
	}

	private async cancelAll(tasks: TaskData[], currentContext: CurrentContext): Promise<void> {
		for (const t of tasks) {
			await this.taskApi.cancelTask({ id: Number(t.id), created_by: currentContext?.user?.username });
		}
	}

	private async resolveBusinessEntityId(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<number> {
		const record = await this.caseRepository.getCaseById(caseId);
		// Both absent on a Navex-imported case opened without a Business Unit selected;
		// without the last step this sent NaN, which serialises to null in the task payload.
		return Number(record?.businessEntityId) || Number(currentContext?.entityId) || UNSCOPED_ENTITY_ID;
	}

	private entityTypeFor(type: AssignmentType): CMS_TASK_ENTITY_TYPE {
		switch (type) {
			case AssignmentType.ALLEGATION_MANAGER:
				return CMS_TASK_ENTITY_TYPE.ALLEGATION_MANAGER;
			case AssignmentType.PROCEDURE_ASSIGNEE:
				return CMS_TASK_ENTITY_TYPE.PROCEDURE_ASSIGNEE;
			case AssignmentType.SUB_ASSIGNEE:
				return CMS_TASK_ENTITY_TYPE.SUB_ASSIGNEE;
			case AssignmentType.RECOMMENDATION_OWNER:
				return CMS_TASK_ENTITY_TYPE.RECOMMENDATION_OWNER;
		}
	}

	private assignmentTypeFor(entityType: string): AssignmentType | null {
		switch (entityType) {
			case CMS_TASK_ENTITY_TYPE.ALLEGATION_MANAGER:
				return AssignmentType.ALLEGATION_MANAGER;
			case CMS_TASK_ENTITY_TYPE.PROCEDURE_ASSIGNEE:
				return AssignmentType.PROCEDURE_ASSIGNEE;
			case CMS_TASK_ENTITY_TYPE.SUB_ASSIGNEE:
				return AssignmentType.SUB_ASSIGNEE;
			case CMS_TASK_ENTITY_TYPE.RECOMMENDATION_OWNER:
				return AssignmentType.RECOMMENDATION_OWNER;
			default:
				return null;
		}
	}

	private defaultTitle(type: AssignmentType): string {
		switch (type) {
			case AssignmentType.PROCEDURE_ASSIGNEE:
				return 'Procedure assignment';
			case AssignmentType.ALLEGATION_MANAGER:
				return 'Allegation manager assignment';
			case AssignmentType.SUB_ASSIGNEE:
				return 'Sub-assignment';
			case AssignmentType.RECOMMENDATION_OWNER:
				return 'Recommendation assignment';
			default:
				return 'Assignment';
		}
	}

	private isActive(task: TaskData): boolean {
		const status = (task.task_status ?? '').toLowerCase();
		return !CMS_TASK_TERMINAL_STATUSES.includes(status);
	}

	private parseInfo(additionalInfo: any): CmsAssignmentTaskInfo {
		if (!additionalInfo) return {} as CmsAssignmentTaskInfo;
		if (typeof additionalInfo === 'string') {
			try {
				return JSON.parse(additionalInfo) as CmsAssignmentTaskInfo;
			} catch {
				return {} as CmsAssignmentTaskInfo;
			}
		}
		return additionalInfo as CmsAssignmentTaskInfo;
	}

	private normalizeAssignedTo(assignedTo: any): string {
		if (!assignedTo) return '';
		if (typeof assignedTo === 'string') return assignedTo.toLowerCase();
		const value =
			assignedTo.user_name ??
			assignedTo.username ??
			assignedTo.upn ??
			assignedTo.email ??
			assignedTo.id ??
			'';
		return String(value).toLowerCase();
	}

	private mapStatus(task: TaskData, info: CmsAssignmentTaskInfo): AssignmentTaskStatus {
		if (info.cmsStatus) return info.cmsStatus as AssignmentTaskStatus;
		const status = (task.task_status ?? '').toLowerCase();
		if (status.includes('complete')) return AssignmentTaskStatus.COMPLETED;
		if (status.includes('cancel') || status.includes('closed') || status.includes('reject')) {
			return AssignmentTaskStatus.CLOSED;
		}
		if (status.includes('progress')) return AssignmentTaskStatus.IN_PROGRESS;
		return AssignmentTaskStatus.PENDING;
	}

	private toView(task: TaskData): AssignmentTaskView {
		const info = this.parseInfo(task.additional_info);
		return {
			id: Number(task.id),
			caseId: Number(info.caseId ?? 0),
			assignmentType:
				(info.assignmentType as AssignmentType) ?? this.assignmentTypeFor(task.entity_type as string),
			sourceId: Number(info.sourceId ?? task.entity_id ?? 0),
			assigneeUserId: this.normalizeAssignedTo(task.assigned_to),
			assigneeName: info.assigneeName ?? null,
			assigneeEmail: info.assigneeEmail ?? null,
			status: this.mapStatus(task, info),
			redelegatedFromUserId: info.redelegatedFromUserId ?? null,
			createdBy: info.createdBy ?? task.created_by ?? '',
			createdByName: info.createdByName ?? null,
			createdOn: new Date(info.createdOn ?? task.created_on ?? Date.now()),
		};
	}
}
