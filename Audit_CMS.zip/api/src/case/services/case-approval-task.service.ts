import { Injectable } from '@nestjs/common';
import { ConfigService } from 'src/config/config.service';
import { TaskApiClient } from 'src/shared/clients';
import { CMS_TASK_TERMINAL_STATUSES, UNSCOPED_ENTITY_ID } from 'src/shared/constants';
import { CMS_TASK_ENTITY_TYPE } from 'src/shared/enums';
import { CmsApprovalTaskInfo, CreateTask, CurrentContext, TaskData } from 'src/shared/types';
import { CaseRepository } from '../repositories';
import { mapWithConcurrency } from '../helpers/concurrency.helper';
import { CaseTaskStatus, CaseTaskType } from '../enums';
import { CaseNotificationService } from './case-notification.service';

const TASK_FETCH_CONCURRENCY = 16;

export interface CaseTaskView {
	id: number;
	caseId: number;
	taskType: CaseTaskType;
	status: CaseTaskStatus;
	assignedTo: string;
	assignedToName: string | null;
	payload: Record<string, any> | null;
	rejectionReason: string | null;
	resolvedAt: Date | null;
	resolvedBy: string | null;
	createdOn: Date;
	createdBy: string;
	createdByName: string | null;
}

export interface CaseTaskCreateInput {
	caseId: number;
	taskType: CaseTaskType;
	assignedTo: string;
	assignedToName?: string | null;
	payload?: Record<string, any> | null;
	title?: string;
}

@Injectable()
export class CaseApprovalTaskService {
	constructor(
		private readonly taskApi: TaskApiClient,
		private readonly caseRepository: CaseRepository,
		private readonly config: ConfigService,
		private readonly caseNotification: CaseNotificationService,
	) {}

	public async getById(id: number): Promise<CaseTaskView | null> {
		const task = await this.taskApi.getTaskById(id);
		return task && this.isCmsApprovalTask(task) ? this.toView(task) : null;
	}

	public async getByAssignee(assignedTo: string): Promise<CaseTaskView[]> {
		const user = assignedTo.toLowerCase();
		const [pending, indexed] = await Promise.all([
			this.taskApi.getAllPendingUserTasks(user),
			this.fetchIndexedSafely(() => this.caseRepository.getAllApprovalTaskIds()),
		]);
		const mineIndexed = indexed.filter(t => this.taskBelongsToUser(t, user));
		return this.mapCmsTasks(this.dedupeById([...pending, ...mineIndexed]));
	}

	private taskBelongsToUser(task: TaskData, user: string): boolean {
		return [task.assigned_to, task.original_owner, task.completed_by].some(
			v => this.normalizeAssignedTo(v) === user,
		);
	}

	public async getPendingByAssignee(assignedTo: string): Promise<CaseTaskView[]> {
		const tasks = await this.taskApi.getAllPendingUserTasks(assignedTo.toLowerCase());
		return this.mapCmsTasks(tasks).filter(t => t.status === CaseTaskStatus.PENDING);
	}

	public async getAll(): Promise<CaseTaskView[]> {
		const indexed = await this.fetchIndexedSafely(() => this.caseRepository.getAllApprovalTaskIds());
		return this.mapCmsTasks(this.dedupeById(indexed));
	}

	public async getAllPending(): Promise<CaseTaskView[]> {
		return (await this.getAll()).filter(t => t.status === CaseTaskStatus.PENDING);
	}

	/**
	 * Every approval task an HFRS/Admin reviewer may act on.
	 *
	 * This used to also brute-force the task API case by case (`scanCasesRaw` over
	 * `getAllCaseIds`), which was affordable when the table held a few dozen cases. The
	 * Navex sync then imported ~4,800, turning one request into cases x 7 entity types
	 * upstream calls — measured at ~34,000 calls and ~10 minutes, so the endpoint never
	 * answered. `cases.approval_task_ids` already indexes every task `create()` makes, so
	 * the scan only ever rediscovered what the index holds.
	 */
	public async getAllForUser(username: string): Promise<CaseTaskView[]> {
		const [live, indexed] = await Promise.all([
			this.taskApi.getAllPendingUserTasks(username.toLowerCase()),
			this.fetchIndexedSafely(() => this.caseRepository.getAllApprovalTaskIds()),
		]);
		return this.mapCmsTasks(this.dedupeById([...(live ?? []), ...indexed]));
	}

	public async getAllPendingForUser(username: string): Promise<CaseTaskView[]> {
		return (await this.getAllForUser(username)).filter(t => t.status === CaseTaskStatus.PENDING);
	}

	public async getByCase(caseId: number): Promise<CaseTaskView[]> {
		const [active, indexed] = await Promise.all([
			this.getByCaseRaw(caseId),
			this.fetchIndexedSafely(() => this.caseRepository.getApprovalTaskIds(caseId)),
		]);
		return this.mapCmsTasks(this.dedupeById([...active, ...indexed]));
	}

	public async getByTaskIds(ids: number[]): Promise<CaseTaskView[]> {
		if (ids.length === 0) return [];

		try {
			return this.mapCmsTasks(await this.fetchByIds([...new Set(ids)]));
		} catch (err) {
			console.error('Approval-task lookup by id failed; returning no tasks', err);
			return [];
		}
	}

	public async create(data: CaseTaskCreateInput, currentContext: CurrentContext): Promise<CaseTaskView> {
		const assignedTo = (data.assignedTo ?? '').toLowerCase();
		const businessEntityId = await this.resolveBusinessEntityId(data.caseId, currentContext);
		const appConfig = this.config.getAppConfig();
		const createdBy = currentContext?.user?.username ?? null;
		const createdByName = currentContext?.user?.name ?? null;
		const createdOn = new Date();
		const info: CmsApprovalTaskInfo = {
			caseId: data.caseId,
			taskType: data.taskType,
			assignedToName: data.assignedToName ?? null,
			payload: data.payload ?? null,
			cmsStatus: CaseTaskStatus.PENDING,
			rejectionReason: null,
			resolvedBy: null,
			resolvedAt: null,
			createdBy,
			createdByName,
			createdOn: createdOn.toISOString(),
		};
		const payload: CreateTask = {
			assigned_to: assignedTo,
			entity_type: this.entityTypeFor(data.taskType),
			entity_id: String(data.caseId),
			is_group_assignemnt: false,
			business_entity_id: businessEntityId,
			title: data.title ?? this.defaultTitle(data.taskType),
			base_url: appConfig?.uiClient?.baseUrl,
			rel_url: appConfig?.uiClient?.task?.relativeUrl,
			additional_info: info,
			created_by: currentContext?.user?.username,
		};
		const res = await this.taskApi.createTaskWithoutUseDelegation(payload);
		const taskId = this.extractTaskId(res);
		if (taskId) {
			try {
				await this.caseRepository.addApprovalTaskId(data.caseId, taskId, currentContext);
			} catch (err) {
				console.error(`Failed to record approval task id ${taskId} on case ${data.caseId}`, err);
			}
		}
		const view: CaseTaskView = {
			id: taskId,
			caseId: data.caseId,
			taskType: data.taskType,
			status: CaseTaskStatus.PENDING,
			assignedTo,
			assignedToName: data.assignedToName ?? null,
			payload: data.payload ?? null,
			rejectionReason: null,
			resolvedAt: null,
			resolvedBy: null,
			createdOn,
			createdBy: createdBy ?? '',
			createdByName,
		};
		await this.caseNotification.notifyTaskAssigned(view);
		return view;
	}

	public async resolve(
		id: number,
		data: { approved: boolean; rejectionReason?: string | null },
		currentContext: CurrentContext,
	): Promise<CaseTaskView | null> {
		const task = await this.taskApi.getTaskById(id);
		if (!task || !this.isCmsApprovalTask(task)) return null;
		const info = this.parseInfo(task.additional_info);
		const resolvedBy = currentContext?.user?.username ?? null;
		const resolvedAt = new Date();
		const updatedInfo: CmsApprovalTaskInfo = {
			...info,
			cmsStatus: data.approved ? CaseTaskStatus.APPROVED : CaseTaskStatus.REJECTED,
			rejectionReason: data.approved ? null : data.rejectionReason ?? null,
			resolvedBy,
			resolvedAt: resolvedAt.toISOString(),
		};
		if (data.approved) {
			await this.taskApi.completeTask({
				id,
				outcome: CaseTaskStatus.APPROVED,
				created_by: resolvedBy ?? undefined,
				additional_info: updatedInfo,
			});
		} else {
			await this.taskApi.cancelTask({
				id,
				created_by: resolvedBy ?? undefined,
				comments: data.rejectionReason ?? undefined,
				additional_info: updatedInfo,
			});
		}
		return {
			...this.toView(task),
			status: updatedInfo.cmsStatus as CaseTaskStatus,
			rejectionReason: updatedInfo.rejectionReason ?? null,
			resolvedBy,
			resolvedAt,
		};
	}

	public async cancelByCase(caseId: number, currentContext: CurrentContext): Promise<void> {
		const active = (await this.getByCaseRaw(caseId)).filter(t => this.isActive(t));
		await this.cancelAll(active, currentContext);
	}

	public async cancelByCaseAndTypes(
		caseId: number,
		taskTypes: CaseTaskType[],
		currentContext: CurrentContext,
	): Promise<void> {
		const wanted = new Set(taskTypes.map(t => this.entityTypeFor(t) as string));
		const perType = await Promise.all(
			[...wanted].map(type => this.taskApi.getAllTasks(caseId, type)),
		);
		const active = perType.flat().filter(t => this.isActive(t));
		await this.cancelAll(active, currentContext);
	}

	private extractTaskId(res: any): number {
		if (res == null) return 0;
		if (typeof res === 'object') return Number(res.task_id ?? res.id ?? 0) || 0;
		return Number(res) || 0;
	}

	private async fetchByIds(ids: number[]): Promise<TaskData[]> {
		const unique = [...new Set(ids)];
		const tasks = await mapWithConcurrency(unique, TASK_FETCH_CONCURRENCY, id =>
			this.taskApi.getTaskById(id),
		);
		return tasks.filter((t): t is TaskData => !!t);
	}

	private async fetchIndexedSafely(getIds: () => Promise<number[]>): Promise<TaskData[]> {
		return this.fetchByIds(await this.fetchIndexedSafelyIds(getIds));
	}

	private async fetchIndexedSafelyIds(getIds: () => Promise<number[]>): Promise<number[]> {
		try {
			return await getIds();
		} catch (err) {
			console.error('Approval-task id-index read failed; returning live feeds only (history unavailable)', err);
			return [];
		}
	}

	private dedupeById(tasks: TaskData[]): TaskData[] {
		const byId = new Map<number, TaskData>();
		for (const t of tasks) byId.set(Number(t.id), t);
		return [...byId.values()];
	}

	private async getByCaseRaw(caseId: number): Promise<TaskData[]> {
		const perType = await Promise.all(
			this.cmsEntityTypes().map(type => this.taskApi.getAllTasks(caseId, type)),
		);
		return perType.flat();
	}

	private async cancelAll(tasks: TaskData[], currentContext: CurrentContext): Promise<void> {
		for (const t of tasks) {
			await this.taskApi.cancelTask({ id: Number(t.id), created_by: currentContext?.user?.username });
		}
	}

	private mapCmsTasks(tasks: TaskData[]): CaseTaskView[] {
		return (tasks ?? [])
			.filter(t => this.isCmsApprovalTask(t))
			.map(t => this.toView(t))
			.sort((a, b) => b.createdOn.getTime() - a.createdOn.getTime());
	}

	private isCmsApprovalTask(task: TaskData): boolean {
		return (this.cmsEntityTypes() as string[]).includes(task.entity_type as string);
	}

	private cmsEntityTypes(): CMS_TASK_ENTITY_TYPE[] {
		return [
			CMS_TASK_ENTITY_TYPE.HFRS_FRAUD_INVESTIGATION,
			CMS_TASK_ENTITY_TYPE.HFRS_CASE_LEAD_NOMINATION,
			CMS_TASK_ENTITY_TYPE.HFRS_NO_INVESTIGATION_CLOSURE,
			CMS_TASK_ENTITY_TYPE.HFRS_NON_FRAUD_REPORTING_SIGNOFF,
			CMS_TASK_ENTITY_TYPE.CASE_LEAD_RESULTS_CONFIRMATION,
			CMS_TASK_ENTITY_TYPE.DELEGATION_REQUEST,
			CMS_TASK_ENTITY_TYPE.AM_PROCEDURE_REVIEW,
		];
	}

	private async resolveBusinessEntityId(
		caseId: number,
		currentContext: CurrentContext,
	): Promise<number> {
		const record = await this.caseRepository.getCaseById(caseId);
		// Both absent on a Navex-imported case opened without a Business Unit selected;
		// without the last step this sent NaN, which serialises to null in the task payload.
		return Number(record?.businessEntityId) || Number(currentContext?.entityId) || UNSCOPED_ENTITY_ID;
	}

	private entityTypeFor(type: CaseTaskType): CMS_TASK_ENTITY_TYPE {
		switch (type) {
			case CaseTaskType.HFRS_FRAUD_INVESTIGATION:
				return CMS_TASK_ENTITY_TYPE.HFRS_FRAUD_INVESTIGATION;
			//case CaseTaskType.HFRS_CASE_LEAD_NOMINATION:
				//return CMS_TASK_ENTITY_TYPE.HFRS_CASE_LEAD_NOMINATION;
			case CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE:
				return CMS_TASK_ENTITY_TYPE.HFRS_NO_INVESTIGATION_CLOSURE;
			case CaseTaskType.HFRS_NON_FRAUD_REPORTING_SIGNOFF:
				return CMS_TASK_ENTITY_TYPE.HFRS_NON_FRAUD_REPORTING_SIGNOFF;
			case CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION:
				return CMS_TASK_ENTITY_TYPE.CASE_LEAD_RESULTS_CONFIRMATION;
			case CaseTaskType.DELEGATION_REQUEST:
				return CMS_TASK_ENTITY_TYPE.DELEGATION_REQUEST;
			case CaseTaskType.AM_PROCEDURE_REVIEW:
				return CMS_TASK_ENTITY_TYPE.AM_PROCEDURE_REVIEW;
		}
	}

	private taskTypeFor(entityType: string): CaseTaskType | null {
		switch (entityType) {
			case CMS_TASK_ENTITY_TYPE.HFRS_FRAUD_INVESTIGATION:
				return CaseTaskType.HFRS_FRAUD_INVESTIGATION;
			//case CMS_TASK_ENTITY_TYPE.HFRS_CASE_LEAD_NOMINATION:
				//return CaseTaskType.HFRS_CASE_LEAD_NOMINATION;
			case CMS_TASK_ENTITY_TYPE.HFRS_NO_INVESTIGATION_CLOSURE:
				return CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE;
			case CMS_TASK_ENTITY_TYPE.HFRS_NON_FRAUD_REPORTING_SIGNOFF:
				return CaseTaskType.HFRS_NON_FRAUD_REPORTING_SIGNOFF;
			case CMS_TASK_ENTITY_TYPE.CASE_LEAD_RESULTS_CONFIRMATION:
				return CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION;
			case CMS_TASK_ENTITY_TYPE.DELEGATION_REQUEST:
				return CaseTaskType.DELEGATION_REQUEST;
			case CMS_TASK_ENTITY_TYPE.AM_PROCEDURE_REVIEW:
				return CaseTaskType.AM_PROCEDURE_REVIEW;
			default:
				return null;
		}
	}

	private defaultTitle(type: CaseTaskType): string {
		switch (type) {
			case CaseTaskType.HFRS_FRAUD_INVESTIGATION:
				return 'Investigation & FRS assignment approval';
			//case CaseTaskType.HFRS_CASE_LEAD_NOMINATION:
				//return 'Case lead nomination approval';
			case CaseTaskType.HFRS_NO_INVESTIGATION_CLOSURE:
				return 'No-investigation closure approval';
			case CaseTaskType.HFRS_NON_FRAUD_REPORTING_SIGNOFF:
				return 'Non-fraud reporting sign-off';
			case CaseTaskType.CASE_LEAD_RESULTS_CONFIRMATION:
				return 'Case Lead results confirmation';
			case CaseTaskType.DELEGATION_REQUEST:
				return 'Delegation request';
			case CaseTaskType.AM_PROCEDURE_REVIEW:
				return 'Procedure completion review';
			default:
				return 'Approval task';
		}
	}

	private isActive(task: TaskData): boolean {
		const status = (task.task_status ?? '').toLowerCase();
		return !CMS_TASK_TERMINAL_STATUSES.includes(status);
	}

	private parseInfo(additionalInfo: any): CmsApprovalTaskInfo {
		if (!additionalInfo) return {} as CmsApprovalTaskInfo;
		if (typeof additionalInfo === 'string') {
			try {
				return JSON.parse(additionalInfo) as CmsApprovalTaskInfo;
			} catch {
				return {} as CmsApprovalTaskInfo;
			}
		}
		return additionalInfo as CmsApprovalTaskInfo;
	}

	private normalizeAssignedTo(assignedTo: any): string {
		if (!assignedTo) return '';
		if (typeof assignedTo === 'string') return assignedTo.toLowerCase();
		const value =
			assignedTo.user_name ??
			assignedTo.username ??
			assignedTo.upn ??
			assignedTo.email ??
			assignedTo.id ??
			'';
		return String(value).toLowerCase();
	}

	private mapStatus(task: TaskData, info: CmsApprovalTaskInfo): CaseTaskStatus {
		if (this.isActive(task)) return CaseTaskStatus.PENDING;
		const status = (task.task_status ?? '').toString().toLowerCase();
		const outcome = (task.task_outcome ?? '').toString().toLowerCase();
		if (
			outcome.includes('reject') ||
			status.includes('cancel') ||
			status.includes('reject') ||
			(info.cmsStatus === CaseTaskStatus.REJECTED &&
				!outcome.includes('approve') &&
				!status.includes('complete'))
		) {
			return CaseTaskStatus.REJECTED;
		}
		return CaseTaskStatus.APPROVED;
	}

	private toView(task: TaskData): CaseTaskView {
		const info = this.parseInfo(task.additional_info);
		const status = this.mapStatus(task, info);
		const resolvedAtRaw = info.resolvedAt ?? task.task_completion_date ?? null;
		return {
			id: Number(task.id),
			caseId: Number(info.caseId ?? task.entity_id ?? 0),
			taskType: (info.taskType as CaseTaskType) ?? this.taskTypeFor(task.entity_type as string),
			status,
			assignedTo: this.normalizeAssignedTo(task.assigned_to),
			assignedToName: info.assignedToName ?? null,
			payload: info.payload ?? null,
			rejectionReason:
				status === CaseTaskStatus.REJECTED
					? info.rejectionReason ?? task.task_completion_comments ?? null
					: null,
			resolvedAt: resolvedAtRaw ? new Date(resolvedAtRaw) : null,
			resolvedBy: info.resolvedBy ?? task.completed_by ?? null,
			createdOn: new Date(info.createdOn ?? task.created_on ?? Date.now()),
			createdBy: info.createdBy ?? task.created_by ?? '',
			createdByName: info.createdByName ?? null,
		};
	}
}
