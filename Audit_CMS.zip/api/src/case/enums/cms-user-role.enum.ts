export enum CmsUserRole {
	HFRS = 'HFRS',
	ADMIN = 'Admin',
	FRS = 'FRS',
}

const ADMIN_ROLE_NAME_TO_CMS_ROLE: Record<string, CmsUserRole> = {
	hfrs: CmsUserRole.HFRS,
	frsadmin: CmsUserRole.ADMIN,
	admin: CmsUserRole.ADMIN,
	frsteam: CmsUserRole.FRS,
	frs: CmsUserRole.FRS,
};

export function mapAdminRoleName(roleName?: string | null): CmsUserRole | null {
	return ADMIN_ROLE_NAME_TO_CMS_ROLE[(roleName ?? '').trim().toLowerCase()] ?? null;
}
