export enum RemediationStatus {
	PENDING = 'Pending',
	COMPLETE = 'Complete',
}
