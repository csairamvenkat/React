export enum CaseStatus {
	CASE_CREATED = 'Case Created',
	DEFINE_SCOPE = 'Define Scope',
	DEFINE_PROCEDURES = 'Define Procedures',
	/**
	 * Legacy. Planning and performing merged into DEFINE_PROCEDURES; kept only so cases stamped
	 * with it before the merge still resolve. Deliberately absent from STATUS_ORDER.
	 */
	PERFORM_PROCEDURES = 'Perform Procedures',
	REPORT_RESULTS = 'Report Results',
	REMEDIATION_ACTIONS = 'Remediation Actions',
	RECOMMENDATIONS = 'Recommendations',
	REPORTING = 'Reporting',
	FRAUD_RISK_DOCS = 'Fraud Risk Documentation',
	CLOSED = 'Closed',
}
