export enum RecommendationItemType {
	CONTROL_ENHANCEMENT = 'Control Enhancement',
	POLICY_PROCESS_REVIEW = 'Policy / Process Review',
	TRAINING = 'Training',
	NO_ACTION_TAKEN = 'No Action Taken',
	NO_ACTION_NECESSARY = 'No Action Necessary',
	OTHER = 'Other',
}
