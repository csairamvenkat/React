export enum RecommendationItemStatus {
	PENDING = 'Pending',
	IMPLEMENTED = 'Implemented',
}
