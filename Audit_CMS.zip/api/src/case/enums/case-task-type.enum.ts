export enum CaseTaskType {
	HFRS_FRAUD_INVESTIGATION = 'hfrs_fraud_investigation',
	//HFRS_CASE_LEAD_NOMINATION = 'hfrs_case_lead_nomination',
	HFRS_NO_INVESTIGATION_CLOSURE = 'hfrs_no_investigation_closure',
	HFRS_NON_FRAUD_REPORTING_SIGNOFF = 'hfrs_non_fraud_reporting_signoff',
	CASE_LEAD_RESULTS_CONFIRMATION = 'case_lead_results_confirmation',
	DELEGATION_REQUEST = 'delegation_request',
	AM_PROCEDURE_REVIEW = 'am_procedure_review',
}

export enum CaseTaskStatus {
	PENDING = 'Pending',
	APPROVED = 'Approved',
	REJECTED = 'Rejected',
}
