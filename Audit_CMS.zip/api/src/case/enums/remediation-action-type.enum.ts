export enum RemediationActionType {
	LEGAL_ACTION = 'Legal Action',
	RECOVERY = 'Recovery',
	DISCIPLINE = 'Discipline',
	TERMINATION = 'Termination',
	OTHER = 'Other',
}
