/**
 * Who added a scope item or procedure, shown on the item itself so the Case Lead and the
 * Allegation Manager can each tell their own work from the other's.
 */
export enum ItemOrigin {
	CASE_LEAD = 'Case Lead',
	FRS = 'FRS',
	ALLEGATION_MANAGER = 'Allegation Manager',
}
