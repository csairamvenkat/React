export enum PermissionSourceType {
	SCOPE_ITEM = 'scope_item',
	ALLEGATION = 'allegation',
	PROCEDURE = 'procedure',
	SUB_ASSIGNEE = 'allegation_sub_assignee',
}
