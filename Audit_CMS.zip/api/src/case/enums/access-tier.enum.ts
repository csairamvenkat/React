export enum AccessTier {
	CONFIG = 'config',
	CASE_ACCESS = 'caseAccess',
	TASK_ONLY = 'taskOnly',
}
