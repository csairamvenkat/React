export enum EvidenceCategory {
	DOCUMENT = 'Document',
	REPORT = 'Report',
	AUDIO = 'Audio',
	NOTES = 'Notes',
	PHOTO = 'Photo',
	VIDEO = 'Video',
	OTHER = 'Other',
}
