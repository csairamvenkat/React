export enum CaseListPreset {
	OPEN = 'open',
	NEW_THIS_MONTH = 'new-this-month',
	CLOSED_THIS_MONTH = 'closed-this-month',
}
