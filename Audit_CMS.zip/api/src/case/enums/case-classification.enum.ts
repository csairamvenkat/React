export enum CaseClassification {
	FRAUD = 'Fraud',
	NON_FRAUD = 'Non-Fraud',
}
