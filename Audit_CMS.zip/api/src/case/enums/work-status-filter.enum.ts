export enum WorkStatusFilter {
	ALL = 'all',
	PENDING = 'pending',
	COMPLETED = 'completed',
}
