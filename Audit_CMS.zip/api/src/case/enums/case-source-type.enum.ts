export enum CaseSourceType {
	CMS = 'CMS',
	NAVEX = 'NAVEX',
}
