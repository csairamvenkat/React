export enum AnalysisResult {
	SUBSTANTIATED = 'Substantiated',
	PARTIALLY_SUBSTANTIATED = 'Partially Substantiated',
	UNSUBSTANTIATED = 'Unsubstantiated',
	INVALID = 'Invalid',
	INSUFFICIENT_INFORMATION = 'Insufficient Information',
}
