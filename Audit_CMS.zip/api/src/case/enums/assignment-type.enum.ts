export enum AssignmentType {
	ALLEGATION_MANAGER = 'allegation_manager',
	PROCEDURE_ASSIGNEE = 'procedure_assignee',
	SUB_ASSIGNEE = 'sub_assignee',
	RECOMMENDATION_OWNER = 'recommendation_owner',
}

export enum AssignmentTaskStatus {
	PENDING = 'Pending',
	IN_PROGRESS = 'In Progress',
	COMPLETED = 'Completed',
	CLOSED = 'Closed',
}
