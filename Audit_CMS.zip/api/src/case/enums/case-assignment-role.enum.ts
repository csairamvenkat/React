export enum CaseAssignmentRole {
	ALLEGATION_MANAGER = 'Allegation Manager',
	SUB_ASSIGNEE = 'Sub-Assignee',
	PROCEDURE_INVESTIGATOR = 'Procedure Investigator',
}
