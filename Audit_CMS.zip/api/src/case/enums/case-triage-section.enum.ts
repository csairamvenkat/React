export enum CaseTriageSection {
	ALLEGATIONS = 'allegations',
	CLASSIFICATION = 'classification',
	FINALIZATION = 'finalization',
}
