export enum ProcedureStatus {
	PENDING = 'Pending',
	COMPLETE = 'Complete',
}
