import { CaseStatus } from '../enums';

/**
 * Closing is no longer a stage: a closed case keeps the stage it reached and carries
 * `cases.status = 'Closed'` instead, so a case closed at Triage still reads as a Triage case.
 */
export const STATUS_ORDER: CaseStatus[] = [
	CaseStatus.CASE_CREATED,
	CaseStatus.DEFINE_SCOPE,
	CaseStatus.DEFINE_PROCEDURES,
	CaseStatus.REPORT_RESULTS,
	CaseStatus.REMEDIATION_ACTIONS,
	CaseStatus.RECOMMENDATIONS,
	CaseStatus.REPORTING,
	CaseStatus.FRAUD_RISK_DOCS,
];

/**
 * Navex's own case status, held on `cases.status`. Distinct from `current_stage`, which is the
 * CMS lifecycle stage.
 */
export const CASE_RECORD_STATUSES = ['Unreviewed', 'Open', 'In Process', 'Closed'] as const;

/** What an imported case carries until someone picks it up — the count behind the Unreviewed stat card. */
export const CASE_RECORD_STATUS_UNREVIEWED: (typeof CASE_RECORD_STATUSES)[number] = 'Unreviewed';

/** Closure lives here rather than on the stage, so it can happen from any point in the lifecycle. */
export const CASE_RECORD_STATUS_CLOSED: (typeof CASE_RECORD_STATUSES)[number] = 'Closed';

export const isCaseClosed = (status?: string | null): boolean =>
	status === CASE_RECORD_STATUS_CLOSED;

export const ALLEGATION_MANAGER_SECTIONS = ['scope', 'procedures'];

/**
 * A Procedure Assignee still carries 'perform'. Since the merge it reads as "the Procedures stage,
 * complete-only": it grants the same panel as 'procedures' but without planning rights.
 */
export const PROCEDURE_ASSIGNEE_SECTIONS = ['perform'];

/**
 * Where a case stamped with a status no longer in STATUS_ORDER belongs now.
 */
export const LEGACY_STATUS_REPLACEMENT: Partial<Record<CaseStatus, CaseStatus>> = {
	[CaseStatus.PERFORM_PROCEDURES]: CaseStatus.DEFINE_PROCEDURES,
	// Cases closed before closure moved onto `status` have lost the stage they were closed at;
	// Reporting is where the lifecycle ended for them.
	[CaseStatus.CLOSED]: CaseStatus.REPORTING,
};

export const resolveStage = (status: CaseStatus): CaseStatus =>
	LEGACY_STATUS_REPLACEMENT[status] ?? status;

export const LOCATION_JSON_FIELDS = [
	'organizationName',
	'branchNumber',
	'address',
	'city',
	'state',
	'zip',
] as const;

export const REPORTER_JSON_FIELDS = [
	'reporterFirstName',
	'reporterLastName',
	'reporterEmail',
	'reporterPhoneNumber',
	'reporterIdCode',
	'reporterAvailability',
	'reporterIsEmployee',
] as const;

/**
 * Scope of work on a Fraud allegation is owned by FRS / the Case Lead. An Allegation Manager may
 * still define scope on a Non-Fraud allegation, but never edit what FRS / the Case Lead wrote.
 */
export const SCOPE_FRAUD_RESTRICTED_MESSAGE =
	'Scope of work for a fraud allegation can only be added or edited by FRS or the Case Lead.';

/** A procedure assignee chosen by FRS / the Case Lead is theirs to change, never the Allegation Manager's. */
export const PROCEDURE_ASSIGNEE_LOCKED_MESSAGE =
	'This procedure assignee was set by FRS or the Case Lead and only they can change or remove it.';

/**
 * Report Results is written per allegation: its Manager reports on their own allegation, FRS / the
 * Case Lead on any of them. The overall analysis and conclusion are the case's, so they stay with
 * FRS / the Case Lead, and a confirmed outcome is reopened only by them.
 */
export const RESULTS_ALLEGATION_RESTRICTED_MESSAGE =
	'You can only report results for an allegation you manage.';

export const RESULTS_CASE_SUMMARY_RESTRICTED_MESSAGE =
	'Only FRS or the Case Lead can write the overall analysis and conclusion.';

export const RESULTS_CONFIRMED_LOCKED_MESSAGE =
	'The Case Lead has confirmed this outcome — only FRS or the Case Lead can change it now.';
