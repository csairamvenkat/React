import * as fs from 'fs';
import * as path from 'path';
import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Post,
	Put,
	Query,
	Req,
	Res,
	UploadedFile,
	UseGuards,
	UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { AuthGuard } from '@nestjs/passport';
import {
	ApiBearerAuth,
	ApiBody,
	ApiConsumes,
	ApiQuery,
	ApiResponse,
	ApiTags,
} from '@nestjs/swagger';
import { RequestContext } from 'src/shared/types';
import { MessageResponseDto } from 'src/shared/dtos';
import { CaseService, AuditLogService } from '../services';
import {
	CaseDetailResponseDto,
	CaseListFilterRequestDto,
	CasePaginatedListingResponseDto,
	CompleteProcedureRequestDto,
	CreateCaseRequestDto,
	CreateProcedureRequestDto,
	CreateRemediationActionRequestDto,
	CreateScopeItemRequestDto,
	NextStageRequestDto,
	SaveRecommendationRequestDto,
	SaveResultsRequestDto,
	ConfirmOutcomeRequestDto,
	UpdateCaseRequestDto,
	UpdateProcedureRequestDto,
	UpdateRemediationActionRequestDto,
	UpdateScopeItemRequestDto,
	CreateAllegationRequestDto,
	UpdateAllegationRequestDto,
	CreateRecommendationItemRequestDto,
	UpdateRecommendationItemRequestDto,
	CreateFraudRiskRequestDto,
	UpdateFraudRiskRequestDto,
	SetUserPermissionRequestDto,
	CaseUserPermissionResponseDto,
	MyAccessResponseDto,
	MyCasePermissionsResponseDto,
	CreateCaseTaskRequestDto,
	ResolveCaseTaskRequestDto,
	DelegateRequestDto,
	CaseTaskResponseDto,
	AssignmentTaskResponseDto,
	AssignmentTaskDetailResponseDto,
	TaskProcedureResponseDto,
	CaseApproverResponseDto,
	SaveCaseReportRequestDto,
	CaseReportResponseDto,
	CaseStatsResponseDto,
	WorkListFilterRequestDto,
	WorkStatsFilterRequestDto,
	WorkItemPaginatedResponseDto,
	WorkStatsResponseDto,
	WORK_ITEM_TYPE_BY_PARAM,
} from '../dtos';
import { PERMISSIONS } from '@/shared/enums';
import { Permissions } from 'src/core/decorators';
import { PermissionsGuard } from '@/core/guards';
import { CASE_LIST_SORT_COLUMNS } from '../repositories/case.repository';

const evidenceDiskStorage = diskStorage({
	destination: (req, _file, cb) => {
		const caseId = req.body?.caseId || 'unknown';
		const dir = path.join('uploads', 'cases', String(caseId), 'evidence');
		fs.mkdirSync(dir, { recursive: true });
		cb(null, dir);
	},
	filename: (_req, file, cb) => {
		cb(null, `${Date.now()}_${file.originalname}`);
	},
});

@ApiTags('Case Management APIs')
@ApiBearerAuth()
// @UseGuards(AuthGuard('oauth-bearer'))
@Controller('cases')
@ApiBearerAuth()
export class CaseController {
	constructor(
		private readonly caseService: CaseService,
		private readonly auditLogService: AuditLogService,
	) {}

	@ApiResponse({ status: 200, type: MyAccessResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('me/access')
	public getMyAccess(@Req() request: RequestContext): Promise<MyAccessResponseDto> {
		return this.caseService.getMyAccess(request.currentContext);
	}

	@ApiResponse({ status: 200, type: [CaseTaskResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('me/tasks')
	public getMyTasks(@Req() request: RequestContext): Promise<CaseTaskResponseDto[]> {
		return this.caseService.getMyTasks(request.currentContext.user.username);
	}

	@ApiResponse({ status: 200, type: [CaseTaskResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('me/tasks/pending')
	public getMyPendingTasks(@Req() request: RequestContext): Promise<CaseTaskResponseDto[]> {
		return this.caseService.getMyPendingTasks(request.currentContext.user.username);
	}

	@ApiBody({ type: WorkListFilterRequestDto })
	@ApiQuery({ name: 'limit', type: Number, required: false })
	@ApiQuery({ name: 'page', type: Number, required: false })
	@ApiQuery({ name: 'searchTerm', type: String, required: false })
	@ApiResponse({ status: 200, type: WorkItemPaginatedResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('work/list')
	public getWorkList(
		@Body() filters: WorkListFilterRequestDto,
		@Req() request: RequestContext,
		@Query('limit') limit: number = 10,
		@Query('page') page: number = 1,
		@Query('searchTerm') searchTerm?: string,
	): Promise<WorkItemPaginatedResponseDto> {
		return this.caseService.getWorkList(
			Number(limit),
			Number(page),
			filters,
			searchTerm,
			request.currentContext,
		);
	}

	@ApiBody({ type: WorkStatsFilterRequestDto, required: false })
	@ApiQuery({ name: 'searchTerm', type: String, required: false })
	@ApiResponse({ status: 200, type: WorkStatsResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('work/list/stats')
	public getWorkStats(
		@Req() request: RequestContext,
		@Body() filters?: WorkStatsFilterRequestDto,
		@Query('searchTerm') searchTerm?: string,
	): Promise<WorkStatsResponseDto> {
		return this.caseService.getWorkStats(filters ?? {}, searchTerm, request.currentContext);
	}

	@ApiResponse({ status: 200, type: [AssignmentTaskResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('me/assignment-tasks')
	public getMyAssignmentTasks(
		@Req() request: RequestContext,
	): Promise<AssignmentTaskResponseDto[]> {
		return this.caseService.getMyAssignmentTasks(request.currentContext.user.username);
	}

	@ApiResponse({ status: 200 })
	@Get(':caseId/audit-logs')
	public getAuditLogs(@Param('caseId') caseId: number) {
		return this.auditLogService.getAuditLogs(Number(caseId));
	}

	@ApiBody({ type: CaseListFilterRequestDto, required: false })
	@ApiQuery({ name: 'searchTerm', type: String, required: false })
	@ApiResponse({ status: 200, type: CaseStatsResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('list/stats')
	public getCaseStats(
		@Query('searchTerm') searchTerm?: string,
		@Body() filters?: CaseListFilterRequestDto,
		@Req() request?: RequestContext,
	): Promise<CaseStatsResponseDto> {
		return this.caseService.getCaseStats(searchTerm, filters, request?.currentContext?.user?.username);
	}

	@ApiQuery({ name: 'limit', type: Number, required: false })
	@ApiQuery({ name: 'page', type: Number, required: false })
	@ApiQuery({ name: 'searchTerm', type: String, required: false })
	@ApiQuery({ name: 'sortBy', enum: CASE_LIST_SORT_COLUMNS, required: false })
	@ApiQuery({ name: 'sortDir', enum: ['asc', 'desc'], required: false })
	@ApiResponse({ status: 200, type: CasePaginatedListingResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('list')
	public getCaseList(
		@Query('limit') limit: number = 10,
		@Query('page') page: number = 1,
		@Query('searchTerm') searchTerm?: string,
		@Query('sortBy') sortBy?: string,
		@Query('sortDir') sortDir?: string,
		@Body() filters?: CaseListFilterRequestDto,
		@Req() request?: RequestContext,
	): Promise<CasePaginatedListingResponseDto> {
		const currentUsername = request?.currentContext?.user?.username;
		return this.caseService.getCaseList(limit, page, searchTerm, filters, currentUsername, sortBy, sortDir);
	}

	@ApiBody({ type: CreateCaseRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'), PermissionsGuard)
	@Permissions(PERMISSIONS.CASE_SUBMIT)
	@Post('')
	public createCase(
		@Req() request: RequestContext,
		@Body() dto: CreateCaseRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createCase(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateCaseRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('')
	public updateCase(
		@Req() request: RequestContext,
		@Body() dto: UpdateCaseRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateCase(dto, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('lookups/primary-issues')
	public getPrimaryIssues(): string[] {
		return this.caseService.getPrimaryIssues();
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('lookups/statuses')
	public getCaseStatusList(): string[] {
		return this.caseService.getCaseStatusList();
	}

	@ApiQuery({ name: 'assignedUser', type: String, required: false })
	@ApiQuery({ name: 'caseId', type: Number, required: false })
	@ApiQuery({
		name: 'actionType',
		type: String,
		required: false,
		description: 'procedure | remediation',
	})
	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('open-actions')
	public getOpenActions(
		@Query('assignedUser') assignedUser?: string,
		@Query('caseId') caseId?: number,
		@Query('actionType') actionType?: string,
	) {
		return this.caseService.getOpenActions(
			assignedUser,
			caseId,
			actionType as 'procedure' | 'remediation' | undefined,
		);
	}

	@ApiResponse({ status: 200, description: 'Download evidence file' })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('evidence/:id/file')
	public async downloadEvidence(@Param('id') id: number, @Res() res: any) {
		const evidence = await this.caseService.getEvidenceById(id);
		const uploadsDir = process.env.UPLOADS_DIR || 'uploads';
		const filePath = path.resolve(uploadsDir, evidence.filePath);

		res.setHeader('Content-Type', evidence.mimeType || 'application/octet-stream');
		res.setHeader('Content-Disposition', `attachment; filename="${evidence.fileName}"`);
		res.sendFile(filePath);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':id/duplicate-check')
	public checkDuplicates(@Param('id') id: number) {
		return this.caseService.checkDuplicates(id);
	}

	@ApiResponse({ status: 200, type: CaseDetailResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':id')
	public getCaseById(@Param('id') id: number): Promise<CaseDetailResponseDto> {
		return this.caseService.getCaseById(id);
	}

	@ApiResponse({ status: 200, type: CaseDetailResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('by-task/:taskId')
	public getCaseByTaskId(
		@Param('taskId') taskId: number,
		@Req() request: RequestContext,
	): Promise<CaseDetailResponseDto> {
		return this.caseService.getCaseByTaskId(taskId, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete(':id')
	public deleteCase(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteCase(id, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':id/deactivate')
	public deactivateCase(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deactivateCase(id, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':id/close')
	public closeCase(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.closeCase(id, request.currentContext);
	}

	@ApiBody({ type: NextStageRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':id/next-stage')
	public advanceToNextStage(
		@Param('id') id: number,
		@Body() dto: NextStageRequestDto,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.advanceToNextStage(id, dto, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/scope-items')
	public getScopeItems(@Param('caseId') caseId: number) {
		return this.caseService.getScopeItems(caseId);
	}

	@ApiBody({ type: CreateScopeItemRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('scope-items')
	public createScopeItem(
		@Req() request: RequestContext,
		@Body() dto: CreateScopeItemRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createScopeItem(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateScopeItemRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('scope-items')
	public updateScopeItem(
		@Req() request: RequestContext,
		@Body() dto: UpdateScopeItemRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateScopeItem(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('scope-items/:id')
	public deleteScopeItem(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteScopeItem(id, request.currentContext);
	}

	@ApiBody({ type: CreateProcedureRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('procedures')
	public createProcedure(
		@Req() request: RequestContext,
		@Body() dto: CreateProcedureRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createProcedure(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateProcedureRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('procedures')
	public updateProcedure(
		@Req() request: RequestContext,
		@Body() dto: UpdateProcedureRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateProcedure(dto, request.currentContext);
	}

	@ApiBody({ type: CompleteProcedureRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('procedures/complete')
	public completeProcedure(
		@Req() request: RequestContext,
		@Body() dto: CompleteProcedureRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.completeProcedure(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('procedures/:id')
	public deleteProcedure(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteProcedure(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/procedures')
	public getProcedures(@Param('caseId') caseId: number) {
		return this.caseService.getProcedures(caseId);
	}

	@ApiBody({ type: SaveResultsRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('results')
	public saveResults(
		@Req() request: RequestContext,
		@Body() dto: SaveResultsRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.saveResults(dto, request.currentContext);
	}

	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':caseId/submit-results-confirmation')
	public submitResultsForConfirmation(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.submitResultsForConfirmation(caseId, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':caseId/confirm-remediation')
	public confirmRemediation(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.confirmRemediation(caseId, request.currentContext);
	}

	@ApiBody({ type: CreateRemediationActionRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('remediation-actions')
	public createRemediationAction(
		@Req() request: RequestContext,
		@Body() dto: CreateRemediationActionRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createRemediationAction(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateRemediationActionRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('remediation-actions')
	public updateRemediationAction(
		@Req() request: RequestContext,
		@Body() dto: UpdateRemediationActionRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateRemediationAction(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('remediation-actions/:id')
	public deleteRemediationAction(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteRemediationAction(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/remediation-actions')
	public getRemediationActions(@Param('caseId') caseId: number) {
		return this.caseService.getRemediationActions(caseId);
	}

	@ApiBody({ type: SaveRecommendationRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('recommendation')
	public saveRecommendation(
		@Req() request: RequestContext,
		@Body() dto: SaveRecommendationRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.saveRecommendation(dto, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/recommendation')
	public getRecommendation(@Param('caseId') caseId: number) {
		return this.caseService.getRecommendation(caseId);
	}

	@ApiConsumes('multipart/form-data')
	@ApiBody({
		schema: {
			type: 'object',
			properties: {
				file: { type: 'string', format: 'binary' },
				caseId: { type: 'number' },
				category: { type: 'string' },
				description: { type: 'string' },
				isKeyEvidence: { type: 'boolean' },
			},
		},
	})
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('evidence')
	@UseInterceptors(FileInterceptor('file', { storage: evidenceDiskStorage }))
	public async uploadEvidence(
		@Req() request: RequestContext,
		@UploadedFile() file: Express.Multer.File,
		@Body('caseId') caseId: number,
		@Body('category') category: string,
		@Body('description') description: string,
		@Body('isKeyEvidence') isKeyEvidence: string,
		@Body('allegationId') allegationId: string,
		@Body('procedureId') procedureId: string,
	): Promise<MessageResponseDto> {
		const relativePath = path
			.join('cases', String(caseId), 'evidence', file.filename)
			.replace(/\\/g, '/');
		return this.caseService.addEvidence(
			{
				caseId: Number(caseId),
				allegationId: allegationId ? Number(allegationId) : undefined,
				procedureId: procedureId ? Number(procedureId) : undefined,
				category,
				description,
				fileName: file.originalname,
				filePath: relativePath,
				fileSize: file.size,
				mimeType: file.mimetype,
				isKeyEvidence: isKeyEvidence === 'true',
			},
			request.currentContext,
		);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('evidence/:id')
	public updateEvidence(
		@Param('id') id: number,
		@Req() request: RequestContext,
		@Body() data: { category?: string; description?: string; isKeyEvidence?: boolean },
	): Promise<MessageResponseDto> {
		return this.caseService.updateEvidence(id, data, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('evidence/:id')
	public deleteEvidence(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteEvidence(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/evidence')
	public getEvidence(@Param('caseId') caseId: number) {
		return this.caseService.getEvidence(caseId);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/evidence/key')
	public getKeyEvidence(@Param('caseId') caseId: number) {
		return this.caseService.getKeyEvidence(caseId);
	}

	@ApiResponse({ status: 200, type: CaseReportResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/case-report')
	public getCaseReport(@Param('caseId') caseId: number): Promise<CaseReportResponseDto> {
		return this.caseService.getCaseReport(caseId);
	}

	@ApiBody({ type: SaveCaseReportRequestDto })
	@ApiResponse({ status: 200, type: CaseReportResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put(':caseId/case-report')
	public saveCaseReport(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
		@Body() dto: SaveCaseReportRequestDto,
	): Promise<CaseReportResponseDto> {
		return this.caseService.saveCaseReport(caseId, dto, request.currentContext);
	}

	@ApiBody({ type: CreateAllegationRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('allegations')
	public createAllegation(
		@Req() request: RequestContext,
		@Body() dto: CreateAllegationRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createAllegation(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateAllegationRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('allegations')
	public updateAllegation(
		@Req() request: RequestContext,
		@Body() dto: UpdateAllegationRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateAllegation(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('allegations/:id')
	public deleteAllegation(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteAllegation(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/allegations')
	public getAllegations(@Param('caseId') caseId: number) {
		return this.caseService.getAllegations(caseId);
	}

	@ApiBody({ type: ConfirmOutcomeRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('allegations/:id/confirm-outcome')
	public confirmAllegationOutcome(
		@Param('id') id: number,
		@Req() request: RequestContext,
		@Body() dto: ConfirmOutcomeRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.confirmAllegationOutcome(id, dto.confirmed, request.currentContext);
	}

	@ApiBody({ type: CreateRecommendationItemRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('recommendation-items')
	public createRecommendationItem(
		@Req() request: RequestContext,
		@Body() dto: CreateRecommendationItemRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createRecommendationItem(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateRecommendationItemRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('recommendation-items')
	public updateRecommendationItem(
		@Req() request: RequestContext,
		@Body() dto: UpdateRecommendationItemRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateRecommendationItem(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('recommendation-items/:id')
	public deleteRecommendationItem(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteRecommendationItem(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/recommendation-items')
	public getRecommendationItems(@Param('caseId') caseId: number) {
		return this.caseService.getRecommendationItems(caseId);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('recommendation-items/transfer')
	public transferRecommendationItemsToArms(
		@Body('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.transferRecommendationItemsToArms(
			Number(caseId),
			request.currentContext,
		);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post(':caseId/confirm-recommendations')
	public confirmRecommendations(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.confirmRecommendations(Number(caseId), request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('recommendation-items/:id/implement')
	public markRecommendationImplemented(
		@Param('id') id: number,
		@Body('implemented') implemented: boolean,
		@Req() request: RequestContext,
		@Body('notes') notes?: string,
	): Promise<MessageResponseDto> {
		return this.caseService.markRecommendationImplemented(
			Number(id),
			implemented !== false,
			request.currentContext,
			notes,
		);
	}

	@ApiBody({ type: CreateFraudRiskRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('fraud-risks')
	public createFraudRisk(
		@Req() request: RequestContext,
		@Body() dto: CreateFraudRiskRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.createFraudRisk(dto, request.currentContext);
	}

	@ApiBody({ type: UpdateFraudRiskRequestDto })
	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('fraud-risks')
	public updateFraudRisk(
		@Req() request: RequestContext,
		@Body() dto: UpdateFraudRiskRequestDto,
	): Promise<MessageResponseDto> {
		return this.caseService.updateFraudRisk(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('fraud-risks/:id')
	public deleteFraudRisk(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.deleteFraudRisk(id, request.currentContext);
	}

	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/fraud-risks')
	public getFraudRisks(@Param('caseId') caseId: number) {
		return this.caseService.getFraudRisks(caseId);
	}

	@ApiResponse({ status: 200, type: MyCasePermissionsResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/permissions/me')
	public getMyPermissions(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<MyCasePermissionsResponseDto> {
		return this.caseService.getMyPermissions(Number(caseId), request.currentContext);
	}

	@ApiResponse({ status: 200, type: [CaseUserPermissionResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/user-permissions')
	public getUserPermissions(@Param('caseId') caseId: number) {
		return this.caseService.getUserPermissions(Number(caseId));
	}

	@ApiBody({ type: SetUserPermissionRequestDto })
	@ApiResponse({ status: 200 })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('user-permissions')
	public setUserPermission(
		@Req() request: RequestContext,
		@Body() dto: SetUserPermissionRequestDto,
	) {
		return this.caseService.setUserPermission(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Delete('user-permissions/:id')
	public deleteUserPermission(
		@Param('id') id: number,
		@Req() request: RequestContext,
	): Promise<{ message: string }> {
		return this.caseService.deleteUserPermission(Number(id), request.currentContext);
	}

	@ApiResponse({ status: 200, type: [CaseTaskResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/tasks')
	public getTasksForCase(@Param('caseId') caseId: number): Promise<CaseTaskResponseDto[]> {
		return this.caseService.getTasksForCase(Number(caseId));
	}

	@ApiResponse({ status: 200, type: AssignmentTaskDetailResponseDto })
	@ApiQuery({ name: 'type', required: false, enum: ['procedure'] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@ApiQuery({
		name: 'type',
		enum: Object.keys(WORK_ITEM_TYPE_BY_PARAM),
		required: false,
		description: 'Reads :taskId as the id of the item itself rather than of an assignment task.',
	})
	@Get('tasks/assignments/:taskId')
	public getAssignmentTaskDetail(
		@Param('taskId') taskId: number,
		@Req() request: RequestContext,
		@Query('type') type?: string,
	): Promise<AssignmentTaskDetailResponseDto> {
		const workItemType = type ? WORK_ITEM_TYPE_BY_PARAM[type] : undefined;
		return workItemType
			? this.caseService.getWorkItemDetail(workItemType, Number(taskId), request.currentContext)
			: this.caseService.getAssignmentTaskDetail(Number(taskId), request.currentContext);
	}

	@ApiResponse({ status: 200, type: [TaskProcedureResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get('work/allegations/:allegationId/procedures')
	public getAllegationProcedures(
		@Param('allegationId') allegationId: number,
		@Req() request: RequestContext,
	): Promise<TaskProcedureResponseDto[]> {
		return this.caseService.getAllegationProcedures(Number(allegationId), request.currentContext);
	}

	@ApiBody({ type: DelegateRequestDto })
	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('tasks/assignments/:taskId/delegate')
	public requestDelegation(
		@Param('taskId') taskId: number,
		@Body() dto: DelegateRequestDto,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.requestDelegation(Number(taskId), dto, request.currentContext);
	}

	@ApiResponse({ status: 201, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Post('tasks')
	public createTask(
		@Body() dto: CreateCaseTaskRequestDto,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.createCaseTask(dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: MessageResponseDto })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Put('tasks/:taskId/resolve')
	public resolveTask(
		@Param('taskId') taskId: number,
		@Body() dto: ResolveCaseTaskRequestDto,
		@Req() request: RequestContext,
	): Promise<MessageResponseDto> {
		return this.caseService.resolveTask(Number(taskId), dto, request.currentContext);
	}

	@ApiResponse({ status: 200, type: [CaseApproverResponseDto] })
	@UseGuards(AuthGuard('oauth-bearer'))
	@Get(':caseId/approvers')
	public getCaseApprovers(
		@Param('caseId') caseId: number,
		@Req() request: RequestContext,
	): Promise<CaseApproverResponseDto[]> {
		return this.caseService.getCaseApprovers(Number(caseId), request.currentContext);
	}
}
