import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { CaseTaskType } from '../../enums';

export class CreateCaseTaskRequestDto {
	@ApiProperty()
	@IsNumber()
	caseId: number;

	@ApiProperty({ enum: CaseTaskType })
	@IsEnum(CaseTaskType)
	taskType: CaseTaskType;

	@ApiProperty({ description: 'UPN/email of the HFRS user the task is assigned to' })
	@IsString()
	@IsNotEmpty()
	assignedTo: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedToName?: string;

	@ApiPropertyOptional({ description: 'JSON string with contextual data for the review screen' })
	@IsOptional()
	@IsString()
	payload?: string;
}

export class ResolveCaseTaskRequestDto {
	@ApiProperty({ description: 'true = Approve, false = Reject' })
	@IsBoolean()
	approved: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	rejectionReason?: string;
}
