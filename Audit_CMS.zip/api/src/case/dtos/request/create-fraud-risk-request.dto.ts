import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateFraudRiskRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) caseId: number;
	@ApiProperty() @IsString() @IsNotEmpty() riskCategory: string;
	@ApiPropertyOptional() @IsOptional() @IsString() riskSubcategory?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() riskDescription?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
}

export class UpdateFraudRiskRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) id: number;
	@ApiPropertyOptional() @IsOptional() @IsString() riskCategory?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() riskSubcategory?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() riskDescription?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
}
