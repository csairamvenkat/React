import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { RemediationActionType } from '../../models';

export class CreateRemediationActionRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	caseId: number;

	@ApiProperty({ enum: RemediationActionType })
	@IsNotEmpty()
	@IsEnum(RemediationActionType)
	actionType: RemediationActionType;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	description?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	responsibleParty?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsEmail()
	responsibleEmail?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	sortOrder?: number;
}

export class UpdateRemediationActionRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	id: number;

	@ApiPropertyOptional({ enum: RemediationActionType })
	@IsOptional()
	@IsEnum(RemediationActionType)
	actionType?: RemediationActionType;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	description?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	responsibleParty?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsEmail()
	responsibleEmail?: string;
}
