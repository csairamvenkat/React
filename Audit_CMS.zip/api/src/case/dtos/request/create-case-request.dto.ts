import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsBoolean, IsDateString, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { CaseClassification } from '../../models';

export class CreateCaseRequestDto {
	@ApiProperty({ example: 'IR-2025-001' })
	@IsNotEmpty()
	@IsString()
	irNumber: string;

	@ApiProperty({ example: 'AMR-DTL' })
	@IsNotEmpty()
	@IsString()
	businessUnit: string;

	@ApiPropertyOptional({ example: 3674 })
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	businessEntityId?: number;

	@ApiPropertyOptional({ example: 'AMR-DTL' })
	@IsOptional()
	@IsString()
	businessEntityCode?: string;

	@ApiPropertyOptional({
		enum: CaseClassification,
		description: 'Set during Triage — not required at creation',
	})
	@IsOptional()
	@IsEnum(CaseClassification)
	classification?: CaseClassification;

	@ApiPropertyOptional({
		example: 'Cat 0',
		description: 'FMF category — set during Triage Finalization',
	})
	@IsOptional()
	@IsString()
	category?: string;

	@ApiPropertyOptional({ example: 'Accurate Books & Records' })
	@IsOptional()
	@IsString()
	primaryIssue?: string;

	@ApiPropertyOptional({ example: ['Anti-Bribery', 'Compliance'] })
	@IsOptional()
	@IsArray()
	secondaryIssues?: string[];

	@ApiProperty({ example: '2025-06-23' })
	@IsNotEmpty()
	@IsDateString()
	dateOfReport: string;

	@ApiPropertyOptional({ example: 'Hotline', description: 'Intake channel captured at manual creation' })
	@IsOptional()
	@IsString()
	mode?: string;

	@ApiPropertyOptional({ example: 'Reported via the confidential hotline on 12 Jun', description: 'Free-text source details captured at manual creation' })
	@IsOptional()
	@IsString()
	sourceDetails?: string;

	// Reported Tier Information
	@ApiPropertyOptional() @IsOptional() @IsString() caseType?: string;
	@ApiPropertyOptional() @IsOptional() @IsBoolean() partialReport?: boolean;

	// Location
	@ApiPropertyOptional() @IsOptional() @IsString() organizationName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() branchNumber?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() address?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() city?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() state?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() zip?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() country?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() region?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() businessPillar?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() argusUniqueId?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() incidentAddress?: string;

	// Reporter Information
	@ApiPropertyOptional() @IsOptional() @IsBoolean() isAnonymous?: boolean;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterFirstName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterLastName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterEmail?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterPhoneNumber?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterAvailability?: string;
	@ApiPropertyOptional() @IsOptional() @IsBoolean() reporterIsEmployee?: boolean;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterIdCode?: string;

	// Case Information
	@ApiPropertyOptional() @IsOptional() @IsString() alertStatus?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() details?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() translatedDetails?: string;
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexCustomQuestions?: Record<string, unknown>[];
}
