import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsBoolean, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class SaveCaseReportRequestDto {
	@ApiPropertyOptional() @IsOptional() @IsBoolean() reset?: boolean;

	@ApiPropertyOptional() @IsOptional() @IsString() status?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() alertLevel?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() alertStatus?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() caseType?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() intakeChannel?: string;
	@ApiPropertyOptional() @IsOptional() @IsNumber() @Type(() => Number) daysOpen?: number;
	@ApiPropertyOptional() @IsOptional() @IsBoolean() partialReport?: boolean;

	@ApiPropertyOptional() @IsOptional() @IsString() primaryIssue?: string;
	@ApiPropertyOptional() @IsOptional() @IsArray() secondaryIssues?: string[];
	@ApiPropertyOptional() @IsOptional() @IsString() summary?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() details?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() translatedDetails?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() language?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() allegedIncidentDate?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() dateOfReport?: string;

	@ApiPropertyOptional() @IsOptional() @IsString() businessUnit?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() organizationName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() assignedTier?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() branchNumber?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() address?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() city?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() state?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() zip?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() country?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() region?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() businessPillar?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() businessVertical?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() argusUniqueId?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() incidentAddress?: string;

	@ApiPropertyOptional() @IsOptional() @IsBoolean() isAnonymous?: boolean;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterFirstName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterLastName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterEmail?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterPhoneNumber?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterAvailability?: string;
	@ApiPropertyOptional() @IsOptional() @IsBoolean() reporterIsEmployee?: boolean;
	@ApiPropertyOptional() @IsOptional() @IsString() reporterIdCode?: string;

	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexParticipants?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexFiles?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexComments?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexCustomQuestions?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexRelatedCases?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexIssueTypeLayers?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexNotes?: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @IsOptional() @IsArray() navexFollowupQuestions?: Record<string, unknown>[];
}
