import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsDateString, IsEnum, IsIn, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { CaseClassification } from '../../models';
import { CASE_RECORD_STATUSES } from '../../constants/case.constant';

export class AssigneeRefDto {
	@ApiPropertyOptional({ example: 'john.doe@dpworld.com' })
	@IsOptional()
	@IsString()
	email_id?: string;

	@ApiPropertyOptional({ example: 'John Doe' })
	@IsOptional()
	@IsString()
	full_name?: string;
}

export class UpdateCaseRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	id: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	irNumber?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	businessUnit?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	businessEntityId?: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	businessEntityCode?: string;

	@ApiPropertyOptional({ type: AssigneeRefDto })
	@IsOptional()
	assignedTo?: AssigneeRefDto | string;

	@ApiPropertyOptional({ enum: CaseClassification })
	@IsOptional()
	@IsEnum(CaseClassification)
	classification?: CaseClassification;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	category?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	primaryIssue?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsArray()
	secondaryIssues?: string[];

	@ApiPropertyOptional()
	@IsOptional()
	@IsDateString()
	dateOfReport?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	synopsis?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	departmentOfAccused?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	alertStatus?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	fmfClassification?: string;

	@ApiPropertyOptional()
	@IsOptional()
	investigationRequired?: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	noInvestigationReason?: string;

	@ApiPropertyOptional({ type: AssigneeRefDto })
	@IsOptional()
	caseLead?: AssigneeRefDto | string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	linkedIrNumber?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	routingType?: string;

	@ApiPropertyOptional()
	@IsOptional()
	posncdpqFlag?: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	remediationNotApplicable?: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	recommendationsNotApplicable?: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	overallAnalysisResult?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	conclusion?: string;

	@ApiPropertyOptional({
		enum: CASE_RECORD_STATUSES,
		description: "Navex's own case status; the CMS stage is currentStage.",
	})
	@IsOptional()
	@IsIn(CASE_RECORD_STATUSES)
	status?: (typeof CASE_RECORD_STATUSES)[number];
}
