import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsIn, IsEnum, IsOptional } from 'class-validator';
import { AssignmentType, WorkStatusFilter } from '../../enums';

export const WORK_ITEM_TYPES = [
	AssignmentType.ALLEGATION_MANAGER,
	AssignmentType.PROCEDURE_ASSIGNEE,
	AssignmentType.RECOMMENDATION_OWNER,
] as const;

export type WorkItemType = (typeof WORK_ITEM_TYPES)[number];

export const WORK_ITEM_TYPE_BY_PARAM: Record<string, WorkItemType> = {
	allegation: AssignmentType.ALLEGATION_MANAGER,
	procedure: AssignmentType.PROCEDURE_ASSIGNEE,
	recommendation: AssignmentType.RECOMMENDATION_OWNER,
};

export class WorkListFilterRequestDto {
	@ApiProperty({ enum: WORK_ITEM_TYPES })
	@IsIn(WORK_ITEM_TYPES as readonly string[])
	assignmentType: WorkItemType;

	@ApiPropertyOptional({ enum: WorkStatusFilter, default: WorkStatusFilter.ALL })
	@IsOptional()
	@IsEnum(WorkStatusFilter)
	status?: WorkStatusFilter;

	@ApiPropertyOptional({ description: 'Narrows the list to items assigned to the caller.' })
	@IsOptional()
	@IsBoolean()
	@Transform(({ value }) => value === true || value === 'true')
	assignedToMe?: boolean;
}

export class WorkStatsFilterRequestDto {
	@ApiPropertyOptional({ description: 'Narrows the counts to items assigned to the caller.' })
	@IsOptional()
	@IsBoolean()
	@Transform(({ value }) => value === true || value === 'true')
	assignedToMe?: boolean;
}
