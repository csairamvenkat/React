import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsBoolean, IsEnum, IsIn, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';
import { CaseClassification, CaseSourceType, CaseStatus } from '../../models';
import { CaseListPreset, CaseTriageSection } from '../../enums';
import { CASE_RECORD_STATUSES } from '../../constants/case.constant';

export class CaseListFilterRequestDto {
	@ApiPropertyOptional({ enum: CaseClassification })
	@IsOptional()
	@IsEnum(CaseClassification)
	classification?: CaseClassification;

	@ApiPropertyOptional({ enum: CaseStatus })
	@IsOptional()
	@IsEnum(CaseStatus)
	currentStage?: CaseStatus;

	@ApiPropertyOptional({ enum: CaseTriageSection, description: 'Narrows the Triage stage to one of its sections.' })
	@IsOptional()
	@IsEnum(CaseTriageSection)
	triageSection?: CaseTriageSection;

	@ApiPropertyOptional({ description: 'With triageSection, keeps only cases whose HFRS approval is (or is not) pending.' })
	@IsOptional()
	@IsBoolean()
	@Transform(({ value }) => value === true || value === 'true')
	hfrsApprovalPending?: boolean;

	@ApiPropertyOptional({ enum: CaseSourceType })
	@IsOptional()
	@IsEnum(CaseSourceType)
	sourceType?: CaseSourceType;

	@ApiPropertyOptional({ description: 'Intake mode, e.g. Hotline Phone, Email, Fax.' })
	@IsOptional()
	@IsString()
	mode?: string;

	@ApiPropertyOptional({ enum: CASE_RECORD_STATUSES, description: "Navex's own status; the CMS stage is currentStage." })
	@IsOptional()
	@IsIn(CASE_RECORD_STATUSES)
	status?: (typeof CASE_RECORD_STATUSES)[number];

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedTo?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	businessUnit?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsBoolean()
	@Transform(({ value }) => value === true || value === 'true')
	myCasesOnly?: boolean;

	@ApiPropertyOptional({ enum: CaseListPreset })
	@IsOptional()
	@IsEnum(CaseListPreset)
	preset?: CaseListPreset;

	@ApiPropertyOptional()
	@IsOptional()
	@IsBoolean()
	@Transform(({ value }) => value === true || value === 'true')
	onlyDeactivated?: boolean;

	@ApiPropertyOptional()
	@IsOptional()
	@IsArray()
	public business_entities: any;

	@ApiPropertyOptional({
		type: [String],
		description: 'Scopes the free-text search to specific case fields. Empty searches all fields.',
	})
	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	searchFields?: string[];
}
