import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';
import { CaseClassification } from '../../enums/case-classification.enum';

export class CreateAllegationRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) caseId: number;
	@ApiProperty() @IsString() @IsNotEmpty() label: string;
	@ApiProperty() @IsString() @IsNotEmpty() description: string;
	@ApiPropertyOptional() @IsOptional() @IsString() incidentTypeCode?: string;

	@ApiPropertyOptional({ enum: CaseClassification })
	@IsOptional()
	@IsEnum(CaseClassification)
	classification?: CaseClassification;

	@ApiPropertyOptional() @IsOptional() @IsString() outcome?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() detailedAnalysis?: string;
	@ApiPropertyOptional() @IsOptional() lossAmount?: number;
	@ApiPropertyOptional() @IsOptional() recoveredAmount?: number;
	@ApiPropertyOptional() @IsOptional() @IsString() currency?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() allegationManagerId?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() allegationManagerName?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
}

export class UpdateAllegationRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) id: number;
	@ApiPropertyOptional() @IsOptional() @IsString() label?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() description?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() incidentTypeCode?: string;

	@ApiPropertyOptional({ enum: CaseClassification })
	@IsOptional()
	@IsEnum(CaseClassification)
	classification?: CaseClassification;

	@ApiPropertyOptional() @IsOptional() @IsString() outcome?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() detailedAnalysis?: string;
	@ApiPropertyOptional() @IsOptional() lossAmount?: number;
	@ApiPropertyOptional() @IsOptional() recoveredAmount?: number;
	@ApiPropertyOptional() @IsOptional() @IsString() currency?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() allegationManagerId?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() allegationManagerName?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
	@ApiPropertyOptional() @IsOptional() @IsBoolean() scopeReviewNeeded?: boolean;
}
