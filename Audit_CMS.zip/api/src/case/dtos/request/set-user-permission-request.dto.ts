import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class SetUserPermissionRequestDto {
	@ApiProperty() @IsNotEmpty() @IsNumber() @Type(() => Number) caseId: number;
	@ApiProperty() @IsNotEmpty() @IsString() userId: string;
	@ApiPropertyOptional() @IsOptional() @IsString() userName?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() userEmail?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() role?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() sourceType?: string;
	@ApiPropertyOptional() @IsOptional() @IsNumber() @Type(() => Number) sourceId?: number;
	@ApiPropertyOptional({ type: [String] }) @IsOptional() @IsArray() @IsString({ each: true }) sections?: string[];
}
