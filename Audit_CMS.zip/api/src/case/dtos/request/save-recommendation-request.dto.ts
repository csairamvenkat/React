import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class SaveRecommendationRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	caseId: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	lessonsLearned?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	recommendations?: string;
}
