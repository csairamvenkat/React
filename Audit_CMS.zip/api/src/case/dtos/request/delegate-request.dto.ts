import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsOptional, IsString } from 'class-validator';

export class DelegateRequestDto {
	@ApiProperty({ description: 'UPN / email of the user the task should be delegated to.' })
	@IsString()
	toUserId: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	toUserName?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsEmail()
	toUserEmail?: string;
}
