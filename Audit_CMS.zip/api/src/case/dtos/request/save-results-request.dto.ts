import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { AnalysisResult } from '../../models';

export class AllegationResultDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	allegationId: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	outcome?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	detailedAnalysis?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	lossAmount?: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	recoveredAmount?: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	currency?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	lossNotes?: string;
}

export class SaveResultsRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	caseId: number;

	@ApiProperty({ type: [AllegationResultDto] })
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => AllegationResultDto)
	results: AllegationResultDto[];

	@ApiPropertyOptional({ enum: AnalysisResult })
	@IsOptional()
	@IsEnum(AnalysisResult)
	overallAnalysisResult?: AnalysisResult;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	conclusion?: string;
}
