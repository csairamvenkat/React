import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Transform, Type } from 'class-transformer';

export class CreateScopeItemRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	caseId: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Transform(({ value }) => (value != null && value !== '' ? Number(value) : undefined))
	allegationId?: number;

	@ApiProperty()
	@IsNotEmpty()
	@IsString()
	description: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserId?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserName?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserEmail?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	sortOrder?: number;
}

export class UpdateScopeItemRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	id: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	description?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserId?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserName?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	assignedUserEmail?: string;
}
