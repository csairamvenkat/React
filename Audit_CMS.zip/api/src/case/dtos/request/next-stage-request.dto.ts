import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsOptional, IsString } from 'class-validator';

export class NextStageRequestDto {
	@ApiPropertyOptional({ description: 'For approval steps: true = approve, false = reject' })
	@IsOptional()
	@IsBoolean()
	approved?: boolean;

	@ApiPropertyOptional({ description: 'Rejection reason when approved = false' })
	@IsOptional()
	@IsString()
	rejectionReason?: string;
}
