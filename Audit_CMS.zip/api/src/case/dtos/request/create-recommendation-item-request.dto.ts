import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateRecommendationItemRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) caseId: number;
	@ApiProperty() @IsString() @IsNotEmpty() issueTitle: string;
	@ApiPropertyOptional() @IsOptional() @IsString() issueDescription?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() actionDetails?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() implementationDeadline?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationType?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationOwner?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationOwnerEmail?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
}

export class UpdateRecommendationItemRequestDto {
	@ApiProperty() @IsNumber() @Type(() => Number) id: number;
	@ApiPropertyOptional() @IsOptional() @IsString() issueTitle?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() issueDescription?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() actionDetails?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() implementationDeadline?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationType?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationOwner?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() recommendationOwnerEmail?: string;
	@ApiPropertyOptional() @IsOptional() @IsString() status?: string;
	@ApiPropertyOptional() @IsOptional() @Type(() => Number) sortOrder?: number;
}
