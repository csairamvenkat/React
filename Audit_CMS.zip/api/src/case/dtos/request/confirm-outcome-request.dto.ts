import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty } from 'class-validator';

export class ConfirmOutcomeRequestDto {
	@ApiProperty({ description: 'true to confirm the per-allegation outcome, false to withdraw confirmation' })
	@IsNotEmpty()
	@IsBoolean()
	confirmed: boolean;
}
