import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { ProcedureStatus } from '../../models';

export class CreateProcedureRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	caseId: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Transform(({ value }) => (value != null && value !== '' ? Number(value) : undefined))
	allegationId?: number;

	@ApiProperty()
	@IsNotEmpty()
	@IsString()
	description: string;

	@ApiProperty()
	@IsNotEmpty()
	@IsString()
	actionBy: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	actionByUserId?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	actionByEmail?: string;

	@ApiProperty()
	@IsNotEmpty()
	@IsDateString()
	deadline: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsNumber()
	@Type(() => Number)
	sortOrder?: number;
}

export class UpdateProcedureRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	id: number;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	description?: string;

	@ApiPropertyOptional({ enum: ProcedureStatus })
	@IsOptional()
	@IsEnum(ProcedureStatus)
	status?: ProcedureStatus;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	actionBy?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	actionByUserId?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	actionByEmail?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsDateString()
	deadline?: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsDateString()
	completedDate?: string;
}

export class CompleteProcedureRequestDto {
	@ApiProperty()
	@IsNotEmpty()
	@IsNumber()
	@Type(() => Number)
	id: number;

	@ApiProperty()
	@IsNotEmpty()
	@IsDateString()
	completedDate: string;

	@ApiPropertyOptional()
	@IsOptional()
	@IsString()
	workPerformed?: string;
}
