import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { CaseTaskType, CaseTaskStatus } from '../../enums';

export class CaseTaskResponseDto {
	@ApiProperty()
	@Expose()
	@Transform(({ value }) => (typeof value === 'string' ? Number(value) : value))
	id: number;

	@ApiProperty()
	@Expose()
	@Transform(({ value }) => (typeof value === 'string' ? Number(value) : value))
	caseId: number;

	@ApiProperty({ enum: CaseTaskType })
	@Expose()
	taskType: CaseTaskType;

	@ApiProperty({ enum: CaseTaskStatus })
	@Expose()
	status: CaseTaskStatus;

	@ApiProperty()
	@Expose()
	assignedTo: string;

	@ApiPropertyOptional()
	@Expose()
	assignedToName: string;

	@ApiPropertyOptional({ description: 'Parsed JSON payload with review context' })
	@Expose()
	@Transform(({ value }) => {
		if (!value) return null;
		try {
			return JSON.parse(value);
		} catch {
			return value;
		}
	})
	payload: any;

	@ApiPropertyOptional()
	@Expose()
	rejectionReason: string;

	@ApiPropertyOptional()
	@Expose()
	resolvedAt: Date;

	@ApiPropertyOptional()
	@Expose()
	resolvedBy: string;

	@ApiProperty()
	@Expose()
	createdOn: Date;

	@ApiProperty()
	@Expose()
	createdBy: string;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	createdByName: string | null;

	@ApiPropertyOptional({ nullable: true, description: 'Read live from the case; My Tasks only.' })
	@Expose()
	irNumber?: string | null;

	@ApiPropertyOptional({ nullable: true, description: 'Read live from the case; My Tasks only.' })
	@Expose()
	businessUnit?: string | null;

	@ApiPropertyOptional({ nullable: true, description: 'Read live from the case; My Tasks only.' })
	@Expose()
	classification?: string | null;
}
