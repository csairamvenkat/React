import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { AccessTier, CmsUserRole } from '../../enums';

export class MyAccessResponseDto {
	@ApiProperty({ enum: AccessTier })
	@Expose()
	tier: AccessTier;

	@ApiProperty()
	@Expose()
	hasCaseScopedRole: boolean;

	@ApiProperty({ enum: CmsUserRole, isArray: true, description: 'Logical CMS roles resolved from the admin API' })
	@Expose()
	roles: CmsUserRole[];

	@ApiProperty({ description: 'Full access + receives approval tasks' })
	@Expose()
	isHfrs: boolean;

	@ApiProperty({ description: 'Full access, but does not receive approvals unless also HFRS' })
	@Expose()
	isAdmin: boolean;

	@ApiProperty({ description: 'Can view all cases; may only act on own cases' })
	@Expose()
	isFrs: boolean;

	@ApiProperty({ description: 'Whether the user receives HFRS approval tasks (HFRS role)' })
	@Expose()
	receivesApprovals: boolean;
}
