import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

const UNRESTRICTED = 'Null when the caller is unrestricted on this case (FRS or the Case Lead).';

export class MyCasePermissionsResponseDto {
	@ApiProperty({ type: [String], nullable: true, description: UNRESTRICTED })
	@Expose()
	sections: string[] | null;

	@ApiProperty({ type: [Number], nullable: true, description: UNRESTRICTED })
	@Expose()
	allegationIds: number[] | null;

	@ApiProperty({ type: [Number], nullable: true, description: UNRESTRICTED })
	@Expose()
	procedureIds: number[] | null;

	@ApiProperty({
		type: [Number],
		nullable: true,
		description: `Allegations the caller may add scope of work to — Fraud allegations are excluded. ${UNRESTRICTED}`,
	})
	@Expose()
	scopeWritableAllegationIds: number[] | null;

	@ApiProperty({
		type: [Number],
		nullable: true,
		description: `Scope items the caller may edit or delete — those written by FRS or the Case Lead are excluded. ${UNRESTRICTED}`,
	})
	@Expose()
	editableScopeItemIds: number[] | null;
}
