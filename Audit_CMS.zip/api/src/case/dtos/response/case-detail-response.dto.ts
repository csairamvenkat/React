import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { parseAssignee } from 'src/shared/helpers';

/**
 * Reads one key out of a JSONB column on the case and exposes it as a flat field, so
 * consolidating a section into a blob (migration 033) does not change the API contract.
 */
function fromJson(column: 'locationData' | 'reporterData', key: string) {
	return ({ obj }: { obj: Record<string, any> }) => obj?.[column]?.[key] ?? null;
}

export class AssigneeRefResponseDto {
	@ApiProperty() @Expose() email_id: string;
	@ApiProperty() @Expose() full_name: string;
}

export class ScopeItemResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() allegationId: number;
	@Expose() description: string;
	@Expose() sortOrder: number;
	/** Case Lead / FRS / Allegation Manager — who added it. */
	@Expose() addedByRole: string | null;
}

export class ProcedureResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() allegationId: number;
	@Expose() description: string;
	@Expose() status: string;
	@Expose() actionBy: string;
	@Expose() deadline: string;
	@Expose() completedDate: string;
	@Expose() workPerformed: string;
	@Expose() sortOrder: number;
	/** Case Lead / FRS / Allegation Manager — who added it. */
	@Expose() addedByRole: string | null;
}

export class RemediationActionResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() actionType: string;
	@Expose() description: string;
	@Expose() responsibleParty: string;
	@Expose() responsibleEmail: string;
	@Expose() status: string;
	@Expose() sortOrder: number;
}

export class RecommendationResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() lessonsLearned: string;
	@Expose() recommendations: string;
}

export class EvidenceResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() allegationId: number;
	@Expose() procedureId: number;
	@Expose() category: string;
	@Expose() description: string;
	@Expose() fileName: string;
	@Expose() filePath: string;
	@Expose() fileSize: number;
	@Expose() mimeType: string;
	@Expose() uploadedBy: string;
	@Expose() isKeyEvidence: boolean;
	@Expose() createdOn: Date;
}

export class AllegationResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() label: string;
	@Expose() description: string;
	@Expose() incidentTypeCode: string;
	@Expose() classification: string;
	@Expose() outcome: string;
	@Expose() detailedAnalysis: string;
	@Expose() lossAmount: number;
	@Expose() recoveredAmount: number;
	@Expose() currency: string;
	@Expose() lossNotes: string;
	@Expose() outcomeConfirmed: boolean;
	@Expose() outcomeConfirmedBy: string;
	@Expose() outcomeConfirmedOn: Date;
	@Expose() allegationManagerId: string;
	@Expose() allegationManagerName: string;
	@Expose() sortOrder: number;
	@Expose() scopeReviewNeeded: boolean;
}

export class RecommendationItemResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() issueTitle: string;
	@Expose() issueDescription: string;
	@Expose() actionDetails: string;
	@Expose() implementationDeadline: string;
	@Expose() recommendationType: string;
	@Expose() recommendationOwner: string;
	@Expose() recommendationOwnerEmail: string;
	@Expose() status: string;
	@Expose() armsTransferred: boolean;
	@Expose() armsTransferredAt: Date;
	@Expose() sortOrder: number;
}

export class FraudRiskResponseDto {
	@Expose() id: number;
	@Expose() caseId: number;
	@Expose() riskCategory: string;
	@Expose() riskSubcategory: string;
	@Expose() riskDescription: string;
	@Expose() sortOrder: number;
}

export class CaseDetailResponseDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() irNumber: string;
	@ApiProperty() @Expose() businessUnit: string;
	@ApiPropertyOptional({ type: AssigneeRefResponseDto })
	@Expose()
	@Transform(({ value }) => parseAssignee(value))
	assignedTo: AssigneeRefResponseDto;
	@ApiProperty() @Expose() classification: string;
	@ApiProperty() @Expose() category: string;
	@ApiProperty() @Expose() primaryIssue: string;
	@ApiProperty()
	@Expose()
	@Transform(({ value }) => {
		if (!value) return [];
		if (Array.isArray(value)) return value;
		try { return JSON.parse(value); } catch { return []; }
	})
	secondaryIssues: string[];
	@ApiProperty() @Expose() dateOfReport: string;
	@ApiProperty() @Expose() currentStage: string;
	@ApiPropertyOptional() @Expose() rejectionReason: string;
	@ApiPropertyOptional() @Expose() overallAnalysisResult: string;
	@ApiPropertyOptional() @Expose() conclusion: string;
	@ApiPropertyOptional() @Expose() synopsis: string;
	@ApiPropertyOptional() @Expose() departmentOfAccused: string;
	@ApiPropertyOptional() @Expose() alertStatus: string;
	@ApiPropertyOptional() @Expose() fmfClassification: string;
	@ApiPropertyOptional() @Expose() investigationRequired: boolean;
	@ApiPropertyOptional() @Expose() noInvestigationReason: string;
	@ApiPropertyOptional({ type: AssigneeRefResponseDto })
	@Expose()
	@Transform(({ value }) => parseAssignee(value))
	caseLead: AssigneeRefResponseDto;
	@ApiPropertyOptional() @Expose() linkedIrNumber: string;
	@ApiPropertyOptional() @Expose() routingType: string;
	@ApiPropertyOptional() @Expose() posncdpqFlag: boolean;
	@ApiPropertyOptional() @Expose() remediationNotApplicable: boolean;
	@ApiPropertyOptional() @Expose() remediationConfirmedBy: string;
	@ApiPropertyOptional() @Expose() remediationConfirmedOn: Date;
	@ApiPropertyOptional() @Expose() recommendationsNotApplicable: boolean;
	@ApiPropertyOptional() @Expose() recommendationsConfirmedBy: string;
	@ApiPropertyOptional() @Expose() recommendationsConfirmedOn: Date;
	@ApiPropertyOptional() @Expose() isDeactivated: boolean;
	@ApiPropertyOptional() @Expose() deactivatedBy: string;
	@ApiPropertyOptional() @Expose() deactivatedOn: Date;
	@ApiPropertyOptional() @Expose() sourceType: string;
	@ApiPropertyOptional() @Expose() mode: string;
	@ApiPropertyOptional() @Expose() sourceDetails: string;

	@ApiPropertyOptional() @Expose() region: string;
	@ApiPropertyOptional() @Expose() country: string;
	@ApiPropertyOptional() @Expose() businessPillar: string;
	@ApiPropertyOptional() @Expose() businessVertical: string;
	@ApiPropertyOptional() @Expose() intakeChannel: string;
	@ApiPropertyOptional() @Expose() isAnonymous: boolean;

	@ApiPropertyOptional() @Expose() navexCaseId: number;
	@ApiPropertyOptional() @Expose() reportKey: string;
	@ApiPropertyOptional() @Expose() caseCreator: string;
	@ApiPropertyOptional() @Expose() intakeSpecialistName: string;
	@ApiPropertyOptional() @Expose() status: string;
	@ApiPropertyOptional() @Expose() daysOpen: number;
	@ApiPropertyOptional() @Expose() alertLevel: string;
	@ApiPropertyOptional() @Expose() dueDate: Date;
	@ApiPropertyOptional() @Expose() resolvedDate: Date;
	@ApiPropertyOptional() @Expose() reporterInputDisabledDate: Date;
	@ApiPropertyOptional() @Expose() allegedIncidentDate: Date;
	@ApiPropertyOptional() @Expose() caseType: string;
	@ApiPropertyOptional() @Expose() correctiveAction: string;
	@ApiPropertyOptional() @Expose() summary: string;
	@ApiPropertyOptional() @Expose() details: string;
	@ApiPropertyOptional() @Expose() translatedDetails: string;
	@ApiPropertyOptional() @Expose() language: string;
	@ApiPropertyOptional() @Expose() assignedTier: string;

	// Stored inside cases.location_data — flattened back out so the API contract, and the
	// Case Report panel's casePath mapping, stay unchanged. See migration 033.
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'organizationName')) organizationName: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'branchNumber')) branchNumber: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'address')) address: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'city')) city: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'state')) state: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('locationData', 'zip')) zip: string;
	@ApiPropertyOptional() @Expose() argusUniqueId: string;
	@ApiPropertyOptional() @Expose() incidentAddress: string;
	@ApiPropertyOptional() @Expose() isHotlineCase: boolean;
	@ApiPropertyOptional() @Expose() isContactCenter: boolean;
	@ApiPropertyOptional() @Expose() isDataPrivacy: boolean;
	@ApiPropertyOptional() @Expose() dataPrivacyReason: string;
	@ApiPropertyOptional() @Expose() dataPrivacyLocation: string;
	@ApiPropertyOptional() @Expose() isViolation: boolean;
	@ApiPropertyOptional() @Expose() isAssigneeOnly: boolean;
	@ApiPropertyOptional() @Expose() isEdited: boolean;
	@ApiPropertyOptional() @Expose() hasOriginal: boolean;
	@ApiPropertyOptional() @Expose() reporterMiddleName: string;
	@ApiPropertyOptional() @Expose() reporterCountry: string;
	@ApiPropertyOptional() @Expose() reporterBadge: string;

	// Stored inside cases.reporter_data, flattened out the same way as the location fields.
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterFirstName')) reporterFirstName: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterLastName')) reporterLastName: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterEmail')) reporterEmail: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterPhoneNumber')) reporterPhoneNumber: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterAvailability')) reporterAvailability: string;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterIsEmployee')) reporterIsEmployee: boolean;
	@ApiPropertyOptional() @Expose() @Transform(fromJson('reporterData', 'reporterIdCode')) reporterIdCode: string;
	@ApiPropertyOptional() @Expose() reporterFollowupCount: number;
	@ApiPropertyOptional() @Expose() userFollowupCount: number;
	@ApiPropertyOptional() @Expose() legacyCaseNumber: string;
	@ApiPropertyOptional() @Expose() legacyEnteredBy: string;
	@ApiPropertyOptional() @Expose() legacyEnteredDate: Date;
	@ApiPropertyOptional() @Expose() legacyClosedDate: Date;
	@ApiPropertyOptional() @Expose() legacyReceivedDate: Date;
	@ApiPropertyOptional() @Expose() partialReport: boolean;
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexParticipants: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexFiles: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexComments: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexCustomQuestions: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexRelatedCases: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexIssueTypeLayers: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexNotes: Record<string, unknown>[];
	@ApiPropertyOptional({ type: [Object] }) @Expose() navexFollowupQuestions: Record<string, unknown>[];

	@ApiPropertyOptional() @Expose() caseReportEdited: boolean;
	@ApiPropertyOptional() @Expose() caseReportSavedAt: Date;
	@ApiPropertyOptional() @Expose() caseReportSavedBy: string;

	@ApiProperty() @Expose() createdOn: Date;
	@ApiProperty() @Expose() createdBy: string;
	@ApiProperty() @Expose() updatedOn: Date;
	@ApiProperty() @Expose() updatedBy: string;

	@ApiProperty({ type: [ScopeItemResponseDto] })
	@Expose()
	@Type(() => ScopeItemResponseDto)
	scopeItems: ScopeItemResponseDto[];

	@ApiProperty({ type: [ProcedureResponseDto] })
	@Expose()
	@Type(() => ProcedureResponseDto)
	procedures: ProcedureResponseDto[];

	@ApiProperty({ type: [RemediationActionResponseDto] })
	@Expose()
	@Type(() => RemediationActionResponseDto)
	remediationActions: RemediationActionResponseDto[];

	@ApiPropertyOptional({ type: RecommendationResponseDto })
	@Expose()
	@Type(() => RecommendationResponseDto)
	recommendation: RecommendationResponseDto;

	@ApiProperty({ type: [RecommendationItemResponseDto] })
	@Expose()
	@Type(() => RecommendationItemResponseDto)
	recommendationItems: RecommendationItemResponseDto[];

	@ApiProperty({ type: [EvidenceResponseDto] })
	@Expose()
	@Type(() => EvidenceResponseDto)
	evidence: EvidenceResponseDto[];

	@ApiProperty({ type: [AllegationResponseDto] })
	@Expose()
	@Type(() => AllegationResponseDto)
	allegations: AllegationResponseDto[];

	@ApiProperty({ type: [FraudRiskResponseDto] })
	@Expose()
	@Type(() => FraudRiskResponseDto)
	fraudRisks: FraudRiskResponseDto[];
}
