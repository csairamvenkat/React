import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class TaskProcedureAssigneeDto {
	@ApiProperty() @Expose() permissionId: number;
	@ApiProperty() @Expose() userId: string;
	@ApiProperty() @Expose() userName: string;
	@ApiProperty() @Expose() userEmail: string;
	@ApiProperty() @Expose() canModify: boolean;
}

export class TaskProcedureResponseDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() description: string;
	@ApiPropertyOptional() @Expose() actionBy: string | null;
	@ApiPropertyOptional() @Expose() actionByEmail: string | null;
	@ApiPropertyOptional() @Expose() deadline: string | null;
	@ApiProperty() @Expose() status: string;
	@ApiPropertyOptional() @Expose() workPerformed: string | null;
	@ApiPropertyOptional() @Expose() completedDate: string | Date | null;
	@ApiProperty() @Expose() createdBy: string;
	@ApiPropertyOptional() @Expose() addedByRole: string | null;
	@ApiProperty() @Expose() canDelete: boolean;
	@ApiProperty({ type: [TaskProcedureAssigneeDto] }) @Expose() assignees: TaskProcedureAssigneeDto[];
}
