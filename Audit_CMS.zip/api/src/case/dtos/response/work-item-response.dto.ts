import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { AssignmentTaskStatus, AssignmentType } from '../../enums';

export class WorkItemResponseDto {
	@ApiProperty({ description: 'Id of the allegation, procedure or recommendation item itself.' })
	@Expose()
	id: number;

	@ApiProperty()
	@Expose()
	caseId: number;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	irNumber: string | null;

	@ApiProperty({ enum: AssignmentType })
	@Expose()
	assignmentType: AssignmentType;

	@ApiProperty()
	@Expose()
	title: string;

	@ApiProperty({ enum: AssignmentTaskStatus })
	@Expose()
	status: AssignmentTaskStatus;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	assigneeName: string | null;

	@ApiPropertyOptional({
		nullable: true,
		description: 'Allegations only; null for other work types.',
	})
	@Expose()
	classification: string | null;

	@ApiPropertyOptional({
		nullable: true,
		description: 'Allegations only; null for other work types.',
	})
	@Expose()
	incidentTypeCode: string | null;

	@ApiProperty()
	@Expose()
	assignedToMe: boolean;

	@ApiProperty()
	@Expose()
	createdBy: string;

	@ApiProperty()
	@Expose()
	createdOn: Date;
}

export class WorkItemPaginatedResponseDto {
	@ApiProperty({ type: [WorkItemResponseDto] })
	records: WorkItemResponseDto[];

	@ApiProperty()
	total: number;
}

/** Per-type counts for the work-type tabs, under every filter but the status one. */
export class WorkStatsResponseDto {
	@ApiProperty()
	@Expose()
	allegations: number;

	@ApiProperty()
	@Expose()
	procedures: number;

	@ApiProperty()
	@Expose()
	recommendations: number;
}
