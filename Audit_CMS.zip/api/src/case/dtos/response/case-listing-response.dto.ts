import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { parseAssignee } from 'src/shared/helpers';
import { CaseTriageSection } from '../../enums';
import { AssigneeRefResponseDto } from './case-detail-response.dto';

export class CaseListingResponseDto {
	@ApiProperty()
	@Expose()
	id: number;

	@ApiProperty()
	@Expose()
	irNumber: string;

	@ApiProperty()
	@Expose()
	businessUnit: string;

	@ApiPropertyOptional({ type: AssigneeRefResponseDto })
	@Expose()
	@Transform(({ value }) => parseAssignee(value))
	assignedTo: AssigneeRefResponseDto;

	@ApiPropertyOptional({ type: AssigneeRefResponseDto })
	@Expose()
	@Transform(({ value }) => parseAssignee(value))
	caseLead: AssigneeRefResponseDto;

	@ApiProperty()
	@Expose()
	classification: string;

	@ApiProperty()
	@Expose()
	category: string;

	@ApiProperty()
	@Expose()
	primaryIssue: string;

	@ApiProperty()
	@Expose()
	dateOfReport: string;

	@ApiPropertyOptional()
	@Expose()
	sourceType: string;

	@ApiPropertyOptional()
	@Expose()
	mode: string;

	@ApiPropertyOptional()
	@Expose()
	sourceDetails: string;

	@ApiProperty()
	@Expose()
	currentStage: string;

	@ApiPropertyOptional()
	@Expose()
	status: string;

	@ApiProperty({ required: false, nullable: true })
	@Expose()
	alertStatus: string;

	@ApiProperty({ required: false })
	@Expose()
	posncdpqFlag: boolean;

	@ApiPropertyOptional()
	@Expose()
	isDeactivated: boolean;

	@ApiProperty()
	@Expose()
	createdOn: Date;

	@ApiProperty()
	@Expose()
	createdBy: string;

	@ApiProperty()
	@Expose()
	updatedOn: Date;

	/** Null for a case created in the CMS — it has no Navex mirror row to sync from. */
	@ApiPropertyOptional({ nullable: true })
	@Expose()
	lastSyncedOn: Date | null;

	@ApiPropertyOptional({ enum: CaseTriageSection, nullable: true })
	@Expose()
	triageSection: CaseTriageSection | null;

	@ApiPropertyOptional()
	@Expose()
	hfrsApprovalPending: boolean;
}

export class CasePaginatedListingResponseDto {
	@ApiProperty({ type: [CaseListingResponseDto] })
	records: CaseListingResponseDto[];

	@ApiProperty()
	total: number;
}
