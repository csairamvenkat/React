import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CaseApproverResponseDto {
	@ApiProperty({ description: 'UPN/login id used as the task assignee' })
	@Expose()
	userUpn: string;

	@ApiPropertyOptional()
	@Expose()
	userName: string;

	@ApiPropertyOptional()
	@Expose()
	userEmail: string;

	@ApiPropertyOptional()
	@Expose()
	userJobTitle: string;
}
