import { ApiProperty } from '@nestjs/swagger';

export class CaseStatsResponseDto {
	@ApiProperty({ description: 'Cases matching the current filters and access scope' })
	totalCases: number;

	@ApiProperty({ description: 'Anything not yet Closed' })
	inProgress: number;

	@ApiProperty()
	closed: number;

	@ApiProperty({
		description:
			"Cases still at Navex's 'Unreviewed' record status — cases.status, not the CMS lifecycle stage",
	})
	unreviewed: number;

	@ApiProperty({ description: "Cases classified 'Fraud'" })
	fraudCount: number;

	@ApiProperty({ description: "Cases classified 'Non-Fraud'" })
	nonFraudCount: number;

	@ApiProperty({ description: 'Cases with no classification yet — imported cases arrive this way' })
	unclassifiedCount: number;
}
