import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CaseReportResponseDto {
	@ApiProperty() @Expose() caseId: number;

	@ApiPropertyOptional() @Expose() navexCaseId: string | null;

	@ApiProperty() @Expose() isEdited: boolean;
	@ApiPropertyOptional() @Expose() lastSavedAt: string | null;
	@ApiPropertyOptional() @Expose() lastSavedBy: string | null;
	@ApiPropertyOptional() @Expose() importedOn: string | null;
}
