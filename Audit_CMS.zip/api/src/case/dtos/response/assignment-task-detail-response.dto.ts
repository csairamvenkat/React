import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { AllegationOutcome, AssignmentTaskStatus, AssignmentType } from '../../enums';

export class TaskAllegationResultDto {
	@ApiPropertyOptional({ enum: AllegationOutcome, nullable: true })
	@Expose()
	outcome: AllegationOutcome | null;

	@ApiPropertyOptional({ nullable: true }) @Expose() detailedAnalysis: string | null;
	@ApiPropertyOptional({ nullable: true }) @Expose() lossAmount: number | null;
	@ApiPropertyOptional({ nullable: true }) @Expose() recoveredAmount: number | null;
	@ApiPropertyOptional({ nullable: true }) @Expose() currency: string | null;
	@ApiPropertyOptional({ nullable: true }) @Expose() lossNotes: string | null;

	@ApiProperty({ description: 'Set by the Case Lead. A confirmed outcome is read-only here.' })
	@Expose()
	outcomeConfirmed: boolean;

	@ApiPropertyOptional({ nullable: true }) @Expose() outcomeConfirmedBy: string | null;
	@ApiPropertyOptional({ nullable: true }) @Expose() outcomeConfirmedOn: Date | null;
}

export class TaskAttachmentDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() fileName: string;
	@ApiProperty() @Expose() category: string;
	@ApiPropertyOptional({ nullable: true }) @Expose() description: string | null;
	@ApiProperty() @Expose() uploadedBy: string;
	@ApiProperty() @Expose() createdOn: Date;
}

export class AssignedProcedureDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() description: string;
	@ApiPropertyOptional() @Expose() deadline: string | null;
	@ApiProperty() @Expose() status: string;
	@ApiPropertyOptional() @Expose() workPerformed: string | null;
	@ApiPropertyOptional() @Expose() completedDate: string | Date | null;
}

export class AssignedRecommendationDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() issueTitle: string;
	@ApiPropertyOptional() @Expose() actionDetails: string | null;
	@ApiPropertyOptional() @Expose() implementationDeadline: string | null;
	@ApiProperty() @Expose() status: string;
	@ApiPropertyOptional() @Expose() implementationNotes: string | null;
}

export class TaskScopeItemDto {
	@ApiProperty()
	@Expose()
	id: number;

	@ApiProperty()
	@Expose()
	description: string;

	@ApiProperty()
	@Expose()
	createdBy: string;

	@ApiPropertyOptional({
		nullable: true,
		description: 'Case Lead / FRS / Allegation Manager — who added the item.',
	})
	@Expose()
	addedByRole: string | null;

	@ApiProperty({ description: 'Whether the caller may delete this item.' })
	@Expose()
	canDelete: boolean;
}

export class AssignmentTaskDetailResponseDto {
	@ApiProperty()
	@Expose()
	id: number;

	@ApiProperty()
	@Expose()
	caseId: number;

	@ApiProperty({ enum: AssignmentType })
	@Expose()
	assignmentType: AssignmentType;

	@ApiPropertyOptional()
	@Expose()
	allegationId: number | null;

	@ApiPropertyOptional()
	@Expose()
	incidentTypeCode: string | null;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	irNumber: string | null;

	@ApiPropertyOptional()
	@Expose()
	classification: string | null;

	@ApiPropertyOptional({ type: AssignedProcedureDto })
	@Expose()
	procedure: AssignedProcedureDto | null;

	@ApiPropertyOptional({ type: AssignedRecommendationDto })
	@Expose()
	recommendation: AssignedRecommendationDto | null;

	@ApiProperty({ enum: AssignmentTaskStatus })
	@Expose()
	status: AssignmentTaskStatus;

	@ApiProperty()
	@Expose()
	title: string;

	@ApiPropertyOptional()
	@Expose()
	description: string | null;

	@ApiProperty()
	@Expose()
	canDelegate: boolean;

	@ApiProperty({ description: 'False when the caller is only viewing work assigned to someone else.' })
	@Expose()
	canAct: boolean;

	@ApiProperty({
		description:
			'False on a Fraud allegation for anyone other than FRS / the Case Lead — its scope of work is theirs to define. An FRS member who is also the Allegation Manager keeps it true.',
	})
	@Expose()
	canWriteScope: boolean;

	@ApiProperty({ type: [TaskScopeItemDto] })
	@Expose()
	scopeOfWork: TaskScopeItemDto[];

	@ApiPropertyOptional({
		type: TaskAllegationResultDto,
		description: 'Report Results for the assigned allegation. Null on any other kind of task.',
	})
	@Expose()
	result: TaskAllegationResultDto | null;

	@ApiProperty({
		type: [TaskAttachmentDto],
		description: "Supporting attachments on the assigned allegation — never the whole case's.",
	})
	@Expose()
	attachments: TaskAttachmentDto[];

	@ApiProperty({
		description:
			'False once the Case Lead has confirmed the outcome, or the case is closed or deactivated.',
	})
	@Expose()
	canWriteResults: boolean;

	@ApiPropertyOptional()
	@Expose()
	role: string | null;

	@ApiProperty({ type: [String] })
	@Expose()
	sections: string[];

	@ApiPropertyOptional()
	@Expose()
	assigneeName: string | null;

	@ApiProperty()
	@Expose()
	assignedBy: string;

	@ApiProperty()
	@Expose()
	assignedOn: Date;

	@ApiPropertyOptional()
	@Expose()
	redelegatedFromUserId: string | null;
}
