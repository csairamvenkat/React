import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CaseUserPermissionResponseDto {
	@ApiProperty() @Expose() id: number;
	@ApiProperty() @Expose() caseId: number;
	@ApiProperty() @Expose() userId: string;
	@ApiPropertyOptional() @Expose() userName: string;
	@ApiPropertyOptional() @Expose() userEmail: string;
	@ApiPropertyOptional() @Expose() role: string;
	@ApiPropertyOptional() @Expose() sourceType: string | null;
	@ApiPropertyOptional() @Expose() sourceId: number | null;
	@ApiProperty({ type: [String] }) @Expose() sections: string[];
}
