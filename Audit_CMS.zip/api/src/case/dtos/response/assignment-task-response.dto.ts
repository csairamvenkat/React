import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { AssignmentTaskStatus, AssignmentType } from '../../enums';

export class AssignmentTaskResponseDto {
	@ApiProperty()
	@Expose()
	id: number;

	@ApiProperty()
	@Expose()
	caseId: number;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	irNumber: string | null;

	@ApiProperty({ enum: AssignmentType })
	@Expose()
	assignmentType: AssignmentType;

	@ApiProperty()
	@Expose()
	sourceId: number;

	@ApiProperty()
	@Expose()
	title: string;

	@ApiProperty({ enum: AssignmentTaskStatus })
	@Expose()
	status: AssignmentTaskStatus;

	@ApiPropertyOptional()
	@Expose()
	assigneeName: string | null;

	@ApiPropertyOptional({
		nullable: true,
		description: 'Allegations only; null for other work types.',
	})
	@Expose()
	classification: string | null;

	@ApiPropertyOptional({
		nullable: true,
		description: 'Allegations only; null for other work types.',
	})
	@Expose()
	incidentTypeCode: string | null;

	@ApiProperty()
	@Expose()
	createdBy: string;

	@ApiPropertyOptional({ nullable: true })
	@Expose()
	createdByName: string | null;

	@ApiProperty()
	@Expose()
	createdOn: Date;
}
