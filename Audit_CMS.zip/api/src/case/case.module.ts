import { Module } from '@nestjs/common';
import { SharedModule } from 'src/shared/shared.module';
import { CaseController } from './controllers';
import { CaseService, AuditLogService, CaseAssignmentTaskService, CaseApprovalTaskService, CaseNotificationService } from './services';
import {
	CaseRepository,
	CaseScopeItemRepository,
	CaseProcedureRepository,
	CaseResultRepository,
	CaseRemediationActionRepository,
	CaseRecommendationRepository,
	CaseRecommendationItemRepository,
	CaseEvidenceRepository,
	CaseAllegationRepository,
	CaseFraudRiskRepository,
	CaseUserPermissionRepository,
	CaseWorkItemRepository,
} from './repositories';

const repositories = [
	CaseRepository,
	CaseScopeItemRepository,
	CaseProcedureRepository,
	CaseResultRepository,
	CaseRemediationActionRepository,
	CaseRecommendationRepository,
	CaseRecommendationItemRepository,
	CaseEvidenceRepository,
	CaseAllegationRepository,
	CaseFraudRiskRepository,
	CaseUserPermissionRepository,
	CaseWorkItemRepository,
];

const services = [
	CaseService,
	AuditLogService,
	CaseAssignmentTaskService,
	CaseApprovalTaskService,
	CaseNotificationService,
];

@Module({
	imports: [SharedModule],
	controllers: [CaseController],
	providers: [...services, ...repositories],
	exports: [...services, ...repositories],
})
export class CaseModule {}
