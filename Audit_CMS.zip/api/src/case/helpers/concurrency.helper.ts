export async function mapWithConcurrency<TIn, TOut>(
	items: readonly TIn[],
	limit: number,
	worker: (item: TIn, index: number) => Promise<TOut>,
): Promise<TOut[]> {
	if (items.length === 0) return [];

	const results = new Array<TOut>(items.length);
	const workerCount = Math.max(1, Math.min(limit, items.length));
	let next = 0;

	const runners = Array.from({ length: workerCount }, async () => {
		while (true) {
			const index = next++;
			if (index >= items.length) return;
			results[index] = await worker(items[index], index);
		}
	});

	await Promise.all(runners);
	return results;
}
