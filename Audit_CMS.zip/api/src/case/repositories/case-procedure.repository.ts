import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseProcedure } from '../models';
import { ProcedureStatus } from '../enums/procedure-status.enum';

@Injectable()
export class CaseProcedureRepository extends BaseRepository<CaseProcedure> {
	constructor() {
		super(CaseProcedure);
	}

	public async getByCaseId(caseId: number): Promise<CaseProcedure[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseProcedure | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createProcedure(data: Partial<CaseProcedure>, currentContext: CurrentContext): Promise<CaseProcedure> {
		return this.save(data as CaseProcedure, currentContext);
	}

	public async updateProcedure(id: number, data: Partial<CaseProcedure>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteProcedure(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}

	public async getByIds(ids: number[]): Promise<CaseProcedure[]> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return [];
		return this.findAll({ where: { id: { [Op.in]: unique }, deleted: false } });
	}

	public async getByAllegationId(allegationId: number): Promise<CaseProcedure[]> {
		return this.getByAllegationIds([allegationId]);
	}

	public async getByAllegationIds(allegationIds: number[]): Promise<CaseProcedure[]> {
		const unique = [...new Set(allegationIds.map(Number).filter(Boolean))];
		if (unique.length === 0) return [];
		return this.findAll({
			where: { allegationId: { [Op.in]: unique }, deleted: false },
			order: [['sortOrder', 'ASC']],
		});
	}

	public async getOutstandingProcedures(
		filter: { caseId?: number; actionBy?: string } = {},
	): Promise<CaseProcedure[]> {
		const where: any = { status: ProcedureStatus.PENDING, deleted: false };
		if (filter.caseId) where.caseId = filter.caseId;
		if (filter.actionBy) where.actionBy = { [Op.iLike]: filter.actionBy };
		return this.findAll({ where });
	}

	public async getCompletedByActionUser(username: string): Promise<CaseProcedure[]> {
		return this.findAll({
			where: {
				deleted: false,
				status: ProcedureStatus.COMPLETE,
				actionByUserId: { [Op.iLike]: username },
			},
		});
	}
}
