import { Injectable } from '@nestjs/common';
import { Op, literal } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { Case, CaseScopeItem, CaseProcedure, CaseRemediationAction, CaseRecommendation, CaseRecommendationItem, CaseEvidence, CaseAllegation, CaseFraudRisk } from '../models';
import { CaseClassification, CaseListPreset, CaseStatus, CaseTriageSection } from '../enums';
import { CaseListFilterRequestDto } from '../dtos';
import {
	CASE_RECORD_STATUS_CLOSED,
	CASE_RECORD_STATUS_UNREVIEWED,
	isCaseClosed,
} from '../constants/case.constant';

export interface CaseRef {
	irNumber: string | null;
	businessUnit: string | null;
	classification: CaseClassification | null;
}

const SEARCH_FIELD_COLUMNS: Record<string, string[]> = {
	caseNumber: ['irNumber'],
	businessUnit: ['businessUnit'],
	primaryIssue: ['primaryIssue'],
	caseAssignees: ['assignedTo', 'caseLead'],
	synopsis: ['synopsis'],
	summary: ['conclusion'],
	reportingNumber: ['linkedIrNumber'],
	details: ['sourceDetails'],
};

function schemaPrefix(): string {
	const dbSchema: string | undefined = (Case as any).sequelize?.options?.schema;
	return dbSchema ? `"${dbSchema}".` : '';
}

function assigneeIs(field: 'assignedTo' | 'caseLead', email: string) {
	return {
		[Op.or]: [
			{ [field]: { [Op.iLike]: email } },
			{ [field]: { [Op.iLike]: `%"email_id":"${email}"%` } },
		],
	};
}

function dateOnly(d: Date): string {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export const CASE_LIST_SORT_COLUMNS = [
	'updatedOn',
	'createdOn',
	'dateOfReport',
	'irNumber',
	'lastSyncedOn',
] as const;
export type CaseListSortBy = (typeof CASE_LIST_SORT_COLUMNS)[number];

/**
 * When the sync last refreshed this case's Navex mirror row.
 *
 * It lives on `navex_case_reports`, not on `cases`: the mirror stamps `last_synced_on` on
 * every run, while the `cases` upsert only writes when a follow-up actually changed — so
 * `cases.updated_on` is a different fact and would answer "last synced" wrongly. A
 * correlated subquery on the mirror's primary key is one index lookup per row and adds no
 * join, which leaves findAndCountAll's COUNT query and the access scoping untouched.
 */
function lastSyncedOnSql(): string {
	return `(SELECT r.last_synced_on FROM ${schemaPrefix()}"navex_case_reports" r WHERE r.id = "Case".navex_case_id)`;
}

function allegationsCompleteSql(): string {
	const allegations = `${schemaPrefix()}"case_allegations" a WHERE a.case_id = "Case".id AND a.deleted = false`;

	return `(EXISTS (SELECT 1 FROM ${allegations})
		AND NOT EXISTS (SELECT 1 FROM ${allegations} AND COALESCE(a.classification, '') = ''))`;
}

function allegationsReadySql(): string {
	return `(CASE WHEN "Case".current_stage = '${CaseStatus.CASE_CREATED}' THEN ${allegationsCompleteSql()} END)`;
}

const IN_TRIAGE_SQL = `("Case".current_stage = '${CaseStatus.CASE_CREATED}' AND "Case".status IS DISTINCT FROM '${CASE_RECORD_STATUS_CLOSED}')`;

/** The classification choices that raise an HFRS approval task, mirroring CaseService._pathwayTaskType. */
const HFRS_PATHWAY_SQL = `("Case".investigation_required IS FALSE OR ("Case".investigation_required IS TRUE AND "Case".classification = '${CaseClassification.FRAUD}'))`;

/**
 * Whether a case without an HFRS pathway has left Case Classification is decided by its columns
 * alone; one on the pathway depends on its task's status in the Task API, so the caller resolves
 * those upstream and passes the matching ids in.
 */
function triageSectionCondition(filters: CaseListFilterRequestDto, hfrsPathwayMatchIds: number[]): any {
	if (filters.triageSection === CaseTriageSection.ALLEGATIONS) {
		return filters.hfrsApprovalPending
			? literal('FALSE')
			: { [Op.and]: [literal(IN_TRIAGE_SQL), literal(`NOT ${allegationsCompleteSql()}`)] };
	}

	const withoutHfrsPathway =
		filters.triageSection === CaseTriageSection.FINALIZATION
			? `("Case".investigation_required IS TRUE AND "Case".classification IS DISTINCT FROM '${CaseClassification.FRAUD}')`
			: `("Case".investigation_required IS NULL)`;
	const matches: any[] = [{ id: { [Op.in]: hfrsPathwayMatchIds } }];
	if (!filters.hfrsApprovalPending) matches.push(literal(withoutHfrsPathway));

	return {
		[Op.and]: [literal(IN_TRIAGE_SQL), literal(allegationsCompleteSql()), { [Op.or]: matches }],
	};
}

/**
 * IR numbers arrive from Navex as bare digit strings ("1820", "3064"), so a plain text sort
 * puts "1000" ahead of "999". Ordering on the digits as a number fixes that; the raw string
 * is the tiebreaker and carries any hand-entered CMS IR number with no digits at all.
 */
const IR_NUMBER_NUMERIC_SQL = `NULLIF(regexp_replace("Case".ir_number, '[^0-9]', '', 'g'), '')::numeric`;

function resolveCaseListSort(sortBy?: string, sortDir?: string): any[] {
	const column = (CASE_LIST_SORT_COLUMNS as readonly string[]).includes(sortBy ?? '')
		? (sortBy as string)
		: 'lastSyncedOn';
	const direction = sortDir === 'asc' ? 'ASC' : 'DESC';

	// A case created in the CMS has no mirror row, and one with a purely alphabetic IR number
	// has no digits — either way it sorts to the end rather than crowding the top of the list.
	if (column === 'lastSyncedOn') {
		return [literal(`${lastSyncedOnSql()} ${direction} NULLS LAST`), ['id', direction]];
	}
	if (column === 'irNumber') {
		return [literal(`${IR_NUMBER_NUMERIC_SQL} ${direction} NULLS LAST`), ['irNumber', direction]];
	}

	// Id breaks ties so a page boundary can't shuffle rows sharing a timestamp, matching the
	// tiebreakers the lastSyncedOn and irNumber branches above already carry.
	return [
		[column, direction],
		['id', direction],
	];
}

function presetCondition(preset: CaseListPreset): any {
	const now = new Date();
	const start = new Date(now.getFullYear(), now.getMonth(), 1);
	const end = new Date(now.getFullYear(), now.getMonth() + 1, 1);
	const inMonth = { [Op.gte]: start, [Op.lt]: end };
	const inMonthDateOnly = { [Op.gte]: dateOnly(start), [Op.lt]: dateOnly(end) };

	switch (preset) {
		case CaseListPreset.OPEN:
			// `status` is nullable, so an inequality alone would drop every case that has none.
			return {
				[Op.or]: [{ status: { [Op.ne]: CASE_RECORD_STATUS_CLOSED } }, { status: null }],
			};
		case CaseListPreset.NEW_THIS_MONTH:
			return { [Op.or]: [{ createdOn: inMonth }, { dateOfReport: inMonthDateOnly }] };
		case CaseListPreset.CLOSED_THIS_MONTH:
			return { [Op.and]: [{ status: CASE_RECORD_STATUS_CLOSED }, { closedOn: inMonth }] };
		default:
			return null;
	}
}

@Injectable()
export class CaseRepository extends BaseRepository<Case> {
	constructor() {
		super(Case);
	}

	public async getCaseById(id: number): Promise<Case | null> {
		return this.findById(id);
	}

	public async getCaseByIdWithRelations(id: number): Promise<Case | null> {
		const childCollection = (model: any, as: string, order: [string, string]) => ({
			model,
			as,
			where: { deleted: false },
			required: false,
			separate: true,
			order: [order],
		});

		return this.findOne({
			where: { id, deleted: false },
			include: [
				childCollection(CaseScopeItem, 'scopeItems', ['sortOrder', 'ASC']),
				childCollection(CaseProcedure, 'procedures', ['sortOrder', 'ASC']),
				childCollection(CaseRemediationAction, 'remediationActions', ['sortOrder', 'ASC']),
				{ model: CaseRecommendation, as: 'recommendation', where: { deleted: false }, required: false },
				childCollection(CaseRecommendationItem, 'recommendationItems', ['sortOrder', 'ASC']),
				childCollection(CaseEvidence, 'evidence', ['createdOn', 'DESC']),
				childCollection(CaseAllegation, 'allegations', ['sortOrder', 'ASC']),
				childCollection(CaseFraudRisk, 'fraudRisks', ['sortOrder', 'ASC']),
			],
		});
	}

	private buildCaseListCondition(
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
		hfrsPathwayMatchIds: number[] = [],
	): any[] {
		const filterCondition: any[] = [{ deleted: false }];

		if (filters?.classification) {
			filterCondition.push({ classification: filters.classification });
		}
		if (filters?.currentStage) {
			filterCondition.push({ currentStage: filters.currentStage });
		}
		if (filters?.triageSection) {
			filterCondition.push(triageSectionCondition(filters, hfrsPathwayMatchIds));
		}
		if (filters?.sourceType) {
			filterCondition.push({ sourceType: filters.sourceType });
		}
		if (filters?.mode) {
			filterCondition.push({ mode: filters.mode });
		}
		if (filters?.status) {
			filterCondition.push({ status: filters.status });
		}
		if (filters?.preset) {
			const condition = presetCondition(filters.preset);
			if (condition) filterCondition.push(condition);
		}
		if (filters?.assignedTo) {
			filterCondition.push({ assignedTo: { [Op.iLike]: `%${filters.assignedTo}%` } });
		}
		if (filters?.businessUnit) {
			filterCondition.push({ businessUnit: { [Op.iLike]: `%${filters.businessUnit}%` } });
		}
		if (filters?.onlyDeactivated) {
			filterCondition.push({ isDeactivated: true });
		}
		if (filters?.myCasesOnly && currentUsername) {
			const quotedUser = this.quote(currentUsername);
			const s = schemaPrefix();
			filterCondition.push({
				[Op.or]: [
					{ createdBy: { [Op.iLike]: currentUsername } },
					assigneeIs('assignedTo', currentUsername),
					{
						[Op.and]: [
							assigneeIs('caseLead', currentUsername),
							literal(`(NOT EXISTS (
								SELECT 1 FROM ${s}"case_tasks" ct
								WHERE ct.case_id = "Case".id
								AND ct.task_type = 'hfrs_fraud_investigation'
								AND ct.status != 'Approved'
								AND ct.deleted = false
							))`),
						],
					},
					literal(`(EXISTS (
						SELECT 1 FROM ${s}"case_user_permissions" cup
						WHERE cup.case_id = "Case".id
						AND LOWER(cup.user_id) = LOWER(${quotedUser})
						AND cup.source_type IS NULL
						AND cup.deleted = false
					))`),
				],
			});
		}

		if (searchTerm) {
			const requested = (filters?.searchFields ?? []).filter(key => SEARCH_FIELD_COLUMNS[key]);
			const activeKeys = requested.length ? requested : Object.keys(SEARCH_FIELD_COLUMNS);
			const columns = [...new Set(activeKeys.flatMap(key => SEARCH_FIELD_COLUMNS[key]))];
			filterCondition.push({
				[Op.or]: columns.map(column => ({ [column]: { [Op.iLike]: `%${searchTerm}%` } })),
			});
		}

		return filterCondition;
	}

	public getPaginatedCases(
		limit: number,
		page: number,
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
		sortBy?: string,
		sortDir?: string,
		hfrsPathwayMatchIds?: number[],
	): Promise<{ rows: Case[]; count: number }> {
		return this.findAndCountAll({
			where: {
				[Op.and]: this.buildCaseListCondition(searchTerm, filters, currentUsername, hfrsPathwayMatchIds),
			},
			// Carried on every row, not just when sorting by it, so the card can show the value
			// the sort is ordering on.
			attributes: {
				include: [
					[literal(lastSyncedOnSql()), 'lastSyncedOn'],
					[literal(allegationsReadySql()), 'allegationsReady'],
				],
			},
			...(page && limit && { offset: (page - 1) * limit }),
			...(limit && { limit }),
			order: resolveCaseListSort(sortBy, sortDir),
		});
	}

	/** Triage cases on an HFRS pathway, whose section needs their approval tasks to resolve. */
	public getHfrsPathwayTriageCases(
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
	): Promise<(Case & { allegationsReady: boolean })[]> {
		const unsectioned = { ...filters, triageSection: undefined, hfrsApprovalPending: undefined };

		return this.findAll({
			where: {
				[Op.and]: [
					...this.buildCaseListCondition(searchTerm, unsectioned, currentUsername),
					literal(IN_TRIAGE_SQL),
					literal(allegationsCompleteSql()),
					literal(HFRS_PATHWAY_SQL),
				],
			},
			attributes: [
				'id',
				'currentStage',
				'status',
				'classification',
				'investigationRequired',
				'caseLead',
				'approvalTaskIds',
				[literal('TRUE'), 'allegationsReady'],
			],
		});
	}

	public async getCaseStats(
		searchTerm?: string,
		filters?: CaseListFilterRequestDto,
		currentUsername?: string,
		hfrsPathwayMatchIds?: number[],
	): Promise<CaseStatsRow> {
		const [row] = await this.model.findAll({
			where: {
				[Op.and]: this.buildCaseListCondition(searchTerm, filters, currentUsername, hfrsPathwayMatchIds),
			},
			attributes: [
				[literal('COUNT(*)::int'), 'totalCases'],
				[literal(`COUNT(*) FILTER (WHERE status = '${CASE_RECORD_STATUS_CLOSED}')::int`), 'closed'],
				[
					literal(
						`COUNT(*) FILTER (WHERE status IS DISTINCT FROM '${CASE_RECORD_STATUS_CLOSED}')::int`,
					),
					'inProgress',
				],
				// Navex's own record status on cases.status, not the CMS lifecycle stage the counts
				// either side of this one are built from.
				[
					literal(`COUNT(*) FILTER (WHERE status = '${CASE_RECORD_STATUS_UNREVIEWED}')::int`),
					'unreviewed',
				],
				[literal(`COUNT(*) FILTER (WHERE classification = '${CaseClassification.FRAUD}')::int`), 'fraudCount'],
				[
					literal(`COUNT(*) FILTER (WHERE classification = '${CaseClassification.NON_FRAUD}')::int`),
					'nonFraudCount',
				],
				// Counted separately rather than folded into Non-Fraud: an imported case arrives with no
				// classification at all, and "everything that is not Fraud" reports the entire untriaged
				// backlog as cleared.
				[literal(`COUNT(*) FILTER (WHERE COALESCE(classification, '') = '')::int`), 'unclassifiedCount'],
			],
			raw: true,
		});

		return {
			totalCases: Number((row as any)?.totalCases ?? 0),
			inProgress: Number((row as any)?.inProgress ?? 0),
			closed: Number((row as any)?.closed ?? 0),
			unreviewed: Number((row as any)?.unreviewed ?? 0),
			fraudCount: Number((row as any)?.fraudCount ?? 0),
			nonFraudCount: Number((row as any)?.nonFraudCount ?? 0),
			unclassifiedCount: Number((row as any)?.unclassifiedCount ?? 0),
		};
	}

	public async findDuplicateCandidates(criteria: DuplicateCheckCriteria): Promise<Case[]> {
		const { excludeId, businessUnit, primaryIssue, incidentTypeCodes, allegationDescriptions } =
			criteria;
		const s = schemaPrefix();
		const anyOf: any[] = [];

		if (businessUnit) anyOf.push({ businessUnit });
		if (primaryIssue) anyOf.push({ primaryIssue });

		const allegationExists = (predicate: string, values: string[]) =>
			literal(`(EXISTS (
				SELECT 1 FROM ${s}"case_allegations" ca
				WHERE ca.case_id = "Case".id
				  AND ca.deleted = false
				  AND ${predicate} IN (${values.map(v => this.quote(v)).join(', ')})
			))`);

		if (incidentTypeCodes.length > 0) {
			anyOf.push(allegationExists('ca.incident_type_code', incidentTypeCodes));
		}
		if (allegationDescriptions.length > 0) {
			anyOf.push(allegationExists('LOWER(TRIM(ca.description))', allegationDescriptions));
		}

		if (anyOf.length === 0) return [];

		return this.findAll({
			where: { id: { [Op.ne]: excludeId }, deleted: false, [Op.or]: anyOf },
			include: [
				{
					model: CaseAllegation,
					as: 'allegations',
					where: { deleted: false },
					required: false,
					separate: true,
				},
			],
			order: [['createdOn', 'DESC']],
		});
	}

	private quote(value: string): string {
		return `'${String(value).replace(/'/g, "''")}'`;
	}

	public async getApprovalTaskIds(caseId: number): Promise<number[]> {
		const record = await this.findOne({ where: { id: caseId, deleted: false }, attributes: ['approvalTaskIds'] });
		return this.parseApprovalTaskIds(record?.approvalTaskIds);
	}

	public async getAllApprovalTaskIds(): Promise<number[]> {
		const rows = await this.findAll(
			{
				where: { deleted: false, approvalTaskIds: { [Op.ne]: null } },
				attributes: ['approvalTaskIds'],
				raw: true,
			},
			{ includeDeleted: false, includeInactive: false, throwException: false },
		);
		return (rows as { approvalTaskIds: unknown }[]).flatMap(r =>
			this.parseApprovalTaskIds(r.approvalTaskIds),
		);
	}

	public async getActiveCaseRefs(ids: number[]): Promise<Map<number, CaseRef>> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return new Map();
		const rows = await this.findAll(
			{
				where: { id: { [Op.in]: unique }, deleted: false },
				attributes: ['id', 'irNumber', 'businessUnit', 'classification'],
				raw: true,
			},
			{ includeDeleted: false, includeInactive: false, throwException: false },
		);
		return new Map(
			(rows as (Partial<CaseRef> & { id: number })[]).map(r => [
				Number(r.id),
				{
					irNumber: r.irNumber ?? null,
					businessUnit: r.businessUnit ?? null,
					classification: r.classification ?? null,
				},
			]),
		);
	}

	public async addApprovalTaskId(caseId: number, taskId: number, currentContext: CurrentContext): Promise<void> {
		const id = Number(taskId);
		if (!id) return;
		const instance = await this.model.findOne({ where: { id: caseId, deleted: false } });
		if (!instance) return;
		const current = this.parseApprovalTaskIds(instance.approvalTaskIds);
		if (current.includes(id)) return;
		instance.approvalTaskIds = JSON.stringify([...current, id]);
		instance.updatedBy = (currentContext?.user?.username ?? 'system').toLowerCase();
		await instance.save();
	}

	public parseApprovalTaskIds(raw: unknown): number[] {
		if (!raw) return [];
		if (Array.isArray(raw)) return raw.map(Number).filter(Boolean);
		if (typeof raw === 'string') {
			try {
				const parsed = JSON.parse(raw);
				return Array.isArray(parsed) ? parsed.map(Number).filter(Boolean) : [];
			} catch {
				return [];
			}
		}
		return [];
	}

	public async createCase(caseData: Partial<Case>, currentContext: CurrentContext): Promise<Case> {
		return this.save(caseData as Case, currentContext);
	}

	public async updateCase(id: number, caseData: Partial<Case>, currentContext: CurrentContext): Promise<number> {
		if (isCaseClosed(caseData.status) && !caseData.closedOn) {
			caseData.closedOn = new Date();
		}
		return this.update(caseData, currentContext, { where: { id } });
	}

	/**
	 * Bump `updated_on` without changing anything else. Allegations, scope items, procedures and the
	 * rest live in their own tables, so a write there leaves the `cases` row untouched and the
	 * "Last Updated" sort would never see the work. This is what keeps that column honest.
	 */
	public async touchCase(id: number, currentContext: CurrentContext): Promise<void> {
		await this.update(
			{},
			currentContext,
			{ where: { id } },
			{ includeDeleted: false, includeInactive: false, throwException: false },
		);
	}

	public async deleteCase(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}

	public async userHasCaseScopedRoleOnAnyCase(username: string): Promise<boolean> {
		return this.isRecordExist({ where: { deleted: false, ...assigneeIs('caseLead', username) } });
	}
}

export interface DuplicateCheckCriteria {
	excludeId: number;
	businessUnit?: string | null;
	primaryIssue?: string | null;
	incidentTypeCodes: string[];
	allegationDescriptions: string[];
}

export interface CaseStatsRow {
	totalCases: number;
	inProgress: number;
	closed: number;
	unreviewed: number;
	fraudCount: number;
	nonFraudCount: number;
	unclassifiedCount: number;
}
