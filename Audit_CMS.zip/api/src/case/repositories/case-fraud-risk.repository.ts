import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseFraudRisk } from '../models';

@Injectable()
export class CaseFraudRiskRepository extends BaseRepository<CaseFraudRisk> {
	constructor() {
		super(CaseFraudRisk);
	}

	public async getByCaseId(caseId: number): Promise<CaseFraudRisk[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseFraudRisk | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createRisk(data: Partial<CaseFraudRisk>, currentContext: CurrentContext): Promise<CaseFraudRisk> {
		return this.save(data as CaseFraudRisk, currentContext);
	}

	public async updateRisk(id: number, data: Partial<CaseFraudRisk>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteRisk(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}
}
