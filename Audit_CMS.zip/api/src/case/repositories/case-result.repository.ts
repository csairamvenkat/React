import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseResult } from '../models';

@Injectable()
export class CaseResultRepository extends BaseRepository<CaseResult> {
	constructor() {
		super(CaseResult);
	}

	public async getByCaseId(caseId: number): Promise<CaseResult[]> {
		return this.findAll({ where: { caseId, deleted: false } });
	}

	public async getByScopeItemId(scopeItemId: number): Promise<CaseResult | null> {
		return this.findOne({ where: { scopeItemId, deleted: false } });
	}

	public async getById(id: number): Promise<CaseResult | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createResult(data: Partial<CaseResult>, currentContext: CurrentContext): Promise<CaseResult> {
		return this.save(data as CaseResult, currentContext);
	}

	public async updateResult(id: number, data: Partial<CaseResult>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async upsertByScopeItem(
		caseId: number,
		scopeItemId: number,
		data: Partial<CaseResult>,
		currentContext: CurrentContext,
	): Promise<CaseResult> {
		const existing = await this.getByScopeItemId(scopeItemId);
		if (existing) {
			await this.updateResult(existing.id, data, currentContext);
			return this.getById(existing.id);
		}
		return this.createResult({ ...data, caseId, scopeItemId }, currentContext);
	}
}
