import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseScopeItem } from '../models';

@Injectable()
export class CaseScopeItemRepository extends BaseRepository<CaseScopeItem> {
	constructor() {
		super(CaseScopeItem);
	}

	public async getByCaseId(caseId: number): Promise<CaseScopeItem[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseScopeItem | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async getByAllegationId(allegationId: number): Promise<CaseScopeItem[]> {
		return this.findAll({
			where: { allegationId, deleted: false },
			order: [['sortOrder', 'ASC']],
		});
	}

	public async createItem(data: Partial<CaseScopeItem>, currentContext: CurrentContext): Promise<CaseScopeItem> {
		return this.save(data as CaseScopeItem, currentContext);
	}

	public async updateItem(id: number, data: Partial<CaseScopeItem>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteItem(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}
}
