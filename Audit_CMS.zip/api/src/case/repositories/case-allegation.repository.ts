import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseAllegation } from '../models';

@Injectable()
export class CaseAllegationRepository extends BaseRepository<CaseAllegation> {
	constructor() {
		super(CaseAllegation);
	}

	public async getByCaseId(caseId: number): Promise<CaseAllegation[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseAllegation | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async getByIds(ids: number[]): Promise<CaseAllegation[]> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return [];
		return this.findAll({ where: { id: { [Op.in]: unique }, deleted: false } });
	}

	public async createAllegation(data: Partial<CaseAllegation>, currentContext: CurrentContext): Promise<CaseAllegation> {
		return this.save(data as CaseAllegation, currentContext);
	}

	public async updateAllegation(id: number, data: Partial<CaseAllegation>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteAllegation(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}

	public async confirmAllOutcomesForCase(
		caseId: number,
		confirmedBy: string | null,
		currentContext: CurrentContext,
	): Promise<number> {
		return this.update(
			{ outcomeConfirmed: true, outcomeConfirmedBy: confirmedBy, outcomeConfirmedOn: new Date() },
			currentContext,
			{ where: { caseId } },
		);
	}
}
