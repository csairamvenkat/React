import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseUserPermission } from '../models';
import { PermissionSourceType, CaseAssignmentRole } from '../enums';

@Injectable()
export class CaseUserPermissionRepository extends BaseRepository<CaseUserPermission> {
	constructor() {
		super(CaseUserPermission);
	}

	public async getByCaseId(caseId: number): Promise<CaseUserPermission[]> {
		return this.findAll({ where: { caseId, deleted: false } });
	}

	public async getById(id: number): Promise<CaseUserPermission | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async getByUserAndCase(caseId: number, userId: string): Promise<CaseUserPermission | null> {
		return this.findOne({ where: { caseId, userId: userId.toLowerCase(), sourceType: null, deleted: false } });
	}

	public async hasAnyGrantForCase(caseId: number, userId: string): Promise<boolean> {
		return this.isRecordExist({
			where: { caseId, userId: userId.toLowerCase(), deleted: false },
		});
	}

	public async getProcedureGrants(
		caseId: number,
		procedureId: number,
	): Promise<CaseUserPermission[]> {
		return this.findAll({
			where: {
				caseId,
				sourceType: PermissionSourceType.PROCEDURE,
				sourceId: procedureId,
				deleted: false,
			},
		});
	}

	public async deleteOtherProcedureGrants(
		caseId: number,
		procedureId: number,
		keepUserId: string,
		currentContext: CurrentContext,
	): Promise<void> {
		await this.deleteByCondition(
			{
				caseId,
				sourceType: PermissionSourceType.PROCEDURE,
				sourceId: procedureId,
				userId: { [Op.ne]: keepUserId.toLowerCase() },
			},
			currentContext,
		);
	}

	public async getSourceAssignmentGrant(
		caseId: number,
		sourceType: PermissionSourceType,
		sourceId: number,
	): Promise<CaseUserPermission | null> {
		return this.findOne({
			where: { caseId, sourceType, sourceId, deleted: false },
			order: [['id', 'DESC']],
		});
	}

	public async getByUserCaseAndSource(
		caseId: number,
		userId: string,
		sourceType: string | null,
		sourceId: number | null,
	): Promise<CaseUserPermission | null> {
		return this.findOne({
			where: { caseId, userId: userId.toLowerCase(), sourceType: sourceType ?? null, sourceId: sourceId ?? null, deleted: false },
		});
	}

	public async upsertPermission(
		caseId: number,
		userId: string,
		data: Partial<CaseUserPermission>,
		currentContext: CurrentContext,
	): Promise<CaseUserPermission> {
		const sourceType = (data as any).sourceType ?? null;
		const sourceId = (data as any).sourceId ?? null;
		const existing = await this.getByUserCaseAndSource(caseId, userId, sourceType, sourceId);
		if (existing) {
			await this.update(data, currentContext, { where: { id: existing.id } });
			return (await this.getById(existing.id))!;
		}
		const instance = CaseUserPermission.build({
			caseId,
			userId: userId.toLowerCase(),
			sourceType,
			sourceId,
			...data,
		} as any);
		return this.save(instance, currentContext);
	}

	public async getAllegationRecordsByUser(caseId: number, userId: string): Promise<CaseUserPermission[]> {
		return this.findAll({
			where: {
				caseId,
				userId: userId.toLowerCase(),
				sourceType: { [Op.in]: [PermissionSourceType.ALLEGATION, PermissionSourceType.SUB_ASSIGNEE] },
				deleted: false,
			},
		});
	}

	public async getProcedureRecordsByUser(caseId: number, userId: string): Promise<CaseUserPermission[]> {
		return this.findAll({
			where: {
				caseId,
				userId: userId.toLowerCase(),
				sourceType: PermissionSourceType.PROCEDURE,
				deleted: false,
			},
		});
	}

	public async getProcedureGrantsByUser(userId: string): Promise<CaseUserPermission[]> {
		return this.findAll({
			where: {
				userId: userId.toLowerCase(),
				sourceType: PermissionSourceType.PROCEDURE,
				deleted: false,
			},
		});
	}

	public async deletePermission(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}

	public async hasAnyCaseLevelGrant(userId: string): Promise<boolean> {
		return this.isRecordExist({
			where: {
				userId: userId.toLowerCase(),
				sourceType: null,
				deleted: false,
				[Op.or]: [
					{ role: null },
					{ role: { [Op.notIn]: [CaseAssignmentRole.ALLEGATION_MANAGER, CaseAssignmentRole.PROCEDURE_INVESTIGATOR] } },
				],
			},
		});
	}
}
