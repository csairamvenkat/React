import { Injectable } from '@nestjs/common';
import { Model, ModelStatic, Op, literal } from 'sequelize';
import {
	Case,
	CaseAllegation,
	CaseProcedure,
	CaseRecommendationItem,
	ProcedureStatus,
	RecommendationItemStatus,
} from '../models';
import { AssignmentType, PermissionSourceType, WorkStatusFilter } from '../enums';
import type { WorkItemType } from '../dtos/request/work-list-filter-request.dto';

export interface WorkItemRow {
	id: number;
	caseId: number;
	irNumber: string | null;
	title: string;
	assigneeUserId: string | null;
	assigneeName: string | null;
	classification: string | null;
	incidentTypeCode: string | null;
	isCompleted: boolean;
	createdBy: string;
	createdOn: Date;
}

export interface WorkItemQuery {
	status?: WorkStatusFilter;
	assignedToMe?: boolean;
	searchTerm?: string;
	username?: string;
}

interface WorkTypeSource {
	model: ModelStatic<Model>;
	alias: string;
	titleColumn: string;
	build: (alias: string) => WorkTypeSql;
	sql?: WorkTypeSql;
}

interface WorkTypeSql {
	assigneeIdSql: string;
	assigneeNameSql: string;
	/** Allegation-only today; other work types report null rather than guessing at a parent. */
	classificationSql: string;
	incidentTypeSql: string;
	completedSql: string;
}

const NO_VALUE_SQL = 'CAST(NULL AS text)';

function schemaPrefix(): string {
	const dbSchema: string | undefined = (Case as any).sequelize?.options?.schema;
	return dbSchema ? `"${dbSchema}".` : '';
}

function assignedBySql(
	alias: string,
	sourceType: PermissionSourceType,
	grantColumn: string,
	fallbackColumn: string,
): string {
	const grant = `(SELECT p.${grantColumn} FROM ${schemaPrefix()}"case_user_permissions" p
		WHERE p.deleted = false AND p.source_type = '${sourceType}' AND p.source_id = "${alias}".id
		ORDER BY p.id DESC LIMIT 1)`;
	return `COALESCE(${grant}, "${alias}"."${fallbackColumn}")`;
}

function quote(value: string): string {
	return `'${String(value).replace(/'/g, "''")}'`;
}

function columnSql(source: WorkTypeSource, attribute: string): string {
	const field = source.model.getAttributes()[attribute]?.field ?? attribute;
	return `"${source.alias}"."${field}"`;
}

function toWorkItemRow(row: WorkItemRow): WorkItemRow {
	return {
		...row,
		id: Number(row.id),
		caseId: Number(row.caseId),
		isCompleted: row.isCompleted === true,
	};
}

@Injectable()
export class CaseWorkItemRepository {
	private readonly sources: Record<WorkItemType, WorkTypeSource> = {
		[AssignmentType.ALLEGATION_MANAGER]: {
			model: CaseAllegation,
			alias: 'CaseAllegation',
			titleColumn: 'label',
			build: alias => ({
				assigneeIdSql: assignedBySql(
					alias,
					PermissionSourceType.ALLEGATION,
					'user_id',
					'allegation_manager_id',
				),
				assigneeNameSql: assignedBySql(
					alias,
					PermissionSourceType.ALLEGATION,
					'user_name',
					'allegation_manager_name',
				),
				classificationSql: `"${alias}"."classification"`,
				incidentTypeSql: `"${alias}"."incident_type_code"`,
				completedSql: 'FALSE',
			}),
		},
		[AssignmentType.PROCEDURE_ASSIGNEE]: {
			model: CaseProcedure,
			alias: 'CaseProcedure',
			titleColumn: 'description',
			build: alias => ({
				assigneeIdSql: assignedBySql(
					alias,
					PermissionSourceType.PROCEDURE,
					'user_id',
					'action_by_user_id',
				),
				assigneeNameSql: assignedBySql(
					alias,
					PermissionSourceType.PROCEDURE,
					'user_name',
					'action_by',
				),
				classificationSql: NO_VALUE_SQL,
				incidentTypeSql: NO_VALUE_SQL,
				completedSql: `("${alias}".status = '${ProcedureStatus.COMPLETE}')`,
			}),
		},
		[AssignmentType.RECOMMENDATION_OWNER]: {
			model: CaseRecommendationItem,
			alias: 'CaseRecommendationItem',
			titleColumn: 'issueTitle',
			// A recommendation owner is usually outside the case team and holds no grant, so the item
			// itself is where the owner is recorded.
			build: alias => ({
				assigneeIdSql: `"${alias}"."recommendation_owner_email"`,
				assigneeNameSql: `"${alias}"."recommendation_owner"`,
				classificationSql: NO_VALUE_SQL,
				incidentTypeSql: NO_VALUE_SQL,
				completedSql: `("${alias}".status = '${RecommendationItemStatus.IMPLEMENTED}')`,
			}),
		},
	};

	private resolveSource(type: WorkItemType): Required<WorkTypeSource> {
		const source = this.sources[type];
		if (!source.sql) source.sql = source.build(source.alias);
		return source as Required<WorkTypeSource>;
	}

	public async getPaginatedWorkItems(
		type: WorkItemType,
		limit: number,
		page: number,
		query: WorkItemQuery,
	): Promise<{ rows: WorkItemRow[]; count: number }> {
		const source = this.resolveSource(type);
		const { rows, count } = await source.model.findAndCountAll({
			where: { [Op.and]: this.buildCondition(source, query) },
			attributes: this.rowAttributes(source),
			offset: page > 0 && limit > 0 ? (page - 1) * limit : 0,
			...(limit && { limit }),
			order: [
				['createdOn', 'DESC'],
				['id', 'DESC'],
			],
			raw: true,
		});

		return { rows: (rows as unknown as WorkItemRow[]).map(toWorkItemRow), count };
	}

	/** How many items of one type match the current filters, for the type tabs. */
	public async countWorkItems(type: WorkItemType, query: WorkItemQuery): Promise<number> {
		const source = this.resolveSource(type);
		return source.model.count({
			where: { [Op.and]: this.buildCondition(source, { ...query, status: WorkStatusFilter.ALL }) },
		});
	}

	private rowAttributes(source: Required<WorkTypeSource>): any[] {
		const s = schemaPrefix();
		return [
			'id',
			'caseId',
			'createdBy',
			'createdOn',
			[literal(columnSql(source, source.titleColumn)), 'title'],
			[literal(source.sql.assigneeIdSql), 'assigneeUserId'],
			[literal(source.sql.assigneeNameSql), 'assigneeName'],
			[literal(source.sql.classificationSql), 'classification'],
			[literal(source.sql.incidentTypeSql), 'incidentTypeCode'],
			[
				literal(`(SELECT c.ir_number FROM ${s}"cases" c WHERE c.id = "${source.alias}".case_id)`),
				'irNumber',
			],
			[literal(source.sql.completedSql), 'isCompleted'],
		];
	}

	private buildCondition(source: Required<WorkTypeSource>, query: WorkItemQuery): any[] {
		const s = schemaPrefix();
		const caseExists = (extra = '') =>
			`EXISTS (SELECT 1 FROM ${s}"cases" c WHERE c.id = "${source.alias}".case_id AND c.deleted = false${extra})`;
		const condition: any[] = [{ deleted: false, active: true }, literal(caseExists())];

		if (query.status === WorkStatusFilter.COMPLETED) {
			condition.push(literal(source.sql.completedSql));
		} else if (query.status === WorkStatusFilter.PENDING) {
			condition.push(literal(`NOT ${source.sql.completedSql}`));
		}

		if (query.assignedToMe) {
			// Matched against the same expression the card displays, so the toggle can never
			// disagree with the assignee on screen. Without a username it matches nothing.
			condition.push(
				literal(`LOWER(${source.sql.assigneeIdSql}) = LOWER(${quote(query.username ?? '')})`),
			);
		}

		if (query.searchTerm) {
			const term = quote(`%${query.searchTerm}%`);
			condition.push({
				[Op.or]: [
					{ [source.titleColumn]: { [Op.iLike]: `%${query.searchTerm}%` } },
					literal(`${source.sql.assigneeNameSql} ILIKE ${term}`),
					literal(caseExists(` AND c.ir_number ILIKE ${term}`)),
				],
			});
		}

		return condition;
	}
}
