import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseEvidence } from '../models';

@Injectable()
export class CaseEvidenceRepository extends BaseRepository<CaseEvidence> {
	constructor() {
		super(CaseEvidence);
	}

	public async getByCaseId(caseId: number): Promise<CaseEvidence[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['createdOn', 'DESC']] });
	}

	public async getKeyEvidenceByCaseId(caseId: number): Promise<CaseEvidence[]> {
		return this.findAll({ where: { caseId, isKeyEvidence: true, deleted: false }, order: [['createdOn', 'DESC']] });
	}

	/**
	 * Supporting attachments reported against the allegation itself. Files captured while completing
	 * a procedure carry a procedureId and belong to that procedure, not to Report Results.
	 */
	public async getAllegationAttachments(allegationId: number): Promise<CaseEvidence[]> {
		return this.findAll({
			where: { allegationId, procedureId: null, deleted: false },
			order: [['createdOn', 'DESC']],
		});
	}

	public async getById(id: number): Promise<CaseEvidence | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createEvidence(data: Partial<CaseEvidence>, currentContext: CurrentContext): Promise<CaseEvidence> {
		return this.save(data as CaseEvidence, currentContext);
	}

	public async updateEvidence(id: number, data: Partial<CaseEvidence>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteEvidence(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}
}
