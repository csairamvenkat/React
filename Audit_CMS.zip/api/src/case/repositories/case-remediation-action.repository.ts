import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseRemediationAction } from '../models';
import { RemediationStatus } from '../enums/remediation-status.enum';

@Injectable()
export class CaseRemediationActionRepository extends BaseRepository<CaseRemediationAction> {
	constructor() {
		super(CaseRemediationAction);
	}

	public async getByCaseId(caseId: number): Promise<CaseRemediationAction[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseRemediationAction | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createAction(data: Partial<CaseRemediationAction>, currentContext: CurrentContext): Promise<CaseRemediationAction> {
		return this.save(data as CaseRemediationAction, currentContext);
	}

	public async updateAction(id: number, data: Partial<CaseRemediationAction>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteAction(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}

	public async getOutstandingActions(
		filter: { caseId?: number; responsibleParty?: string } = {},
	): Promise<CaseRemediationAction[]> {
		const where: any = { status: RemediationStatus.PENDING, deleted: false };
		if (filter.caseId) where.caseId = filter.caseId;
		if (filter.responsibleParty) where.responsibleParty = { [Op.iLike]: filter.responsibleParty };
		return this.findAll({ where });
	}
}
