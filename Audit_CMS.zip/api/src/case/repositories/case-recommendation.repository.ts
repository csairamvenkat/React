import { Injectable } from '@nestjs/common';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseRecommendation } from '../models';

@Injectable()
export class CaseRecommendationRepository extends BaseRepository<CaseRecommendation> {
	constructor() {
		super(CaseRecommendation);
	}

	public async getByCaseId(caseId: number): Promise<CaseRecommendation | null> {
		return this.findOne({ where: { caseId, deleted: false } });
	}

	public async getById(id: number): Promise<CaseRecommendation | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async createRecommendation(data: Partial<CaseRecommendation>, currentContext: CurrentContext): Promise<CaseRecommendation> {
		return this.save(data as CaseRecommendation, currentContext);
	}

	public async updateRecommendation(id: number, data: Partial<CaseRecommendation>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async upsertByCaseId(
		caseId: number,
		data: Partial<CaseRecommendation>,
		currentContext: CurrentContext,
	): Promise<CaseRecommendation> {
		const existing = await this.getByCaseId(caseId);
		if (existing) {
			await this.updateRecommendation(existing.id, data, currentContext);
			return this.getById(existing.id);
		}
		return this.createRecommendation({ ...data, caseId }, currentContext);
	}
}
