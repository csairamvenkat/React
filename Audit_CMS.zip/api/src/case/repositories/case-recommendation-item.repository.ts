import { Injectable } from '@nestjs/common';
import { Op } from 'sequelize';
import { BaseRepository } from 'src/shared/repositories';
import { CurrentContext } from 'src/shared/types';
import { CaseRecommendationItem } from '../models';

@Injectable()
export class CaseRecommendationItemRepository extends BaseRepository<CaseRecommendationItem> {
	constructor() {
		super(CaseRecommendationItem);
	}

	public async getByCaseId(caseId: number): Promise<CaseRecommendationItem[]> {
		return this.findAll({ where: { caseId, deleted: false }, order: [['sortOrder', 'ASC']] });
	}

	public async getById(id: number): Promise<CaseRecommendationItem | null> {
		return this.findOne({ where: { id, deleted: false } });
	}

	public async getByIds(ids: number[]): Promise<CaseRecommendationItem[]> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return [];
		return this.findAll({ where: { id: { [Op.in]: unique }, deleted: false } });
	}

	public async markTransferredToArms(
		ids: number[],
		currentContext: CurrentContext,
	): Promise<number> {
		const unique = [...new Set(ids.map(Number).filter(Boolean))];
		if (unique.length === 0) return 0;
		return this.update(
			{ armsTransferred: true, armsTransferredAt: new Date() } as any,
			currentContext,
			{ where: { id: { [Op.in]: unique } } },
		);
	}

	public async createItem(data: Partial<CaseRecommendationItem>, currentContext: CurrentContext): Promise<CaseRecommendationItem> {
		return this.save(data as CaseRecommendationItem, currentContext);
	}

	public async updateItem(id: number, data: Partial<CaseRecommendationItem>, currentContext: CurrentContext): Promise<number> {
		return this.update(data, currentContext, { where: { id } });
	}

	public async deleteItem(id: number, currentContext: CurrentContext): Promise<boolean> {
		return this.deleteById(id, currentContext);
	}
}
