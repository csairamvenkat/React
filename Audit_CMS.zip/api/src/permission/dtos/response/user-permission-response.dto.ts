import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class UserPermissionResponseDto {
	@ApiProperty()
	@Expose()
	public permissionName: string;

	constructor(partial: Partial<UserPermissionResponseDto> = {}) {
		Object.assign(this, partial);
	}
}
