import { Injectable } from '@nestjs/common';
import { AdminApiClient } from 'src/shared/clients';
import { multiObjectToInstance } from 'src/shared/helpers';
import { CurrentContext, PermissionsResponse } from 'src/shared/types';
import { UserPermissionResponseDto } from '../dtos';

@Injectable()
export class PermissionService {
	constructor(private readonly adminApiClient: AdminApiClient) {}

	/**
	 * Get location ids for an given permission for the user.
	 * @param username
	 * @param permission
	 * @returns
	 */
	public async getAllLocationIdForGivenPermission(
		username: string,
		permission: string,
	): Promise<number[]> {
		const response = await this.adminApiClient.getListOfUserPermissions(username);
		const locations = response
			.find((p: PermissionsResponse) => p.permissionName === permission)
			?.locations.map(Number);
		return locations || [];
	}

	/**
	 * Get list of permissions with locations of a user.
	 * @param currentContext
	 * @returns
	 */
	public async getListOfUserPermissions(
		currentContext: CurrentContext,
	): Promise<UserPermissionResponseDto[]> {
		const { username } = currentContext.user;
		const permissions = await this.adminApiClient.getListOfUserPermissions(username);
		return multiObjectToInstance(UserPermissionResponseDto, permissions);
	}
}
