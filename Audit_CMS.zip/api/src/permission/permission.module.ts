import { Module } from '@nestjs/common';
import { AdminApiClient } from 'src/shared/clients';
import { PermissionController } from './controllers';
import { PermissionService } from './services';

@Module({
	controllers: [PermissionController],
	providers: [PermissionService, AdminApiClient],
})
export class PermissionModule {}
