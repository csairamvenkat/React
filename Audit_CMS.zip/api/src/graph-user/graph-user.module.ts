import { Module } from '@nestjs/common';
import { GraphUserController } from './controllers/graph-user.controller';
import { GraphUserService } from './services/graph-user.service';
import { MSGraphApiClient } from '@/shared/clients';

@Module({
	controllers: [GraphUserController],
	providers: [GraphUserService, MSGraphApiClient],
})
export class GraphUserModule {}
