import { SetMetadata } from '@nestjs/common';

export const Permissions = (
	permission: string,
	params: { checkEntity: boolean } = { checkEntity: true },
) => SetMetadata('permissions', { permission, checkEntity: params.checkEntity });
