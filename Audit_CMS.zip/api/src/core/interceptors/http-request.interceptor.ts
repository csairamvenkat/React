import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { AuthTokenPayload } from 'src/shared/types';

@Injectable()
export class HttpRequestInterceptor implements NestInterceptor {
	intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
		const request = context.switchToHttp().getRequest();
		const user: AuthTokenPayload = request.user;
		if (user) {
			const entityId = Number(request.headers['x-entity-id']) || null;
			request.currentContext = { user, locations: request.user.locations, entityId };
			request.currentContext.user.username = user.unique_name.toLowerCase();
		}
		return next.handle();
	}
}
