import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { ConfigService } from 'src/config/config.service';

@Injectable()
export class ApiKeyGuard implements CanActivate {
	constructor(private readonly configService: ConfigService) {}

	async canActivate(context: ExecutionContext): Promise<boolean> {
		let request = context.switchToHttp().getRequest();
		return request.headers['apikey'] === this.configService.apiKey;
	}
}
