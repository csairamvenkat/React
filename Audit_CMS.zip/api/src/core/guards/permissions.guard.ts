import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AdminApiClient } from 'src/shared/clients';
import { SharedPermissionService } from 'src/shared/services';

@Injectable()
export class PermissionsGuard implements CanActivate {
	constructor(
		private readonly reflector: Reflector,
		private readonly adminApiClient: AdminApiClient,
		private readonly permissionService: SharedPermissionService,
	) {}

	async canActivate(context: ExecutionContext): Promise<boolean> {
		const routePermission = this.reflector.get<{
			permission: string;
			checkEntity?: boolean;
			checkReader?: boolean;
		}>('permissions', context.getHandler());

		let request = context.switchToHttp().getRequest();
		const { body, user, query } = request;
		const { permission, checkEntity } = routePermission;
		let entityId = null;
		if (checkEntity && (body?.entityId || query?.entityId)) {
			entityId = body?.entityId || query?.entityId;
		}

		const locations = await this.permissionService.getAllLocationIdsForGivenPermission(
			user.unique_name,
			permission,
		);

		request.user.locations = locations || [];
		return this.adminApiClient.hasPermissionToUser(user.unique_name, permission, entityId);
	}
}
