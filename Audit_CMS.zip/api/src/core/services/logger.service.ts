import { ConsoleLogger, Injectable } from '@nestjs/common';
import { ConfigService } from 'src/config/config.service';

@Injectable()
export class LoggerService {
	constructor(private readonly logger: ConsoleLogger, private readonly config: ConfigService) {
		this.logger = new ConsoleLogger();
		this.logger.setLogLevels(this.config.getLogLevel());
	}

	log(message: any, context?: string) {
		this.logger.log(message, context);
	}

	error(message: any, stack?: string, context?: string) {
		this.logger.error(message, stack, context);
	}

	warn(message: any, context?: string) {
		this.logger.warn(message, context);
	}

	debug(message: any, context?: string) {
		this.logger.debug(message, context);
	}

	verbose(message: any, context?: string) {
		this.logger.verbose(message, context);
	}
}
