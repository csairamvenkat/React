import { Controller, Get, Param, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RequestContext } from 'src/shared/types';
import { AttachmentService } from '../services/attachment.service';
import { replace } from 'lodash';

@ApiTags('Attachment API')
@Controller('attachment')
export class AttachmentController {
	constructor(private readonly attachmentService: AttachmentService) { }

	@ApiBearerAuth()
	@UseGuards(AuthGuard('oauth-bearer'))
	@ApiResponse({
		status: 200,
		description: 'Get document content by id.',
		type: Buffer,
	})
	@Get('content/:fileId')
	public async getDraftsByIdAndActiveUser(
		@Param('fileId') fileId: string,
		@Req() request: RequestContext,
		@Res() res: any,
	) {
		const data = await this.attachmentService.getContentByFileId(fileId, request.currentContext);

		if (data?.attachment_name) {
			data.attachment_name = replace(data.attachment_name, ',', '-');
		}

		res.status(200);
		res.setHeader('Content-Type', data.attachment_content_type);
		res.setHeader('Content-Disposition', 'attachment; filename=' + data.attachment_name);
		const buffer: Buffer = Buffer.from(data.contents.data);
		res.write(buffer);
		res.end();
	}
}
