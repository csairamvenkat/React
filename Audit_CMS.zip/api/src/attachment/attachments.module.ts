import { Module } from '@nestjs/common';
import { AdminApiClient, TaskApiClient } from '@/shared/clients';
import { AttachmentApiClient } from '@/shared/clients/attachment-api.client';
import { DatabaseHelper } from '@/shared/helpers';
import { SharedPermissionService } from '@/shared/services';
import { AttachmentController } from './controllers/attachment.controller';
import { AttachmentService } from './services/attachment.service';

@Module({
	controllers: [AttachmentController],
	providers: [
		SharedPermissionService,
		AttachmentService,
		DatabaseHelper,
		AdminApiClient,
		AttachmentApiClient,
		TaskApiClient,
	],
})
export class AttachmentModule {}
