# CMS API

NestJS 11 REST API for the Case Management System, on Sequelize 6 + PostgreSQL.

## Quick start

```bash
npm install
npm run start:dev        # http://localhost:5600/api
```

Requires Node 24 (the Docker images pin `node:24.12.0-alpine3.22`). No `.env` file is needed —
configuration lives in JSON, see below.

## Configuration

Settings come from a JSON file next to the source, **not** from environment variables.
`ConfigService` picks one at startup:

| Condition | File read |
| --- | --- |
| `USE_SECRET` is set | `process.env.APP_CONFIG`, parsed as JSON |
| `NODE_ENV` is set | `src/config.<NODE_ENV>.json` |
| neither | `src/config.json` |

So `npm run start:dev` with no `NODE_ENV` reads `src/config.json`, and `NODE_ENV=dev` reads
`src/config.dev.json`. These files are committed and hold real credentials — treat them
accordingly. In deployed environments, pass the whole config as the `APP_CONFIG` secret and set
`USE_SECRET`.

The config covers `database`, `azureAD`, `swagger`, `microservices` (Admin / Request /
Notification APIs), `uiClient`, `webClientConfig`, `apiKey` and `azureOpenAI`. Its shape is typed
in [`src/shared/types/app-config.type.ts`](src/shared/types/app-config.type.ts).

Note the `database.schema` setting — the app does not use Postgres' `public` schema, so any
manual SQL needs `SET search_path` first.

## Runtime shape

- Global route prefix **`api`**, so endpoints live at `/api/...`.
- Port **5600** by default, `PORT` to override (the production image sets 3665).
- Swagger UI at **`/doc`**, JSON at `/doc-json` — enabled only when `NODE_ENV !== 'prod'` and
  protected by basic auth using `swagger.user` / `swagger.password` from the config.
- `helmet`, CORS enabled, a global `ValidationPipe` with `whitelist` and `transform`, a 400 MB
  JSON body limit and a 10-minute server timeout (large evidence uploads and PDF generation).
- Timestamps are parsed as UTC (`pg.defaults.parseInputDatesAsUTC`).

## Modules

| Module | Responsibility |
| --- | --- |
| `case` | The core domain — cases, allegations, scope items, procedures, results, remediation, recommendations, fraud risks, evidence, per-user permissions. Controllers / services / repositories / models / dtos / enums. |
| `auth` | Azure AD bearer strategy and login endpoints. |
| `permission` | Section- and case-level access grants. |
| `attachment` | File upload / download; files land under `uploads/`. |
| `notification` | Outbound email via the internal Notification API. |
| `ai` | Azure OpenAI prompts and usage logging (allegation drafting, review assistance). |
| `analytics` | Reporting aggregates and CPE hours. |
| `business-entity` | Business-unit tree from the Admin API. |
| `graph-user` | Microsoft Graph user lookup and search. |
| `pdf-generator` | Puppeteer/Chromium HTML→PDF (module + service; the markup is built in code). |
| `setup` | Reference/setup data. |
| `core`, `shared`, `config`, `database` | Guards, interceptors, decorators, pagination, providers, base models, ORM wiring. |

## Database & migrations

Models are Sequelize + `sequelize-typescript` classes under `src/<module>/models`, registered in
[`src/database/orm-config.ts`](src/database/orm-config.ts).

**On boot the API syncs the schema from the models** — `orm-config.ts` sets `synchronize: true`
with `sync: { alter: false }`, so Sequelize issues `CREATE TABLE IF NOT EXISTS` for every model.
Missing tables are created automatically; existing tables are not altered, so a new column on a
model does *not* reach the database on its own.

Schema changes are therefore written by hand as numbered SQL files in `database/migrations/`:

```
001_create_cms_tables.sql
002_reorder_audit_columns.sql
...
018_add_case_source_details.sql
```

(There is no `006` — the numbering has a gap.)

### Applying a migration

There is no automated runner. Either execute the file directly:

```sql
-- in psql / pgAdmin, against the configured database
SET search_path TO "dev_cms";   -- whatever database.schema is set to
\i database/migrations/018_add_case_source_details.sql
```

…or copy [`scripts/run-migration-014.js`](scripts/run-migration-014.js), which reads the
connection details out of `src/config.dev.json` and applies one specific file.

Two things to know before running anything:

- **`npm run db:migrate` does not work.** It maps to `sequelize-cli db:migrate`, but this project
  has no `.sequelizerc` and no `sequelize-cli` migrations directory — the migrations are the raw
  `.sql` files above.
- **Do not replay migrations blindly on a populated database.** They are mostly idempotent
  (`ADD COLUMN IF NOT EXISTS`), but `002_reorder_audit_columns.sql` renames `cases` to
  `cases_old` and recreates it from its original column list — re-running it on a live database
  would drop every column added since. Apply only what is genuinely outstanding.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run start:dev` | Clean `dist`, then `nest start --watch`. |
| `npm run start:debug` | Same, with the inspector attached. |
| `npm run build` / `npm run start:prod` | Compile to `dist`, then run `node dist/main`. |
| `npm run scheduler` | Builds the scheduler entrypoint (`src/scheduler.ts`, `scheduler-nest-cli.json`, shipped by `scheduler.Dockerfile`). |
| `npm run format` | Prettier over `src` and `test`. |
| `npm run lint` | `lint-staged` (Prettier on staged files). |
| `npm test` / `test:watch` / `test:cov` / `test:e2e` | Jest. |
| `npm run test:ai-connection` | Smoke-tests the Azure OpenAI credentials. |
| `npm run documentation:serve` | Compodoc API documentation. |

`nest build` uses [`tsconfig.build.json`](tsconfig.build.json), which excludes tests. The
`config*.json` files are copied into `dist` by the `assets` list in
[`nest-cli.json`](nest-cli.json), and `ConfigService` resolves them relative to `__dirname` — so
anything that changes the shape of the build output (for example adding a `.ts` file outside
`src`, which widens TypeScript's inferred `rootDir`) will break the config lookup at startup with
an `ENOENT` on `config.json`. That asset list also still references
`pdf-generator/templates/**/*` and `migration_script/**`, neither of which exists any more.

## Docker

Multi-stage [`Dockerfile`](Dockerfile): development → build → production, ending on
`node:24.12.0-alpine3.22` running `node dist/main.js` on port 3665. Chromium and its font/lib
dependencies are installed for Puppeteer (PDF generation), and Python 3 with pandas / openpyxl /
psycopg2 for the data-migration scripts. `scheduler.Dockerfile` builds the scheduler variant.
