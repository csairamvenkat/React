# Audit CMS — Case Management System

Case management for DP World Group Internal Audit / Fraud Risk Services. Whistleblower and
incident reports are triaged, classified as Fraud or Non-Fraud, investigated through a defined
lifecycle, and closed with findings, remediation and recommendations.

## Repository layout

| Path | What it is |
| --- | --- |
| `client/` | React 18 + TypeScript + Vite single-page app. See [client/README.md](client/README.md). |
| `api/` | NestJS 11 REST API on Sequelize + PostgreSQL. See [api/README.md](api/README.md). |
| `cronjobs/navex-sync/` | Nightly Navex import, also run by the API's **Sync now**. See [its README](cronjobs/navex-sync/README.md). |
| `database/migrations/` | Plain `.sql` migrations, applied manually. The schema's source of truth. |

There is no workspace tooling tying these together — each project is installed and run
independently.

## Getting started

Two terminals — the API and the client run separately.

```bash
# 1. API  → http://localhost:5600/api
cd api
npm install
npm run start:dev

# 2. Client → http://localhost:4200/CMS/
cd client
npm install
npm run dev

# 3. Optional, one-off — only the Navex page's "Sync now" button needs it
cd cronjobs/navex-sync
npm install
npm run build
```

The API builds and runs without step 3; **Sync now** reports "not installed" until it is done.

The API reads its settings from `api/src/config*.json` (not `.env`) — including database
credentials, so a local Postgres is only needed if you point the config at one. The client needs
a `.env` with `VITE_HTTP_PROTOCOL`, `VITE_BASE_URL` and `VITE_DEFAULT_LANG`.

Both READMEs cover configuration in detail.

## Database

PostgreSQL, accessed through Sequelize models in `api/src/**/models`. Schema changes are written
by hand as numbered SQL files in `database/migrations/` and applied manually — see
[api/README.md](api/README.md#database--migrations) for how to run them and for the important
caveat about re-running the early migrations.

## Authentication

Azure AD end to end: MSAL in the browser, a Passport Azure AD bearer strategy on the API. User
lookup and role resolution go through the Graph API and the internal Admin API rather than being
stored locally.

## Conventions

- **TypeScript everywhere**, strict-ish; the API uses Nest decorators and Sequelize models, the
  client uses function components and hooks.
- **Formatting** is Prettier, configured at the repo root (`.prettierrc.yml`). Run `npm run format`
  in either project.
- **Feature-first structure** on the client (`src/features/<feature>/…`); **module-first** on the
  API (`src/<module>/…`).
