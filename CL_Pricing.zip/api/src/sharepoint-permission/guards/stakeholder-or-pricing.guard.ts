import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { SharepointPermissionService } from '../providers/sharepoint-permission.service';

@Injectable()
export class StakeholderOrPricingGuard implements CanActivate {
  constructor(private readonly permissionService: SharepointPermissionService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const stakeholderCode =
      request.body?.stakeholderCode ?? request.params?.stakeholderCode;

    if (!user || !stakeholderCode) return false;

    const authorized = await this.permissionService.isUserAuthorizedForStakeholderOrPricing(
      user.unique_name,
      stakeholderCode
    );

    if (!authorized) {
      throw new ForbiddenException('User does not have permission for this action');
    }

    return true;
  }
}
