import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { SharepointPermissionService } from '../providers/sharepoint-permission.service';
import { SHAREPOINT_GROUP_KEY } from '../decorators/require-sharepoint-group.decorator';

@Injectable()
export class SharepointPermissionGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly permissionService: SharepointPermissionService
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredGroup = this.reflector.getAllAndOverride<string>(SHAREPOINT_GROUP_KEY, [
      context.getHandler(),
      context.getClass()
    ]);

    if (!requiredGroup) return true;

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) return false;

    const inGroup = await this.permissionService.isUserInGroup(user.unique_name, requiredGroup);

    if (!inGroup) {
      throw new ForbiddenException(`User is not in the required SharePoint group: ${requiredGroup}`);
    }

    return true;
  }
}
