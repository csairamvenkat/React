import { Module } from '@nestjs/common';
import { SharepointPermissionService } from './providers/sharepoint-permission.service';
import { SharepointPermissionGuard } from './guards/sharepoint-permission.guard';
import { StakeholderOrPricingGuard } from './guards/stakeholder-or-pricing.guard';

@Module({
  providers: [SharepointPermissionService, SharepointPermissionGuard, StakeholderOrPricingGuard],
  exports: [SharepointPermissionService, SharepointPermissionGuard, StakeholderOrPricingGuard],
})
export class SharepointPermissionModule {}
