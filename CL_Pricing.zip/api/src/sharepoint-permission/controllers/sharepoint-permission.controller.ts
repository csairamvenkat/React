import { Controller, Get, Query, UseGuards, Req } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { SharepointPermissionService } from '../providers/sharepoint-permission.service';
import { AuthTokenPayload } from 'src/shared/types';

@ApiTags('SharePoint Permission APIs')
@ApiBearerAuth()
@UseGuards(AuthGuard('oauth-bearer'))
@Controller('sharepoint-permission')
export class SharepointPermissionController {
  constructor(private readonly service: SharepointPermissionService) {}

  @ApiResponse({ status: 200, description: 'Check if the calling user belongs to the given SharePoint group.' })
  @ApiQuery({ name: 'groupName', type: String, example: 'Pricing' })
  @Get('check')
  async checkAccess(
    @Query('groupName') groupName: string,
    @Req() req: any,
  ): Promise<{ hasAccess: boolean }> {
    const user = req.user as AuthTokenPayload;
    const userLogin = user?.unique_name || user?.upn || user?.username || '';
    const hasAccess = await this.service.isUserInGroup(userLogin, groupName);
    return { hasAccess };
  }
}
