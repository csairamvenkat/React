import * as crypto from "crypto";
import * as fs from "fs";
import * as path from "path";
// eslint-disable-next-line @typescript-eslint/no-require-imports
const forge = require("node-forge");
import {
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException
} from "@nestjs/common";
import axios from "axios";
import { ConfigService } from "src/config/config.service";
import { CurrentContext, SharePointAppConfig } from "src/shared/types";
import { PermissionEnum } from "src/shared/enums/permission-status.enum";

@Injectable()
export class SharepointPermissionService {
  private readonly logger = new Logger(SharepointPermissionService.name);
  private readonly cfg: SharePointAppConfig;

  private cachedCert: { privateKeyPem: string; x5t: string } | null = null;

  private get siteName(): string {
    const match = this.cfg.sharePointUrl.match(/\/sites\/([^/]+)/);
    return match ? match[1] : "CLPricingStaging";
  }

  constructor(private readonly configService: ConfigService) {
    this.cfg = this.configService.getAppConfig().sharePointApp;
    if (!this.cfg) {
      throw new Error(
        "sharePointApp configuration is missing from config.json"
      );
    }
  }

  private toBase64Url(input: Buffer | string): string {
    const b64 =
      typeof input === "string"
        ? Buffer.from(input, "utf8").toString("base64")
        : input.toString("base64");
    return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  private async loadCertificate(): Promise<{
    privateKeyPem: string;
    x5t: string;
  }> {
    if (this.cachedCert) return this.cachedCert;

    let pfxBuffer: Buffer;
    let pfxPassword: string;

    const certPath = process.env.CERT_PATH ?? this.cfg.certPath ?? "";

    if (!certPath) {
      throw new Error(
        "No certificate path configured. Set CERT_PATH env var or certPath in config."
      );
    }

    const absolutePath = path.resolve(process.cwd(), certPath);

    if (!fs.existsSync(absolutePath)) {
      throw new Error(`Certificate not found at path: ${absolutePath}`);
    }

    pfxBuffer = fs.readFileSync(absolutePath);
    pfxPassword = process.env.CERT_PASSWORD ?? this.cfg.certPassword ?? "";

    this.logger.log(`Certificate loaded from: ${absolutePath}`);

    const p12Asn1 = forge.asn1.fromDer(pfxBuffer.toString("binary"));
    const p12 = forge.pkcs12.pkcs12FromAsn1(p12Asn1, pfxPassword);

    const keyBags = p12.getBags({
      bagType: forge.pki.oids.pkcs8ShroudedKeyBag
    });
    const certBags = p12.getBags({ bagType: forge.pki.oids.certBag });

    const keyBag = keyBags[forge.pki.oids.pkcs8ShroudedKeyBag]?.[0];
    const certBag = certBags[forge.pki.oids.certBag]?.[0];

    if (!keyBag?.key || !certBag?.cert) {
      throw new Error("Failed to extract key or certificate from PFX");
    }

    const privateKeyPem = forge.pki.privateKeyToPem(keyBag.key);

    const certDer = forge.asn1
      .toDer(forge.pki.certificateToAsn1(certBag.cert))
      .getBytes();
    const thumbprintBuffer = crypto
      .createHash("sha1")
      .update(Buffer.from(certDer, "binary"))
      .digest();
    const x5t = this.toBase64Url(thumbprintBuffer);

    this.cachedCert = { privateKeyPem, x5t };
    return this.cachedCert;
  }

  private buildClientAssertion(privateKeyPem: string, x5t: string): string {
    const now = Math.floor(Date.now() / 1000);

    const header = this.toBase64Url(
      JSON.stringify({ alg: "RS256", typ: "JWT", x5t })
    );

    const payload = this.toBase64Url(
      JSON.stringify({
        aud: `https://login.microsoftonline.com/${this.cfg.tenantId}/oauth2/v2.0/token`,
        iss: this.cfg.clientId,
        sub: this.cfg.clientId,
        jti: crypto.randomUUID(),
        nbf: now,
        exp: now + 600
      })
    );

    const toSign = `${header}.${payload}`;
    const signature = crypto
      .createSign("SHA256")
      .update(toSign)
      .sign(privateKeyPem, "base64");

    const sigEncoded = signature
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    return `${toSign}.${sigEncoded}`;
  }

  private async getAppOnlyToken(): Promise<string> {
    const { privateKeyPem, x5t } = await this.loadCertificate();
    const clientAssertion = this.buildClientAssertion(privateKeyPem, x5t);

    try {
      const params = new URLSearchParams({
        grant_type: "client_credentials",
        client_id: this.cfg.clientId,
        client_assertion_type:
          "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        client_assertion: clientAssertion,
        scope: "https://dpworld.sharepoint.com/.default"
      });

      const response = await axios.post(
        `https://login.microsoftonline.com/${this.cfg.tenantId}/oauth2/v2.0/token`,
        params.toString(),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
      );

      return response.data.access_token as string;
    } catch (ex: any) {
      throw new Error("Error while getting token");
    }
  }

  private matchesLogin(
    users: Array<{ Email: string; LoginName: string }>,
    userLogin: string
  ): boolean {
    const loginLower = userLogin.toLowerCase();
    return users.some(
      (u) =>
        u.Email?.toLowerCase() === loginLower ||
        u.LoginName?.toLowerCase().includes(loginLower)
    );
  }

  private async fetchGroupUsers(
    token: string,
    groupName: string
  ): Promise<Array<{ Email: string; LoginName: string }>> {
    const encodedGroup = encodeURIComponent(`'${groupName}'`);
    const url = `${this.cfg.sharePointUrl}/_api/web/sitegroups/getbyname(${encodedGroup})/users`;
    try {
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json;odata=nometadata"
        }
      });
      return response.data?.value ?? [];
    } catch (err: any) {
      this.logger.error(
        `Failed to fetch users for group '${groupName}': ${err?.message}`
      );
      return [];
    }
  }

  private static readonly GLOBAL_FULL_READ_GROUPS = [
    PermissionEnum.CLPricingOwners,
    PermissionEnum.CLPricingMembers,
    PermissionEnum.CLPricingVisitors,
    PermissionEnum.Pricing
  ];
  private static readonly COUNTRY_VISITOR_GROUPS: Record<string, string> = {
    "Visitors - Austria": "Austria",
    "Visitors - Belgium": "Belgium",
    "Visitors - Czech Republic": "Czech Republic",
    "Visitors - France": "France",
    "Visitors - Germany": "Germany",
    "Visitors - Hungary": "Hungary",
    "Visitors - Italy": "Italy",
    "Visitors - Netherlands": "Netherlands",
    "Visitors - Poland": "Poland",
    "Visitors - Romania": "Romania",
    "Visitors - Serbia": "Serbia",
    "Visitors - Slovakia": "Slovakia",
    "Visitors - Spain": "Spain",
    "Visitors - Sweden": "Sweden",
    "Visitors - Turkey": "Turkey",
    "Visitors - United Kingdom": "United Kingdom"
  };

  private static readonly ASSOCIATED_GROUP_FIELDS = ["AssociatedGroup"];

  private async fetchAssociatedGroup(
    token: string,
    stakeholderCode: string
  ): Promise<string | null> {
    const url = `${this.cfg.sharePointUrl}/_api/web/lists/getByTitle('InputTemplate')/items`;
    try {
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json;odata=nometadata"
        },
        params: {
          $filter: `Code eq '${stakeholderCode}'`,
          $top: 1,
          $select: "AssociatedGroup/Title",
          $expand: "AssociatedGroup"
        }
      });

      const item: Record<string, unknown> = response.data?.value?.[0];
      if (!item) return null;

      for (const field of SharepointPermissionService.ASSOCIATED_GROUP_FIELDS) {
        const val = item[field];
        const entry = Array.isArray(val) ? val[0] : val;
        if (entry && typeof entry === "object") {
          const name = (entry as any).Title ?? (entry as any).Name;
          if (typeof name === "string" && name) return name;
        }
      }

      this.logger.warn(
        `Could not find Associated Group field on InputTemplate item. ` +
          `Available fields: ${Object.keys(item).join(", ")}`
      );
      return null;
    } catch (err: any) {
      const spError =
        err?.response?.data?.["odata.error"]?.message?.value ??
        err?.response?.data;
      this.logger.error(
        `Failed to fetch InputTemplate for code '${stakeholderCode}': ${err?.message}`,
        spError ? JSON.stringify(spError) : ""
      );
      return null;
    }
  }

  async isUserInGroup(userLogin: string, groupName: string): Promise<boolean> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    const users = await this.fetchGroupUsers(token, groupName);
    return this.matchesLogin(users, userLogin);
  }

  async hasUserFolderAccess(
    userLogin: string,
    fileRelPath: string,
    isEdit = false,
    isView = false,
    skipFileName = true
  ): Promise<boolean> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    const pricingUsers = await this.fetchGroupUsers(
      token,
      PermissionEnum.Pricing
    );
    if (this.matchesLogin(pricingUsers, userLogin)) return true;

    const folderPath = skipFileName
      ? fileRelPath.substring(0, fileRelPath.lastIndexOf("/"))
      : fileRelPath;

    const tenantRoot = this.cfg.sharePointUrl.replace(/\/sites\/[^/]+$/, "");
    const siteMatch = folderPath.match(/^(\/sites\/[^/]+)/);
    const siteWebUrl = siteMatch
      ? `${tenantRoot}${siteMatch[1]}`
      : this.cfg.sharePointUrl;

    const userClaim = `i:0#.f|membership|${userLogin}`;
    const url = `${siteWebUrl}/_api/web/GetFolderByServerRelativeUrl('${encodeURIComponent(folderPath)}')/ListItemAllFields/GetUserEffectivePermissions(@u)?@u='${encodeURIComponent(userClaim)}'`;

    try {
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json;odata=nometadata"
        }
      });

      const permissions = response.data as { High: string; Low: string };
      const low = parseInt(permissions?.Low ?? "0", 10);
      if (isEdit) return (low & 0x4) !== 0; // EditListItems
      if (isView) return (low & 0x1) !== 0; // ViewListItems
      return (low & 0x9) !== 0; // either View or Edit
    } catch (err: any) {
      this.logger.error(
        `Failed to check folder permissions for '${userLogin}' on '${folderPath}': ${err?.message}`
      );
      return false;
    }
  }

  async isUserAuthorizedForStakeholderOrPricing(
    userLogin: string,
    stakeholderCode: string
  ): Promise<boolean> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    // Fetch Pricing group members and the associated group for the code in parallel
    const [pricingUsers, associatedGroup] = await Promise.all([
      this.fetchGroupUsers(token, "Pricing"),
      this.fetchAssociatedGroup(token, stakeholderCode)
    ]);

    if (this.matchesLogin(pricingUsers, userLogin)) return true;

    if (!associatedGroup) {
      this.logger.warn(
        `No Associated Group found for stakeholder code '${stakeholderCode}'`
      );
      return false;
    }

    const groupUsers = await this.fetchGroupUsers(token, associatedGroup);
    return this.matchesLogin(groupUsers, userLogin);
  }

  async isUserAuthorizedForStakeholder(
    userLogin: string,
    stakeholderCode: string
  ): Promise<boolean> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    const pricingUsers = await this.fetchGroupUsers(
      token,
      PermissionEnum.Pricing
    );
    if (this.matchesLogin(pricingUsers, userLogin)) return true;

    const associatedGroup = await this.fetchAssociatedGroup(
      token,
      stakeholderCode
    );

    if (!associatedGroup) {
      this.logger.warn(
        `No Associated Group found for stakeholder code '${stakeholderCode}'`
      );
      return false;
    }

    const groupUsers = await this.fetchGroupUsers(token, associatedGroup);
    return this.matchesLogin(groupUsers, userLogin);
  }

  async getVisitorAccess(
    userLogin: string
  ): Promise<{ isGlobalVisitor: boolean; countries: string[] }> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    const countryGroupNames = Object.keys(
      SharepointPermissionService.COUNTRY_VISITOR_GROUPS
    );

    const [globalResultsByGroup, countryUsersByGroup] = await Promise.all([
      Promise.all(
        SharepointPermissionService.GLOBAL_FULL_READ_GROUPS.map((group) =>
          this.fetchGroupUsers(token, group)
        )
      ),
      Promise.all(
        countryGroupNames.map((group) => this.fetchGroupUsers(token, group))
      )
    ]);

    const isGlobalVisitor = globalResultsByGroup.some((users) =>
      this.matchesLogin(users, userLogin)
    );
    const countries = countryGroupNames
      .filter((_group, idx) =>
        this.matchesLogin(countryUsersByGroup[idx], userLogin)
      )
      .map(
        (group) => SharepointPermissionService.COUNTRY_VISITOR_GROUPS[group]
      );

    return { isGlobalVisitor, countries };
  }

  async hasVisitorAccessToCountry(
    userLogin: string,
    country: string | null | undefined
  ): Promise<boolean> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }

    const countryGroup = country
      ? Object.entries(SharepointPermissionService.COUNTRY_VISITOR_GROUPS).find(
          ([, mappedCountry]) => mappedCountry === country
        )?.[0]
      : undefined;

    const [globalResultsByGroup, countryUsers] = await Promise.all([
      Promise.all(
        SharepointPermissionService.GLOBAL_FULL_READ_GROUPS.map((group) =>
          this.fetchGroupUsers(token, group)
        )
      ),
      countryGroup ? this.fetchGroupUsers(token, countryGroup) : Promise.resolve([])
    ]);

    return (
      globalResultsByGroup.some((users) => this.matchesLogin(users, userLogin)) ||
      this.matchesLogin(countryUsers, userLogin)
    );
  }

  async checkOpportunityRoundPermission(
    id: number,
    opportunity: any,
    roundNumber: number,
    stakeholderCode: string,
    currentContext: CurrentContext,
    isEdit = false,
    isView = false,
    skipFileName = true
  ) {
    if (!opportunity) {
      throw new NotFoundException(`Opportunity with ID ${id} not found`);
    }

    const fileRelPath = stakeholderCode
      ? `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${roundNumber}/${stakeholderCode}`
      : `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${roundNumber}`;

    const hasAccess = await this.hasUserFolderAccess(
      currentContext.user.unique_name,
      fileRelPath,
      isEdit,
      isView,
      skipFileName
    );
    if (!hasAccess) {
      throw new ForbiddenException(
        `User does not have permission to access this Round`
      );
    }
  }

  async checkOpportunityPermission(
    id: number,
    opportunity: any,
    currentContext: CurrentContext,
    isEdit = false,
    isView = false
  ) {
    if (!opportunity) {
      throw new NotFoundException(`Opportunity with ID ${id} not found`);
    }

    const fileRelPath = `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}`;

    const hasAccess = await this.hasUserFolderAccess(
      currentContext.user.unique_name,
      fileRelPath,
      isEdit,
      isView,
      false
    );
    if (!hasAccess) {
      throw new ForbiddenException(
        `User does not have permission to access this Opportunity`
      );
    }
  }

  async getUsersFromSharePointGroup(groupName: string): Promise<any> {
    let token: string;
    try {
      token = await this.getAppOnlyToken();
    } catch (err: any) {
      this.logger.error(
        "Failed to acquire SharePoint app-only token",
        err?.message
      );
      throw new UnauthorizedException("Could not acquire SharePoint token");
    }
    return await this.fetchGroupUsers(token, groupName);
  }
}
