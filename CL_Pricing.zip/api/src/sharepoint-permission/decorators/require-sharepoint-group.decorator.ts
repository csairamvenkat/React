import { SetMetadata } from '@nestjs/common';

export const SHAREPOINT_GROUP_KEY = 'sharepoint-group';
export const RequireSharePointGroup = (group: string) => SetMetadata(SHAREPOINT_GROUP_KEY, group);
