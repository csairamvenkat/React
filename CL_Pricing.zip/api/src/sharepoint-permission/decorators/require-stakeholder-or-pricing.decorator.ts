import { SetMetadata } from '@nestjs/common';

export const STAKEHOLDER_OR_PRICING_KEY = 'stakeholder-or-pricing';
export const RequireStakeholderOrPricingAccess = () => SetMetadata(STAKEHOLDER_OR_PRICING_KEY, true);
