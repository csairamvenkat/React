import { Module, Global } from '@nestjs/common';
import { ConfigController } from './config.controller';
import { ConfigService } from './config.service';
@Global()
@Module({
	providers: [
		{
			provide: ConfigService,
			useValue: new ConfigService(),
		},
	],
	controllers: [ConfigController],
	imports: [],
	exports: [ConfigService],
})
export class ConfigModule { }
