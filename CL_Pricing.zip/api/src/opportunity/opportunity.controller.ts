import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Put,
  Delete,
  Query,
  UseGuards,
  NotFoundException
} from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
  ApiHeader,
  ApiQuery,
  ApiBody
} from "@nestjs/swagger";
import { OpportunityService } from "./opportunity.service";
import { CreateOpportunityDto } from "./dtos/create-opportunity.dto";
import { UpdateOpportunityDto } from "./dtos/update-opportunity.dto";
import { UpdateBidTeamMembersDto } from "./dtos/update-bid-team-members.dto";
import { GetScenariosByNameDto } from "./dtos/get-scenarios-by-name.dto";
import { OpportunityResponseDto } from "./dtos/opportunity-response.dto";
import { CurrentContext } from "../shared/types/current-context.type";
import { Context } from "../shared/decorators/current-context.decorator";
import { AuthGuard } from "@nestjs/passport";
import { GetOpportunitiesFilterDto } from "./dtos/get-opportunities-filter";
import { SharepointPermissionService } from "src/sharepoint-permission/providers/sharepoint-permission.service";
import { SharepointPermissionGuard } from "src/sharepoint-permission/guards/sharepoint-permission.guard";
import { RequireSharePointGroup } from "src/sharepoint-permission/decorators/require-sharepoint-group.decorator";
import { PermissionEnum } from "src/shared/enums/permission-status.enum";

@ApiTags("Opportunity")
@ApiBearerAuth()
@ApiHeader({
  name: "Authorization",
  description:
    "Bearer token (Azure AD for SPFx OR Service Account token for Power Automate)",
  required: true
})
@UseGuards(AuthGuard("oauth-bearer"))
@Controller("opportunity")
export class OpportunityController {
  constructor(
    private readonly opportunityService: OpportunityService,
    private readonly sharepointPermissionService: SharepointPermissionService
  ) {}

  @Post()
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  @ApiOperation({ summary: "Create a new opportunity" })
  @ApiResponse({
    status: 201,
    description: "Opportunity created successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  async createOpportunity(
    @Body() createDto: CreateOpportunityDto,
    @Context() context: CurrentContext
  ): Promise<OpportunityResponseDto> {
    const opportunity = await this.opportunityService.createOpportunity(
      createDto,
      context
    );

    return this.mapToResponseDto(opportunity);
  }

  @Get(":id")
  @ApiOperation({ summary: "Get opportunity by ID" })
  @ApiResponse({
    status: 200,
    description: "Opportunity retrieved successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  async getOpportunityById(
    @Param("id") id: number,
    @Context() context: CurrentContext
  ): Promise<OpportunityResponseDto> {
    const opportunity = await this.opportunityService.getOpportunityById(id);

    await this.sharepointPermissionService.checkOpportunityPermission(
      id,
      opportunity,
      context,
      false,
      true
    );

    return this.mapToResponseDto(opportunity);
  }

  @Post("search")
  @ApiOperation({ summary: "Get all opportunities with filters & pagination" })
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        customer: { type: "string", example: "Acme" },
        project_name: { type: "string", example: "ERP Upgrade" },
        title: { type: "string", example: "Backend Developer" },
        search_text: { type: "string", example: "john" },
        country_code: {
          type: "array",
          items: { type: "string" },
          example: ["AE", "IN"]
        },
        is_lead_pricer: { type: "boolean", example: true },
        page_number: { type: "number", example: 1 },
        page_size: { type: "number", example: 10 },
        is_active: { type: "boolean", example: true }
      }
    }
  })
  @ApiResponse({
    status: 200,
    description: "Paginated opportunities retrieved successfully",
    schema: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: { $ref: "#/components/schemas/OpportunityResponseDto" }
        },
        page_number: { type: "number", example: 1 },
        page_size: { type: "number", example: 10 },
        total_records: { type: "number", example: 42 }
      }
    }
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getAllOpportunities(
    @Body() filters: GetOpportunitiesFilterDto,
    @Context() context: CurrentContext
  ): Promise<{
    data: OpportunityResponseDto[];
    total_records: number;
  }> {
    const result = await this.opportunityService.getAllOpportunities(
      filters,
      context
    );

    return {
      data: result.data.map((opp) => this.mapToResponseDto(opp)),
      total_records: result.total_records
    };
  }

  @Get("customers/search")
  @ApiOperation({
    summary: "Get unique customers filtered by name with pagination"
  })
  @ApiQuery({
    name: "name",
    required: true,
    description: "Customer name filter (case-insensitive partial match)",
    example: "Acme"
  })
  @ApiQuery({
    name: "page_number",
    required: false,
    description: "Page number (starts from 1)",
    example: 1,
    schema: { type: "number", default: 1 }
  })
  @ApiQuery({
    name: "page_size",
    required: false,
    description: "Number of unique customer names per page",
    example: 10,
    schema: { type: "number", default: 10 }
  })
  @ApiResponse({
    status: 200,
    description:
      "Unique customer names retrieved successfully (case-insensitive search)",
    schema: {
      type: "array",
      items: { type: "string" },
      example: ["Acme Corporation", "Acme Industries", "Acme Solutions"]
    }
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getCustomersByName(
    @Query("name") name: string,
    @Query("page_number") page_number?: number,
    @Query("page_size") page_size?: number
  ): Promise<string[]> {
    return this.opportunityService.getCustomersByName(
      name,
      page_number,
      page_size
    );
  }

  @Put(":id")
  @ApiOperation({ summary: "Update an opportunity" })
  @ApiResponse({
    status: 200,
    description: "Opportunity updated successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async updateOpportunity(
    @Param("id") id: number,
    @Body() updateDto: UpdateOpportunityDto,
    @Context() context: CurrentContext
  ): Promise<OpportunityResponseDto> {
    const opportunity = await this.opportunityService.updateOpportunity(
      id,
      updateDto,
      context
    );
    return this.mapToResponseDto(opportunity);
  }

  @Put(":id/bid-team-members")
  @ApiOperation({ summary: "Update bid team members for an opportunity" })
  @ApiResponse({
    status: 200,
    description: "Bid team members updated successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async updateBidTeamMembers(
    @Param("id") id: number,
    @Body() updateDto: UpdateBidTeamMembersDto,
    @Context() context: CurrentContext
  ): Promise<OpportunityResponseDto> {
    const opportunity = await this.opportunityService.updateBidTeamMembers(
      id,
      updateDto.bid_team_members,
      context
    );
    return this.mapToResponseDto(opportunity);
  }

  @Put(":id/active")
  @ApiOperation({ summary: "Toggle active/inactive status of an opportunity" })
  @ApiBody({
    schema: {
      type: "object",
      required: ["active"],
      properties: { active: { type: "boolean", example: true } }
    }
  })
  @ApiResponse({
    status: 200,
    description: "Status updated successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async updateActiveStatus(
    @Param("id") id: number,
    @Body("active") active: boolean,
    @Context() context: CurrentContext
  ): Promise<OpportunityResponseDto> {
    const opportunity = await this.opportunityService.updateActiveStatus(
      id,
      active,
      context
    );
    return this.mapToResponseDto(opportunity);
  }

  @Delete(":id")
  @ApiOperation({ summary: "Delete an opportunity (soft delete)" })
  @ApiResponse({
    status: 200,
    description: "Opportunity deleted successfully",
    schema: {
      type: "object",
      properties: {
        success: { type: "boolean", example: true },
        message: { type: "string", example: "Opportunity deleted successfully" }
      }
    }
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async deleteOpportunity(
    @Param("id") id: number,
    @Context() context: CurrentContext
  ): Promise<{ success: boolean; message: string }> {
    await this.opportunityService.deleteOpportunity(id, context);
    return {
      success: true,
      message: "Opportunity deleted successfully"
    };
  }

  @Post("scenarios/search")
  @ApiOperation({
    summary: "Get all scenarios by opportunity name with stakeholders"
  })
  @ApiResponse({
    status: 200,
    description: "Scenarios with stakeholders retrieved successfully",
    schema: {
      type: "array",
      items: {
        type: "object",
        properties: {
          opportunityId: { type: "number", example: 1 },
          customer: { type: "string", example: "Acme Corporation" },
          opportunityName: {
            type: "string",
            example: "Q1 2025 Pricing Proposal"
          },
          roundId: { type: "number", example: 1 },
          roundNumber: { type: "number", example: 1 },
          roundDescription: {
            type: "string",
            example: "Initial pricing round"
          },
          scenarios: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string", example: "A" },
                desc: {
                  type: "string",
                  example: "Scenario A for standard pricing"
                }
              }
            }
          },
          lead_pricer: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string", example: "John Doe" },
                email: {
                  type: "string",
                  example: "john.doe@example.com"
                },
                login_id: {
                  type: "string",
                  example: "john.doe@example.com"
                }
              }
            }
          },
          stakeholders: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "number", example: 1 },
                stakeholder: { type: "string", example: "Engineering" },
                additionalStakeholders: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string", example: "John Doe" },
                      email: {
                        type: "string",
                        example: "john.doe@example.com"
                      },
                      login_id: {
                        type: "string",
                        example: "john.doe@example.com"
                      }
                    }
                  }
                },
                applicableScenarios: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string", example: "A" },
                      desc: { type: "string", example: "Scenario A" }
                    }
                  }
                },
                dueDate: {
                  type: "string",
                  format: "date-time",
                  example: "2025-02-15T23:59:59.000Z"
                },
                stakeholder_code: { type: "string", example: "ENG" },
                notifyUsers: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string", example: "John Doe" },
                      email: {
                        type: "string",
                        example: "john.doe@example.com"
                      },
                      login_id: {
                        type: "string",
                        example: "john.doe@example.com"
                      }
                    }
                  },
                  nullable: true
                }
              }
            }
          },
          inputs: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "number", example: 10 },
                opportunityId: { type: "number", example: 1 },
                roundId: { type: "number", example: 1 },
                roundNumber: { type: "number", example: 1 },
                stakeholder: { type: "string", example: "Engineering" },
                revisionNumber: { type: "number", example: 1 },
                isCurrentVersion: { type: "string", example: "1" },
                isCurrentApproved: { type: "string", example: "0" },
                scenarioName: { type: "string", example: "A" },
                fileRelPath: { type: "string", nullable: true, example: null },
                exportedOn: {
                  type: "string",
                  format: "date-time",
                  nullable: true,
                  example: null
                },
                userStatus: { type: "string", example: "Created" },
                workflowStatus: { type: "string", example: "Created" },
                isStandardRate: { type: "string", example: "0" },
                isCopiedPreviousRound: { type: "string", example: "0" },
                dataRoundId: { type: "number", nullable: true, example: null },
                inputType: {
                  type: "string",
                  nullable: true,
                  example: "manual"
                },
                active: { type: "boolean", example: true },
                deleted: { type: "boolean", example: false },
                createdOn: {
                  type: "string",
                  format: "date-time",
                  example: "2025-01-15T10:30:00.000Z"
                },
                createdBy: { type: "string", example: "user@example.com" }
              }
            }
          }
        }
      }
    }
  })
  @ApiResponse({
    status: 404,
    description: "No opportunities or scenarios found"
  })
  async getScenariosByOpportunityName(
    @Body() dto: GetScenariosByNameDto,
    @Context() context: CurrentContext
  ): Promise<any[]> {
    const opportunity = await this.opportunityService.getOpportunityByTitle(
      dto.opportunityName
    );

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with Name ${dto.opportunityName} not found`
      );
    }

    await this.sharepointPermissionService.checkOpportunityPermission(
      opportunity.id,
      opportunity,
      context,
      false,
      true
    );

    return this.opportunityService.getScenariosByOpportunityName(
      dto.opportunityName
    );
  }

  @Post("get-opportunity-by-name")
  @ApiOperation({
    summary: "Get all scenarios by opportunity name with stakeholders"
  })
  @ApiResponse({
    status: 200,
    description: "Status updated successfully",
    type: OpportunityResponseDto
  })
  @ApiResponse({ status: 404, description: "Opportunity not found" })
  async getOpportunityByTitle(
    @Body() dto: GetScenariosByNameDto,
    @Context() context: CurrentContext
  ): Promise<any> {
    const opportunity = await this.opportunityService.getOpportunityByTitle(
      dto.opportunityName
    );
    if (!opportunity) throw new NotFoundException("Opportunity not found");
    return this.mapToResponseDto(opportunity);
  }

  private mapToResponseDto(opportunity: any): OpportunityResponseDto {
    return {
      id: opportunity.id,
      leadNumber: opportunity.leadNumber,
      customer: opportunity.customer,
      region: opportunity.region,
      title: opportunity.title,
      country: opportunity.country,
      countryCode: opportunity.countryCode,
      project_name: opportunity.project_name,
      bid_team_members: opportunity.bid_team_members,
      lead_pricer: opportunity.lead_pricer,
      userStatus: opportunity.userStatus,
      workflowStatus: opportunity.workflowStatus,
      active: opportunity.active,
      deleted: opportunity.deleted,
      createdOn: opportunity.createdOn,
      createdBy: opportunity.createdBy,
      modifiedOn: opportunity.modifiedOn,
      modifiedBy: opportunity.modifiedBy
    };
  }
}
