import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { Customer } from '../models/customer.model';

@Injectable()
export class CustomerRepository extends BaseRepository<Customer> {
  constructor(
    @InjectModel(Customer)
    private customerModel: typeof Customer,
  ) {
    super(customerModel);
  }
}
