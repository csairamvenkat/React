import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { Opportunity } from '../models/opportunity.model';

@Injectable()
export class OpportunityRepository extends BaseRepository<Opportunity> {
  constructor(
    @InjectModel(Opportunity)
    private opportunityModel: typeof Opportunity,
  ) {
    super(opportunityModel);
  }
}
