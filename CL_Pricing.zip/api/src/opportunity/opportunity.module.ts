import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { OpportunityController } from './opportunity.controller';
import { OpportunityService } from './opportunity.service';
import { Opportunity } from './models/opportunity.model';
import { Customer } from './models/customer.model';
import { OpportunityRepository } from './repositories/opportunity.repository';
import { SharepointPermissionModule } from '../sharepoint-permission/sharepoint-permission.module';
import { CustomerRepository } from './repositories/customer.repository';
import { HistoryModule } from "../history/history.module";

@Module({
  imports: [SequelizeModule.forFeature([Opportunity, Customer]), SharepointPermissionModule,HistoryModule],
  controllers: [OpportunityController],
  providers: [OpportunityService, OpportunityRepository, CustomerRepository],
  exports: [OpportunityService, OpportunityRepository, CustomerRepository],
})
export class OpportunityModule {}
