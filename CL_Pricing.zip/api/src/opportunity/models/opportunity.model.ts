import { Column, DataType, HasMany, Table } from 'sequelize-typescript';
import { BaseModel } from '../../shared/models/base.model';
import { OpportunityRound } from '../../opportunity-round/models/opportunity-round.model';

export interface user {
  name: string;
  email: string;
  login_id: string;
}

@Table({
  tableName: 'opportunity',
  timestamps: false,
})
export class Opportunity extends BaseModel<Opportunity> {
  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'lead_number',
  })
  leadNumber: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'customer',
  })
  customer: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: 'region',
  })
  region: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'title',
  })
  title: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'country',
  })
  country: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: 'country_code',
  })
  countryCode: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'user_status',
  })
  userStatus: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'workflow_status',
  })
  workflowStatus: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'project_name',
  })
  project_name: string;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: 'bid_team_members',
  })
  bid_team_members: user[];

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: 'lead_pricer',
  })
  lead_pricer: user[];
  
  @HasMany(() => OpportunityRound, 'opportunityId')
  rounds: OpportunityRound[];
}
