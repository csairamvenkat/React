import { Column, DataType, HasMany, Table } from 'sequelize-typescript';
import { BaseModel } from '../../shared/models/base.model';
import { OpportunityRound } from '../../opportunity-round/models/opportunity-round.model';

export interface user {
  name: string;
  email: string;
  login_id: string;
}

@Table({
  tableName: 'customer',
  timestamps: false,
})
export class Customer extends BaseModel<Customer> {
  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'customer',
  })
  customer: string;
}
