import { Injectable, NotFoundException } from "@nestjs/common";
import { OpportunityRepository } from "./repositories/opportunity.repository";
import { CreateOpportunityDto } from "./dtos/create-opportunity.dto";
import { UpdateOpportunityDto } from "./dtos/update-opportunity.dto";
import { Opportunity } from "./models/opportunity.model";
import { OpportunityUserStatus } from "src/shared/enums/opportunity-status.enum";
import { CurrentContext } from "../shared/types/current-context.type";
import { Op, Sequelize } from "sequelize";
import { OpportunityRound } from "../opportunity-round/models/opportunity-round.model";
import { OpportunityRoundStakeholder } from "../opportunity-round/models/opportunity-round-stakeholder.model";
import { GetOpportunitiesFilterDto } from "./dtos/get-opportunities-filter";
import { OpportunityRoundInput } from "src/opportunity-round/models/opportunity-round-input.model";
import { CustomerRepository } from "./repositories/customer.repository";
import { Customer } from "./models/customer.model";
import { HistoryActionComments, HistoryActionPerformed, HistoryEntityType } from "src/shared/enums/history.enum";
//import { HistoryService } from "../history/history.service";
import { History } from "../history/models/history.model";
@Injectable()
export class OpportunityService {
  constructor(private readonly opportunityRepository: OpportunityRepository,
    private readonly customerRepository: CustomerRepository,
    //private readonly historyService: HistoryService
  ) { }

  async createOpportunity(
    createDto: CreateOpportunityDto,
    currentContext: CurrentContext
  ): Promise<Opportunity> {
    const opportunity = new Opportunity();

    opportunity.leadNumber = createDto.leadNumber;
    opportunity.customer = createDto.customer;
    opportunity.region = createDto.region;
    opportunity.title = createDto.title;
    opportunity.country = createDto.country;
    opportunity.countryCode = createDto.countryCode;
    opportunity.project_name = createDto.project_name;
    opportunity.bid_team_members = createDto.bid_team_members;
    opportunity.lead_pricer = createDto.lead_pricer;
    opportunity.userStatus = OpportunityUserStatus.Created;
    opportunity.workflowStatus = OpportunityUserStatus.Created;
    opportunity.active = true;
    opportunity.deleted = false;

    const isCustomerIsExist = await this.customerRepository.findOne(
      {
        where: {
          customer: Sequelize.where(
            Sequelize.fn("LOWER", Sequelize.col("customer")),
            Op.eq,
            createDto.customer.toLowerCase()
          )
        }
      },
      { includeInactive: true }
    );

    if (!isCustomerIsExist) {
      const customer = new Customer();
      customer.customer = createDto.customer;

      await this.customerRepository.save(
        customer,
        currentContext
      );
    }

    const createdOpportunity =
      await this.opportunityRepository.save(
        opportunity,
        currentContext
      );
    const history = new History();
    history.entityType = HistoryEntityType.OPPORTUNITY;
    history.entityId = createdOpportunity.id;
    history.actionPerformed = HistoryActionPerformed.CREATED;
    history.actionComments = HistoryActionComments.OPPORTUNITY_CREATED;
    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    await history.save();
    return createdOpportunity;
  }

  async getOpportunityById(id: number): Promise<Opportunity> {
    return this.opportunityRepository.findById(id, { includeInactive: true });
  }

  async getOpportunityByTitle(opportunityName: string): Promise<Opportunity> {
    return this.opportunityRepository.findOne(
      {
        where: {
          title: {
            [Op.iLike]: `${opportunityName}`
          }
        }
      },
      { includeInactive: true }
    );
  }

  async getAllOpportunities(
    filters: GetOpportunitiesFilterDto,
    currentContext: CurrentContext
  ): Promise<{
    data: Opportunity[];
    total_records: number;
  }> {
    const pageNumber = filters.page_number || 1;
    const pageSize = filters.page_size || 10;
    const offset = (pageNumber - 1) * pageSize;

    const where: any = {};

    if (filters.customer) {
      where.customer = {
        [Op.iLike]: `%${filters.customer}%`
      };
    }

    if (filters.project_name) {
      where.project_name = {
        [Op.iLike]: `%${filters.project_name}%`
      };
    }

    if (filters.title) {
      where.title = {
        [Op.iLike]: `%${filters.title}%`
      };
    }

    if (filters.is_active !== undefined) {
      where.active = { [Op.eq]: filters.is_active };
    }

    if (filters.search_text) {
      const term = filters.search_text.replace(/'/g, "''");
      where[Op.and] = [
        ...(Array.isArray(where[Op.and]) ? where[Op.and] : []),
        {
          [Op.or]: [
            { title: { [Op.iLike]: `%${term}%` } },
            { customer: { [Op.iLike]: `%${term}%` } },
            { project_name: { [Op.iLike]: `%${term}%` } },
            Sequelize.literal(
              `EXISTS (SELECT 1 FROM jsonb_array_elements(lead_pricer) AS lp WHERE ` +
              `lower(lp->>'name') LIKE lower('%${term}%') OR ` +
              `lower(lp->>'email') LIKE lower('%${term}%') OR ` +
              `lower(lp->>'login_id') LIKE lower('%${term}%'))`
            )
          ]
        }
      ];
    }

    if (filters.country_code?.length) {
      where.countryCode = {
        [Op.in]: filters.country_code
      };
    }

    if (filters.is_lead_pricer) {
      const username = currentContext.user.upn?.toLowerCase();
      where[Op.and] = [
        ...(Array.isArray(where[Op.and]) ? where[Op.and] : []),
        Sequelize.literal(
          `EXISTS (SELECT 1 FROM jsonb_array_elements(lead_pricer) AS elem WHERE lower(elem->>'login_id') = '${username}')`
        )
      ];
    }

    const { rows, count } = await this.opportunityRepository.findAndCountAll(
      {
        where,
        limit: pageSize,
        offset,
        order: [["id", "DESC"]]
      },
      { includeInactive: true }
    );

    return {
      data: rows,
      total_records: count
    };
  }

  async getCustomersByName(
    nameFilter: string,
    page_number: number = 1,
    page_size: number = 10
  ): Promise<any> {
    const offset = (page_number - 1) * page_size;

    // const { rows, count } = await this.opportunityRepository.findAndCountAll(
    //   {
    //     attributes: [
    //       [Sequelize.fn("DISTINCT", Sequelize.col("customer")), "customer"]
    //     ],
    //     where: {
    //       customer: {
    //         [Op.iLike]: `%${nameFilter}%`
    //       }
    //     },
    //     limit: page_size,
    //     offset
    //   },
    //   { includeInactive: true }
    // );

    const { rows, count } = await this.customerRepository.findAndCountAll(
      {
        where: {
          customer: {
            [Op.iLike]: `%${nameFilter}%`
          }
        },
        limit: page_size,
        offset
      },
      { includeInactive: true }
    );

    return {
      data: rows.map((r) => r.customer),
      page_number,
      page_size,
      total_records: count
    };
  }

  async updateOpportunity(
    id: number,
    updateDto: UpdateOpportunityDto,
    currentContext: CurrentContext
  ): Promise<Opportunity> {
    const opportunity = await this.opportunityRepository.findById(id);

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with ID ${id} not found`
      );
    }

    const fieldsToUpdate = Object.fromEntries(
      Object.entries(updateDto).filter(
        ([, v]) => v !== undefined && v !== null
      )
    );

    const changedFields: Record<string, any> = {};

    for (const [field, newValue] of Object.entries(fieldsToUpdate)) {
      const oldValue = (opportunity as any)[field];

      if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
        changedFields[field] = {
          old_value: oldValue,
          new_value: newValue,
        };
      }
    }

    await this.opportunityRepository.update(
      fieldsToUpdate,
      currentContext,
      {
        where: { id }
      },
      { includeDeleted: true }
    );

    if (Object.keys(changedFields).length > 0) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.UPDATED;
      history.actionComments = HistoryActionComments.OPPORTUNITY_UPDATED;
      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();
      history.additionalInfo = changedFields;

      await history.save();
    }

    return this.opportunityRepository.findById(
      id,
      { includeInactive: true }
    );
  }

  async updateBidTeamMembers(
    id: number,
    bid_team_members: any[],
    currentContext: CurrentContext
  ): Promise<Opportunity> {
    const opportunity = await this.opportunityRepository.findById(id, {
      includeInactive: true
    });

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with ID ${id} not found`
      );
    }

    // NEW: get old value
    const oldBidTeamMembers = opportunity.bid_team_members;

    // NEW: check whether value actually changed
    const hasChanged =
      JSON.stringify(oldBidTeamMembers) !==
      JSON.stringify(bid_team_members);

    // EXISTING: update database
    await this.opportunityRepository.update(
      { bid_team_members },
      currentContext,
      { where: { id } },
      { includeDeleted: true }
    );

    // NEW: create history
    if (hasChanged) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.UPDATED;
      history.actionComments =
        HistoryActionComments.BID_TEAM_MEMBERS_UPDATED;
      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      history.additionalInfo = {
        bid_team_members: {
          old_value: oldBidTeamMembers,
          new_value: bid_team_members
        }
      };

      await history.save();
    }

    return this.opportunityRepository.findById(
      id,
      { includeInactive: true }
    );
  }

  async updateActiveStatus(
    id: number,
    active: boolean,
    currentContext: CurrentContext
  ): Promise<Opportunity> {
    const opportunity = await this.opportunityRepository.findById(id, {
      includeInactive: true
    });

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with ID ${id} not found`
      );
    }

    const oldActive = opportunity.active;

    await this.opportunityRepository.update(
      { active: active },
      currentContext,
      {
        where: { id }
      },
      { includeInactive: true }
    );

    if (oldActive !== active) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.UPDATED;
      history.actionComments =
        HistoryActionComments.ACTIVE_STATUS_UPDATED;
      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      history.additionalInfo = {
        active: {
          old_value: oldActive,
          new_value: active
        }
      };

      await history.save();
    }
    return this.opportunityRepository.findById(
      id,
      { includeInactive: true }
    );
  }
  async deleteOpportunity(
    id: number,
    currentContext: CurrentContext
  ): Promise<boolean> {
    const opportunity = await this.opportunityRepository.findById(id, {
      includeInactive: true
    });

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with ID ${id} not found`
      );
    }

    const result = await this.opportunityRepository.deleteById(
      id,
      currentContext
    );

    if (result) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.DELETED;
      history.actionComments =
        HistoryActionComments.OPPORTUNITY_DELETED;
      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      await history.save();
    }

    return result;
  }

  async getScenariosByOpportunityName(opportunityName: string): Promise<any[]> {
        const opportunities = await this.opportunityRepository.search(
      {
        title: {
          [Op.iLike]: `${opportunityName}`
        }
      },
      {
        order: [["id", "DESC"]],
        include: [
          {
            model: OpportunityRound,
            as: "rounds",
            required: false,
            separate: true,
            // order: [['roundNumber', 'DESC']],
            include: [
              {
                model: OpportunityRoundStakeholder,
                as: "stakeholders",
                required: false,
                separate: true
                // order: [['id', 'DESC']]
              },
              {
                model: OpportunityRoundInput,
                as: "inputs",
                required: false,
                separate: true
              }
            ]
          }
        ]
      }
    );

    if (!opportunities || opportunities.length === 0) {
      throw new NotFoundException(
        `No opportunities found with name matching "${opportunityName}"`
      );
    }

    const scenariosResult = [];

    for (const opportunity of opportunities) {
      if (!opportunity.rounds || opportunity.rounds.length === 0) {
        scenariosResult.push({
          opportunityId: opportunity.id,
          customer: opportunity.customer,
          opportunityName: opportunity.title,
          roundId: null,
          roundNumber: null,
          roundDescription: null,
          scenarios: [],
          stakeholders: [],
          lead_pricer: opportunity.lead_pricer
        });
      } else {
        for (const round of opportunity.rounds) {
          scenariosResult.push({
            opportunityId: opportunity.id,
            customer: opportunity.customer,
            opportunityName: opportunity.title,
            roundId: round.id,
            roundNumber: round.roundNumber,
            roundDescription: round.description,
            scenarios: round.scenarioList || [],
            lead_pricer: opportunity.lead_pricer,
            stakeholders: round.stakeholders
              ? round.stakeholders.map((s) => ({
                id: s.id,
                stakeholder: s.stakeholder,
                additionalStakeholders: s.additionalStakeholders,
                applicableScenarios: s.applicableScenarios,
                dueDate: s.dueDate,
                stakeholder_code: s.stakeholder_code,
                notify_users: s.notify_users,
                stakeholderType: s.stakeholderType,
                collectDraftInput: s.collectDraftInput,
                draftDueDate: s.draftDueDate
              }))
              : [],
            inputs: round.inputs
              ? round.inputs.map((input) => ({
                id: input.id,
                opportunityId: input.opportunityId,
                roundId: input.roundId,
                roundNumber: input.roundNumber,
                stakeholder: input.stakeholder,
                stakeholderCode: input.stakeholderCode,
                revisionNumber: input.revisionNumber,
                isCurrentVersion: input.isCurrentVersion,
                isCurrentApproved: input.isCurrentApproved,
                scenarioName: input.scenarioName,
                fileRelPath: input.fileRelPath,
                exportedOn: input.exportedOn,
                userStatus: input.userStatus,
                workflowStatus: input.workflowStatus,
                isStandardRate: input.isStandardRate,
                isCopiedPreviousRound: input.isCopiedPreviousRound,
                dataRoundId: input.dataRoundId,
                inputType: input.input_type,
                revisionAttempt: input.revisionAttempt,
                lastRevisionAttempt: input.lastRevisionAttempt,
                inputRequired: input.inputRequired,
                versionNumber: input.versionNumber,
                active: input.active,
                deleted: input.deleted,
                createdOn: input.createdOn,
                createdBy: input.createdBy,
                submissionType: input.submissionType,
              }))
              : []
          });
        }
      }
    }

    return scenariosResult;
  }
}
