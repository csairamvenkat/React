import { ApiPropertyOptional } from "@nestjs/swagger";
import { IsArray, IsBoolean, IsNumber, IsOptional, IsString } from "class-validator";
import { Transform } from "class-transformer";

export class GetOpportunitiesFilterDto {
  @ApiPropertyOptional({
    description: "Customer name",
    example: "Acme Corporation"
  })
  @IsOptional()
  @IsString()
  customer?: string;

  @ApiPropertyOptional({
    description: "Project name",
    example: "Acme Corporation"
  })
  @IsOptional()
  @IsString()
  project_name?: string;

  @ApiPropertyOptional({
    description: "Customer name",
    example: "Acme Corporation"
  })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional({
    description: 'Country Code',
    example: ['IN', 'AE'],
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  country_code?: string[];

  @ApiPropertyOptional({
    description: "Search across title, customer, project_name, and lead_pricer name/email/login_id",
    example: "john"
  })
  @IsOptional()
  @IsString()
  search_text?: string;

  @ApiPropertyOptional({
    description: "Filter to show only opportunities where current user is lead pricer",
    example: true
  })
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === true || value === "true")
  is_lead_pricer?: boolean;

  @ApiPropertyOptional({
    description: "Page Number",
    example: "1"
  })
  @IsOptional()
  @IsNumber()
  page_number?: number;

  @ApiPropertyOptional({
    description: "Page Size",
    example: "10"
  })
  @IsOptional()
  @IsNumber()
  page_size?: number;

  @ApiPropertyOptional({
    description: "Filter to show only active opportunity",
    example: true
  })
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === true || value === "true")
  is_active?: boolean;
}
