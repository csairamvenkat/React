import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { UserDto } from "./bid-team-member.dto";
import { ValidateNested, IsArray, } from "class-validator";
import { Type } from "class-transformer";

export class OpportunityResponseDto {
  @ApiProperty({
    description: "Opportunity ID",
    example: 1
  })
  id: number;

  @ApiProperty({
    description: "Lead number",
    example: "LEAD-2025-001"
  })
  leadNumber: string;

  @ApiProperty({
    description: "Customer name",
    example: "Acme Corporation"
  })
  customer: string;

  @ApiPropertyOptional({
    description: "Region for the opportunity",
    example: "EUR"
  })
  region?: string;

  @ApiProperty({
    description: "Opportunity title",
    example: "Q1 2025 Pricing Proposal"
  })
  title: string;

  @ApiPropertyOptional({
    description: "Country",
    example: "United States"
  })
  country?: string;

  @ApiPropertyOptional({
    description: "Country code",
    example: "US"
  })
  countryCode?: string;

  @ApiPropertyOptional({
    description: "Project name",
    example: "Project X"
  })
  project_name?: string;

  @ApiPropertyOptional({
    description: "User status",
    example: "Draft"
  })
  userStatus?: string;

  @ApiPropertyOptional({
    description: "Workflow status",
    example: "In Progress"
  })
  workflowStatus?: string;

  @ApiProperty({
    description: "Active flag",
    example: true
  })
  active: boolean;

  @ApiProperty({
    description: "Deleted flag",
    example: false
  })
  deleted: boolean;

  @ApiProperty({
    description: "Created on timestamp",
    example: "2025-01-15T10:30:00.000Z"
  })
  createdOn: Date;

  @ApiProperty({
    description: "Created by user",
    example: "john.doe@example.com"
  })
  createdBy: string;

  @ApiPropertyOptional({
    description: "Modified on timestamp",
    example: "2025-01-15T14:30:00.000Z"
  })
  modifiedOn?: Date;

  @ApiPropertyOptional({
    description: "Modified by user",
    example: "jane.smith@example.com"
  })
  modifiedBy?: string;

  @ApiPropertyOptional({
    description: "Bid team members",
    example: [
      { name: "John Doe", email: "john.doe@example.com", login_id: "john.doe@example.com" },
      { name: "Jane Smith", email: "jane.smith@example.com", login_id: "jane.smith@example.com" }
    ],
    type: [UserDto]
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  bid_team_members?: UserDto[];

   @ApiPropertyOptional({
    description: "Lead pricer",
    example: [
      { name: "John Doe", email: "john.doe@example.com", login_id: "john.doe@example.com" },
    ],
    type: [UserDto]
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  lead_pricer?: UserDto[];
}
