import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { UserDto } from './bid-team-member.dto';

export class UpdateOpportunityDto {
  @ApiPropertyOptional({
    description: 'Lead number for the opportunity',
    example: 'LEAD-2025-001',
  })
  @IsOptional()
  @IsString()
  leadNumber?: string;

  @ApiPropertyOptional({
    description: 'Customer name',
    example: 'Acme Corporation',
  })
  @IsOptional()
  @IsString()
  customer?: string;

  @ApiPropertyOptional({
    description: 'Region for the opportunity',
    example: 'EUR',
  })
  @IsOptional()
  @IsString()
  region?: string;

  @ApiPropertyOptional({
    description: 'Opportunity title',
    example: 'Q1 2025 Pricing Proposal',
  })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional({
    description: 'Country',
    example: 'United States',
  })
  @IsOptional()
  @IsString()
  country?: string;

  @ApiPropertyOptional({
    description: 'Country code',
    example: 'US',
  })
  @IsOptional()
  @IsString()
  countryCode?: string;

  @ApiPropertyOptional({
    description: 'Project name',
    example: 'Project X',
  })
  @IsOptional()
  @IsString()
  project_name?: string;

  @ApiPropertyOptional({
    description: 'Bid team members',
    example: [
      { name: 'John Doe', email: 'john.doe@example.com', login_id: 'john.doe@example.com' },
      { name: 'Jane Smith', email: 'jane.smith@example.com', login_id: 'jane.smith@example.com' }
    ],
    type: [UserDto],
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  bid_team_members?: UserDto[];

  @ApiPropertyOptional({
    description: "Lead pricer",
    example: [
      { name: "John Doe", email: "john.doe@example.com", login_id: "john.doe@example.com" }
    ],
    type: [UserDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  lead_pricer?: UserDto[];
}

