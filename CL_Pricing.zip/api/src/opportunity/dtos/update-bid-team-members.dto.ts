import { ApiProperty } from '@nestjs/swagger';
import { IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { UserDto } from './bid-team-member.dto';

export class UpdateBidTeamMembersDto {
  @ApiProperty({
    description: 'Bid team members',
    example: [
      { name: 'John Doe', email: 'john.doe@example.com', login_id: 'john.doe@example.com' },
      { name: 'Jane Smith', email: 'jane.smith@example.com', login_id: 'jane.smith@example.com' }
    ],
    type: [UserDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  bid_team_members: UserDto[];
}

