import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class GetScenariosByNameDto {
  @ApiProperty({
    description: 'Opportunity name (customer name) to search for',
    example: 'Acme Corporation',
  })
  @IsNotEmpty()
  @IsString()
  opportunityName: string;
}

