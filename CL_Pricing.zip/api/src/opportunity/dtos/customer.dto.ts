import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString, IsEmail } from "class-validator";

export class CustomerDto {
  @ApiProperty({
    description: "Customer",
    example: "Apple"
  })
  @IsNotEmpty()
  @IsString()
  customer: string;
}
