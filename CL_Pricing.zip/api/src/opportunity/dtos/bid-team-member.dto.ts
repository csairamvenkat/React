import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString, IsEmail } from "class-validator";

export class UserDto {
  @ApiProperty({
    description: "User name",
    example: "John Doe"
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    description: "User email",
    example: "john.doe@example.com"
  })
  @IsString()
  @IsNotEmpty()
  email: string;

  @ApiProperty({
    description: "User login ID",
    example: "john.doe@example.com"
  })
  // @IsNotEmpty()
  @IsString()
  login_id: string;
}
