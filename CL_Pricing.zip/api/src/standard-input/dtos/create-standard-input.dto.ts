import { ApiProperty } from "@nestjs/swagger";
import { IsOptional, IsString } from "class-validator";

export class CreateStandardInputDto {
  @ApiProperty({ example: "Engineering", required: false })
  @IsOptional()
  @IsString()
  stakeholder?: string;

  @ApiProperty({ example: "US", required: false })
  @IsOptional()
  @IsString()
  countryCode?: string;

  @ApiProperty({ example: "Standard Rate Card Q1 2026", required: false })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiProperty({ example: "Standard input for Q1 pricing", required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: "/uploads/standard/q1-2026.xlsx", required: false })
  @IsOptional()
  @IsString()
  fileRelPath?: string;

  @ApiProperty({ example: { rates: [] }, required: false })
  @IsOptional()
  processedData?: any;

  @ApiProperty({ example: "V1", required: false })
  @IsOptional()
  versionNumber: string;
}
