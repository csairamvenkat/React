import { Injectable, NotFoundException } from "@nestjs/common";
import { StandardInputRepository } from "./repositories/standard-input.repository";
import { StandardInput } from "./models/standard-input.model";
import { CreateStandardInputDto } from "./dtos/create-standard-input.dto";
import { CurrentContext } from "../shared/types/current-context.type";
import { OpportunityRepository } from "../opportunity/repositories/opportunity.repository";
import { History } from "../history/models/history.model";
import {
  HistoryEntityType,
  HistoryActionPerformed,
  HistoryActionComments,
} from "../shared/enums/history.enum";

@Injectable()
export class StandardInputService {
  constructor(
    private readonly standardInputRepository: StandardInputRepository,
    private readonly opportunityRepository: OpportunityRepository,
  ) { }

  async create(
    dto: CreateStandardInputDto,
    context: CurrentContext
  ): Promise<StandardInput> {
    const record = StandardInput.build({
      stakeholder: dto.stakeholder,
      countryCode: dto.countryCode,
      title: dto.title,
      description: dto.description,
      fileRelPath: dto.fileRelPath,
      processedData: dto.processedData,
      versionNumber: dto.versionNumber,
      active: true,
      deleted: false
    } as any);

    //return this.standardInputRepository.save(record, context);
    const createdRecord =
      await this.standardInputRepository.save(
        record,
        context
      );
    debugger;
    await History.create({

      entityType: HistoryEntityType.STANDARD_INPUT,
      entityId: createdRecord.id,
      actionPerformed: HistoryActionPerformed.CREATED,
      actionComments: HistoryActionComments.STANDARD_INPUT_CREATED,
      actionDate: new Date(),
      createdBy: context.user.unique_name,
      createdOn: new Date(),
    });

    return createdRecord;
  }

  async getByOpportunityId(
    opportunityId: number
  ): Promise<{ id: number; title: string; stakeholder: string }[]> {
    const opportunity = await this.opportunityRepository.findById(
      opportunityId,
      {
        throwException: false,
        includeDeleted: false,
        includeInactive: true
      }
    );

    if (!opportunity) {
      throw new NotFoundException(
        `Opportunity with ID ${opportunityId} not found`
      );
    }

    const records = await this.standardInputRepository.findAll({
      where: { countryCode: opportunity.countryCode },
      attributes: ["id", "title", "stakeholder", "versionNumber"]
    });

    return (records || []).map((r: StandardInput) => ({
      id: r.id,
      title: r.title,
      stakeholder: r.stakeholder,
      versionNumber: r.versionNumber
    }));
  }
}
