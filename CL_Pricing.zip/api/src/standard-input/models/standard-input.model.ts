import { Column, DataType, Table } from 'sequelize-typescript';
import { BaseModel } from '../../shared/models/base.model';

@Table({
  tableName: 'standard_input',
  timestamps: false,
})
export class StandardInput extends BaseModel<StandardInput> {
  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'stakeholder',
  })
  stakeholder: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: 'country_code',
  })
  countryCode: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: 'title',
  })
  title: string;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: 'description',
  })
  description: string;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: 'file_rel_path',
  })
  fileRelPath: string;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: 'processed_data',
  })
  processedData: any;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "version_number"
  })
  versionNumber: string;
}
