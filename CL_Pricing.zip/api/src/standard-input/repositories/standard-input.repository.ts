import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { StandardInput } from '../models/standard-input.model';

@Injectable()
export class StandardInputRepository extends BaseRepository<StandardInput> {
  constructor(
    @InjectModel(StandardInput)
    private standardInputModel: typeof StandardInput,
  ) {
    super(standardInputModel);
  }
}
