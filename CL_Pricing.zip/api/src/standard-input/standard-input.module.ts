import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { StandardInputController } from './standard-input.controller';
import { StandardInputService } from './standard-input.service';
import { StandardInput } from './models/standard-input.model';
import { StandardInputRepository } from './repositories/standard-input.repository';
import { OpportunityModule } from '../opportunity/opportunity.module';
import { SharepointPermissionModule } from 'src/sharepoint-permission/sharepoint-permission.module';
import { HistoryModule } from "../history/history.module";

@Module({
  imports: [
    SequelizeModule.forFeature([StandardInput]),
    OpportunityModule,
    SharepointPermissionModule,
    HistoryModule
  ],
  controllers: [StandardInputController],
  providers: [
    StandardInputService,
    StandardInputRepository,
  ],
  exports: [
    StandardInputService,
    StandardInputRepository,
  ],
})
export class StandardInputModule {}
