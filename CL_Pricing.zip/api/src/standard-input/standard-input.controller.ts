import { Body, Controller, Get, Param, ParseIntPipe, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiHeader, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { StandardInputService } from './standard-input.service';
import { CreateStandardInputDto } from './dtos/create-standard-input.dto';
import { Context } from '../shared/decorators/current-context.decorator';
import { CurrentContext } from '../shared/types/current-context.type';
import { SharepointPermissionGuard } from 'src/sharepoint-permission/guards/sharepoint-permission.guard';
import { RequireSharePointGroup } from 'src/sharepoint-permission/decorators/require-sharepoint-group.decorator';
import { PermissionEnum } from 'src/shared/enums/permission-status.enum';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Standard Input')
@ApiBearerAuth()
@ApiHeader({
  name: 'Authorization',
  description:
    'Bearer token (Azure AD for SPFx OR Service Account token for Power Automate)',
  required: true,
})
@UseGuards(AuthGuard("oauth-bearer"))
@Controller('standard-input')
export class StandardInputController {
  constructor(private readonly standardInputService: StandardInputService) {}

  @Get('opportunity/:opportunityId')
  @ApiOperation({ summary: 'Get standard inputs (id, title, stakeholder) filtered by opportunity country code' })
  @ApiResponse({ status: 200, description: 'Standard inputs returned successfully' })
  @ApiResponse({ status: 404, description: 'Opportunity not found' })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getByOpportunityId(
    @Param('opportunityId', ParseIntPipe) opportunityId: number,
  ): Promise<any> {
    return this.standardInputService.getByOpportunityId(opportunityId);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new standard input record' })
  @ApiResponse({
    status: 201,
    description: 'Standard input created successfully',
  })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async create(
    @Body() dto: CreateStandardInputDto,
    @Context() context: CurrentContext,
  ): Promise<any> {
    return this.standardInputService.create(dto, context);
  }
}
