import { CurrentContext } from '../types';

export const SYSTEM_USER: CurrentContext = { user: { username: 'SYSTEM' } };
