import { LogLevel } from "@nestjs/common/services";

export interface DatabaseConfig {
	host: string;
	port: number;
	username: string;
	password: string;
	db: string;
	dialect: string;
	schema: string;
	enableSSL: boolean;
}

export interface AzureADConfig {
	authority: string;
	tennantId: string;
	clientId: string;
	clientSecret: string;
	version: string;
	discovery: string;
	audience: string;
	graphApiUrl: string;
	graphApiVersion: string;
	scope: string[];
}

export interface SwaggerConfig {
	user: string;
	password: string;
}

export interface MicroserviceConfig {
	url: string;
	tennantId?: string;
	appId?: string;
	Authorization?: string;
}

export interface MicroservicesConfig {
	adminApi: MicroserviceConfig;
	requestApi: MicroserviceConfig;
	notificationApi: MicroserviceConfig;
	fusionApi: MicroserviceConfig;
}

export interface ServiceAccountConfig {
	token: string;
	enabled: boolean;
}

export interface SharePointAppConfig {
	sharePointUrl: string;
	tenantId: string;
	clientId: string;
	certPath?: string;
	certPassword?: string;
}

export interface NotificationsConfig {
	dueDateReminderDays: number;
}

export interface AppConfig {
	database: DatabaseConfig;
	azureAD: AzureADConfig;
	microservices: MicroservicesConfig;
	swagger: SwaggerConfig;
	webClientConfig: WebClientConfig;
	serviceAccount?: ServiceAccountConfig;
	sharePointApp?: SharePointAppConfig;
	notifications?: NotificationsConfig;
	logLevel: LogLevel[]
}


export interface WebClientConfig {
	apiBaseUrl: string;
	webAppUrl?: string;
	msDetail: MsDetail
}

export interface MsDetail {
	authority: string;
	clientId: string;
	redirectUrl: string;
	scope: string[];
	graphUrl: string;
	graphScope: string[];
}

