export type ADUserDetails = {
    givenName: string;
    jobTitle: string;
    surname: string;
    mail: string;
    userPrincipalName: string;
    userType: string;
    displayName: string;
};