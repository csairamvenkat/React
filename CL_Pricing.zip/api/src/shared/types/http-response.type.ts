import { ResponseHeaders } from './http-response-header.type';

export interface HttpResponse {
	data;
	headers: any;
	status: number;
}
