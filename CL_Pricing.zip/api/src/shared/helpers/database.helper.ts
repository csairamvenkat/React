import { Sequelize } from 'sequelize-typescript';
import { Injectable } from '@nestjs/common';
import { Transaction } from 'sequelize';

/**
 * Database helper has wrapper functions of orm or database object.
 */
@Injectable()
export class DatabaseHelper {
	constructor(private readonly sequelize: Sequelize) {}

	//Wrapper on sequelize transaction
	public startTransaction<T>(autoCallback: (t: Transaction) => PromiseLike<T>): Promise<T> {
		return this.sequelize.transaction(autoCallback);
	}
}
