export const stringPlaceholderReplacer = (str: string, replacements: { [key: string]: string }) => {
    return str.replace(
        /{(\w+)}/g,
        (placeholderWithDelimiters, placeholderWithoutDelimiters) =>
            replacements.hasOwnProperty(placeholderWithoutDelimiters) ?
                replacements[placeholderWithoutDelimiters] : placeholderWithDelimiters
    );
}