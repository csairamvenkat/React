import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { CurrentContext } from '../types/current-context.type';

export const Context = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): CurrentContext => {
    const request = ctx.switchToHttp().getRequest();
    return {
      user: request.user || { username: 'system' },
      locations: request.locations,
    };
  },
);
