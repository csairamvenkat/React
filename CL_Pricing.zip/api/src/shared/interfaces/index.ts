export * from './base-repo.interface';
export * from './user-detail.type';
export * from './filter.interface';