import { Inject, Injectable } from '@nestjs/common';
import { toNumber } from 'lodash';
import { INTERNAL_API } from '../constants';
import { HttpService } from '../services/http.service';
import { NotificationTemplateResponse } from '../types';

@Injectable()
export class AdminApiClient {
	constructor(@Inject(INTERNAL_API.ADMIN_API_PROVIDER) private readonly adminApi: HttpService) { }

	

	/**
	 * Return the email tempplate details.
	 * @param templateName 
	 * @returns 
	 */
	public async getNotificationTemplate(templateName: string): Promise<NotificationTemplateResponse> {
		const { data } = await this.adminApi.post('/notification/getNotificationTemplate', { system_name: templateName });
		return data;
	}
}
