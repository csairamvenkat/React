import { Global, Module } from '@nestjs/common';
import {
	AdminApiClient,
	MSGraphApiClient,
	NotificationApiClient,
} from './clients';
import { SharedNotificationService } from './services/shared-notification.service';

@Global()
@Module({
	providers: [
		MSGraphApiClient,
		AdminApiClient,
		NotificationApiClient,
		SharedNotificationService,
	],
	exports: [
		MSGraphApiClient,
		AdminApiClient,
		NotificationApiClient,
		SharedNotificationService,
	],
})
export class SharedModule {}
