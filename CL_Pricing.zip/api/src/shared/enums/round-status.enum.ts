export enum RoundWorkflowStatus {
	Created = 'Created',
	InProgress = 'InProgress',
	Submitted = 'Submitted',
	Approved = 'Approved',
	DraftApproved = 'DraftApproved',
	Rejected = 'Rejected',
	Completed = 'Completed',
	Cancelled = 'Cancelled',
	Retracted = 'Retracted'
}

export enum RoundUserStatus {
	Created = 'Created',
	InProgress = 'In Progress',
	Submitted = 'Submitted',
	Approved = 'Approved',
	DraftApproved = 'Draft Approved',
	Rejected = 'Rejected',
	Completed = 'Completed',
	Cancelled = 'Cancelled',
	Retracted = 'Retracted',
}