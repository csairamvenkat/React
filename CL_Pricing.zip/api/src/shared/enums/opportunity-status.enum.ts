export enum OpportunityWorkflowStatus {
	Created = 'Created',
	InProgress = 'InProgress',
	Completed = 'Completed',
	Cancelled = 'Cancelled'
}

export enum OpportunityUserStatus {
	Created = 'Created',
	InProgress = 'In Progress',
	Completed = 'Completed',
	Cancelled = 'Cancelled'
}