export enum InputType {
	CollectInput = 'CollectInput',
	UsePreviousRoundInput = 'usePreviousRoundInput',
	UseStandardInput = 'useStandardInput'
}

export enum SubmissionType {
	Draft = 'Draft',
	Final = 'Final'
}

export enum StakeholderType {
	Standard = 'Standard',
	Adhoc = 'Adhoc'
}