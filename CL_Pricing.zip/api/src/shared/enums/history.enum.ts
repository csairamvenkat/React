export enum HistoryEntityType {
    STANDARD_INPUT = "standard_input",
    OPPORTUNITY = "opportunity",
    OPPORTUNITY_ROUND = "opportunity_round",
    OPPORTUNITY_ROUND_STAKEHOLDER = "opportunity_round_stakeholder",
    OPPORTUNITY_ROUND_INPUT = "opportunity_round_input",
}

export enum HistoryActionPerformed {
    RETRACTED="retracted",
    DELETED="deleted",
    UPDATED = "updated",
    CREATED = "created",
    CLOSED = "closed",
    VERSION_CHANGED = "version_changed",
    APPROVED = "approved",
    REJECTED = "rejected",
    REVISION_REQUESTED = "revision_requested",
    SUBMITTED="submitted"
}

export enum HistoryActionComments {
    STAKEHOLDER_INPUT_RETRACTED="Stakeholder input retracted",
    BID_TEAM_MEMBERS_UPDATED = "Bid team members updated",
    OPPORTUNITY_UPDATED = "Opportunity updated",
    OPPORTUNITY_CREATED = "Opportunity created",
    OPPORTUNITY_ROUND_CREATED = "Opportunity round created",
    OPPORTUNITY_ROUND_UPDATED = "Opportunity round updated",
    OPPORTUNITY_ROUND_CLOSED = "Opportunity round closed",
    ROUND_STAKEHOLDER_CREATED = "Round stakeholder created",
    ROUND_STAKEHOLDER_UPDATED = "Round stakeholder updated",
    STAKEHOLDER_VERSION_CHANGED = "Stakeholder version changed",
    STAKEHOLDER_INPUT_APPROVED = "Stakeholder input approved",
    STAKEHOLDER_INPUT_REJECTED = "Stakeholder input rejected",
    REVISION_REQUESTED_FOR_STAKEHOLDER_INPUT = "Revision requested for stakeholder input",
    STANDARD_INPUT_CREATED="Standard input created",
    ACTIVE_STATUS_UPDATED="Active status updated",
    OPPORTUNITY_DELETED="Opportunity deleted",
    ROUND_INPUT_REQUIRED_STATUS_UPDATED="Round input required status updated",
    STAKEHOLDER_INPUT_SUBMITTED="Stakeholder input submitted",
    STAKEHOLDER_INPUT_REVISION_REQUESTED="Stakeholder input revision requested"
}