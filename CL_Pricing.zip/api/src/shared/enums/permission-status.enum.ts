export enum PermissionEnum {
	Pricing = 'Pricing',
	CLPricingMembers = 'CLPricing Members',
	CLPricingOwners = 'CLPricing Owners',
	CLPricingVisitors = 'CLPricing Visitors'
}