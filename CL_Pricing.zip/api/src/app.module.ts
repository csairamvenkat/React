import { Logger, Module } from '@nestjs/common';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { SequelizeModule } from '@nestjs/sequelize';
import { Dialect } from 'sequelize';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { ConfigModule } from './config/config.module';
import { ConfigService } from './config/config.service';
import { CoreModule } from './core/core.module';
import { LoggingInterceptor } from './core/interceptors/logger.interceptor';
import { DatabaseModule } from './database/database.module';
import { getSequelizeOrmConfig } from './database/orm-config';
import { GraphUserModule } from './graph-user/graph-user.module';
import { SharedModule } from './shared/shared.module';
import { OpportunityModule } from './opportunity/opportunity.module';
import { OpportunityRoundModule } from './opportunity-round/opportunity-round.module';
import { StandardInputModule } from './standard-input/standard-input.module';
import { SharepointPermissionModule } from './sharepoint-permission/sharepoint-permission.module';
import { SchedulerModule } from './scheduler/scheduler.module';
import { HistoryModule } from "./history/history.module";

@Module({
	imports: [
		DatabaseModule,
		ConfigModule,
		CoreModule,
		AuthModule,
		SharedModule,
		GraphUserModule,
		OpportunityModule,
		OpportunityRoundModule,
		StandardInputModule,
		SharepointPermissionModule,
		HistoryModule,
		SchedulerModule,
		SequelizeModule.forRootAsync({
			imports: [ConfigModule],
			useFactory: async (configService: ConfigService) => {
				const { database } = configService.getAppConfig();
				const { dialect, host, password, db, port, username, schema, enableSSL } = database;
				return {
					dialect: dialect as Dialect,
					host,
					port,
					database: db,
					username,
					password,
					logging: false,
					...getSequelizeOrmConfig(enableSSL, schema),
				};
			},
			inject: [ConfigService],
		}),
	],
	controllers: [AppController],
	providers: [
		AppService,
		Logger,
		{
			provide: APP_INTERCEPTOR,
			useClass: LoggingInterceptor,
		},
	],
})
export class AppModule {}
