import { Module } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { ConfigService } from 'src/config/config.service';
import { AzureADStrategy } from './azure-ad.strategy';
import { ServiceAccountStrategy } from './service-account.strategy';
import { AzureADGuard, ServiceAccountGuard, FlexibleAuthGuard } from './guards';

@Module({
	imports: [PassportModule.register({ defaultStrategy: 'oauth-bearer' })],
	providers: [
		AzureADStrategy,
		ServiceAccountStrategy,
		ConfigService,
		AzureADGuard,
		ServiceAccountGuard,
		FlexibleAuthGuard,
	],
	exports: [AzureADGuard, ServiceAccountGuard, FlexibleAuthGuard],
})
export class AuthModule {}
