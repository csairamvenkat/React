import { createParamDecorator, ExecutionContext } from '@nestjs/common';

/**
 * Decorator to get the authentication type
 * Returns 'user' for SPFx or 'service-account' for Power Automate
 */
export const AuthType = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): string => {
    const request = ctx.switchToHttp().getRequest();
    return request.authType || (request.user?.isServiceAccount ? 'service-account' : 'user');
  },
);

/**
 * Decorator to check if the request is from a service account
 */
export const IsServiceAccount = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): boolean => {
    const request = ctx.switchToHttp().getRequest();
    return request.user?.isServiceAccount === true;
  },
);
