import { Injectable, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/**
 * Flexible Authentication Guard
 * Accepts both Azure AD user tokens (SPFx) and Service Account tokens (Power Automate)
 * Tries Azure AD first, then falls back to Service Account
 */
@Injectable()
export class FlexibleAuthGuard extends AuthGuard(['oauth-bearer', 'service-account']) {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context);
  }

  handleRequest(err: any, user: any, info: any, context: ExecutionContext) {
    // If authentication failed with both strategies
    if (err || !user) {
      throw new UnauthorizedException(
        'Authentication failed. Please provide either a valid Azure AD token or Service Account token.',
      );
    }

    // Add authentication metadata
    const request = context.switchToHttp().getRequest();
    request.authType = user.isServiceAccount ? 'service-account' : 'user';

    return user;
  }
}
