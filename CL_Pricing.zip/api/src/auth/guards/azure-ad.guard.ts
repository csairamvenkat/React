import { Injectable, ExecutionContext } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/**
 * Guard for Azure AD OAuth Bearer token authentication
 * Used for SPFx SharePoint applications with user context
 */
@Injectable()
export class AzureADGuard extends AuthGuard('oauth-bearer') {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context);
  }

  handleRequest(err: any, user: any, info: any) {
    if (err || !user) {
      throw err || new Error('Unauthorized');
    }
    // Mark as user authentication
    user.type = 'user';
    user.isServiceAccount = false;
    return user;
  }
}
