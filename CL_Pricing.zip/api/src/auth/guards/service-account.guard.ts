import { Injectable, ExecutionContext } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

/**
 * Guard for Service Account authentication
 * Used for Power Automate flows with service account token
 */
@Injectable()
export class ServiceAccountGuard extends AuthGuard('service-account') {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context);
  }

  handleRequest(err: any, user: any, info: any) {
    if (err || !user) {
      throw err || new Error('Unauthorized - Invalid service account token');
    }
    return user;
  }
}
