import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { Strategy } from 'passport-http-bearer';
import { ConfigService } from '../config/config.service';

/**
 * Service Account Strategy for Power Automate flows
 * Uses a Bearer token with service account credentials
 */
@Injectable()
export class ServiceAccountStrategy extends PassportStrategy(Strategy, 'service-account') {
  private readonly serviceAccountToken: string;

  constructor(configService: ConfigService) {
    super();
    const config = configService.getAppConfig();
    // Service account token from environment or config
    this.serviceAccountToken =
      process.env.SERVICE_ACCOUNT_TOKEN ||
      config.serviceAccount?.token ||
      config.azureAD.clientSecret;
  }

  async validate(token: string): Promise<any> {
    // Validate the service account token
    if (token !== this.serviceAccountToken) {
      throw new UnauthorizedException('Invalid service account token');
    }

    // Return service account context
    return {
      username: 'service-account',
      email: 'service-account@system',
      type: 'service-account',
      isServiceAccount: true,
      name: 'Power Automate Service Account',
    };
  }
}
