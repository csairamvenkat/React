import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { OpportunityRoundController } from './opportunity-round.controller';
import { OpportunityRoundService } from './opportunity-round.service';
import { OpportunityRound } from './models/opportunity-round.model';
import { OpportunityRoundStakeholder } from './models/opportunity-round-stakeholder.model';
import { OpportunityRoundInput } from './models/opportunity-round-input.model';
import { OutputLog } from './models/output-log.model';
import { OpportunityRoundRepository } from './repositories/opportunity-round.repository';
import { OpportunityRoundStakeholderRepository } from './repositories/opportunity-round-stakeholder.repository';
import { OpportunityRoundInputRepository } from './repositories/opportunity-round-input.repository';
import { OutputLogRepository } from './repositories/output-log.repository';
import { OpportunityModule } from '../opportunity/opportunity.module';
import { StandardInputModule } from '../standard-input/standard-input.module';
import { SharepointPermissionModule } from '../sharepoint-permission/sharepoint-permission.module';
import { ConfigModule } from '../config/config.module';
import { HistoryModule } from "../history/history.module";
@Module({
  imports: [
    SequelizeModule.forFeature([
      OpportunityRound,
      OpportunityRoundStakeholder,
      OpportunityRoundInput,
      OutputLog,
    ]),
    OpportunityModule,
    StandardInputModule,
    SharepointPermissionModule,
    ConfigModule,
    HistoryModule
  ],
  controllers: [OpportunityRoundController],
  providers: [
    OpportunityRoundService,
    OpportunityRoundRepository,
    OpportunityRoundStakeholderRepository,
    OpportunityRoundInputRepository,
    OutputLogRepository,
  ],
  exports: [
    OpportunityRoundService,
    OpportunityRoundRepository,
    OpportunityRoundStakeholderRepository,
    OpportunityRoundInputRepository,
    OutputLogRepository,
  ],
})
export class OpportunityRoundModule {}
