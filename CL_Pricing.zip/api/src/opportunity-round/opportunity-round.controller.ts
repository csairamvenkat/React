import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Patch,
  Post,
  Put,
  UseGuards
} from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiResponse,
  ApiTags,
  ApiHeader
} from "@nestjs/swagger";
import { OpportunityRoundService } from "./opportunity-round.service";
import { CreateRoundDto } from "./dtos/create-round.dto";
import { UpdateRoundDto } from "./dtos/update-round.dto";
import { CreateStakeholderDto } from "./dtos/create-stakeholder.dto";
import { UpsertStakeholderDto } from "./dtos/upsert-stakeholder.dto";
import { ChangeStakeholderVersionDto } from "./dtos/change-stakeholder-version.dto";
import { GetInputsByScenarioDto } from "./dtos/get-inputs-by-scenario.dto";
import { GetRoundInputsDto } from "./dtos/get-round-inputs.dto";
import { CompleteStakeholderInputDto } from "./dtos/complete-stakeholder-input.dto";
import { InitiateRevisionDto } from "./dtos/initiate-revision.dto";
import { RetractStakeholderInputDto } from "./dtos/retract-stakeholder-input.dto";
import { SubmitStakeholderInputDto } from "./dtos/submit-stakeholder-input.dto";
import { GenerateOutputLogDto } from "./dtos/generate-output-log.dto";
import {
  RoundResponseDto,
  StakeholderInputResponseDto,
  OutputLogResponseDto,
  StakeholderInputWithoutProcessedDataDto
} from "./dtos/round-response.dto";
import { CurrentContext } from "../shared/types/current-context.type";
import { Context } from "../shared/decorators/current-context.decorator";
import { RejectStakeholderInputDto } from "./dtos/reject-stakeholder-input.dto";
import { UpdateRoundInputRequiredDto } from "./dtos/update-round-input-active.dto";
import { AuthGuard } from "@nestjs/passport";
import { SharepointPermissionService } from "../sharepoint-permission/providers/sharepoint-permission.service";
import { RequireSharePointGroup } from "src/sharepoint-permission/decorators/require-sharepoint-group.decorator";
import { SharepointPermissionGuard } from "src/sharepoint-permission/guards/sharepoint-permission.guard";
import { PermissionEnum } from "src/shared/enums/permission-status.enum";
import { OpportunityService } from "src/opportunity/opportunity.service";

@ApiTags("Opportunity Round")
@ApiBearerAuth()
@ApiHeader({
  name: "Authorization",
  description:
    "Bearer token (Azure AD for SPFx OR Service Account token for Power Automate)",
  required: true
})
// @UseGuards(FlexibleAuthGuard)
@UseGuards(AuthGuard("oauth-bearer"))
@Controller("opportunity-round")
export class OpportunityRoundController {
  constructor(
    private readonly roundService: OpportunityRoundService,
    private readonly sharepointPermissionService: SharepointPermissionService,
    private readonly opportunityService: OpportunityService
  ) {}

  @Post()
  @ApiOperation({
    summary: "Create a new round with scenarios and stakeholders"
  })
  @ApiResponse({
    status: 201,
    description: "Round created successfully",
    type: RoundResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async createRound(
    @Body() createDto: CreateRoundDto,
    @Context() context: CurrentContext
  ): Promise<RoundResponseDto> {
    const round = await this.roundService.createRound(createDto, context);

    return await this.mapToRoundResponseDto(round);
  }

  @Put("stakeholder")
  @ApiOperation({ summary: "Create or update a stakeholder for a round" })
  @ApiBody({ type: UpsertStakeholderDto })
  @ApiResponse({
    status: 200,
    description: "Stakeholder created or updated successfully",
    schema: {
      type: "object",
      properties: {
        isNew: {
          type: "boolean",
          example: false,
          description: "True if stakeholder was created, false if updated"
        },
        stakeholder: {
          type: "object",
          properties: {
            id: { type: "number", example: 1 },
            opportunityId: { type: "number", example: 1 },
            roundId: { type: "number", example: 1 },
            roundNumber: { type: "number", example: 1 },
            stakeholder: { type: "string", example: "Engineering" },
            additionalStakeholders: {
              type: "array",
              items: { type: "string" },
              example: ["john.doe@example.com", "jane.smith@example.com"]
            },
            applicableScenarios: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string", example: "A" },
                  desc: { type: "string", example: "Scenario A" },
                  isStandardRate: { type: "boolean", example: false },
                  isCopiedPreviousRound: { type: "boolean", example: false },
                  referenceData: { type: "number", nullable: true, example: 1 },
                  input_type: {
                    type: "string",
                    nullable: true,
                    example: "manual"
                  }
                }
              }
            },
            notify_users: {
              type: "array",
              nullable: true,
              items: {
                type: "object",
                properties: {
                  name: { type: "string", example: "John Doe" },
                  email: { type: "string", example: "john.doe@example.com" },
                  login_id: { type: "string", example: "john.doe@example.com" }
                }
              }
            },
            dueDate: {
              type: "string",
              format: "date-time",
              example: "2025-02-15T23:59:59.000Z"
            },
            stakeholder_code: { type: "string", nullable: true, example: "ENG" },
            stakeholderType: {
              type: "string",
              nullable: true,
              example: "Standard"
            },
            collectDraftInput: { type: "boolean", nullable: true, example: false },
            draftDueDate: {
              type: "string",
              format: "date-time",
              nullable: true,
              example: "2025-02-10T23:59:59.000Z"
            }
          }
        }
      }
    }
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @ApiResponse({
    status: 404,
    description: "Round not found or does not belong to opportunity"
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async upsertStakeholder(
    @Body() upsertDto: UpsertStakeholderDto,
    @Context() context: CurrentContext
  ): Promise<any> {
    const result = await this.roundService.upsertStakeholder(
      upsertDto,
      context
    );

    return {
      isNew: result.isNew,
      stakeholder: {
        id: result.stakeholder.id,
        opportunityId: result.stakeholder.opportunityId,
        roundId: result.stakeholder.roundId,
        roundNumber: result.stakeholder.roundNumber,
        stakeholder: result.stakeholder.stakeholder,
        additionalStakeholders: result.stakeholder.additionalStakeholders,
        applicableScenarios: result.stakeholder.applicableScenarios,
        notifyUsers: result.stakeholder.notify_users,
        dueDate: result.stakeholder.dueDate,
        stakeholder_code: result.stakeholder.stakeholder_code,
        stakeholderType: result.stakeholder.stakeholderType,
        description: result.stakeholder.description,
        collectDraftInput: result.stakeholder.collectDraftInput,
        draftDueDate: result.stakeholder.draftDueDate
      }
    };
  }

  @Post("stakeholder/change-version")
  @ApiOperation({
    summary:
      "Cancel a stakeholder's current inputs and create new inputs under a new version, for all of the stakeholder's applicable scenarios"
  })
  @ApiBody({ type: ChangeStakeholderVersionDto })
  @ApiResponse({
    status: 201,
    description: "Stakeholder version changed successfully"
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @ApiResponse({
    status: 404,
    description:
      "Round or stakeholder not found, or stakeholder has no applicable scenarios"
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async changeStakeholderVersion(
    @Body() changeDto: ChangeStakeholderVersionDto,
    @Context() context: CurrentContext
  ): Promise<any> {
    const stakeholder = await this.roundService.changeStakeholderVersion(
      changeDto,
      context
    );

    return {
      id: stakeholder.id,
      opportunityId: stakeholder.opportunityId,
      roundId: stakeholder.roundId,
      roundNumber: stakeholder.roundNumber,
      stakeholder: stakeholder.stakeholder,
      stakeholder_code: stakeholder.stakeholder_code,
      applicableScenarios: stakeholder.applicableScenarios,
      versionNumber: changeDto.versionNumber
    };
  }

  @Put(":id")
  @ApiOperation({ summary: "Update an existing round" })
  @ApiResponse({
    status: 200,
    description: "Round updated successfully",
    type: RoundResponseDto
  })
  @ApiResponse({ status: 404, description: "Round not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async updateRound(
    @Param("id") id: number,
    @Body() updateDto: UpdateRoundDto,
    @Context() context: CurrentContext
  ): Promise<RoundResponseDto> {
    const round = await this.roundService.updateRound(id, updateDto, context);
    return await this.mapToRoundResponseDto(round);
  }

  @Patch(":id/close")
  @ApiOperation({ summary: "Close a round" })
  @ApiResponse({
    status: 200,
    description: "Round closed successfully",
    type: RoundResponseDto
  })
  @ApiResponse({ status: 404, description: "Round not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async closeRound(
    @Param("id") id: number,
    @Context() context: CurrentContext
  ): Promise<RoundResponseDto> {
    const round = await this.roundService.closeRound(id, context);
    return await this.mapToRoundResponseDto(round);
  }

  @Post("stakeholder-input/complete")
  @ApiOperation({ summary: "Complete stakeholder input with processed data" })
  @ApiResponse({
    status: 201,
    description: "Stakeholder input completed successfully",
    type: StakeholderInputResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async completeStakeholderInput(
    @Body() inputDto: CompleteStakeholderInputDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputResponseDto> {
    const input = await this.roundService.completeStakeholderInput(
      inputDto,
      context
    );

    return this.mapToInputResponseDto(input);
  }

  @Post("stakeholder-input/reject")
  @ApiOperation({ summary: "Reject stakeholder input with processed data" })
  @ApiResponse({
    status: 201,
    description: "Stakeholder input rejected successfully",
    type: StakeholderInputResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async rejectStakeholderInput(
    @Body() inputDto: RejectStakeholderInputDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputResponseDto> {
    const input = await this.roundService.rejectStakeholderInput(
      inputDto,
      context
    );

    return this.mapToInputResponseDto(input);
  }

  @Post("stakeholder-input/submit")
  @ApiOperation({ summary: "Submit stakeholder input" })
  @ApiResponse({
    status: 201,
    description: "Stakeholder input submitted successfully",
    type: StakeholderInputResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  async submitStakeholderInput(
    @Body() submitDto: SubmitStakeholderInputDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputResponseDto> {
    const opportunity = await this.opportunityService.getOpportunityById(
      submitDto.opportunityId
    );

    await this.sharepointPermissionService.checkOpportunityRoundPermission(
      submitDto.opportunityId,
      opportunity,
      submitDto.roundNumber,
      submitDto.stakeholderCode,
      context,
      true,
      false,
      false
    );

    const input = await this.roundService.submitStakeholderInput(
      submitDto,
      context
    );
    return this.mapToInputResponseDto(input);
  }

  @Post("stakeholder-input/retract")
  @ApiOperation({ summary: "Retract stakeholder input" })
  @ApiResponse({
    status: 201,
    description: "Stakeholder input retracted successfully",
    type: StakeholderInputResponseDto
  })
  @ApiResponse({ status: 403, description: "Forbidden" })
  @ApiResponse({ status: 404, description: "Input not found" })
  async retractStakeholderInput(
    @Body() retractDto: RetractStakeholderInputDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputResponseDto> {
    // const inputs = await this.roundService.currentInputs(
    //   retractDto.opportunityId,
    //   retractDto.roundId,
    //   retractDto.stakeholderCode,
    //   retractDto.roundNumber,
    //   retractDto.scenarioName
    // );

    // const input = inputs?.find(
    //   (i) => i.workflowStatus === RoundWorkflowStatus.Submitted
    // );

    // await this.sharepointPermissionService.hasUserFolderAccess(
    //   context.user.unique_name,
    //   input.fileRelPath,
    //   true
    // );

    const opportunity = await this.opportunityService.getOpportunityById(
      retractDto.opportunityId
    );

    await this.sharepointPermissionService.checkOpportunityRoundPermission(
      retractDto.opportunityId,
      opportunity,
      retractDto.roundNumber,
      retractDto.stakeholderCode,
      context,
      true,
      false,
      false
    );

    const response = await this.roundService.retractStakeholderInput(
      retractDto,
      context
    );
    return this.mapToInputResponseDto(response);
  }

  @Post("stakeholder-input/initiate-revision")
  @ApiOperation({ summary: "Initiate revision for stakeholder input(s)" })
  @ApiResponse({
    status: 201,
    description: "Revision initiated successfully",
    type: [StakeholderInputWithoutProcessedDataDto]
  })
  @ApiResponse({ status: 404, description: "No inputs found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async initiateRevision(
    @Body() dto: InitiateRevisionDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputWithoutProcessedDataDto[]> {
    const inputs = await this.roundService.initiateRevision(dto, context);
    return inputs.map((input) =>
      this.mapToInputResponseWithoutProcessedDataDto(input, null)
    );
  }

  @Patch("input/required")
  @ApiOperation({ summary: "Update required of a round input" })
  @ApiBody({ type: UpdateRoundInputRequiredDto })
  @ApiResponse({
    status: 200,
    description: "Round input active status updated successfully",
    type: StakeholderInputResponseDto
  })
  @ApiResponse({ status: 404, description: "Round input not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async updateRoundInputRequired(
    @Body() dto: UpdateRoundInputRequiredDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputResponseDto> {
    const input = await this.roundService.updateRoundInputRequired(
      dto.id,
      dto.inputRequired,
      context
    );
    return this.mapToInputResponseDto(input);
  }

  @Get(":id")
  @ApiOperation({ summary: "Get round by ID with stakeholders" })
  @ApiResponse({
    status: 200,
    description: "Round retrieved successfully",
    type: RoundResponseDto
  })
  @ApiResponse({ status: 404, description: "Round not found" })
  async getRoundById(
    @Param("id") id: number,
    @Context() context: CurrentContext
  ): Promise<RoundResponseDto> {
    const round = await this.roundService.getRoundById(id);

    if (!round) {
      throw new NotFoundException(`Round with ID ${id} not found`);
    }

    const opportunity = await this.opportunityService.getOpportunityById(
      round.opportunityId
    );

    await this.sharepointPermissionService.checkOpportunityRoundPermission(
      round.opportunityId,
      opportunity,
      round.roundNumber,
      "",
      context,
      false,
      true,
      false
    );

    return await this.mapToRoundResponseDto(round);
  }

  @Get("opportunity/:opportunityId")
  @ApiOperation({ summary: "Get all rounds for an opportunity" })
  @ApiResponse({
    status: 200,
    description: "Rounds retrieved successfully",
    type: [RoundResponseDto]
  })
  async getRoundsByOpportunity(
    @Param("opportunityId") opportunityId: number,
    @Context() context: CurrentContext
  ): Promise<RoundResponseDto[]> {
    const opportunity =
      await this.opportunityService.getOpportunityById(opportunityId);

    await this.sharepointPermissionService.checkOpportunityPermission(
      opportunityId,
      opportunity,
      context,
      false,
      true
    );

    const rounds =
      await this.roundService.getRoundsByOpportunityId(opportunityId);
    return Promise.all(
      rounds.map((round) => this.mapToRoundResponseDto(round))
    );
  }

  @Post(":roundId/inputs")
  @ApiOperation({ summary: "Get all current stakeholder inputs for a round" })
  @ApiResponse({
    status: 201,
    description: "Stakeholder inputs retrieved successfully",
    type: [StakeholderInputResponseDto]
  })
  async getStakeholderInputs(
    @Param("roundId") roundId: number,
    @Body() body: GetRoundInputsDto,
    @Context() context: CurrentContext
  ): Promise<StakeholderInputWithoutProcessedDataDto[]> {
    const round = await this.roundService.getRoundById(roundId);
    if (!round) {
      throw new NotFoundException(`Round with ID ${roundId} not found`);
    }

    const opportunity = await this.opportunityService.getOpportunityById(
      round.opportunityId
    );

    await this.sharepointPermissionService.checkOpportunityRoundPermission(
      round.opportunityId,
      opportunity,
      round.roundNumber,
      "",
      context,
      false,
      true,
      false
    );

    const inputs = await this.roundService.getStakeholderInputsByRound(
      roundId,
      body.workflowStatuses
    );
    return inputs.map((input) =>
      this.mapToInputResponseWithoutProcessedDataDto(
        input,
        opportunity?.title ?? null
      )
    );
  }

  @Post("inputs-by-stakeholder-and-scenario")
  @ApiOperation({
    summary: "Get round inputs grouped by scenario for a stakeholder"
  })
  @ApiResponse({
    status: 200,
    description: "Round inputs grouped by scenario retrieved successfully",
    schema: {
      type: "object",
      properties: {
        datasets: {
          type: "array",
          items: {
            type: "object",
            properties: {
              scenario: { type: "string", example: "A" },
              date_of_data: { type: "string", example: "2026-01-01" },
              data: {
                type: "object",
                description: "Processed data for the scenario"
              }
            }
          }
        }
      }
    }
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getRoundInputsByScenario(
    @Body() dto: GetInputsByScenarioDto,
    @Context() context: CurrentContext
  ): Promise<any> {
    return this.roundService.getRoundInputsByScenario(
      dto.roundId,
      dto.stakeholder,
      dto.scenarios
    );
  }

  @Get(":roundId/output-logs")
  @ApiOperation({ summary: "Get all output logs for a round" })
  @ApiResponse({
    status: 200,
    description: "Output logs retrieved successfully",
    type: [OutputLogResponseDto]
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getOutputLogs(
    @Param("roundId") roundId: number
  ): Promise<OutputLogResponseDto[]> {
    const logs = await this.roundService.getOutputLogsByRound(roundId);
    return logs.map((log) => this.mapToOutputLogResponseDto(log));
  }

  @Post("output-log")
  @ApiOperation({ summary: "Generate output log for file generation" })
  @ApiResponse({
    status: 201,
    description: "Output log created successfully",
    type: OutputLogResponseDto
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @ApiResponse({
    status: 409,
    description: "Output file name already exists for this Opportunity and Round"
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async generateOutputLog(
    @Body() logDto: GenerateOutputLogDto,
    @Context() context: CurrentContext
  ): Promise<OutputLogResponseDto> {
    const log = await this.roundService.generateOutputLog(logDto, context);

    return this.mapToOutputLogResponseDto(log);
  }

  @Get(":roundId/scenarios")
  @ApiOperation({ summary: "Get all scenarios for a round" })
  @ApiResponse({
    status: 200,
    description: "Scenarios retrieved successfully",
    schema: {
      type: "array",
      items: {
        type: "object",
        properties: {
          name: { type: "string", example: "A" },
          desc: { type: "string", example: "Scenario A for standard pricing" }
        }
      }
    }
  })
  @ApiResponse({ status: 404, description: "Round not found" })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async getRoundScenarios(@Param("roundId") roundId: number): Promise<any[]> {
    return this.roundService.getRoundScenarios(roundId);
  }

  @Post("stakeholder")
  @ApiOperation({
    summary: "Create one or more stakeholders for an existing round"
  })
  @ApiBody({ type: [CreateStakeholderDto] })
  @ApiResponse({
    status: 201,
    description: "Stakeholder(s) created successfully"
  })
  @ApiResponse({ status: 400, description: "Bad Request" })
  @ApiResponse({
    status: 404,
    description: "Round not found or does not belong to opportunity"
  })
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async createStakeholder(
    @Body() createDtos: CreateStakeholderDto[],
    @Context() context: CurrentContext
  ): Promise<any[]> {
    const stakeholders = await this.roundService.createStakeholders(
      createDtos,
      context
    );

    return stakeholders.map((stakeholder) => ({
      id: stakeholder.id,
      opportunityId: stakeholder.opportunityId,
      roundId: stakeholder.roundId,
      roundNumber: stakeholder.roundNumber,
      stakeholder: stakeholder.stakeholder,
      stakeholderType: stakeholder.stakeholderType,
      description: stakeholder.description,
      additionalStakeholders: stakeholder.additionalStakeholders,
      applicableScenarios: stakeholder.applicableScenarios,
      notifyUsers: stakeholder.notify_users,
      dueDate: stakeholder.dueDate,
      active: stakeholder.active,
      deleted: stakeholder.deleted,
      createdOn: stakeholder.createdOn,
      createdBy: stakeholder.createdBy
    }));
  }

  @Post("get-stakeholder-all-inputs")
  @ApiOperation({
    summary:
      "List all opportunities → rounds → inputs accessible to the current user"
  })
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        page: { type: "number", example: 1 },
        limit: { type: "number", example: 10 },
        myRecord: { type: "boolean", example: false },
        search_text: {
          type: "string",
          example: "ABC",
          description:
            "Filter by opportunity title/customer/lead number, stakeholder code, or input status"
        },
        workflowStatuses: {
          type: "array",
          items: { type: "string" },
          example: ["Draft", "In Progress"]
        },
        isMyPending: { type: "boolean", example: false }
      }
    }
  })
  @ApiResponse({
    status: 200,
    description:
      "Returns paginated opportunities with their rounds and stakeholder inputs the current user can access, based on SharePoint group membership or direct stakeholder assignment"
  })
  async getStakeholderAllInputs(
    @Context() context: CurrentContext,
    @Body()
    body: {
      page?: number;
      limit?: number;
      workflowStatuses?: string[];
      myRecord?: boolean;
      search_text?: string;
      isMyPending?: boolean;
    }
  ): Promise<{ data: any[]; total: number; page: number; limit: number }> {
    const page = body.page ?? 1;
    const limit = body.limit ?? 10;
    return this.roundService.getStakeholderAllInputs(
      context.user.unique_name,
      +page,
      +limit,
      body.myRecord,
      body.search_text,
      body.workflowStatuses,
      body.isMyPending
    );
  }

  private async mapToRoundResponseDto(round: any): Promise<RoundResponseDto> {
    if (!round) return null;

    const stakeholderTypeByCode = new Map<string, string>(
      (round.stakeholders ?? []).map((s: any) => [
        s.stakeholder_code,
        s.stakeholderType
      ])
    );

    const stakeholderDescriptionByCode = new Map<string, string>(
      (round.stakeholders ?? []).map((s: any) => [
        s.stakeholder_code,
        s.description
      ])
    );

    const inputs = round.inputs
      ? await Promise.all(
          round.inputs.map(async (input) => {
            let standardInputInfo = null;
            if (input.isStandardRate === "1" && input.dataRoundId) {
              const si = await this.roundService.getStandardInput(
                input.dataRoundId
              );
              if (si)
                standardInputInfo = {
                  id: si.id,
                  title: si.title,
                  description: si.description,
                  fileRelPath: si.fileRelPath
                };
            }
            return {
              id: input.id,
              opportunityId: input.opportunityId,
              opportunityTitle: round?.opportunity?.title ?? null,
              roundId: input.roundId,
              roundNumber: input.roundNumber,
              stakeholder: input.stakeholder,
              stakeholderType:
                stakeholderTypeByCode.get(input.stakeholderCode) ?? null,
              description:
                stakeholderDescriptionByCode.get(input.stakeholderCode) ??
                null,
              stakeholderCode: input.stakeholderCode,
              revisionNumber: input.revisionNumber,
              isCurrentVersion: input.isCurrentVersion,
              isCurrentApproved: input.isCurrentApproved,
              scenarioName: input.scenarioName,
              fileRelPath: input.fileRelPath,
              exportedOn: input.exportedOn,
              userStatus: input.userStatus,
              workflowStatus: input.workflowStatus,
              isStandardRate: input.isStandardRate,
              isCopiedPreviousRound: input.isCopiedPreviousRound,
              referenceData: input.dataRoundId,
              inputType: input.input_type,
              revisionAttempt: input.revisionAttempt,
              lastRevisionAttempt: input.lastRevisionAttempt,
              versionNumber: input.versionNumber,
              submissionType: input.submissionType,
              standardInputInfo: standardInputInfo,
              inputRequired: input.inputRequired ?? true,
              active: input.active,
              deleted: input.deleted,
              createdOn: input.createdOn,
              createdBy: input.createdBy,
              submittedOn: input.submittedOn,
              submittedBy: input.submittedBy,
              approvedBy: input.approvedBy
            };
          })
        )
      : [];

    return {
      id: round.id,
      opportunityId: round.opportunityId,
      opportunityTitle: round?.opportunity?.title ?? null,
      roundNumber: round.roundNumber,
      description: round.description,
      customerSubmissionDate: round.customerSubmissionDate,
      inputDueDate: round.templateDueDate,
      scenarioList: round.scenarioList,
      userStatus: round.userStatus,
      workflowStatus: round.workflowStatus,
      stakeholders: round.stakeholders
        ? round.stakeholders.map((s) => ({
            id: s.id,
            opportunityId: s.opportunityId,
            roundId: s.roundId,
            roundNumber: s.roundNumber,
            stakeholder: s.stakeholder,
            stakeholder_code: s.stakeholder_code,
            stakeholderType: s.stakeholderType,
            description: s.description,
            additionalStakeholders: s.additionalStakeholders,
            applicableScenarios: s.applicableScenarios,
            notifyUsers: s.notify_users,
            dueDate: s.dueDate,
            collectDraftInput: s.collectDraftInput,
            draftDueDate: s.draftDueDate,
            active: s.active,
            deleted: s.deleted,
            createdOn: s.createdOn,
            createdBy: s.createdBy,
            modifiedOn: s.modifiedOn,
            modifiedBy: s.modifiedBy
          }))
        : [],
      inputs,
      active: round.active,
      deleted: round.deleted,
      createdOn: round.createdOn,
      createdBy: round.createdBy,
      modifiedOn: round.modifiedOn,
      modifiedBy: round.modifiedBy,
      leadPricer: round?.opportunity?.lead_pricer ?? null
    };
  }

  private mapToInputResponseDto(input: any): StakeholderInputResponseDto {
    if (!input) return null;

    return {
      id: input.id,
      opportunityId: input.opportunityId,
      roundId: input.roundId,
      roundNumber: input.roundNumber,
      stakeholder: input.stakeholder,
      stakeholderType: input.stakeholderData?.stakeholderType ?? null,
      description: input.stakeholderData?.description ?? null,
      revisionNumber: input.revisionNumber,
      isCurrentVersion: input.isCurrentVersion,
      isCurrentApproved: input.isCurrentApproved,
      scenarioName: input.scenarioName,
      fileRelPath: input.fileRelPath,
      processedData: input.processedData,
      exportedOn: input.exportedOn,
      userStatus: input.userStatus,
      workflowStatus: input.workflowStatus,
      active: input.active,
      deleted: input.deleted,
      createdOn: input.createdOn,
      createdBy: input.createdBy,
      modifiedOn: input.modifiedOn,
      modifiedBy: input.modifiedBy,
      inputType: input.input_type,
      isStandardRate: input.isStandardRate,
      isCopiedPreviousRound: input.isCopiedPreviousRound,
      referenceData: input.dataRoundId,
      stakeholderCode: input.stakeholder_code,
      revisionAttempt: input.revisionAttempt,
      lastRevisionAttempt: input.lastRevisionAttempt,
      versionNumber: input.versionNumber,
      submissionType: input.submissionType,
      submittedOn: input.submittedOn,
      submittedBy: input.submittedBy,
      approvedBy: input.approvedBy
    };
  }

  private mapToInputResponseWithoutProcessedDataDto(
    input: any,
    opportunityTitle: any
  ): StakeholderInputWithoutProcessedDataDto {
    if (!input) return null;

    return {
      id: input.id,
      opportunityId: input.opportunityId,
      opportunityTitle: opportunityTitle,
      roundId: input.roundId,
      roundNumber: input.roundNumber,
      stakeholder: input.stakeholder,
      stakeholderType:
        input.stakeholderData?.stakeholderType ?? input.stakeholderType ?? null,
      description:
        input.stakeholderData?.description ?? input.description ?? null,
      revisionNumber: input.revisionNumber,
      isCurrentVersion: input.isCurrentVersion,
      isCurrentApproved: input.isCurrentApproved,
      scenarioName: input.scenarioName,
      scenarioDescription: input.scenarioDescription,
      fileRelPath: input.fileRelPath,
      exportedOn: input.exportedOn,
      userStatus: input.userStatus,
      workflowStatus: input.workflowStatus,
      active: input.active,
      deleted: input.deleted,
      createdOn: input.createdOn,
      createdBy: input.createdBy,
      modifiedOn: input.modifiedOn,
      modifiedBy: input.modifiedBy,
      inputType: input.input_type,
      isStandardRate: input.isStandardRate,
      isCopiedPreviousRound: input.isCopiedPreviousRound,
      referenceData: input.dataRoundId,
      stakeholderCode: input.stakeholderCode,
      revisionAttempt: input.revisionAttempt,
      lastRevisionAttempt: input.lastRevisionAttempt,
      versionNumber: input.versionNumber,
      submissionType: input.submissionType,
      additionalStakeholders: input.additionalStakeholders ?? null,
      notifyUsers: input.notifyUsers ?? null,
      inputRequired: input.inputRequired ?? true,
      submittedOn: input.submittedOn,
      submittedBy: input.submittedBy,
      approvedBy: input.approvedBy,
    };
  }

  private mapToOutputLogResponseDto(log: any): OutputLogResponseDto {
    if (!log) return null;

    return {
      id: log.id,
      opportunityId: log.opportunityId,
      roundId: log.roundId,
      fileName: log.file_name,
      fileRelPath: log.fileRelPath,
      processedData: log.processedData,
      extractedOn: log.extrated_on,
      extractedBy: log.extrated_by,
      active: log.active,
      deleted: log.deleted,
      createdOn: log.createdOn,
      createdBy: log.createdBy,
      modifiedOn: log.modifiedOn,
      modifiedBy: log.modifiedBy
    };
  }
}
