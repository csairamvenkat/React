import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString, IsObject, IsBoolean } from 'class-validator';

export class RejectStakeholderInputDto {
  @ApiProperty({
    description: 'Opportunity ID',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({
    description: 'Round ID',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({
    description: 'Round number',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  roundNumber: number;

  @ApiPropertyOptional({
    description: 'Revision number',
    example: 1,
  })
  @IsOptional()
  @IsNumber()
  revisionNumber?: number;

  @ApiPropertyOptional({
    description: 'Scenario name',
    example: 'A',
  })
  @IsOptional()
  @IsString()
  scenarioName?: string;

  @ApiPropertyOptional({
    description: 'User status',
    example: 'Completed',
  })
  @IsOptional()
  @IsString()
  userStatus?: string;

  @ApiPropertyOptional({
    description: 'Workflow status',
    example: 'Approved',
  })
  @IsOptional()
  @IsString()
  workflowStatus?: string;

  @ApiPropertyOptional({
    description: 'Is standard rate',
    example: false,
  })
  @IsOptional()
  @IsBoolean()
  isStandardRate?: boolean;

  @ApiPropertyOptional({
    description: 'Is copied from previous round',
    example: false,
  })
  @IsOptional()
  @IsBoolean()
  isCopiedPreviousRound?: boolean;

  @ApiPropertyOptional({
    description: 'Data round ID (reference to previous round or standard input)',
    example: 1,
  })
  @IsOptional()
  @IsNumber()
  dataRoundId?: number;

  @ApiPropertyOptional({
    description: 'Input type',
    example: 'manual',
  })
  @IsOptional()
  @IsString()
  input_type?: string;

  @ApiPropertyOptional({
    description: 'Stakeholder code',
    example: 'ENG',
  })
  @IsOptional()
  @IsString()
  stakeholderCode?: string;

  @ApiPropertyOptional({
    description: 'Version number',
    example: "1",
  })
  @IsOptional()
  @IsString()
  versionNumber?: string;

  @ApiPropertyOptional({
    description: 'Submission type',
    example: 'Draft',
  })
  @IsOptional()
  @IsString()
  submissionType?: string;
}
