import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsObject
} from "class-validator";

export class SubmitStakeholderInputDto {
  @ApiProperty({ description: "Opportunity ID", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({ description: "Round ID", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({ description: "Round number", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundNumber: number;

  @ApiPropertyOptional({ description: "Stakeholder code", example: "ENG" })
  @IsOptional()
  @IsString()
  stakeholderCode?: string;

  @ApiPropertyOptional({ description: "Scenario name", example: "A" })
  @IsOptional()
  @IsString()
  scenarioName?: string;

  @ApiPropertyOptional({
    description: "File relative path",
    example: "/uploads/opportunity_1/round_1/stakeholder_input.xlsx"
  })
  @IsOptional()
  @IsString()
  fileRelPath?: string;

  @ApiProperty({
    description: "Processed data JSON from stakeholder template",
    example: {
      rates: [
        { service: "Service A", price: 100, currency: "USD" },
        { service: "Service B", price: 200, currency: "USD" }
      ]
    }
  })
  @IsNotEmpty()
  @IsObject()
  processedData: any;

  @ApiPropertyOptional({ description: "User status", example: "Submitted" })
  @IsOptional()
  @IsString()
  userStatus?: string;

  @ApiPropertyOptional({ description: "Version number", example: "V1" })
  @IsOptional()
  @IsString()
  versionNumber?: string;

  @ApiPropertyOptional({
    description: "Submission type",
    example: "Draft"
  })
  @IsOptional()
  @IsString()
  submissionType?: string;
}
