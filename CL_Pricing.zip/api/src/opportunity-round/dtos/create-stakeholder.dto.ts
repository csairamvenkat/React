import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import {
  IsNotEmpty,
  IsNumber,
  IsString,
  IsOptional,
  IsArray,
  ValidateNested,
  IsDateString,
  IsBoolean
} from "class-validator";
import { Type } from "class-transformer";
import { UserDto } from "src/opportunity/dtos/bid-team-member.dto";
import { ScenarioDetailDto } from "./create-round.dto";

export class ScenarioDto {
  @ApiProperty({
    description: "Scenario name",
    example: "A"
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    description: "Scenario description",
    example: "Scenario A for standard pricing"
  })
  @IsString()
  desc: string;

  @ApiPropertyOptional({
    description: "Is standard rate",
    example: false
  })
  @IsOptional()
  @IsBoolean()
  isStandardRate?: boolean;

  @ApiPropertyOptional({
    description: "Is copied from previous round",
    example: false
  })
  @IsOptional()
  @IsBoolean()
  isCopiedPreviousRound?: boolean;

  @ApiPropertyOptional({
    description:
      "Data round ID (reference to previous round or standard input)",
    example: 1
  })
  @IsOptional()
  @IsNumber()
  dataRoundId?: number;

  @ApiPropertyOptional({
    description: "Input type",
    example: "manual"
  })
  @IsOptional()
  @IsString()
  input_type?: string;
}

export class CreateStakeholderDto {
  @ApiProperty({
    description: "Opportunity ID",
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({
    description: "Round ID",
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({
    description: "Stakeholder Name",
    example: "Engineering"
  })
  @IsNotEmpty()
  @IsString()
  stakeholder: string;

  @ApiPropertyOptional({
    description: "Additional stakeholders for this stakeholder",
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  additionalStakeholders?: UserDto[];

  @ApiProperty({
    description: "Applicable scenarios for this stakeholder",
    type: [ScenarioDetailDto]
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ScenarioDetailDto)
  applicableScenarios: ScenarioDetailDto[];

  @ApiProperty({
    description: "Due date for stakeholder submission",
    example: "2025-02-15T23:59:59.000Z"
  })
  @IsNotEmpty()
  @IsDateString()
  dueDate: string;

  @ApiPropertyOptional({
    description: "Users to notify for this stakeholder",
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  notify_users?: UserDto[];

  @ApiPropertyOptional({
    description: "Stakeholder code",
    example: "ENG"
  })
  @IsOptional()
  @IsString()
  stakeholder_code?: string;

  @ApiPropertyOptional({
    description: "Stakeholder type",
    example: "Standard"
  })
  @IsOptional()
  @IsString()
  stakeholderType?: string;

  @ApiPropertyOptional({
    description: "Stakeholder description",
    example: "Handles engineering pricing inputs"
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    description: "Version Number",
    example: "V1"
  })
  @IsOptional()
  @IsString()
  versionNumber?: string;

  @ApiPropertyOptional({
    description: "Whether draft input should be collected for this stakeholder",
    example: false
  })
  @IsOptional()
  @IsBoolean()
  collectDraftInput?: boolean;

  @ApiPropertyOptional({
    description: "Due date for draft input submission",
    example: "2025-02-10T23:59:59.000Z"
  })
  @IsOptional()
  @IsString()
  draftDueDate?: string;
}
