import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsNotEmpty, IsNumber } from "class-validator";
import { Transform } from "class-transformer";

export class UpdateRoundInputRequiredDto {
  @ApiProperty({ description: "Round Input ID", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  id: number;

  @ApiProperty({ description: "Input Required", example: true })
  @IsNotEmpty()
  @IsBoolean()
  @Transform(({ value }) => value === true || value === "true")
  inputRequired: boolean;
}
