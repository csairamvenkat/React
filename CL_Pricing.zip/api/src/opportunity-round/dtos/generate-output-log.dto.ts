import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class GenerateOutputLogDto {
  @ApiProperty({
    description: 'Opportunity ID',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({
    description: 'Round ID',
    example: 1,
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiPropertyOptional({
    description: 'File relative path for the generated output',
    example: '/outputs/opportunity_1/round_1/output_file.xlsx',
  })
  @IsOptional()
  @IsString()
  fileRelPath?: string;

  @ApiPropertyOptional({
    description: 'Processed data associated with the generated output',
  })
  @IsOptional()
  processedData?: any;

  
  @ApiPropertyOptional({
    description: 'Processed data associated with the generated output',
  })
  @IsOptional()
  extratedOn?: Date;

  
  @ApiPropertyOptional({
    description: 'Processed data associated with the generated output',
  })
  @IsOptional()
  extratedBy?: string;
}
