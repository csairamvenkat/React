import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty, IsNumber, IsOptional, IsString } from "class-validator";

export class RetractStakeholderInputDto {
  @ApiProperty({ description: "Opportunity ID", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({ description: "Round ID", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({ description: "Round number", example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundNumber: number;

  @ApiPropertyOptional({ description: "Scenario name", example: "A" })
  @IsOptional()
  @IsString()
  scenarioName?: string;

  @ApiPropertyOptional({ description: "Stakeholder code", example: "ENG" })
  @IsOptional()
  @IsString()
  stakeholderCode?: string;

  @ApiPropertyOptional({ description: "Version number", example: "V1" })
  @IsOptional()
  @IsString()
  versionNumber?: string;

  @ApiPropertyOptional({
    description: "Submission type",
    example: "Draft"
  })
  @IsOptional()
  @IsString()
  submissionType?: string;
}
