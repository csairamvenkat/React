import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsOptional, IsString } from "class-validator";
import { UserDto } from "src/opportunity/dtos/bid-team-member.dto";

export class ScenarioResponseDto {
  @ApiProperty({ example: "A" })
  name: string;

  @ApiProperty({ example: "Scenario A for standard pricing" })
  desc: string;
}

export class StakeholderResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 1 })
  opportunityId: number;

  @ApiProperty({ example: 1 })
  roundId: number;

  @ApiProperty({ example: 1 })
  roundNumber: number;

  @ApiProperty({ example: "john.doe@example.com" })
  stakeholder: string;

  @ApiPropertyOptional({ example: "Standard" })
  stakeholderType?: string;

  @ApiPropertyOptional({ example: "Handles engineering pricing inputs" })
  description?: string;

  @ApiPropertyOptional({
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  additionalStakeholders?: UserDto[];

  @ApiProperty({ type: [ScenarioResponseDto] })
  applicableScenarios: ScenarioResponseDto[];

  @ApiProperty({ example: "2025-02-15T23:59:59.000Z" })
  dueDate: Date;

  @ApiProperty({ example: true })
  active: boolean;

  @ApiProperty({ example: false })
  deleted: boolean;

  @ApiProperty({ example: "2025-01-15T10:30:00.000Z" })
  createdOn: Date;

  @ApiProperty({ example: "john.doe@example.com" })
  createdBy: string;

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  modifiedOn?: Date;

  @ApiPropertyOptional({ example: "jane.smith@example.com" })
  modifiedBy?: string;

  @ApiPropertyOptional({
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  notifyUsers?: UserDto[];

  @ApiPropertyOptional({ example: "ENG" })
  stakeholder_code?: string;

  @ApiPropertyOptional({ example: false })
  collectDraftInput?: boolean;

  @ApiPropertyOptional({ example: "2025-02-10T23:59:59.000Z" })
  @IsOptional()
  @IsString()
  draftDueDate?: string;
}

export class StakeholderInputResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 1 })
  opportunityId: number;

  @ApiProperty({ example: 1 })
  roundId: number;

  @ApiProperty({ example: 1 })
  roundNumber: number;

  @ApiProperty({ example: "john.doe@example.com" })
  stakeholder: string;

  @ApiPropertyOptional({ example: "Standard" })
  stakeholderType?: string;

  @ApiPropertyOptional({ example: "Handles engineering pricing inputs" })
  description?: string;

  @ApiPropertyOptional({ example: 1 })
  revisionNumber?: number;

  @ApiPropertyOptional({ example: "1" })
  isCurrentVersion?: string;

  @ApiPropertyOptional({ example: "0" })
  isCurrentApproved?: string;

  @ApiPropertyOptional({ example: "A" })
  scenarioName?: string;

  @ApiPropertyOptional({
    example: "/uploads/opportunity_1/round_1/stakeholder_input.xlsx"
  })
  fileRelPath?: string;

  @ApiProperty({ example: { rates: [] } })
  processedData: any;

  @ApiPropertyOptional({ example: "2025-01-15T10:30:00.000Z" })
  exportedOn?: Date;

  @ApiPropertyOptional({ example: "Completed" })
  userStatus?: string;

  @ApiPropertyOptional({ example: "Approved" })
  workflowStatus?: string;

  @ApiPropertyOptional({ example: "0" })
  isStandardRate?: string;

  @ApiPropertyOptional({ example: "0" })
  isCopiedPreviousRound?: string;

  @ApiPropertyOptional({ example: 1 })
  referenceData?: number;

  @ApiPropertyOptional({ example: "manual" })
  inputType?: string;

  @ApiPropertyOptional({ example: "ENG" })
  stakeholderCode?: string;

  @ApiPropertyOptional({ example: 1 })
  revisionAttempt?: number;

  @ApiPropertyOptional({ example: "2025-01-15T10:30:00.000Z" })
  lastRevisionAttempt?: Date;

  @ApiPropertyOptional({ example: "V1" })
  versionNumber?: string;

  @ApiPropertyOptional({ example: "Draft" })
  submissionType?: string;

  @ApiProperty({ example: true })
  active: boolean;

  @ApiProperty({ example: false })
  deleted: boolean;

  @ApiProperty({ example: "2025-01-15T10:30:00.000Z" })
  createdOn: Date;

  @ApiProperty({ example: "john.doe@example.com" })
  createdBy: string;

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  modifiedOn?: Date;

  @ApiPropertyOptional({ example: "jane.smith@example.com" })
  modifiedBy?: string;

  @ApiPropertyOptional({ type: [UserDto] })
  additionalStakeholders?: UserDto[];

  @ApiPropertyOptional({ type: [UserDto] })
  notifyUsers?: UserDto[];

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  submittedOn?: Date;

  @ApiPropertyOptional({ type: UserDto })
  submittedBy?: any;

  @ApiPropertyOptional({ type: UserDto })
  approvedBy?: any;
}

export class RoundResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 1 })
  opportunityId: number;

  @ApiPropertyOptional({ example: "Project Alpha" })
  opportunityTitle?: string;

  @ApiProperty({ example: 1 })
  roundNumber: number;

  @ApiPropertyOptional({ example: "Initial pricing round for Q1 2025" })
  description?: string;

  @ApiPropertyOptional({ example: "2025-03-01T23:59:59.000Z" })
  customerSubmissionDate?: Date;

  @ApiPropertyOptional({ example: "2025-02-28T23:59:59.000Z" })
  inputDueDate?: Date;

  @ApiProperty({ type: [ScenarioResponseDto] })
  scenarioList: ScenarioResponseDto[];

  @ApiPropertyOptional({ example: "Draft" })
  userStatus?: string;

  @ApiPropertyOptional({ example: "In Progress" })
  workflowStatus?: string;

  @ApiProperty({ type: [StakeholderResponseDto] })
  stakeholders: StakeholderResponseDto[];

  @ApiPropertyOptional({ example: "HR" })
  stakeholder_code?: string;

  @ApiProperty({ example: true })
  active: boolean;

  @ApiProperty({ example: false })
  deleted: boolean;

  @ApiProperty({ example: "2025-01-15T10:30:00.000Z" })
  createdOn: Date;

  @ApiProperty({ example: "john.doe@example.com" })
  createdBy: string;

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  modifiedOn?: Date;

  @ApiPropertyOptional({ example: "jane.smith@example.com" })
  modifiedBy?: string;

  @ApiPropertyOptional({
    type: [StakeholderInputResponseDto]
  })
  inputs?: StakeholderInputResponseDto[];

  @ApiPropertyOptional({ type: "array", items: { type: "object" } })
  leadPricer?: any[];
}

export class OutputLogResponseDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 1 })
  opportunityId: number;

  @ApiProperty({ example: 1 })
  roundId: number;

  @ApiProperty({ example: "output_file.xlsx" })
  fileName: string;

  @ApiPropertyOptional({
    example: "/outputs/opportunity_1/round_1/output_file.xlsx"
  })
  fileRelPath?: string;

  @ApiPropertyOptional({
    description: "Processed data associated with the output"
  })
  processedData?: any;

  @ApiPropertyOptional({ example: "2025-01-15T10:30:00.000Z" })
  extractedOn?: Date;

  @ApiPropertyOptional({ example: "john.doe@example.com" })
  extractedBy?: string;

  @ApiProperty({ example: true })
  active: boolean;

  @ApiProperty({ example: false })
  deleted: boolean;

  @ApiProperty({ example: "2025-01-15T10:30:00.000Z" })
  createdOn: Date;

  @ApiProperty({ example: "john.doe@example.com" })
  createdBy: string;

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  modifiedOn?: Date;

  @ApiPropertyOptional({ example: "jane.smith@example.com" })
  modifiedBy?: string;
}

export class StakeholderInputWithoutProcessedDataDto {
  @ApiProperty({ example: 1 })
  id: number;

  @ApiProperty({ example: 1 })
  opportunityId: number;

  @ApiProperty({ example: "ABC" })
  opportunityTitle: string;

  @ApiProperty({ example: 1 })
  roundId: number;

  @ApiProperty({ example: 1 })
  roundNumber: number;

  @ApiProperty({ example: "john.doe@example.com" })
  stakeholder: string;

  @ApiPropertyOptional({ example: "Internal" })
  stakeholderType?: string;

  @ApiPropertyOptional({ example: "Handles engineering pricing inputs" })
  description?: string;

  @ApiPropertyOptional({ example: 1 })
  revisionNumber?: number;

  @ApiPropertyOptional({ example: "1" })
  isCurrentVersion?: string;

  @ApiPropertyOptional({ example: "0" })
  isCurrentApproved?: string;

  @ApiPropertyOptional({ example: "A" })
  scenarioName?: string;

  @ApiPropertyOptional({ example: "A" })
  scenarioDescription?: string;

  @ApiPropertyOptional({ example: true })
  inputRequired?: boolean;

  @ApiPropertyOptional({
    example: "/uploads/opportunity_1/round_1/stakeholder_input.xlsx"
  })
  fileRelPath?: string;

  @ApiPropertyOptional({ example: "2025-01-15T10:30:00.000Z" })
  exportedOn?: Date;

  @ApiPropertyOptional({ example: "Completed" })
  userStatus?: string;

  @ApiPropertyOptional({ example: "Approved" })
  workflowStatus?: string;

  @ApiPropertyOptional({ example: "0" })
  isStandardRate?: string;

  @ApiPropertyOptional({ example: "0" })
  isCopiedPreviousRound?: string;

  @ApiPropertyOptional({ example: 1 })
  referenceData?: number;

  @ApiPropertyOptional({ example: "manual" })
  inputType?: string;

  @ApiPropertyOptional({ example: "ENG" })
  stakeholderCode?: string;

  @ApiPropertyOptional({ example: 1 })
  revisionAttempt?: number;

  @ApiPropertyOptional({ example: "2025-01-15T10:30:00.000Z" })
  lastRevisionAttempt?: Date;

  @ApiPropertyOptional({ example: "V1" })
  versionNumber?: string;

  @ApiPropertyOptional({ example: "Draft" })
  submissionType?: string;

  @ApiProperty({ example: true })
  active: boolean;

  @ApiProperty({ example: false })
  deleted: boolean;

  @ApiProperty({ example: "2025-01-15T10:30:00.000Z" })
  createdOn: Date;

  @ApiProperty({ example: "john.doe@example.com" })
  createdBy: string;

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  modifiedOn?: Date;

  @ApiPropertyOptional({ example: "jane.smith@example.com" })
  modifiedBy?: string;

  @ApiPropertyOptional({ type: [UserDto] })
  additionalStakeholders?: UserDto[];

  @ApiPropertyOptional({ type: [UserDto] })
  notifyUsers?: UserDto[];

  @ApiPropertyOptional({ example: "2025-01-15T14:30:00.000Z" })
  submittedOn?: Date;

  @ApiPropertyOptional({ type: [UserDto] })
  submittedBy: any;

  @ApiPropertyOptional({ type: [UserDto] })
  approvedBy: any;
}
