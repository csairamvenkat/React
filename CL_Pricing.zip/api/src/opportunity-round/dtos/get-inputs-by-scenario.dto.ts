import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString
} from "class-validator";

export class GetInputsByScenarioDto {
  @ApiProperty({
    description: "Round ID",
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({
    description: "Stakeholder Name",
    example: "Engineering"
  })
  @IsNotEmpty()
  @IsString()
  stakeholder: string;

  @ApiPropertyOptional({
    description: "scenarios",
    example: ["A", "B"],
    type: [String]
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  scenarios?: string[];
}
