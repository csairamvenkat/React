import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import {
  IsNotEmpty,
  IsNumber,
  IsString,
  IsOptional,
  IsArray,
  ValidateNested,
  IsDateString,
  IsBoolean
} from "class-validator";
import { Type } from "class-transformer";
import { UserDto } from "src/opportunity/dtos/bid-team-member.dto";
import { UpsertScenarioDto } from "./upsert-stakeholder.dto";

export class ChangeStakeholderVersionDto {
  @ApiProperty({
    description: "Opportunity ID",
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({
    description: "Round ID",
    example: 1
  })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({
    description: "Stakeholder code",
    example: "ENG"
  })
  @IsNotEmpty()
  @IsString()
  stakeholder_code: string;

  @ApiPropertyOptional({
    description: "Additional stakeholders for this stakeholder",
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  additionalStakeholders?: UserDto[];

  @ApiPropertyOptional({
    description: "Applicable scenarios for this stakeholder",
    type: [UpsertScenarioDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpsertScenarioDto)
  applicableScenarios?: UpsertScenarioDto[];

  @ApiPropertyOptional({
    description: "Due date for stakeholder submission",
    example: "2025-02-15T23:59:59.000Z"
  })
  @IsOptional()
  @IsDateString()
  dueDate?: string;

  @ApiPropertyOptional({
    description: "Users to notify for this stakeholder",
    example: [
      {
        name: "John Doe",
        email: "john.doe@example.com",
        login_id: "john.doe@example.com"
      }
    ],
    type: [UserDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UserDto)
  notify_users?: UserDto[];

  @ApiPropertyOptional({
    description: "Stakeholder type",
    example: "Standard"
  })
  @IsOptional()
  @IsString()
  stakeholderType?: string;

  @ApiPropertyOptional({
    description: "Stakeholder description",
    example: "Handles engineering pricing inputs"
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    description: "Whether draft input should be collected for this stakeholder",
    example: false
  })
  @IsOptional()
  @IsBoolean()
  collectDraftInput?: boolean;

  @ApiPropertyOptional({
    description: "Due date for draft input submission",
    example: "2025-02-10T23:59:59.000Z"
  })
  @IsOptional()
  @IsString()
  draftDueDate?: string;

  @ApiProperty({
    description:
      "New version number to apply. Existing current inputs for the stakeholder are cancelled and new inputs are created under this version for each applicable scenario",
    example: "V2"
  })
  @IsNotEmpty()
  @IsString()
  versionNumber: string;
}
