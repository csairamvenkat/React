import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class InitiateRevisionDto {
  @ApiProperty({ description: 'Opportunity ID', example: 1 })
  @IsNotEmpty()
  @IsNumber()
  opportunityId: number;

  @ApiProperty({ description: 'Round ID', example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundId: number;

  @ApiProperty({ description: 'Round number', example: 1 })
  @IsNotEmpty()
  @IsNumber()
  roundNumber: number;

  @ApiPropertyOptional({ description: 'Stakeholder code', example: 'ENG' })
  @IsOptional()
  @IsString()
  stakeholderCode?: string;

  @ApiPropertyOptional({ description: 'Scenario name', example: 'A' })
  @IsOptional()
  @IsString()
  scenarioName?: string;
}
