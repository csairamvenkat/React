import { ApiPropertyOptional } from "@nestjs/swagger";
import { IsArray, IsEnum, IsOptional } from "class-validator";
import { RoundWorkflowStatus } from "src/shared/enums/round-status.enum";

export class GetRoundInputsDto {
  @ApiPropertyOptional({
    description:
      "Filter inputs by workflow status. If empty or omitted, all statuses are returned.",
    example: ["Submitted", "Approved"],
    enum: RoundWorkflowStatus,
    isArray: true
  })
  @IsOptional()
  @IsArray()
  @IsEnum(RoundWorkflowStatus, { each: true })
  workflowStatuses?: RoundWorkflowStatus[];
}
