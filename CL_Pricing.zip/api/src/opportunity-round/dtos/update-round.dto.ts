import { ApiPropertyOptional } from "@nestjs/swagger";
import {
  IsOptional,
  IsString,
  IsArray,
  ValidateNested,
  IsDateString
} from "class-validator";
import { Type } from "class-transformer";
import { ScenarioDto } from "./create-round.dto";

export class UpdateRoundDto {
  @ApiPropertyOptional({
    description: "Round description",
    example: "Updated pricing round for Q1 2025"
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    description: "Customer submission date",
    example: "2025-03-01T23:59:59.000Z"
  })
  @IsOptional()
  @IsDateString()
  customerSubmissionDate?: string;

  @ApiPropertyOptional({
    description: "Input due date",
    example: "2025-02-28T23:59:59.000Z"
  })
  @IsOptional()
  @IsDateString()
  inputDueDate?: string;

  @ApiPropertyOptional({
    description: "List of scenarios for this round",
    type: [ScenarioDto]
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ScenarioDto)
  scenarioList?: ScenarioDto[];
}
