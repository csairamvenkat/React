import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class UpdateStakeholderInputDto {
  @ApiPropertyOptional({ description: 'Stakeholder code', example: 'ENG' })
  @IsOptional()
  @IsString()
  stakeholder_code?: string;

  @ApiPropertyOptional({ description: 'File relative path', example: '/uploads/opportunity_1/round_1/stakeholder_input.xlsx' })
  @IsOptional()
  @IsString()
  fileRelPath?: string;

  @ApiPropertyOptional({ description: 'User status', example: 'Completed' })
  @IsOptional()
  @IsString()
  userStatus?: string;

  @ApiPropertyOptional({ description: 'Workflow status', example: 'Approved' })
  @IsOptional()
  @IsString()
  workflowStatus?: string;

  @ApiPropertyOptional({ description: 'Input type', example: 'manual' })
  @IsOptional()
  @IsString()
  input_type?: string;
}
