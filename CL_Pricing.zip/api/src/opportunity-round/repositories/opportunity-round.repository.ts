import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { OpportunityRound } from '../models/opportunity-round.model';

@Injectable()
export class OpportunityRoundRepository extends BaseRepository<OpportunityRound> {
  constructor(
    @InjectModel(OpportunityRound)
    private opportunityRoundModel: typeof OpportunityRound,
  ) {
    super(opportunityRoundModel);
  }
}
