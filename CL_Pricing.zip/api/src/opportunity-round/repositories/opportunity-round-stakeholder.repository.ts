import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { OpportunityRoundStakeholder } from '../models/opportunity-round-stakeholder.model';

@Injectable()
export class OpportunityRoundStakeholderRepository extends BaseRepository<OpportunityRoundStakeholder> {
  constructor(
    @InjectModel(OpportunityRoundStakeholder)
    private stakeholderModel: typeof OpportunityRoundStakeholder,
  ) {
    super(stakeholderModel);
  }
}
