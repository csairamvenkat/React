import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { OutputLog } from '../models/output-log.model';

@Injectable()
export class OutputLogRepository extends BaseRepository<OutputLog> {
  constructor(
    @InjectModel(OutputLog)
    private outputLogModel: typeof OutputLog,
  ) {
    super(outputLogModel);
  }
}
