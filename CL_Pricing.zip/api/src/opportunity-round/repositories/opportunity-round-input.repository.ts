import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { BaseRepository } from '../../shared/repositories/base.repository';
import { OpportunityRoundInput } from '../models/opportunity-round-input.model';

@Injectable()
export class OpportunityRoundInputRepository extends BaseRepository<OpportunityRoundInput> {
  constructor(
    @InjectModel(OpportunityRoundInput)
    private inputModel: typeof OpportunityRoundInput,
  ) {
    super(inputModel);
  }
}
