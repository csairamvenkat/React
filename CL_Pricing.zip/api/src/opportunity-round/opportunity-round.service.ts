import {
  ConflictException,
  Injectable,
  NotFoundException
} from "@nestjs/common";
import { Op, literal, where, cast, col, fn } from "sequelize";
import * as path from "path";
import { OpportunityRoundRepository } from "./repositories/opportunity-round.repository";
import { OpportunityRoundStakeholderRepository } from "./repositories/opportunity-round-stakeholder.repository";
import { OpportunityRoundInputRepository } from "./repositories/opportunity-round-input.repository";
import { OutputLogRepository } from "./repositories/output-log.repository";
import { CreateRoundDto, StakeholderDto } from "./dtos/create-round.dto";
import { CreateStakeholderDto } from "./dtos/create-stakeholder.dto";
import { UpsertStakeholderDto } from "./dtos/upsert-stakeholder.dto";
import { ChangeStakeholderVersionDto } from "./dtos/change-stakeholder-version.dto";
import { CompleteStakeholderInputDto } from "./dtos/complete-stakeholder-input.dto";
import { InitiateRevisionDto } from "./dtos/initiate-revision.dto";
import { RetractStakeholderInputDto } from "./dtos/retract-stakeholder-input.dto";
import { SubmitStakeholderInputDto } from "./dtos/submit-stakeholder-input.dto";
import { GenerateOutputLogDto } from "./dtos/generate-output-log.dto";
import { UpdateRoundDto } from "./dtos/update-round.dto";
import { OpportunityRound } from "./models/opportunity-round.model";
import { OpportunityRoundStakeholder } from "./models/opportunity-round-stakeholder.model";
import { OpportunityRoundInput } from "./models/opportunity-round-input.model";
import { OutputLog } from "./models/output-log.model";
import { Opportunity } from "../opportunity/models/opportunity.model";
import { StandardInputRepository } from "../standard-input/repositories/standard-input.repository";
import {
  RoundUserStatus,
  RoundWorkflowStatus
} from "src/shared/enums/round-status.enum";
import { CurrentContext } from "../shared/types/current-context.type";
import { RejectStakeholderInputDto } from "./dtos/reject-stakeholder-input.dto";
import {
  InputType,
  StakeholderType,
  SubmissionType
} from "src/shared/enums/general-status.enum";
import { SharepointPermissionService } from "src/sharepoint-permission/providers/sharepoint-permission.service";
import { SharePointAppConfig } from "src/shared/types";
import { ConfigService } from "src/config/config.service";
import { OpportunityRepository } from "src/opportunity/repositories/opportunity.repository";
import { SharedNotificationService } from "src/shared/services/shared-notification.service";
import {
  NOTIFICATION_ENTITY_TYPE,
  NOTIFICATION_TEMPLATES
} from "src/shared/enums";
import { PermissionEnum } from "src/shared/enums/permission-status.enum";
import { History } from "../history/models/history.model";
import {
  HistoryEntityType,
  HistoryActionPerformed,
  HistoryActionComments,
} from "../shared/enums/history.enum";
@Injectable()
export class OpportunityRoundService {
  private cfg: SharePointAppConfig;

  constructor(
    private readonly roundRepository: OpportunityRoundRepository,
    private readonly stakeholderRepository: OpportunityRoundStakeholderRepository,
    private readonly inputRepository: OpportunityRoundInputRepository,
    private readonly outputLogRepository: OutputLogRepository,
    private readonly standardInputRepository: StandardInputRepository,
    private readonly sharepointPermissionService: SharepointPermissionService,
    private readonly configService: ConfigService,
    private readonly opportunityRepository: OpportunityRepository,
    private readonly sharedNotificationService: SharedNotificationService,
  ) {
    this.cfg = this.configService.getAppConfig().sharePointApp;
  }

  private get siteName(): string {
    const match = this.cfg.sharePointUrl.match(/\/sites\/([^/]+)/);
    return match ? match[1] : "CLPricingStaging";
  }

  private async getNextRevisionNumber(
    opportunityId: number,
    stakeholderCode: string,
    scenarioName: string,
    submissionType: SubmissionType,
    versionNumber?: string,
    inputType?: string
  ): Promise<number> {
    const where: any = {
      opportunityId,
      stakeholderCode,
      scenarioName,
      submissionType,
      workflowStatus: {
        [Op.ne]: RoundWorkflowStatus.Created
      }
    };

    if (versionNumber !== undefined) {
      where.versionNumber = versionNumber;
    }
    if (inputType !== undefined) {
      where.input_type = inputType;
    }

    const inputs = await this.inputRepository.search({
      where,
      order: [["revision_number", "DESC"]]
    });

    const maxRevision =
      inputs.length > 0
        ? Math.max(
          ...inputs.map((i) => Number(i.revisionNumber || 0))
        )
        : 0;

    return maxRevision + 1;
  }

  async createRound(
    createDto: CreateRoundDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRound> {
    // Get existing rounds for this opportunity to calculate next round number
    const existingRounds = await this.roundRepository.search({
      where: { opportunityId: createDto.opportunityId }
    });

    // Calculate next round number
    let nextRoundNumber = 1;
    if (existingRounds && existingRounds.length > 0) {
      const maxRoundNumber = Math.max(
        ...existingRounds.map((r) => r.roundNumber || 1)
      );
      nextRoundNumber = maxRoundNumber + 1;
    }

    var round = new OpportunityRound();
    round.opportunityId = createDto.opportunityId;
    round.roundNumber = nextRoundNumber;
    round.description = createDto.description;
    round.customerSubmissionDate = createDto.customerSubmissionDate
      ? new Date(createDto.customerSubmissionDate)
      : null;
    round.templateDueDate = createDto.inputDueDate
      ? new Date(createDto.inputDueDate)
      : null;
    round.scenarioList = createDto.scenarioList;
    round.userStatus = RoundUserStatus.Created;
    round.workflowStatus = RoundUserStatus.Created;
    round.active = true;
    round.deleted = false;

    round = await this.roundRepository.save(round, currentContext);

    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND;
    history.entityId = round.id;
    history.actionPerformed = HistoryActionPerformed.CREATED;
    history.actionComments =
      HistoryActionComments.OPPORTUNITY_ROUND_CREATED;
    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    await history.save();

    const stakeholders = [];
    for (const stakeholderDto of createDto.stakeholders) {
      var stakeholder = new OpportunityRoundStakeholder();
      stakeholder.opportunityId = createDto.opportunityId;
      stakeholder.roundId = round.id;
      stakeholder.roundNumber = nextRoundNumber;
      stakeholder.stakeholder = stakeholderDto.stakeholder;
      stakeholder.applicableScenarios = stakeholderDto.applicableScenarios
        ? stakeholderDto.applicableScenarios.map((s) => ({
          name: s.name,
          desc: s.desc
        }))
        : [];
      stakeholder.dueDate = stakeholderDto.dueDate
        ? new Date(stakeholderDto.dueDate)
        : null;
      stakeholder.stakeholder_code = stakeholderDto.stakeholder_code;
      stakeholder.stakeholderType = stakeholderDto.stakeholderType;
      stakeholder.description = stakeholderDto.description;
      stakeholder.collectDraftInput = stakeholderDto.collectDraftInput;
      if (stakeholder.collectDraftInput) {
        stakeholder.draftDueDate = stakeholderDto.draftDueDate
          ? new Date(stakeholderDto.draftDueDate)
          : null;
      } else {
        stakeholder.draftDueDate = null;
      }
      stakeholder.active = true;
      stakeholder.deleted = false;

      stakeholder.additionalStakeholders =
        stakeholderDto.additionalStakeholders || [];

      stakeholder.notify_users = stakeholderDto.notify_users;

      if (
        !stakeholder.additionalStakeholders?.length ||
        !stakeholder.notify_users?.length
      ) {
        const prevScenario = stakeholderDto.applicableScenarios?.find(
          (s) => s.isCopiedPreviousRound && s.referenceData
        );
        if (prevScenario?.referenceData) {
          const prevStakeholder = await this.stakeholderRepository.findOne({
            where: {
              opportunityId: createDto.opportunityId,
              roundId: prevScenario.referenceData,
              stakeholder_code: stakeholderDto.stakeholder_code
            }
          });
          if (prevStakeholder) {
            if (!stakeholder.additionalStakeholders?.length) {
              stakeholder.additionalStakeholders =
                prevStakeholder.additionalStakeholders || [];
            }
            if (!stakeholder.notify_users?.length) {
              stakeholder.notify_users = prevStakeholder.notify_users;
            }
          }
        }
      }

      stakeholder = await this.stakeholderRepository.save(
        stakeholder,
        currentContext
      );
      stakeholders.push(stakeholder);

      const scenarios =
        stakeholderDto.applicableScenarios?.length > 0
          ? stakeholderDto.applicableScenarios
          : [];

      for (const scenario of scenarios) {
        const isStandardRate = scenario.isStandardRate;
        const isCopiedPreviousRound = scenario.isCopiedPreviousRound;
        const dataRoundId = scenario.referenceData;
        const input_type = scenario.input_type;

        if (isCopiedPreviousRound && dataRoundId) {
          const where: any = {
            opportunityId: createDto.opportunityId,
            roundId: dataRoundId,
            stakeholderCode: stakeholderDto.stakeholder_code,
            scenarioName: scenario.name,
            workflowStatus: {
              [Op.in]: [
                RoundWorkflowStatus.Approved,
                RoundWorkflowStatus.DraftApproved
              ]
            },
            submissionType: SubmissionType.Final,
            //versionNumber: stakeholderDto.versionNumber
            ...(stakeholderDto.stakeholderType === StakeholderType.Standard && {
              versionNumber: stakeholderDto.versionNumber
            })
          };

          const previousRoundInput = await this.inputRepository.findOne({
            where,
            order: [
              ["revision_number", "DESC"],
              ["approved_on", "DESC"]
            ]
          });

          if (previousRoundInput != null) {
            const newInput = new OpportunityRoundInput();
            newInput.opportunityId = previousRoundInput.opportunityId;
            newInput.roundId = round.id;
            newInput.roundNumber = nextRoundNumber;
            newInput.stakeholder = previousRoundInput.stakeholder;
            //newInput.revisionNumber =Number(previousRoundInput.revisionNumber || 0) + 1;
            // newInput.revisionNumber = await this.getNextRevisionNumber(
            //   createDto.opportunityId,
            //   stakeholderDto.stakeholder_code,
            //   scenario.name,
            //   SubmissionType.Final,
            //   stakeholderDto.versionNumber,
            //   input_type
            // );
            if (
              stakeholderDto.stakeholderType === StakeholderType.Adhoc &&
              input_type === "usePreviousRoundInput"
            ) {
              newInput.revisionNumber =
                Number(previousRoundInput.revisionNumber || 0) + 1;
            } else {
              newInput.revisionNumber = await this.getNextRevisionNumber(
                createDto.opportunityId,
                stakeholderDto.stakeholder_code,
                scenario.name,
                SubmissionType.Final,
                stakeholderDto.versionNumber,
                input_type
              );
            }
            newInput.isCurrentVersion = "1";
            newInput.isCurrentApproved = "1";
            newInput.scenarioName = previousRoundInput.scenarioName;
            newInput.fileRelPath = previousRoundInput.fileRelPath;
            newInput.processedData = previousRoundInput.processedData;
            newInput.userStatus = previousRoundInput.userStatus;
            newInput.workflowStatus = previousRoundInput.workflowStatus;
            newInput.isStandardRate = isStandardRate ? "1" : "0";
            newInput.isCopiedPreviousRound = "1";
            newInput.dataRoundId = dataRoundId;
            newInput.input_type = input_type;
            newInput.stakeholderCode = stakeholderDto.stakeholder_code;
            newInput.submittedOn = previousRoundInput.submittedOn;
            newInput.submittedBy = previousRoundInput.submittedBy;
            newInput.approvedOn = previousRoundInput.approvedOn;
            newInput.approvedBy = previousRoundInput.approvedBy;
            newInput.versionNumber = previousRoundInput.versionNumber;
            newInput.submissionType = SubmissionType.Final;
            newInput.inputRequired = true;
            newInput.active = true;
            newInput.deleted = false;

            await this.inputRepository.save(newInput, currentContext);
          }
        } else if (isStandardRate && scenario.referenceData) {
          // Use standard input
          const standardInput = await this.standardInputRepository.findById(
            scenario.referenceData
          );

          const input = new OpportunityRoundInput();
          input.opportunityId = createDto.opportunityId;
          input.roundId = round.id;
          input.roundNumber = nextRoundNumber;
          input.stakeholder = stakeholderDto.stakeholder;
          //input.revisionNumber = 1;
          input.revisionNumber = await this.getNextRevisionNumber(
            createDto.opportunityId,
            stakeholderDto.stakeholder_code,
            scenario.name,
            SubmissionType.Final,
            stakeholderDto.versionNumber, input_type
          );
          input.isCurrentVersion = "1";
          input.isCurrentApproved = "1";
          input.scenarioName = scenario.name;

          var opportunity = await this.opportunityRepository.findById(
            createDto.opportunityId
          );
          var file_name = decodeURIComponent(
            standardInput.fileRelPath.split("?")[0].split("/").pop()
          );
          var filePathUrl = `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${nextRoundNumber}/${stakeholderDto.stakeholder_code}/${file_name}`;

          input.fileRelPath = filePathUrl
            ? filePathUrl.replace(/([^/]+)$/, `${scenario.name} - $1`)
            : filePathUrl;

          input.processedData = standardInput.processedData;
          input.userStatus = RoundUserStatus.Approved;
          input.workflowStatus = RoundWorkflowStatus.Approved;
          input.isStandardRate = "1";
          input.isCopiedPreviousRound = "0";
          input.dataRoundId = dataRoundId;
          input.input_type = input_type;
          input.stakeholderCode = stakeholderDto.stakeholder_code;
          input.submittedOn = new Date();
          input.approvedOn = new Date();
          input.inputRequired = true;
          input.versionNumber = standardInput.versionNumber;
          input.submissionType = SubmissionType.Final;
          input.active = true;
          input.deleted = false;

          await this.inputRepository.save(input, currentContext);
        } else {
          // Create empty input for this scenario
          const input = new OpportunityRoundInput();
          input.opportunityId = createDto.opportunityId;
          input.roundId = round.id;
          input.roundNumber = nextRoundNumber;
          input.stakeholder = stakeholderDto.stakeholder;
          //input.revisionNumber = 1;
          input.revisionNumber = await this.getNextRevisionNumber(
            createDto.opportunityId,
            stakeholderDto.stakeholder_code,
            scenario.name,
            SubmissionType.Final,
            stakeholderDto.versionNumber, input_type
          );
          input.isCurrentVersion = "1";
          input.isCurrentApproved = "0";
          input.scenarioName = scenario.name;
          input.userStatus = RoundUserStatus.Created;
          input.workflowStatus = RoundWorkflowStatus.Created;
          input.isStandardRate = isStandardRate ? "1" : "0";
          input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
          input.dataRoundId = dataRoundId;
          input.input_type = input_type;
          input.stakeholderCode = stakeholderDto.stakeholder_code;
          input.versionNumber = stakeholderDto.versionNumber;
          input.submissionType = SubmissionType.Final;
          input.inputRequired = true;
          input.active = true;
          input.deleted = false;

          await this.inputRepository.save(input, currentContext);

          if (stakeholderDto.collectDraftInput) {
            const input = new OpportunityRoundInput();
            input.opportunityId = createDto.opportunityId;
            input.roundId = round.id;
            input.roundNumber = nextRoundNumber;
            input.stakeholder = stakeholderDto.stakeholder;
            //input.revisionNumber = 1;
            input.revisionNumber = await this.getNextRevisionNumber(
              createDto.opportunityId,
              stakeholderDto.stakeholder_code,
              scenario.name,
              SubmissionType.Draft,
              stakeholderDto.versionNumber, input_type
            );
            input.isCurrentVersion = "1";
            input.isCurrentApproved = "0";
            input.scenarioName = scenario.name;
            input.userStatus = RoundUserStatus.Created;
            input.workflowStatus = RoundWorkflowStatus.Created;
            input.isStandardRate = isStandardRate ? "1" : "0";
            input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
            input.dataRoundId = dataRoundId;
            input.input_type = input_type;
            input.stakeholderCode = stakeholderDto.stakeholder_code;
            input.versionNumber = stakeholderDto.versionNumber;
            input.submissionType = SubmissionType.Draft;
            // input.revisionNumber = await this.getNextRevisionNumber(
            //   createDto.opportunityId,
            //   stakeholderDto.stakeholder_code,
            //   scenario.name,
            //   SubmissionType.Draft,
            //   stakeholderDto.versionNumber,input_type
            // );
            input.inputRequired = true;
            input.active = true;
            input.deleted = false;

            await this.inputRepository.save(input, currentContext);
          }
        }
      }
    }

    const roundWithStakeholders = await this.roundRepository.findOne({
      where: { id: round.id },
      include: [
        {
          model: OpportunityRoundStakeholder,
          as: "stakeholders"
        },
        {
          model: OpportunityRoundInput,
          as: "inputs",
          required: false,
          separate: true
        }
      ]
    });

    return roundWithStakeholders;
  }

  async updateRound(
    id: number,
    updateDto: UpdateRoundDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRound> {
    const round = await this.roundRepository.findById(id);

    if (!round) {
      throw new NotFoundException(
        `Round with ID ${id} not found`
      );
    }

    const updates: Partial<OpportunityRound> = {};

    if (updateDto.description !== undefined) {
      updates.description = updateDto.description;
    }

    if (updateDto.customerSubmissionDate !== undefined) {
      updates.customerSubmissionDate = new Date(
        updateDto.customerSubmissionDate
      );
    }

    if (updateDto.inputDueDate !== undefined) {
      updates.templateDueDate = new Date(
        updateDto.inputDueDate
      );
    }

    if (updateDto.scenarioList !== undefined) {
      updates.scenarioList = updateDto.scenarioList;
    }

    const changedFields: Record<string, any> = {};

    for (const [field, newValue] of Object.entries(updates)) {
      const oldValue = (round as any)[field];

      if (
        JSON.stringify(oldValue) !==
        JSON.stringify(newValue)
      ) {
        changedFields[field] = {
          old_value: oldValue,
          new_value: newValue
        };
      }
    }

    await this.roundRepository.update(
      updates,
      currentContext,
      { where: { id } }
    );

    if (Object.keys(changedFields).length > 0) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY_ROUND;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.UPDATED;
      history.actionComments =
        HistoryActionComments.OPPORTUNITY_ROUND_UPDATED;
      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      history.additionalInfo = changedFields;

      await history.save();
    }

    return this.roundRepository.findOne({
      where: { id },
      include: [
        {
          model: OpportunityRoundStakeholder,
          as: "stakeholders"
        },
        {
          model: OpportunityRoundInput,
          as: "inputs",
          required: false,
          separate: true
        }
      ]
    });
  }
  async closeRound(
    id: number,
    currentContext: CurrentContext
  ): Promise<OpportunityRound> {
    console.log("========== CLOSE ROUND CALLED ==========");
    console.log("Round ID:", id);
    const round = await this.roundRepository.findById(id);

    if (!round) {
      throw new NotFoundException(
        `Round with ID ${id} not found`
      );
    }

    // Get all non-cancelled inputs for this round
    // const inputs = await this.inputRepository.search({
    //   where: {
    //     roundId: id,
    //     workflowStatus: {
    //       [Op.ne]: RoundWorkflowStatus.Cancelled
    //     }
    //   }
    // });
    const remainingInputs = await this.inputRepository.search({
      where: {
        roundId: id,
        workflowStatus: {
          [Op.ne]: RoundWorkflowStatus.Cancelled
        }
      }
    });

    console.log("Inputs found for round:", remainingInputs);
    const submittedInputs = remainingInputs.filter(
      (input) =>
        input.workflowStatus === RoundWorkflowStatus.Submitted
    );

    if (submittedInputs.length > 0) {
      throw new ConflictException(
        "Round cannot be closed because at least one input is still submitted."
      );
    }

    await this.roundRepository.update(
      {
        userStatus: RoundUserStatus.Completed,
        workflowStatus: RoundWorkflowStatus.Completed
      },
      currentContext,
      { where: { id } }
    );

    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND;
    history.entityId = id;
    history.actionPerformed = HistoryActionPerformed.CLOSED;
    history.actionComments =
      HistoryActionComments.OPPORTUNITY_ROUND_CLOSED;
    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    await history.save();

    return this.roundRepository.findOne({
      where: { id },
      include: [
        {
          model: OpportunityRoundStakeholder,
          as: "stakeholders"
        },
        {
          model: OpportunityRoundInput,
          as: "inputs",
          required: false,
          separate: true
        }
      ]
    });
  }

  async completeStakeholderInput(
    inputDto: CompleteStakeholderInputDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput> {
    const stakeholderData = await this.stakeholderRepository.findOne({
      where: {
        opportunityId: inputDto.opportunityId,
        roundId: inputDto.roundId,
        roundNumber: inputDto.roundNumber,
        stakeholder_code: inputDto.stakeholderCode
      }
    });

    const existingInputs = await this.inputRepository.findAll({
      where: {
        opportunityId: inputDto.opportunityId,
        roundId: inputDto.roundId,
        stakeholderCode: inputDto.stakeholderCode,
        scenarioName: inputDto.scenarioName,
        ...(stakeholderData?.stakeholderType === StakeholderType.Standard && {
          versionNumber: inputDto.versionNumber
        }),
        submissionType: inputDto.submissionType
      },
      order: [["id", "DESC"]]
    });

    const currentVersion = existingInputs?.find(
      (i) => i.isCurrentVersion === "1"
    );

    if (!existingInputs || !currentVersion) {
      throw new NotFoundException(
        `No pending stakeholder input found to approve for the given criteria`
      );
    }

    const oldUserStatus = currentVersion.userStatus;
    const oldWorkflowStatus = currentVersion.workflowStatus;

    const otherInputIds = existingInputs
      .filter((i: OpportunityRoundInput) => i.id !== currentVersion.id)
      .map((i: OpportunityRoundInput) => i.id);

    if (otherInputIds.length > 0) {
      await this.inputRepository.update(
        { isCurrentApproved: "0" },
        currentContext,
        { where: { id: otherInputIds } }
      );
    }

    const approved_by = {
      name: currentContext.user.name,
      email: currentContext.user.email,
      login_id: currentContext.user.upn
    };

    await this.inputRepository.update(
      {
        userStatus:
          inputDto.submissionType === SubmissionType.Draft
            ? RoundUserStatus.DraftApproved
            : RoundUserStatus.Approved,
        workflowStatus:
          inputDto.submissionType === SubmissionType.Draft
            ? RoundWorkflowStatus.DraftApproved
            : RoundWorkflowStatus.Approved,
        isCurrentApproved: "1",
        input_type: InputType.CollectInput,
        approvedOn: new Date(),
        approvedBy: approved_by,
        isRevisionRequested: false
        // ...(inputDto.versionNumber !== undefined && {
        //   versionNumber: inputDto.versionNumber
        // })
      },
      currentContext,
      { where: { id: currentVersion.id } }
    );
    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
    history.entityId = currentVersion.id;
    history.actionPerformed = HistoryActionPerformed.APPROVED;
    history.actionComments =
      HistoryActionComments.STAKEHOLDER_INPUT_APPROVED;

    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    history.additionalInfo = {
      userStatus: {
        old_value: oldUserStatus,
        new_value:
          inputDto.submissionType === SubmissionType.Draft
            ? RoundUserStatus.DraftApproved
            : RoundUserStatus.Approved
      },
      workflowStatus: {
        old_value: oldWorkflowStatus,
        new_value:
          inputDto.submissionType === SubmissionType.Draft
            ? RoundWorkflowStatus.DraftApproved
            : RoundWorkflowStatus.Approved
      }
    };

    await history.save();

    return this.inputRepository.findById(currentVersion.id);
  }

  async rejectStakeholderInput(
    inputDto: RejectStakeholderInputDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput> {
    const stakeholderData = await this.stakeholderRepository.findOne({
      where: {
        opportunityId: inputDto.opportunityId,
        roundId: inputDto.roundId,
        roundNumber: inputDto.roundNumber,
        stakeholder_code: inputDto.stakeholderCode
      }
    });

    const existingInput = await this.inputRepository.findOne({
      where: {
        opportunityId: inputDto.opportunityId,
        roundId: inputDto.roundId,
        roundNumber: inputDto.roundNumber,
        stakeholderCode: inputDto.stakeholderCode,
        scenarioName: inputDto.scenarioName,
        isCurrentVersion: "1",
        isCurrentApproved: "0",
        ...(stakeholderData?.stakeholderType === StakeholderType.Standard && {
          versionNumber: inputDto.versionNumber
        }),
        submissionType: inputDto.submissionType
      }
    });

    if (!existingInput) {
      throw new NotFoundException(
        `No pending stakeholder input found to reject for the given criteria`
      );
    }

    const oldUserStatus = existingInput.userStatus;
    const oldWorkflowStatus = existingInput.workflowStatus;

    await this.inputRepository.update(
      {
        userStatus: RoundUserStatus.Rejected,
        workflowStatus: RoundWorkflowStatus.Rejected,
        isCurrentApproved: "0"
      },
      currentContext,
      { where: { id: existingInput.id } }
    );
    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
    history.entityId = existingInput.id;
    history.actionPerformed = HistoryActionPerformed.REJECTED;
    history.actionComments =
      HistoryActionComments.STAKEHOLDER_INPUT_REJECTED;
    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    history.additionalInfo = {
      userStatus: {
        old_value: oldUserStatus,
        new_value: RoundUserStatus.Rejected
      },
      workflowStatus: {
        old_value: oldWorkflowStatus,
        new_value: RoundWorkflowStatus.Rejected
      }
    };

    await history.save();

    return this.inputRepository.findById(existingInput.id);
  }

  async retractStakeholderInput(
    retractDto: RetractStakeholderInputDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput> {
    const stakeholderData = await this.stakeholderRepository.findOne({
      where: {
        opportunityId: retractDto.opportunityId,
        roundId: retractDto.roundId,
        roundNumber: retractDto.roundNumber,
        stakeholder_code: retractDto.stakeholderCode
      }
    });

    const currentVersion = await this.inputRepository.findOne({
      where: {
        opportunityId: retractDto.opportunityId,
        roundId: retractDto.roundId,
        stakeholderCode: retractDto.stakeholderCode,
        roundNumber: retractDto.roundNumber,
        scenarioName: retractDto.scenarioName,
        isCurrentVersion: "1",
        workflowStatus: { [Op.eq]: RoundWorkflowStatus.Submitted },
        ...(stakeholderData?.stakeholderType === StakeholderType.Standard && {
          versionNumber: retractDto.versionNumber
        }),
        submissionType: retractDto.submissionType
      }
    });

    if (!currentVersion) {
      throw new NotFoundException(
        `No retractable stakeholder input found for the given criteria`
      );
    }

    const oldUserStatus = currentVersion.userStatus;
    const oldWorkflowStatus = currentVersion.workflowStatus;
    const oldIsCurrentApproved = currentVersion.isCurrentApproved;

    await this.inputRepository.update(
      {
        isCurrentApproved: "0",
        workflowStatus: RoundWorkflowStatus.Retracted,
        userStatus: RoundUserStatus.Retracted
      },
      currentContext,
      { where: { id: currentVersion.id } }
    );

    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
    history.entityId = currentVersion.id;
    history.actionPerformed = HistoryActionPerformed.RETRACTED;
    history.actionComments =
      HistoryActionComments.STAKEHOLDER_INPUT_RETRACTED;

    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    history.additionalInfo = {
      userStatus: {
        old_value: oldUserStatus,
        new_value: RoundUserStatus.Retracted
      },
      workflowStatus: {
        old_value: oldWorkflowStatus,
        new_value: RoundWorkflowStatus.Retracted
      },
      isCurrentApproved: {
        old_value: oldIsCurrentApproved,
        new_value: "0"
      }
    };

    await history.save();


    return this.inputRepository.findOne({
      where: { id: currentVersion.id }
    });
  }

  async submitStakeholderInput(
    submitDto: SubmitStakeholderInputDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput> {
    const stakeholderData = await this.stakeholderRepository.findOne({
      where: {
        opportunityId: submitDto.opportunityId,
        roundId: submitDto.roundId,
        roundNumber: submitDto.roundNumber,
        stakeholder_code: submitDto.stakeholderCode
      }
    });

    const existingInputs = await this.inputRepository.search({
      where: {
        opportunityId: submitDto.opportunityId,
        roundId: submitDto.roundId,
        roundNumber: submitDto.roundNumber,
        stakeholderCode: submitDto.stakeholderCode,
        scenarioName: submitDto.scenarioName,
        workflowStatus: { [Op.ne]: RoundWorkflowStatus.Cancelled },
        ...(stakeholderData?.stakeholderType === StakeholderType.Standard && {
          versionNumber: submitDto.versionNumber
        }),
        submissionType: submitDto.submissionType
      },
      order: [["id", "DESC"]]
    });

    const currentVersion = existingInputs?.find(
      (i) => i.isCurrentVersion === "1"
    );

    const maxRevision =
      existingInputs?.length > 0
        ? Math.max(...existingInputs.map((i) => i.revisionNumber || 1))
        : 1;

    let revisionNumber = maxRevision;

    var submitted_by = {
      name: currentContext.user.name,
      email: currentContext.user.email,
      login_id: currentContext.user.upn
    };

    if (currentVersion) {
      switch (currentVersion.workflowStatus) {
        case RoundWorkflowStatus.Created:

          const oldUserStatus = currentVersion.userStatus;
          const oldWorkflowStatus = currentVersion.workflowStatus;

          // Update existing record
          await this.inputRepository.update(
            {
              fileRelPath: submitDto.fileRelPath,
              processedData: submitDto.processedData,
              submittedOn: new Date(),
              submittedBy: submitted_by,
              userStatus: RoundUserStatus.Submitted,
              workflowStatus: RoundWorkflowStatus.Submitted,
              input_type: InputType.CollectInput,
              inputRequired: true
            },
            currentContext,
            { where: { id: currentVersion.id } }
          );
          const history = new History();

          history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
          history.entityId = currentVersion.id;
          history.actionPerformed = HistoryActionPerformed.SUBMITTED;
          history.actionComments =
            HistoryActionComments.STAKEHOLDER_INPUT_SUBMITTED;

          history.actionDate = new Date();

          history.createdBy =
            currentContext.user.upn?.toLowerCase() ||
            currentContext.user.username;

          history.createdOn = new Date();

          await history.save();
          return this.inputRepository.findById(currentVersion.id);

        case RoundWorkflowStatus.Approved:
        case RoundWorkflowStatus.DraftApproved:
          // Increment revision for approved case
          revisionNumber = maxRevision + 1;

          // Reset any existing approved records
          const approvedIds = existingInputs
            .filter((i) => i.isCurrentApproved === "1")
            .map((i) => i.id);

          if (approvedIds.length > 0) {
            await this.inputRepository.update(
              { isCurrentApproved: "0" },
              currentContext,
              { where: { id: { [Op.in]: approvedIds } } }
            );
          }

          // Mark old approved record as current approved
          await this.inputRepository.update(
            { isCurrentVersion: "0", isCurrentApproved: "1" },
            currentContext,
            { where: { id: currentVersion.id } }
          );
          break;

        case RoundWorkflowStatus.Retracted:
          await this.inputRepository.update(
            {
              workflowStatus: RoundWorkflowStatus.Cancelled,
              userStatus: RoundUserStatus.Cancelled,
              isCurrentVersion: "0",
              deleted: true,
              active: false
            },
            currentContext,
            { where: { id: currentVersion.id } }
          );
          break;

        default:
          // Cancel existing version (no revision increment)
          await this.inputRepository.update(
            {
              isCurrentVersion: "0",
              isCurrentApproved: "0",
              workflowStatus: RoundWorkflowStatus.Cancelled,
              userStatus: RoundUserStatus.Cancelled
            },
            currentContext,
            { where: { id: currentVersion.id } }
          );
          break;
      }
    }

    let stakeholder_title = existingInputs.find(
      (x) => (x.workflowStatus === RoundWorkflowStatus.Approved)
    )?.stakeholder;

    if (!stakeholder_title) {
      var stakeholder = await this.stakeholderRepository.findOne({
        where: {
          stakeholder_code: submitDto.stakeholderCode
        }
      });
      stakeholder_title = stakeholder.stakeholder;
    }

    var submitted_by = {
      name: currentContext.user.name,
      email: currentContext.user.email,
      login_id: currentContext.user.upn
    };

    if (
      !currentVersion ||
      currentVersion.workflowStatus !== RoundWorkflowStatus.Created
    ) {
      const newInput = new OpportunityRoundInput();
      newInput.opportunityId = submitDto.opportunityId;
      newInput.roundId = submitDto.roundId;
      newInput.roundNumber = submitDto.roundNumber;
      newInput.revisionNumber = revisionNumber;
      newInput.stakeholder = stakeholder_title;
      newInput.stakeholderCode = submitDto.stakeholderCode;
      newInput.scenarioName = submitDto.scenarioName;
      newInput.fileRelPath = submitDto.fileRelPath;
      newInput.processedData = submitDto.processedData;
      newInput.input_type = InputType.CollectInput;
      newInput.isCurrentVersion = "1";
      newInput.isCurrentApproved = "0";
      newInput.submittedOn = new Date();
      newInput.submittedBy = submitted_by;
      newInput.isStandardRate = "0";
      newInput.isCopiedPreviousRound = "0";
      newInput.dataRoundId = 0;
      newInput.userStatus = RoundUserStatus.Submitted;
      newInput.workflowStatus = RoundWorkflowStatus.Submitted;
      newInput.inputRequired = true;
      newInput.versionNumber = submitDto.versionNumber;
      newInput.submissionType = submitDto.submissionType;
      newInput.active = true;
      newInput.deleted = false;
      //return await this.inputRepository.save(newInput, currentContext);
      const createdInput = await this.inputRepository.save(
        newInput,
        currentContext
      );

      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
      history.entityId = createdInput.id;
      history.actionPerformed = HistoryActionPerformed.SUBMITTED;
      history.actionComments =
        HistoryActionComments.STAKEHOLDER_INPUT_SUBMITTED;

      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      await history.save();

      return createdInput;
    }
    return null;
  }

  // async getOutputLogsByRound(roundId: number): Promise<OutputLog[]> {
  //   return this.outputLogRepository.search({
  //     where: { roundId }
  //   });
  // }

  async getOutputLogsByRound(roundId: number): Promise<OutputLog[]> {
    return this.outputLogRepository.search({
      where: {
        roundId,
        active: true,
        deleted: false,
      },
    });
  }

  async generateOutputLog(
    logDto: GenerateOutputLogDto,
    currentContext: CurrentContext
  ): Promise<OutputLog> {
    var fileName = logDto.fileRelPath
      ? path.posix.basename(logDto.fileRelPath)
      : undefined;
    // const isDuplicate = await this.outputLogRepository.isRecordExist({
    //   where: {
    //     opportunityId: logDto.opportunityId,
    //     roundId: logDto.roundId,
    //     file_name: fileName
    //   }
    // });

    // if (isDuplicate) {
    //   throw new ConflictException(
    //     `Output file name "${fileName}" already exists for this Opportunity and Round`
    //   );
    // }

    await this.outputLogRepository.update(
      {
        active: false,
        deleted: true,
      },
      currentContext,
      {
        where: {
          opportunityId: logDto.opportunityId,
          roundId: logDto.roundId,
          active: true,
          deleted: false,
        },
      },
    );

    var log = new OutputLog();
    log.opportunityId = logDto.opportunityId;
    log.roundId = logDto.roundId;
    log.fileName = fileName;
    log.fileRelPath = logDto.fileRelPath;
    log.processedData = logDto.processedData;
    log.extratedOn = new Date();
    log.extratedBy = currentContext.user.upn;
    log.active = true;
    log.deleted = false;

    log = await this.outputLogRepository.save(log, currentContext);

    return log;
  }

  async getRoundById(id: number): Promise<OpportunityRound> {
    const round = await this.roundRepository.findOne({
      where: { id },
      include: [
        {
          model: OpportunityRoundStakeholder,
          as: "stakeholders"
        },
        {
          model: OpportunityRoundInput,
          as: "inputs",
          required: false,
          separate: true,
          where: {
            workflowStatus: { [Op.ne]: RoundWorkflowStatus.Cancelled }
          }
        },
        {
          model: Opportunity,
          as: "opportunity",
          attributes: ["title", "lead_pricer"]
        }
      ]
    });

    if (!round) {
      throw new NotFoundException(`Round with ID ${id} not found`);
    }

    return round;
  }

  async getRoundsByOpportunityId(
    opportunityId: number
  ): Promise<OpportunityRound[]> {
    return this.roundRepository.search({
      where: { opportunityId },
      include: [
        {
          model: OpportunityRoundStakeholder,
          as: "stakeholders"
        },
        {
          model: OpportunityRoundInput,
          as: "inputs",
          required: false,
          separate: true,
          where: {
            workflowStatus: { [Op.ne]: RoundWorkflowStatus.Cancelled }
          }
        },
        {
          model: Opportunity,
          as: "opportunity",
          attributes: ["lead_pricer"]
        }
      ]
    });
  }

  async getStakeholderInputsByRound(
    roundId: number,
    workflowStatuses?: string[]
  ): Promise<any[]> {
    const workflowStatusFilter =
      workflowStatuses && workflowStatuses.length > 0
        ? { [Op.in]: workflowStatuses }
        : { [Op.ne]: RoundWorkflowStatus.Cancelled };

    const [inputs, stakeholders, round] = await Promise.all([
      this.inputRepository.search({
        where: {
          roundId,
          // isCurrentVersion: "1",
          workflowStatus: workflowStatusFilter
        },
        order: [["id", "DESC"]]
      }),
      this.stakeholderRepository.search({ where: { roundId } }),
      this.roundRepository.findById(roundId)
    ]);

    const stakeholderMap = new Map(
      stakeholders.map((s) => [s.stakeholder_code, s])
    );

    const scenarioDescMap = new Map<string, string>();
    if (round?.scenarioList) {
      for (const s of round.scenarioList) {
        scenarioDescMap.set(s.name, s.desc);
      }
    }

    return inputs.map((input) => {
      const match = stakeholderMap.get(input.stakeholderCode);
      return {
        ...input.toJSON(),
        stakeholderType: match?.stakeholderType ?? null,
        description: match?.description ?? null,
        additionalStakeholders: match?.additionalStakeholders ?? null,
        notifyUsers: match?.notify_users ?? null,
        scenarioDescription: scenarioDescMap.get(input.scenarioName) ?? null
      };
    });
  }

  async getRoundInputsByScenario(
    roundId: number,
    stakeholder: string,
    scenarios?: string[]
  ): Promise<any> {
    const where: any = {
      roundId: roundId,
      stakeholderCode: stakeholder,
      workflowStatus: {
        [Op.in]: [
          RoundWorkflowStatus.Approved,
          RoundWorkflowStatus.DraftApproved
        ]
      }
    };

    if (scenarios && scenarios.length > 0) {
      where.scenarioName = {
        [Op.in]: scenarios
      };
    }

    const [rawInputs, round] = await Promise.all([
      this.inputRepository.search({
        where,
        order: [
          ["scenario_name", "ASC"],
          ["approved_on", "DESC"]
        ]
      }),
      this.roundRepository.findOne({ where: { id: roundId } })
    ]);

    const scenarioGroups = new Map<string, any[]>();
    for (const input of rawInputs ?? []) {
      const key = input.scenarioName;
      if (!scenarioGroups.has(key)) {
        scenarioGroups.set(key, []);
      }
      scenarioGroups.get(key).push(input);
    }

    const inputs = [...scenarioGroups.values()].map(
      (group) =>
        group.find(
          (input) => input.workflowStatus === RoundWorkflowStatus.Approved
        ) ?? group[0]
    );

    if (!inputs || inputs.length === 0) {
      return { datasets: [] };
    }

    const scenarioDescMap = new Map<string, string>();
    if (round?.scenarioList) {
      for (const s of round.scenarioList) {
        scenarioDescMap.set(s.name, s.desc);
      }
    }

    const scenarioMap = new Map<string, any[]>();

    for (const input of inputs) {
      const scenarioName = input.scenarioName || "Unknown";

      if (!scenarioMap.has(scenarioName)) {
        scenarioMap.set(scenarioName, []);
      }

      scenarioMap.get(scenarioName).push(input);
    }

    const datasets = [];

    for (const [scenarioName, scenarioInputs] of scenarioMap.entries()) {
      const scenarioData = scenarioInputs.find(
        (input) => input.scenarioName === scenarioName
      );

      const processedData = scenarioData.processedData || {};

      const dateOfData =
        scenarioData.submissionType === SubmissionType.Draft
          ? "Draft"
          : processedData.date_of_data ||
          (scenarioData.approvedOn
            ? scenarioData.approvedOn.toLocaleString("en-GB", {
              timeZone: "Europe/Paris"
            })
            : null);

      var file_name = scenarioData.fileRelPath
        ? scenarioData.fileRelPath.split("/")?.pop()
        : null;

      datasets.push({
        scenario: scenarioName,
        scenario_description: scenarioDescMap.get(scenarioName)
          ? `${scenarioDescMap.get(scenarioName)}. File Name: ${file_name}`
          : null,
        date_of_data: dateOfData,
        revision_number: scenarioData.revisionNumber,

        data: processedData
      });
    }

    return { datasets };
  }

  async getRoundScenarios(roundId: number): Promise<any[]> {
    const round = await this.roundRepository.findOne({
      where: { id: roundId }
    });

    if (!round) {
      throw new NotFoundException(`Round with ID ${roundId} not found`);
    }

    return round.scenarioList || [];
  }

  async createStakeholder(
    createDto: CreateStakeholderDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundStakeholder> {
    // Verify that the round exists
    const round = await this.roundRepository.findById(createDto.roundId);
    if (!round) {
      throw new NotFoundException(
        `Round with ID ${createDto.roundId} not found`
      );
    }

    // Verify that the round belongs to the specified opportunity
    if (Number(round.opportunityId) !== Number(createDto.opportunityId)) {
      throw new NotFoundException(
        `Round ${createDto.roundId} does not belong to opportunity ${createDto.opportunityId}`
      );
    }

    // Create the stakeholder
    var stakeholder = new OpportunityRoundStakeholder();
    stakeholder.opportunityId = createDto.opportunityId;
    stakeholder.roundId = createDto.roundId;
    stakeholder.roundNumber = round.roundNumber;
    stakeholder.stakeholder = createDto.stakeholder;
    stakeholder.additionalStakeholders = createDto.additionalStakeholders || [];
    stakeholder.applicableScenarios = createDto.applicableScenarios;
    stakeholder.notify_users = createDto.notify_users;
    stakeholder.dueDate = createDto.dueDate
      ? new Date(createDto.dueDate)
      : null;
    stakeholder.stakeholder_code = createDto.stakeholder_code;
    stakeholder.collectDraftInput = createDto.collectDraftInput;
    if (stakeholder.collectDraftInput) {
      stakeholder.draftDueDate = createDto.draftDueDate
        ? new Date(createDto.draftDueDate)
        : null;
    } else {
      stakeholder.draftDueDate = null;
    }
    stakeholder.stakeholderType = createDto.stakeholderType;
    stakeholder.description = createDto.description;
    stakeholder.active = true;
    stakeholder.deleted = false;

    stakeholder = await this.stakeholderRepository.save(
      stakeholder,
      currentContext
    );

    const history = new History();

    history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_STAKEHOLDER;
    history.entityId = stakeholder.id;
    history.actionPerformed = HistoryActionPerformed.CREATED;
    history.actionComments =
      HistoryActionComments.ROUND_STAKEHOLDER_CREATED;

    history.actionDate = new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    await history.save();

    const scenarios =
      createDto.applicableScenarios?.length > 0
        ? createDto.applicableScenarios
        : [];

    for (const scenario of scenarios) {
      const isStandardRate = scenario.isStandardRate;
      const isCopiedPreviousRound = scenario.isCopiedPreviousRound;
      const dataRoundId = scenario.referenceData;
      const input_type = scenario.input_type;

      if (isCopiedPreviousRound && dataRoundId) {
        const where: any = {
          opportunityId: createDto.opportunityId,
          roundId: dataRoundId,
          stakeholderCode: createDto.stakeholder_code,
          scenarioName: scenario.name,
          workflowStatus: {
            [Op.in]: [
              RoundWorkflowStatus.Approved,
              RoundWorkflowStatus.DraftApproved
            ]
          },
          submissionType: SubmissionType.Final,
          versionNumber: createDto.versionNumber, input_type: input_type
        };

        const previousRoundInput = await this.inputRepository.findOne({
          where,
          order: [
            ["revision_number", "DESC"],
            ["approved_on", "DESC"]
          ]
        });

        if (previousRoundInput != null) {
          const newInput = new OpportunityRoundInput();
          newInput.opportunityId = previousRoundInput.opportunityId;
          newInput.roundId = round.id;
          newInput.roundNumber = round.roundNumber;
          newInput.stakeholder = previousRoundInput.stakeholder;
          //newInput.revisionNumber = previousRoundInput.revisionNumber;
          newInput.revisionNumber = await this.getNextRevisionNumber(
            createDto.opportunityId,
            createDto.stakeholder_code,
            scenario.name,
            SubmissionType.Final,
            createDto.versionNumber,
            input_type
          );
          newInput.isCurrentVersion = "1";
          newInput.isCurrentApproved = "1";
          newInput.scenarioName = previousRoundInput.scenarioName;
          newInput.fileRelPath = previousRoundInput.fileRelPath;
          newInput.processedData = previousRoundInput.processedData;
          newInput.userStatus = previousRoundInput.userStatus;
          newInput.workflowStatus = previousRoundInput.workflowStatus;
          newInput.isStandardRate = isStandardRate ? "1" : "0";
          newInput.isCopiedPreviousRound = "1";
          newInput.dataRoundId = dataRoundId;
          newInput.input_type = input_type;
          newInput.stakeholderCode = createDto.stakeholder_code;
          newInput.submittedOn = previousRoundInput.submittedOn;
          newInput.submittedBy = previousRoundInput.submittedBy;
          newInput.approvedOn = previousRoundInput.approvedOn;
          newInput.approvedBy = previousRoundInput.approvedBy;
          newInput.versionNumber = previousRoundInput.versionNumber;
          newInput.submissionType = SubmissionType.Final;
          newInput.inputRequired = true;
          newInput.active = true;
          newInput.deleted = false;

          await this.inputRepository.save(newInput, currentContext);
        }
      } else if (isStandardRate && dataRoundId) {
        const standardInput =
          await this.standardInputRepository.findById(dataRoundId);

        const input = new OpportunityRoundInput();
        input.opportunityId = createDto.opportunityId;
        input.roundId = createDto.roundId;
        input.roundNumber = round.roundNumber;
        input.stakeholder = createDto.stakeholder;
        //input.revisionNumber = 1;
        input.revisionNumber = await this.getNextRevisionNumber(
          createDto.opportunityId,
          createDto.stakeholder_code,
          scenario.name,
          SubmissionType.Final,
          createDto.versionNumber, input_type
        );
        input.isCurrentVersion = "1";
        input.isCurrentApproved = "1";
        input.scenarioName = scenario.name;

        var opportunity = await this.opportunityRepository.findById(
          createDto.opportunityId
        );
        var file_name = decodeURIComponent(
          standardInput.fileRelPath.split("?")[0].split("/").pop()
        );
        var filePathUrl = `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${round.roundNumber}/${createDto.stakeholder_code}/${file_name}`;

        input.fileRelPath = filePathUrl
          ? filePathUrl.replace(/([^/]+)$/, `${scenario.name} - $1`)
          : filePathUrl;

        input.processedData = standardInput.processedData;
        input.userStatus = RoundUserStatus.Approved;
        input.workflowStatus = RoundWorkflowStatus.Approved;
        input.isStandardRate = "1";
        input.isCopiedPreviousRound = "0";
        input.dataRoundId = dataRoundId;
        input.input_type = input_type;
        input.stakeholderCode = createDto.stakeholder_code;
        input.inputRequired = true;
        input.submittedOn = new Date();
        input.approvedOn = new Date();
        input.active = true;
        input.deleted = false;
        input.versionNumber = standardInput.versionNumber;
        input.submissionType = SubmissionType.Final;

        await this.inputRepository.save(input, currentContext);
      } else {
        const input = new OpportunityRoundInput();
        input.opportunityId = createDto.opportunityId;
        input.roundId = createDto.roundId;
        input.roundNumber = round.roundNumber;
        input.stakeholder = createDto.stakeholder;
        //input.revisionNumber = 1;
        input.revisionNumber = await this.getNextRevisionNumber(
          createDto.opportunityId,
          createDto.stakeholder_code,
          scenario.name,
          SubmissionType.Final,
          createDto.versionNumber, input_type
        );
        input.isCurrentVersion = "1";
        input.isCurrentApproved = "0";
        input.scenarioName = scenario.name;
        input.userStatus = RoundUserStatus.Created;
        input.workflowStatus = RoundWorkflowStatus.Created;
        input.isStandardRate = isStandardRate ? "1" : "0";
        input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
        input.dataRoundId = dataRoundId;
        input.input_type = input_type;
        input.stakeholderCode = createDto.stakeholder_code;
        input.versionNumber = createDto.versionNumber;
        input.submissionType = SubmissionType.Final;
        input.inputRequired = true;
        input.active = true;
        input.deleted = false;
        await this.inputRepository.save(input, currentContext);

        if (createDto.collectDraftInput) {
          const input = new OpportunityRoundInput();
          input.opportunityId = createDto.opportunityId;
          input.roundId = createDto.roundId;
          input.roundNumber = round.roundNumber;
          input.stakeholder = createDto.stakeholder;
          //input.revisionNumber = 1;
          input.revisionNumber = await this.getNextRevisionNumber(
            createDto.opportunityId,
            createDto.stakeholder_code,
            scenario.name,
            SubmissionType.Draft,
            createDto.versionNumber, input_type
          );
          input.isCurrentVersion = "1";
          input.isCurrentApproved = "0";
          input.scenarioName = scenario.name;
          input.userStatus = RoundUserStatus.Created;
          input.workflowStatus = RoundWorkflowStatus.Created;
          input.isStandardRate = isStandardRate ? "1" : "0";
          input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
          input.dataRoundId = dataRoundId;
          input.input_type = input_type;
          input.stakeholderCode = createDto.stakeholder_code;
          input.versionNumber = createDto.versionNumber;
          input.submissionType = SubmissionType.Draft;
          input.inputRequired = true;
          input.active = true;
          input.deleted = false;
          await this.inputRepository.save(input, currentContext);
        }
      }
    }

    return stakeholder;
  }

  async createStakeholders(
    createDtos: CreateStakeholderDto[],
    currentContext: CurrentContext
  ): Promise<OpportunityRoundStakeholder[]> {
    const results: OpportunityRoundStakeholder[] = [];
    for (const dto of createDtos) {
      const stakeholder = await this.createStakeholder(dto, currentContext);
      results.push(stakeholder);
    }
    return results;
  }

  async updateRoundInputRequired(
    id: number,
    inputRequired: boolean,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput> {
    const input = await this.inputRepository.findById(id);
    if (!input) {
      throw new NotFoundException(`Round input with ID ${id} not found`);
    }

    await this.inputRepository.update(
      { inputRequired: inputRequired },
      currentContext,
      {
        where: { id }
      }
    );
    const oldInputRequired = input.inputRequired;
    if (oldInputRequired !== inputRequired) {
      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
      history.entityId = id;
      history.actionPerformed = HistoryActionPerformed.UPDATED;
      history.actionComments =
        HistoryActionComments.ROUND_INPUT_REQUIRED_STATUS_UPDATED;

      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      history.additionalInfo = {
        inputRequired: {
          old_value: oldInputRequired,
          new_value: inputRequired
        }
      };

      await history.save();
    }

    return this.inputRepository.findById(id);
  }

  async getStandardInput(id: number) {
    return this.standardInputRepository.findById(id);
  }

  async upsertStakeholder(
    upsertDto: UpsertStakeholderDto,
    currentContext: CurrentContext
  ): Promise<{ stakeholder: OpportunityRoundStakeholder; isNew: boolean }> {
    const round = await this.roundRepository.findById(upsertDto.roundId);
    if (!round) {
      throw new NotFoundException(
        `Round with ID ${upsertDto.roundId} not found`
      );
    }

    if (Number(round.opportunityId) !== Number(upsertDto.opportunityId)) {
      throw new NotFoundException(
        `Round ${upsertDto.roundId} does not belong to opportunity ${upsertDto.opportunityId}`
      );
    }

    const existingStakeholder = await this.stakeholderRepository.findOne({
      where: {
        roundId: upsertDto.roundId,
        opportunityId: upsertDto.opportunityId,
        stakeholder_code: upsertDto.stakeholder_code
      },
      order: [["id", "DESC"]]
    });

    let stakeholder: OpportunityRoundStakeholder;
    let isNew = false;

    if (!existingStakeholder) {
      throw new NotFoundException(
        `Stackholder does not belong to opportunity ${upsertDto.opportunityId} and round ${upsertDto.roundId}`
      );
    }
    stakeholder = existingStakeholder;

    //old Stakeholder Snapshot

    const oldStakeholder = {
      additionalStakeholders: existingStakeholder.additionalStakeholders,
      applicableScenarios: existingStakeholder.applicableScenarios,
      dueDate: existingStakeholder.dueDate,
      notify_users: existingStakeholder.notify_users,
      collectDraftInput: existingStakeholder.collectDraftInput,
      draftDueDate: existingStakeholder.draftDueDate,
      stakeholderType: existingStakeholder.stakeholderType,
      description: existingStakeholder.description
    };

    const isDraftApplicableChangedToYes =
      existingStakeholder.collectDraftInput !== true &&
      upsertDto.collectDraftInput === true;

    if (isDraftApplicableChangedToYes) {
      const existingInputs = await this.inputRepository.findAll({
        where: {
          opportunityId: upsertDto.opportunityId,
          roundId: upsertDto.roundId,
          stakeholderCode: upsertDto.stakeholder_code,
          submissionType: SubmissionType.Final,
          deleted: false
        }
      });

      const applicableScenarioNames = new Set(
        (upsertDto.applicableScenarios ?? []).map(
          (scenario: any) => scenario.name
        )
      );

      const applicableExistingInputs = existingInputs.filter(
        (input: any) =>
          applicableScenarioNames.has(input.scenarioName)
      );

      for (const existingInput of applicableExistingInputs) {
        const draftExists = await this.inputRepository.findOne({
          where: {
            opportunityId: upsertDto.opportunityId,
            roundId: upsertDto.roundId,
            stakeholderCode: upsertDto.stakeholder_code,
            scenarioName: existingInput.scenarioName,
            submissionType: SubmissionType.Draft,
            deleted: false
          }
        });

        if (draftExists) {
          continue;
        }

        const draftInput = new OpportunityRoundInput();

        draftInput.opportunityId = existingInput.opportunityId;
        draftInput.roundId = existingInput.roundId;
        draftInput.roundNumber = existingInput.roundNumber;
        draftInput.stakeholder = existingInput.stakeholder;
        //draftInput.revisionNumber = 1;
        draftInput.revisionNumber = await this.getNextRevisionNumber(
          existingInput.opportunityId,
          existingInput.stakeholderCode,
          existingInput.scenarioName,
          SubmissionType.Draft,
          existingInput.versionNumber, existingInput.input_type
        );
        draftInput.isCurrentVersion = "1";
        draftInput.isCurrentApproved = "0";
        draftInput.scenarioName = existingInput.scenarioName;
        draftInput.userStatus = RoundUserStatus.Created;
        draftInput.workflowStatus = RoundWorkflowStatus.Created;
        draftInput.isStandardRate = existingInput.isStandardRate;
        draftInput.isCopiedPreviousRound = existingInput.isCopiedPreviousRound;
        draftInput.dataRoundId = existingInput.dataRoundId;
        draftInput.input_type = existingInput.input_type;
        draftInput.stakeholderCode = existingInput.stakeholderCode;
        draftInput.inputRequired = true;
        draftInput.active = true;
        draftInput.deleted = false;
        draftInput.versionNumber = existingInput.versionNumber;
        draftInput.submissionType = SubmissionType.Draft;

        await this.inputRepository.save(draftInput, currentContext);
      }
    }

    if (
      upsertDto.applicableScenarios &&
      upsertDto.applicableScenarios.length > 0
    ) {
      var newScenarios = upsertDto.applicableScenarios.filter(
        (x: any) =>
          !existingStakeholder.applicableScenarios?.some(
            (s: any) => s.name === x.name
          )
      );

      stakeholder.applicableScenarios = upsertDto.applicableScenarios.map(
        (s) => ({ name: s.name, desc: s.desc })
      );

      for (const scenario of newScenarios) {
        const isStandardRate = scenario.isStandardRate;
        const isCopiedPreviousRound = scenario.isCopiedPreviousRound;
        const dataRoundId = scenario.referenceData;
        const input_type = scenario.input_type;

        if (isCopiedPreviousRound && dataRoundId) {
          const where: any = {
            opportunityId: upsertDto.opportunityId,
            roundId: dataRoundId,
            stakeholderCode: upsertDto.stakeholder_code,
            scenarioName: scenario.name,
            workflowStatus: {
              [Op.in]: [
                RoundWorkflowStatus.Approved,
                RoundWorkflowStatus.DraftApproved
              ]
            },
            submissionType: SubmissionType.Final,
            versionNumber: upsertDto.versionNumber, input_type: input_type
          };

          const previousRoundInput = await this.inputRepository.findOne({
            where,
            order: [
              ["revision_number", "DESC"],
              ["approved_on", "DESC"]
            ]
          });

          if (previousRoundInput != null) {
            const newInput = new OpportunityRoundInput();
            newInput.opportunityId = previousRoundInput.opportunityId;
            newInput.roundId = upsertDto.roundId;
            newInput.roundNumber = round.roundNumber;
            newInput.stakeholder = previousRoundInput.stakeholder;
            //newInput.revisionNumber = previousRoundInput.revisionNumber;
            newInput.revisionNumber = await this.getNextRevisionNumber(
              upsertDto.opportunityId,
              upsertDto.stakeholder_code,
              scenario.name,
              SubmissionType.Final,
              upsertDto.versionNumber,
              input_type
            );
            newInput.isCurrentVersion = "1";
            newInput.isCurrentApproved = "1";
            newInput.scenarioName = previousRoundInput.scenarioName;
            newInput.fileRelPath = previousRoundInput.fileRelPath;
            newInput.processedData = previousRoundInput.processedData;
            newInput.userStatus = previousRoundInput.userStatus;
            newInput.workflowStatus = previousRoundInput.workflowStatus;
            newInput.isStandardRate = isStandardRate ? "1" : "0";
            newInput.isCopiedPreviousRound = "1";
            newInput.dataRoundId = dataRoundId;
            newInput.input_type = input_type;
            newInput.stakeholderCode = upsertDto.stakeholder_code;
            newInput.inputRequired = true;
            newInput.submittedOn = previousRoundInput.submittedOn;
            newInput.submittedBy = previousRoundInput.submittedBy;
            newInput.approvedOn = previousRoundInput.approvedOn;
            newInput.approvedBy = previousRoundInput.approvedBy;
            newInput.versionNumber = previousRoundInput.versionNumber;
            newInput.submissionType = SubmissionType.Final;
            newInput.active = true;
            newInput.deleted = false;

            await this.inputRepository.save(newInput, currentContext);
          }
        } else if (isStandardRate && dataRoundId) {
          const standardInput =
            await this.standardInputRepository.findById(dataRoundId);

          const input = new OpportunityRoundInput();
          input.opportunityId = upsertDto.opportunityId;
          input.roundId = upsertDto.roundId;
          input.roundNumber = round.roundNumber;
          input.stakeholder = upsertDto.stakeholder;
          //input.revisionNumber = 1;
          input.revisionNumber = await this.getNextRevisionNumber(
            upsertDto.opportunityId,
            upsertDto.stakeholder_code,
            scenario.name,
            SubmissionType.Final,
            standardInput.versionNumber, input_type
          );
          input.isCurrentVersion = "1";
          input.isCurrentApproved = "1";
          input.scenarioName = scenario.name;

          var opportunity = await this.opportunityRepository.findById(
            upsertDto.opportunityId
          );
          var file_name = decodeURIComponent(
            standardInput.fileRelPath.split("?")[0].split("/").pop()
          );
          var filePathUrl = `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${round.roundNumber}/${upsertDto.stakeholder_code}/${file_name}`;

          input.fileRelPath = filePathUrl
            ? filePathUrl.replace(/([^/]+)$/, `${scenario.name} - $1`)
            : filePathUrl;

          input.processedData = standardInput.processedData;
          input.userStatus = RoundUserStatus.Approved;
          input.workflowStatus = RoundWorkflowStatus.Approved;
          input.isStandardRate = "1";
          input.isCopiedPreviousRound = "0";
          input.dataRoundId = dataRoundId;
          input.input_type = input_type;
          input.stakeholderCode = upsertDto.stakeholder_code;
          input.inputRequired = true;
          input.submittedOn = new Date();
          input.approvedOn = new Date();
          input.active = true;
          input.deleted = false;
          input.versionNumber = standardInput.versionNumber;
          input.submissionType = SubmissionType.Final;

          await this.inputRepository.save(input, currentContext);
        } else {
          const input = new OpportunityRoundInput();
          input.opportunityId = upsertDto.opportunityId;
          input.roundId = upsertDto.roundId;
          input.roundNumber = round.roundNumber;
          input.stakeholder = upsertDto.stakeholder;
          //input.revisionNumber = 1;
          input.revisionNumber = await this.getNextRevisionNumber(
            upsertDto.opportunityId,
            upsertDto.stakeholder_code,
            scenario.name,
            SubmissionType.Final,
            upsertDto.versionNumber, input_type
          );
          input.isCurrentVersion = "1";
          input.isCurrentApproved = "0";
          input.scenarioName = scenario.name;
          input.userStatus = RoundUserStatus.Created;
          input.workflowStatus = RoundWorkflowStatus.Created;
          input.isStandardRate = isStandardRate ? "1" : "0";
          input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
          input.dataRoundId = dataRoundId;
          input.input_type = input_type;
          input.stakeholderCode = upsertDto.stakeholder_code;
          input.inputRequired = true;
          input.active = true;
          input.deleted = false;
          input.versionNumber = upsertDto.versionNumber;
          input.submissionType = SubmissionType.Final;
          await this.inputRepository.save(input, currentContext);

          if (upsertDto.collectDraftInput) {
            const input = new OpportunityRoundInput();
            input.opportunityId = upsertDto.opportunityId;
            input.roundId = upsertDto.roundId;
            input.roundNumber = round.roundNumber;
            input.stakeholder = upsertDto.stakeholder;
            //input.revisionNumber = 1;
            input.revisionNumber = await this.getNextRevisionNumber(
              upsertDto.opportunityId,
              upsertDto.stakeholder_code,
              scenario.name,
              SubmissionType.Draft,
              upsertDto.versionNumber, input_type
            );
            input.isCurrentVersion = "1";
            input.isCurrentApproved = "0";
            input.scenarioName = scenario.name;
            input.userStatus = RoundUserStatus.Created;
            input.workflowStatus = RoundWorkflowStatus.Created;
            input.isStandardRate = isStandardRate ? "1" : "0";
            input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
            input.dataRoundId = dataRoundId;
            input.input_type = input_type;
            input.stakeholderCode = upsertDto.stakeholder_code;
            input.inputRequired = true;
            input.active = true;
            input.deleted = false;
            input.versionNumber = upsertDto.versionNumber;
            input.submissionType = SubmissionType.Draft;
            await this.inputRepository.save(input, currentContext);
          }
        }
      }
    }
    if (upsertDto.dueDate) {
      stakeholder.dueDate = new Date(upsertDto.dueDate);
    }

    if (upsertDto.collectDraftInput !== undefined) {
      stakeholder.collectDraftInput = upsertDto.collectDraftInput;
    }

    if (upsertDto.collectDraftInput) {
      stakeholder.draftDueDate = new Date(upsertDto.draftDueDate);
    } else {
      stakeholder.draftDueDate = null;
    }

    stakeholder.notify_users = upsertDto.notify_users;
    stakeholder.additionalStakeholders = upsertDto.additionalStakeholders;

    if (upsertDto.stakeholderType !== undefined) {
      stakeholder.stakeholderType = upsertDto.stakeholderType;
    }

    if (upsertDto.description !== undefined) {
      stakeholder.description = upsertDto.description;
    }

    await this.stakeholderRepository.update(
      {
        additionalStakeholders: stakeholder.additionalStakeholders,
        applicableScenarios: stakeholder.applicableScenarios,
        dueDate: stakeholder.dueDate ? new Date(stakeholder.dueDate) : null,
        notify_users: stakeholder.notify_users,
        collectDraftInput: stakeholder.collectDraftInput,
        draftDueDate: stakeholder.draftDueDate,
        stakeholderType: stakeholder.stakeholderType,
        description: stakeholder.description
      },
      currentContext,
      { where: { id: stakeholder.id } }
    );

    stakeholder = await this.stakeholderRepository.findById(stakeholder.id);

    //Old and New Values comparission and Logging to History

    const changedFields: Record<string, any> = {};

    for (const field of Object.keys(oldStakeholder)) {
      const oldValue = (oldStakeholder as any)[field];
      const newValue = (stakeholder as any)[field];

      if (
        JSON.stringify(oldValue) !==
        JSON.stringify(newValue)
      ) {
        changedFields[field] = {
          old_value: oldValue,
          new_value: newValue
        };
      }
    }

    if (Object.keys(changedFields).length > 0) {
      const history = new History();

      history.entityType =
        HistoryEntityType.OPPORTUNITY_ROUND_STAKEHOLDER;

      history.entityId = stakeholder.id;

      history.actionPerformed = HistoryActionPerformed.UPDATED;

      history.actionComments =
        HistoryActionComments.ROUND_STAKEHOLDER_UPDATED;

      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();

      history.additionalInfo = changedFields;

      await history.save();
    }

    return { stakeholder, isNew };
  }


  /**
   * Changes the version of a stakeholder within an opportunity round.
   *
   * Main responsibilities:
   * 1. Validate the round and opportunity.
   * 2. Find the stakeholder.
   * 3. Update stakeholder-level details.
   * 4. Cancel the existing/current inputs.
   * 5. Create new versioned scenario inputs.
   * 6. Create an audit/history record.
   * 7. Return the updated stakeholder.
   */
  async changeStakeholderVersion(
    changeDto: ChangeStakeholderVersionDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundStakeholder> {

    // ---------------------------------------------------------
    // 1. Find the round using the roundId from the request
    // ---------------------------------------------------------
    const round = await this.roundRepository.findById(changeDto.roundId);

    // If the round does not exist, stop the operation
    if (!round) {
      throw new NotFoundException(
        `Round with ID ${changeDto.roundId} not found`
      );
    }

    // ---------------------------------------------------------
    // 2. Validate that the round belongs to the given opportunity
    // ---------------------------------------------------------
    if (Number(round.opportunityId) !== Number(changeDto.opportunityId)) {
      throw new NotFoundException(
        `Round ${changeDto.roundId} does not belong to opportunity ${changeDto.opportunityId}`
      );
    }

    // ---------------------------------------------------------
    // 3. Find the stakeholder for this round + opportunity
    //
    // order DESC ensures that if multiple records exist for the
    // same stakeholder, the latest record is selected.
    // ---------------------------------------------------------
    const stakeholder = await this.stakeholderRepository.findOne({
      where: {
        roundId: changeDto.roundId,
        opportunityId: changeDto.opportunityId,
        stakeholder_code: changeDto.stakeholder_code
      },
      order: [["id", "DESC"]]
    });

    // If stakeholder is not found, stop the operation
    if (!stakeholder) {
      throw new NotFoundException(
        `Stackholder does not belong to opportunity ${changeDto.opportunityId} and round ${changeDto.roundId}`
      );
    }

    // ---------------------------------------------------------
    // 4. Determine which scenarios should be used
    //
    // If applicableScenarios are provided in the request,
    // use those.
    //
    // Otherwise, use the scenarios already stored against
    // the stakeholder.
    // ---------------------------------------------------------
    const scenarios =
      changeDto.applicableScenarios &&
        changeDto.applicableScenarios.length > 0
        ? changeDto.applicableScenarios
        : (stakeholder.applicableScenarios ?? []);

    // A stakeholder must have at least one applicable scenario
    if (scenarios.length === 0) {
      throw new NotFoundException(
        `Stakeholder ${changeDto.stakeholder_code} has no applicable scenarios`
      );
    }

    // ---------------------------------------------------------
    // 5. Update applicable scenarios if they were explicitly
    //    provided in the request
    // ---------------------------------------------------------
    if (
      changeDto.applicableScenarios &&
      changeDto.applicableScenarios.length > 0
    ) {
      stakeholder.applicableScenarios = changeDto.applicableScenarios.map(
        (s) => ({
          name: s.name,
          desc: s.desc
        })
      );
    }

    // ---------------------------------------------------------
    // 6. Update stakeholder due date
    //
    // Only update it when a dueDate was supplied.
    // ---------------------------------------------------------
    if (changeDto.dueDate) {
      stakeholder.dueDate = new Date(changeDto.dueDate);
    }

    // ---------------------------------------------------------
    // 7. Update whether draft input should be collected
    //
    // !== undefined is used so that false is also treated
    // as a valid value.
    // ---------------------------------------------------------
    if (changeDto.collectDraftInput !== undefined) {
      stakeholder.collectDraftInput = changeDto.collectDraftInput;
    }

    // ---------------------------------------------------------
    // 8. Handle Draft Due Date
    //
    // If draft input is enabled:
    //   - Use the new draftDueDate if supplied.
    //   - Otherwise keep the existing draftDueDate.
    //
    // If draft input is disabled:
    //   - Clear the draftDueDate.
    // ---------------------------------------------------------
    if (stakeholder.collectDraftInput) {
      stakeholder.draftDueDate = changeDto.draftDueDate
        ? new Date(changeDto.draftDueDate)
        : stakeholder.draftDueDate;
    } else {
      stakeholder.draftDueDate = null;
    }

    // ---------------------------------------------------------
    // 9. Update notification users
    // ---------------------------------------------------------
    if (changeDto.notify_users !== undefined) {
      stakeholder.notify_users = changeDto.notify_users;
    }

    // ---------------------------------------------------------
    // 10. Update additional stakeholders/team members
    // ---------------------------------------------------------
    if (changeDto.additionalStakeholders !== undefined) {
      stakeholder.additionalStakeholders =
        changeDto.additionalStakeholders;
    }

    // ---------------------------------------------------------
    // 11. Update stakeholder type
    // ---------------------------------------------------------
    if (changeDto.stakeholderType !== undefined) {
      stakeholder.stakeholderType = changeDto.stakeholderType;
    }

    // ---------------------------------------------------------
    // 12. Update stakeholder description
    // ---------------------------------------------------------
    if (changeDto.description !== undefined) {
      stakeholder.description = changeDto.description;
    }

    // ---------------------------------------------------------
    // 13. Save the updated stakeholder details
    //
    // Only the required fields are passed to repository.update().
    // ---------------------------------------------------------
    await this.stakeholderRepository.update(
      {
        applicableScenarios: stakeholder.applicableScenarios,

        dueDate: stakeholder.dueDate
          ? new Date(stakeholder.dueDate)
          : null,

        collectDraftInput: stakeholder.collectDraftInput,

        draftDueDate: stakeholder.draftDueDate,

        notify_users: stakeholder.notify_users,

        additionalStakeholders:
          stakeholder.additionalStakeholders,

        stakeholderType: stakeholder.stakeholderType,

        description: stakeholder.description
      },
      currentContext,
      {
        where: {
          id: stakeholder.id
        }
      }
    );

    // ---------------------------------------------------------
    // 14. Find all existing inputs for this stakeholder
    //    in the current round.
    //
    // Cancelled inputs are excluded because they are already
    // cancelled and do not need to be processed again.
    // ---------------------------------------------------------
    const currentInputs = await this.inputRepository.search({
      where: {
        opportunityId: changeDto.opportunityId,
        roundId: changeDto.roundId,
        stakeholderCode: changeDto.stakeholder_code,

        workflowStatus: {
          [Op.ne]: RoundWorkflowStatus.Cancelled
        }
      }
    });

    // Extract the IDs of the existing inputs
    const currentInputIds = currentInputs?.map((i) => i.id) ?? [];

    // ---------------------------------------------------------
    // 15. Cancel the existing inputs
    //
    // Before creating the new version, the previous/current
    // inputs are marked as cancelled.
    //
    // isCurrentVersion = 0
    //     -> No longer the current version
    //
    // isCurrentApproved = 0
    //     -> No longer considered currently approved
    //
    // workflowStatus = Cancelled
    //     -> Input is no longer active in the workflow
    //
    // userStatus = Cancelled
    //     -> User-facing status is also cancelled
    // ---------------------------------------------------------
    if (currentInputIds.length > 0) {
      await this.inputRepository.update(
        {
          isCurrentVersion: "0",
          isCurrentApproved: "0",
          workflowStatus: RoundWorkflowStatus.Cancelled,
          userStatus: RoundUserStatus.Cancelled
        },
        currentContext,
        {
          where: {
            id: {
              [Op.in]: currentInputIds
            }
          }
        }
      );
    }

    // ---------------------------------------------------------
    // 16. Create the new versioned scenario inputs
    //
    // A new input is created for every applicable scenario.
    //
    // versionNumber comes from the request.
    // collectDraftInput comes from the updated stakeholder.
    // ---------------------------------------------------------
    for (const scenario of scenarios) {
      await this.createVersionedScenarioInput(
        scenario,
        {
          opportunityId: changeDto.opportunityId,
          roundId: changeDto.roundId,

          // Pass the complete round object
          round,

          // Stakeholder display/name
          stakeholder: stakeholder.stakeholder,

          // Stakeholder unique code
          stakeholderCode: changeDto.stakeholder_code,

          // New version number requested by the user
          versionNumber: changeDto.versionNumber,

          // Whether draft input collection is enabled
          collectDraftInput: stakeholder.collectDraftInput
        },
        currentContext
      );
    }

    // ---------------------------------------------------------
    // 17. Create history/audit record
    //
    // This records that the stakeholder version was changed.
    // ---------------------------------------------------------
    const history = new History();

    // Identify the type of entity for which the history is created
    history.entityType =
      HistoryEntityType.OPPORTUNITY_ROUND_INPUT;

    // Link the history record to the stakeholder
    history.entityId = stakeholder.id;

    // Mark the action as an update
    history.actionPerformed = HistoryActionPerformed.UPDATED;

    // Store the specific action performed
    history.actionComments =
      HistoryActionComments.STAKEHOLDER_VERSION_CHANGED;

    // Timestamp of the action
    history.actionDate = new Date();

    // Store the user who performed the change
    //
    // Prefer UPN when available; otherwise use username.
    // Convert UPN to lowercase for consistency.
    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    // Timestamp when the history record was created
    history.createdOn = new Date();

    // Store additional information about the version change
    history.additionalInfo = {
      versionNumber: changeDto.versionNumber
    };

    // Save the history record
    await history.save();

    // ---------------------------------------------------------
    // 18. Return the latest stakeholder record
    //
    // Fetching again ensures the returned object contains the
    // latest persisted values from the database.
    // ---------------------------------------------------------
    return this.stakeholderRepository.findById(stakeholder.id);
  }
  private async createVersionedScenarioInput(
    scenario: {
      name: string;
      isStandardRate?: boolean;
      isCopiedPreviousRound?: boolean;
      referenceData?: number;
      input_type?: string;
    },
    ctx: {
      opportunityId: number;
      roundId: number;
      round: OpportunityRound;
      stakeholder: string;
      stakeholderCode: string;
      versionNumber: string;
      collectDraftInput?: boolean;

      // Used only when changing an existing stakeholder version.
      // When true, a non-approved input keeps its existing revision number.
      preserveRevisionNumber?: boolean;

      // Existing revision number to preserve.
      revisionNumber?: number;
    },
    currentContext: CurrentContext
  ): Promise<void> {
    const isStandardRate = scenario.isStandardRate;
    const isCopiedPreviousRound = scenario.isCopiedPreviousRound;
    const dataRoundId = scenario.referenceData;
    const input_type = scenario.input_type;

    if (isCopiedPreviousRound && dataRoundId) {
      const previousRoundInput = await this.inputRepository.findOne({
        where: {
          opportunityId: ctx.opportunityId,
          roundId: dataRoundId,
          stakeholderCode: ctx.stakeholderCode,
          scenarioName: scenario.name,
          input_type: input_type,
          workflowStatus: {
            [Op.in]: [
              RoundWorkflowStatus.Approved,
              RoundWorkflowStatus.DraftApproved
            ]
          },
          submissionType: SubmissionType.Final,
          versionNumber: ctx.versionNumber
        },
        order: [
          ["revision_number", "DESC"],
          ["approved_on", "DESC"]
        ]
      });

      if (previousRoundInput != null) {
        const newInput = new OpportunityRoundInput();
        newInput.opportunityId = previousRoundInput.opportunityId;
        newInput.roundId = ctx.roundId;
        newInput.roundNumber = ctx.round.roundNumber;
        newInput.stakeholder = previousRoundInput.stakeholder;
        //newInput.revisionNumber = previousRoundInput.revisionNumber;
        newInput.revisionNumber = await this.getNextRevisionNumber(
          ctx.opportunityId,
          ctx.stakeholderCode,
          scenario.name,
          SubmissionType.Final,
          ctx.versionNumber,
          input_type
        );
        newInput.isCurrentVersion = "1";
        newInput.isCurrentApproved = "1";
        newInput.scenarioName = previousRoundInput.scenarioName;
        newInput.fileRelPath = previousRoundInput.fileRelPath;
        newInput.processedData = previousRoundInput.processedData;
        newInput.userStatus = previousRoundInput.userStatus;
        newInput.workflowStatus = previousRoundInput.workflowStatus;
        newInput.isStandardRate = isStandardRate ? "1" : "0";
        newInput.isCopiedPreviousRound = "1";
        newInput.dataRoundId = dataRoundId;
        newInput.input_type = input_type;
        newInput.stakeholderCode = ctx.stakeholderCode;
        newInput.inputRequired = true;
        newInput.submittedOn = previousRoundInput.submittedOn;
        newInput.submittedBy = previousRoundInput.submittedBy;
        newInput.approvedOn = previousRoundInput.approvedOn;
        newInput.approvedBy = previousRoundInput.approvedBy;
        newInput.versionNumber = previousRoundInput.versionNumber;
        newInput.submissionType = SubmissionType.Final;
        newInput.active = true;
        newInput.deleted = false;

        await this.inputRepository.save(newInput, currentContext);
      }
    } else if (isStandardRate && dataRoundId) {
      const standardInput =
        await this.standardInputRepository.findById(dataRoundId);

      const input = new OpportunityRoundInput();
      input.opportunityId = ctx.opportunityId;
      input.roundId = ctx.roundId;
      input.roundNumber = ctx.round.roundNumber;
      input.stakeholder = ctx.stakeholder;
      //input.revisionNumber = 1;
      input.revisionNumber = await this.getNextRevisionNumber(
        ctx.opportunityId,
        ctx.stakeholderCode,
        scenario.name,
        SubmissionType.Final,
        ctx.versionNumber, input_type
      );
      input.isCurrentVersion = "1";
      input.isCurrentApproved = "1";
      input.scenarioName = scenario.name;

      const opportunity = await this.opportunityRepository.findById(
        ctx.opportunityId
      );
      const file_name = decodeURIComponent(
        standardInput.fileRelPath.split("?")[0].split("/").pop()
      );
      const filePathUrl = `/sites/${this.siteName}/${opportunity.region}/${opportunity.customer}/${opportunity.title}/RND ${ctx.round.roundNumber}/${ctx.stakeholderCode}/${file_name}`;

      input.fileRelPath = filePathUrl
        ? filePathUrl.replace(/([^/]+)$/, `${scenario.name} - $1`)
        : filePathUrl;

      input.processedData = standardInput.processedData;
      input.userStatus = RoundUserStatus.Approved;
      input.workflowStatus = RoundWorkflowStatus.Approved;
      input.isStandardRate = "1";
      input.isCopiedPreviousRound = "0";
      input.dataRoundId = dataRoundId;
      input.input_type = input_type;
      input.stakeholderCode = ctx.stakeholderCode;
      input.inputRequired = true;
      input.submittedOn = new Date();
      input.approvedOn = new Date();
      input.active = true;
      input.deleted = false;
      input.versionNumber = standardInput.versionNumber;
      input.submissionType = SubmissionType.Final;

      await this.inputRepository.save(input, currentContext);
    } else {
      const input = new OpportunityRoundInput();
      input.opportunityId = ctx.opportunityId;
      input.roundId = ctx.roundId;
      input.roundNumber = ctx.round.roundNumber;
      input.stakeholder = ctx.stakeholder;
      //input.revisionNumber = 1;
      // For stakeholder version changes:
      // - If the existing input was NOT approved/validated,
      //   preserve its existing revision number.
      // - If it was approved/validated, calculate the next revision.
      // For all other flows, getNextRevisionNumber() behaves as before.
      input.revisionNumber =
        ctx.preserveRevisionNumber && ctx.revisionNumber !== undefined
          ? ctx.revisionNumber
          : await this.getNextRevisionNumber(
            ctx.opportunityId,
            ctx.stakeholderCode,
            scenario.name,
            SubmissionType.Final,
            ctx.versionNumber,
            input_type
          );
      input.isCurrentVersion = "1";
      input.isCurrentApproved = "0";
      input.scenarioName = scenario.name;
      input.userStatus = RoundUserStatus.Created;
      input.workflowStatus = RoundWorkflowStatus.Created;
      input.isStandardRate = isStandardRate ? "1" : "0";
      input.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
      input.dataRoundId = dataRoundId;
      input.input_type = input_type;
      input.stakeholderCode = ctx.stakeholderCode;
      input.inputRequired = true;
      input.active = true;
      input.deleted = false;
      input.versionNumber = ctx.versionNumber;
      input.submissionType = SubmissionType.Final;
      await this.inputRepository.save(input, currentContext);

      if (ctx.collectDraftInput) {
        const draftInput = new OpportunityRoundInput();
        draftInput.opportunityId = ctx.opportunityId;
        draftInput.roundId = ctx.roundId;
        draftInput.roundNumber = ctx.round.roundNumber;
        draftInput.stakeholder = ctx.stakeholder;
        //draftInput.revisionNumber = 1;
        // Draft revision follows the same preservation rule
        // when changing an existing stakeholder version.
        draftInput.revisionNumber =
          ctx.preserveRevisionNumber && ctx.revisionNumber !== undefined
            ? ctx.revisionNumber
            : await this.getNextRevisionNumber(
              ctx.opportunityId,
              ctx.stakeholderCode,
              scenario.name,
              SubmissionType.Draft,
              ctx.versionNumber,
              input_type
            );

        draftInput.isCurrentVersion = "1";
        draftInput.isCurrentApproved = "0";
        draftInput.scenarioName = scenario.name;
        draftInput.userStatus = RoundUserStatus.Created;
        draftInput.workflowStatus = RoundWorkflowStatus.Created;
        draftInput.isStandardRate = isStandardRate ? "1" : "0";
        draftInput.isCopiedPreviousRound = isCopiedPreviousRound ? "1" : "0";
        draftInput.dataRoundId = dataRoundId;
        draftInput.input_type = input_type;
        draftInput.stakeholderCode = ctx.stakeholderCode;
        draftInput.inputRequired = true;
        draftInput.active = true;
        draftInput.deleted = false;
        draftInput.versionNumber = ctx.versionNumber;
        draftInput.submissionType = SubmissionType.Draft;
        await this.inputRepository.save(draftInput, currentContext);
      }
    }
  }

  async initiateRevision(
    dto: InitiateRevisionDto,
    currentContext: CurrentContext
  ): Promise<OpportunityRoundInput[]> {
    const where: any = {
      opportunityId: dto.opportunityId,
      roundId: dto.roundId,
      roundNumber: dto.roundNumber,
      // isCurrentVersion: "1",
      workflowStatus: {
        [Op.in]: [
          RoundWorkflowStatus.Approved,
          RoundWorkflowStatus.DraftApproved
        ]
      }
    };

    if (dto.stakeholderCode) where.stakeholderCode = dto.stakeholderCode;
    if (dto.scenarioName) where.scenarioName = dto.scenarioName;

    const inputs = await this.inputRepository.search({ where });

    if (!inputs || inputs.length === 0) {
      throw new NotFoundException(
        `No current inputs found for the given criteria`
      );
    }

    const maxRevision =
      inputs.length > 0
        ? Math.max(...inputs.map((i) => Number(i.revisionNumber || 0)))
        : 0;

    const latestInputs = inputs.filter(
      (i) => Number(i.revisionNumber || 0) === maxRevision
    );

    const now = new Date();
    for (const input of latestInputs) {
      const nextAttempt = Number(input.revisionAttempt || 0) + 1;

      const oldRevisionAttempt = input.revisionAttempt;
      const oldLastRevisionAttempt = input.lastRevisionAttempt;
      const oldIsRevisionRequested = input.isRevisionRequested;

      await this.inputRepository.update(
        {
          revisionAttempt: nextAttempt,
          lastRevisionAttempt: now,
          isRevisionRequested: true
        },
        currentContext,
        { where: { id: input.id } }
      );

      const history = new History();

      history.entityType = HistoryEntityType.OPPORTUNITY_ROUND_INPUT;
      history.entityId = input.id;
      history.actionPerformed =
        HistoryActionPerformed.REVISION_REQUESTED;
      history.actionComments =
        HistoryActionComments.STAKEHOLDER_INPUT_REVISION_REQUESTED;

      history.actionDate = new Date();

      history.createdBy =
        currentContext.user.upn?.toLowerCase() ||
        currentContext.user.username;

      history.createdOn = new Date();
      history.additionalInfo = {
        revisionAttempt: {
          old_value: oldRevisionAttempt,
          new_value: nextAttempt
        },
        lastRevisionAttempt: {
          old_value: oldLastRevisionAttempt,
          new_value: now
        },
        isRevisionRequested: {
          old_value: oldIsRevisionRequested,
          new_value: true
        }
      }

      await history.save();
    }

    return this.inputRepository.search({ where });
  }

  // async getStakeholderAllInputs(
  //   userLogin: string,
  //   page = 1,
  //   limit = 10,
  //   myRecord?: boolean,
  //   searchText?: string,
  //   workflowStatuses?: string[],
  //   isMyPending?: boolean
  // ): Promise<{ data: any[]; total: number; page: number; limit: number }> {
  //   const loginLower = userLogin.toLowerCase();

  //   const visitorAccess =
  //     await this.sharepointPermissionService.getVisitorAccess(loginLower);
  //   const isVisitor =
  //     visitorAccess.isGlobalVisitor || visitorAccess.countries.length > 0;

  //   let codeRows: any[] = [];
  //   let directMatchRows: any[] = [];
  //   let authorizedCodes = new Set<string>();

  //   if (!isVisitor) {
  //     [codeRows, directMatchRows] = await Promise.all([
  //       this.stakeholderRepository.search({
  //         where: { deleted: false, stakeholder_code: { [Op.ne]: null } },
  //         attributes: ["stakeholder_code"],
  //         group: ["stakeholder_code"]
  //       }),
  //       this.stakeholderRepository.search({
  //         where: {
  //           deleted: false,
  //           [Op.or]: [
  //             where(cast(col("additional_stakeholders"), "text"), {
  //               [Op.iLike]: `%${loginLower}%`
  //             }),
  //             where(cast(col("notify_users"), "text"), {
  //               [Op.iLike]: `%${loginLower}%`
  //             })
  //           ]
  //         }
  //       })
  //     ]);

  //     const uniqueCodes = codeRows
  //       .map((r) => r.stakeholder_code)
  //       .filter(Boolean);
  //     const codeChecks = await Promise.all(
  //       uniqueCodes.map(async (code) => ({
  //         code,
  //         authorized:
  //           await this.sharepointPermissionService.isUserAuthorizedForStakeholder(
  //             loginLower,
  //             code
  //           )
  //       }))
  //     );
  //     authorizedCodes = new Set(
  //       codeChecks.filter((r) => r.authorized).map((r) => r.code)
  //     );
  //   }

  //   let statusCondition: any;

  //   const baseConditions = [
  //     { active: true },
  //     { deleted: false },
  //     { inputRequired: true }
  //   ];

  //   let orConditions: any[];

  //   const hasRevisionRequested =
  //     workflowStatuses?.includes("revision_requested");

  //   if (isVisitor) {
  //     const filteredStatuses = workflowStatuses?.filter(
  //       (s) => s !== "revision_requested"
  //     );
  //     if (hasRevisionRequested) {
  //       const orParts: any[] = [
  //         {
  //           workflowStatus: {
  //             [Op.in]: [
  //               RoundWorkflowStatus.Approved,
  //               RoundWorkflowStatus.DraftApproved
  //             ]
  //           },
  //           revisionAttempt: { [Op.gte]: 1 },
  //           isCurrentVersion: "1"
  //         }
  //       ];
  //       if (filteredStatuses && filteredStatuses.length > 0) {
  //         orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
  //       }
  //       statusCondition = { [Op.or]: orParts };
  //     } else {
  //       const statusFilter =
  //         workflowStatuses && workflowStatuses.length > 0
  //           ? { [Op.in]: workflowStatuses }
  //           : { [Op.ne]: RoundWorkflowStatus.Cancelled };
  //       statusCondition = { workflowStatus: statusFilter };
  //     }

  //     orConditions = [];
  //   } else if (myRecord) {
  //     if (isMyPending) {
  //       const pendingBase = [
  //         RoundWorkflowStatus.Created,
  //         RoundWorkflowStatus.Rejected,
  //         RoundWorkflowStatus.Retracted
  //       ];
  //       const pendingStatuses =
  //         workflowStatuses && workflowStatuses?.length > 0
  //           ? pendingBase.filter((s) => workflowStatuses.includes(s))
  //           : pendingBase;

  //       const orParts: any[] = [];
  //       if (pendingStatuses.length > 0) {
  //         orParts.push({ workflowStatus: { [Op.in]: pendingStatuses } });
  //       }

  //       if (hasRevisionRequested) {
  //         orParts.push({
  //           workflowStatus: {
  //             [Op.in]: [
  //               RoundWorkflowStatus.Approved,
  //               RoundWorkflowStatus.DraftApproved
  //             ]
  //           },
  //           revisionAttempt: { [Op.gte]: 1 },
  //           isCurrentVersion: "1"
  //         });
  //       }
  //       statusCondition = { [Op.or]: orParts };
  //     } else {
  //       const hasRevisionRequested =
  //         workflowStatuses?.includes("revision_requested");
  //       const filteredStatuses = workflowStatuses?.filter(
  //         (s) => s !== "revision_requested"
  //       );
  //       if (hasRevisionRequested) {
  //         const orParts: any[] = [
  //           {
  //             workflowStatus: {
  //               [Op.in]: [
  //                 RoundWorkflowStatus.Approved,
  //                 RoundWorkflowStatus.DraftApproved
  //               ]
  //             },
  //             revisionAttempt: { [Op.gte]: 1 },
  //             isCurrentVersion: "1"
  //           }
  //         ];
  //         if (filteredStatuses && filteredStatuses.length > 0) {
  //           orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
  //         }
  //         statusCondition = { [Op.or]: orParts };
  //       } else {
  //         const statusFilter =
  //           workflowStatuses && workflowStatuses.length > 0
  //             ? { [Op.in]: workflowStatuses }
  //             : { [Op.ne]: RoundWorkflowStatus.Cancelled };
  //         statusCondition = { workflowStatus: statusFilter };
  //       }
  //     }

  //     orConditions = [
  //       ...new Map(
  //         directMatchRows
  //           .filter((row) => row.stakeholder_code)
  //           .map((row) => [
  //             `${row.roundId}-${row.stakeholder_code}`,
  //             { stakeholderCode: row.stakeholder_code, roundId: row.roundId }
  //           ])
  //       ).values()
  //     ];
  //   } else {
  //     const filteredStatuses = workflowStatuses?.filter(
  //       (s) => s !== "revision_requested"
  //     );
  //     if (hasRevisionRequested) {
  //       const orParts: any[] = [
  //         {
  //           workflowStatus: {
  //             [Op.in]: [
  //               RoundWorkflowStatus.Approved,
  //               RoundWorkflowStatus.DraftApproved
  //             ]
  //           },
  //           revisionAttempt: { [Op.gte]: 1 },
  //           isCurrentVersion: "1"
  //         }
  //       ];
  //       if (filteredStatuses && filteredStatuses.length > 0) {
  //         orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
  //       }
  //       statusCondition = { [Op.or]: orParts };
  //     } else {
  //       const statusFilter =
  //         workflowStatuses && workflowStatuses.length > 0
  //           ? { [Op.in]: workflowStatuses }
  //           : { [Op.ne]: RoundWorkflowStatus.Cancelled };
  //       statusCondition = { workflowStatus: statusFilter };
  //     }

  //     orConditions = [];
  //     if (authorizedCodes.size > 0) {
  //       orConditions.push({
  //         stakeholderCode: { [Op.in]: [...authorizedCodes] }
  //       });
  //     }
  //     for (const row of directMatchRows) {
  //       if (row.stakeholder_code) {
  //         orConditions.push({
  //           stakeholderCode: row.stakeholder_code,
  //           roundId: row.roundId
  //         });
  //       }
  //     }
  //   }

  //   if (!isVisitor && orConditions.length === 0) {
  //     return { data: [], total: 0, page, limit };
  //   }

  //   let inputWhere: any = isVisitor
  //     ? { [Op.and]: [...baseConditions, statusCondition] }
  //     : {
  //         [Op.and]: [
  //           { [Op.or]: orConditions },
  //           ...baseConditions,
  //           statusCondition
  //         ]
  //       };

  //   if (searchText?.trim()) {
  //     const term = `%${searchText.trim()}%`;
  //     inputWhere = {
  //       [Op.and]: [
  //         inputWhere,
  //         {
  //           [Op.or]: [
  //             { "$opportunity.title$": { [Op.iLike]: term } },
  //             { "$opportunity.customer$": { [Op.iLike]: term } },
  //             { "$opportunity.lead_number$": { [Op.iLike]: term } },
  //             { stakeholderCode: { [Op.iLike]: term } },
  //             { workflowStatus: { [Op.iLike]: term } }
  //           ]
  //         }
  //       ]
  //     };
  //   }

  //   const opportunityWhere: any = { active: true };
  //   if (isVisitor && !visitorAccess.isGlobalVisitor) {
  //     opportunityWhere.country = { [Op.in]: visitorAccess.countries };
  //   }

  //   const useMyPending = !isVisitor && isMyPending;

  //   const { rows: inputRows, count: total } =
  //     await this.inputRepository.findAndCountAll({
  //       where: inputWhere,
  //       include: [
  //         {
  //           model: Opportunity,
  //           as: "opportunity",
  //           attributes: [
  //             "id",
  //             "title",
  //             "customer",
  //             "leadNumber",
  //             "countryCode"
  //           ],
  //           where: opportunityWhere,
  //           required: true
  //         },
  //         {
  //           model: OpportunityRound,
  //           as: "round",
  //           attributes: ["id", "roundNumber", "description"]
  //         },
  //         ...(useMyPending
  //           ? [
  //             {
  //               model: OpportunityRoundStakeholder,
  //               as: "stakeholderData",
  //               on: {
  //                 round_id: {
  //                   [Op.col]: "OpportunityRoundInput.round_id"
  //                 },
  //                 stakeholder_code: {
  //                   [Op.col]: "OpportunityRoundInput.stakeholder_code"
  //                 }
  //               },
  //               required: false,
  //               attributes: [
  //                 "id",
  //                 "dueDate",
  //                 "draftDueDate",
  //                 "stakeholderType"
  //               ]
  //             }
  //           ]
  //           : [])
  //       ],
  //       order: useMyPending
  //         ? [
  //           [
  //             fn(
  //               "COALESCE",
  //               col("stakeholderData.draft_due_date"),
  //               col("stakeholderData.due_date")
  //             ),
  //             "ASC"
  //           ]
  //         ]
  //         : [["created_on", "DESC"]],
  //       limit,
  //       offset: (page - 1) * limit,
  //       distinct: true,
  //       subQuery: false
  //     });

  //   const uniquePairs = [
  //     ...new Map(
  //       (inputRows as any[])
  //         .filter((i) => i.stakeholderCode && i.roundId)
  //         .map((i) => [
  //           `${i.roundId}-${i.stakeholderCode}`,
  //           { roundId: i.roundId, stakeholder_code: i.stakeholderCode }
  //         ])
  //     ).values()
  //   ];

  //   const stakeholderLookup = new Map<string, any>();
  //   if (uniquePairs.length > 0) {
  //     const stakeholderRows = await this.stakeholderRepository.search({
  //       where: {
  //         deleted: false,
  //         [Op.or]: uniquePairs.map((p) => ({
  //           roundId: p.roundId,
  //           stakeholder_code: p.stakeholder_code
  //         }))
  //       }
  //     });
  //     for (const s of stakeholderRows) {
  //       const plain = s.get ? s.get({ plain: true }) : s;
  //       stakeholderLookup.set(
  //         `${plain.roundId}-${plain.stakeholder_code}`,
  //         plain
  //       );
  //     }
  //   }

  //   const data = (inputRows as any[]).map((input) => {
  //     const stk = stakeholderLookup.get(
  //       `${input.roundId}-${input.stakeholderCode}`
  //     );
  //     return {
  //       id: input.id,
  //       opportunityId: input.opportunityId,
  //       opportunityTitle: input.opportunity?.title ?? null,
  //       opportunityCustomer: input.opportunity?.customer ?? null,
  //       opportunityLeadNumber: input.opportunity?.leadNumber ?? null,
  //       opportunityCountryCode: input.opportunity?.countryCode ?? null,
  //       roundId: input.roundId,
  //       roundNumber: input.round?.roundNumber ?? input.roundNumber,
  //       roundDescription: input.round?.description ?? null,
  //       stakeholder: input.stakeholder,
  //       stakeholderType: stk?.stakeholderType ?? null,
  //       description: stk?.description ?? null,
  //       stakeholderCode: input.stakeholderCode,
  //       scenarioName: input.scenarioName,
  //       revisionNumber: input.revisionNumber,
  //       isCurrentVersion: input.isCurrentVersion,
  //       isCurrentApproved: input.isCurrentApproved,
  //       fileRelPath: input.fileRelPath,
  //       approvedOn: input.approvedOn,
  //       submittedOn: input.submittedOn,
  //       userStatus: input.userStatus,
  //       workflowStatus: input.workflowStatus,
  //       isStandardRate: input.isStandardRate,
  //       isCopiedPreviousRound: input.isCopiedPreviousRound,
  //       inputType: input.input_type,
  //       revisionAttempt: input.revisionAttempt,
  //       lastRevisionAttempt: input.lastRevisionAttempt,
  //       versionNumber: input.versionNumber,
  //       submissionType: input.submissionType,
  //       submittedBy: input.submittedBy,
  //       approvedBy: input.approvedBy,
  //       notify_users: stk?.notify_users ?? null,
  //       additional_stakeholders: stk?.additionalStakeholders ?? null,
  //       dueDate: stk?.dueDate ?? null,
  //       draftDueDate: stk?.draftDueDate ?? null,
  //       isRevisionRequested: input.isRevisionRequested
  //     };
  //   });

  //   return { data, total, page, limit };
  // }

  async getStakeholderAllInputs(
    userLogin: string,
    page = 1,
    limit = 10,
    myRecord?: boolean,
    searchText?: string,
    workflowStatuses?: string[],
    isMyPending?: boolean
  ): Promise<{ data: any[]; total: number; page: number; limit: number }> {
    const loginLower = userLogin.toLowerCase();

    const visitorAccess =
      await this.sharepointPermissionService.getVisitorAccess(loginLower);
    const isVisitor =
      visitorAccess.isGlobalVisitor || visitorAccess.countries.length > 0;

    let codeRows: any[] = [];
    let directMatchRows: any[] = [];
    let authorizedCodes = new Set<string>();

    if (!isVisitor) {
      [codeRows, directMatchRows] = await Promise.all([
        this.stakeholderRepository.search({
          where: { deleted: false, stakeholder_code: { [Op.ne]: null } },
          attributes: ["stakeholder_code"],
          group: ["stakeholder_code"]
        }),
        this.stakeholderRepository.search({
          where: {
            deleted: false,
            [Op.or]: [
              where(cast(col("additional_stakeholders"), "text"), {
                [Op.iLike]: `%${loginLower}%`
              }),
              where(cast(col("notify_users"), "text"), {
                [Op.iLike]: `%${loginLower}%`
              })
            ]
          }
        })
      ]);

      const uniqueCodes = codeRows
        .map((r) => r.stakeholder_code)
        .filter(Boolean);
      const codeChecks = await Promise.all(
        uniqueCodes.map(async (code) => ({
          code,
          authorized:
            await this.sharepointPermissionService.isUserAuthorizedForStakeholder(
              loginLower,
              code
            )
        }))
      );
      authorizedCodes = new Set(
        codeChecks.filter((r) => r.authorized).map((r) => r.code)
      );
    }

    let statusCondition: any;

    const baseConditions = [
      { active: true },
      { deleted: false },
      { inputRequired: true }
    ];

    let orConditions: any[];

    const hasRevisionRequested =
      workflowStatuses?.includes("revision_requested");

    if (isVisitor) {
      const filteredStatuses = workflowStatuses?.filter(
        (s) => s !== "revision_requested"
      );
      if (hasRevisionRequested) {
        const orParts: any[] = [
          {
            workflowStatus: {
              [Op.in]: [
                RoundWorkflowStatus.Approved,
                RoundWorkflowStatus.DraftApproved
              ]
            },
            revisionAttempt: { [Op.gte]: 1 },
            isCurrentVersion: "1"
          }
        ];
        if (filteredStatuses && filteredStatuses.length > 0) {
          orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
        }
        statusCondition = { [Op.or]: orParts };
      } else {
        const statusFilter =
          workflowStatuses && workflowStatuses.length > 0
            ? { [Op.in]: workflowStatuses }
            : { [Op.ne]: RoundWorkflowStatus.Cancelled };
        statusCondition = { workflowStatus: statusFilter };
      }

      orConditions = [];
    } else if (myRecord) {
      if (isMyPending) {
        const pendingBase = [
          RoundWorkflowStatus.Created,
          RoundWorkflowStatus.Rejected,
          RoundWorkflowStatus.Retracted
        ];
        const pendingStatuses =
          workflowStatuses && workflowStatuses?.length > 0
            ? pendingBase.filter((s) => workflowStatuses.includes(s))
            : pendingBase;

        const orParts: any[] = [];
        if (pendingStatuses.length > 0) {
          orParts.push({ workflowStatus: { [Op.in]: pendingStatuses } });
        }

        if (hasRevisionRequested) {
          orParts.push({
            workflowStatus: {
              [Op.in]: [
                RoundWorkflowStatus.Approved,
                RoundWorkflowStatus.DraftApproved
              ]
            },
            revisionAttempt: { [Op.gte]: 1 },
            isCurrentVersion: "1"
          });
        }
        statusCondition = { [Op.or]: orParts };
      } else {
        const hasRevisionRequested =
          workflowStatuses?.includes("revision_requested");
        const filteredStatuses = workflowStatuses?.filter(
          (s) => s !== "revision_requested"
        );
        if (hasRevisionRequested) {
          const orParts: any[] = [
            {
              workflowStatus: {
                [Op.in]: [
                  RoundWorkflowStatus.Approved,
                  RoundWorkflowStatus.DraftApproved
                ]
              },
              revisionAttempt: { [Op.gte]: 1 },
              isCurrentVersion: "1"
            }
          ];
          if (filteredStatuses && filteredStatuses.length > 0) {
            orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
          }
          statusCondition = { [Op.or]: orParts };
        } else {
          const statusFilter =
            workflowStatuses && workflowStatuses.length > 0
              ? { [Op.in]: workflowStatuses }
              : { [Op.ne]: RoundWorkflowStatus.Cancelled };
          statusCondition = { workflowStatus: statusFilter };
        }
      }

      orConditions = [
        ...new Map(
          directMatchRows
            .filter((row) => row.stakeholder_code)
            .map((row) => [
              `${row.roundId}-${row.stakeholder_code}`,
              { stakeholderCode: row.stakeholder_code, roundId: row.roundId }
            ])
        ).values()
      ];
    } else {
      const filteredStatuses = workflowStatuses?.filter(
        (s) => s !== "revision_requested"
      );
      if (hasRevisionRequested) {
        const orParts: any[] = [
          {
            workflowStatus: {
              [Op.in]: [
                RoundWorkflowStatus.Approved,
                RoundWorkflowStatus.DraftApproved
              ]
            },
            revisionAttempt: { [Op.gte]: 1 },
            isCurrentVersion: "1"
          }
        ];
        if (filteredStatuses && filteredStatuses.length > 0) {
          orParts.unshift({ workflowStatus: { [Op.in]: filteredStatuses } });
        }
        statusCondition = { [Op.or]: orParts };
      } else {
        const statusFilter =
          workflowStatuses && workflowStatuses.length > 0
            ? { [Op.in]: workflowStatuses }
            : { [Op.ne]: RoundWorkflowStatus.Cancelled };
        statusCondition = { workflowStatus: statusFilter };
      }

      orConditions = [];
      if (authorizedCodes.size > 0) {
        orConditions.push({
          stakeholderCode: { [Op.in]: [...authorizedCodes] }
        });
      }
      for (const row of directMatchRows) {
        if (row.stakeholder_code) {
          orConditions.push({
            stakeholderCode: row.stakeholder_code,
            roundId: row.roundId
          });
        }
      }
    }

    if (!isVisitor && orConditions.length === 0) {
      return { data: [], total: 0, page, limit };
    }

    let inputWhere: any = isVisitor
      ? { [Op.and]: [...baseConditions, statusCondition] }
      : {
        [Op.and]: [
          { [Op.or]: orConditions },
          ...baseConditions,
          statusCondition
        ]
      };

    inputWhere = {
      [Op.and]: [
        inputWhere,
        literal(`
      NOT (
        "OpportunityRoundInput"."workflow_status" = '${RoundWorkflowStatus.Created}'
        AND "round"."workflow_status" = '${RoundWorkflowStatus.Completed}'
      )
    `)
      ]
    };


    if (searchText?.trim()) {
      const term = `%${searchText.trim()}%`;
      inputWhere = {
        [Op.and]: [
          inputWhere,
          {
            [Op.or]: [
              { "$opportunity.title$": { [Op.iLike]: term } },
              { "$opportunity.customer$": { [Op.iLike]: term } },
              { "$opportunity.lead_number$": { [Op.iLike]: term } },
              { stakeholderCode: { [Op.iLike]: term } },
              { workflowStatus: { [Op.iLike]: term } }
            ]
          }
        ]
      };
    }

    const opportunityWhere: any = { active: true };
    if (isVisitor && !visitorAccess.isGlobalVisitor) {
      opportunityWhere.country = { [Op.in]: visitorAccess.countries };
    }

    const useMyPending = !isVisitor && isMyPending;

    const { rows: inputRows, count: total } =
      await this.inputRepository.findAndCountAll({
        where: inputWhere,
        include: [
          {
            model: Opportunity,
            as: "opportunity",
            attributes: [
              "id",
              "title",
              "customer",
              "leadNumber",
              "countryCode"
            ],
            where: opportunityWhere,
            required: true
          },
          {
            model: OpportunityRound,
            as: "round",
            attributes: ["id", "roundNumber", "description", "workflowStatus"]
          },
          ...(useMyPending
            ? [
              {
                model: OpportunityRoundStakeholder,
                as: "stakeholderData",
                on: {
                  round_id: {
                    [Op.col]: "OpportunityRoundInput.round_id"
                  },
                  stakeholder_code: {
                    [Op.col]: "OpportunityRoundInput.stakeholder_code"
                  }
                },
                required: false,
                attributes: [
                  "id",
                  "dueDate",
                  "draftDueDate",
                  "stakeholderType"
                ]
              }
            ]
            : [])
        ],
        order: useMyPending
          ? [
            [
              fn(
                "COALESCE",
                col("stakeholderData.draft_due_date"),
                col("stakeholderData.due_date")
              ),
              "ASC"
            ]
          ]
          : [["created_on", "DESC"]],
        limit,
        offset: (page - 1) * limit,
        distinct: true,
        subQuery: false
      });

    const validatedPairs = new Set(
      inputRows
        .filter(
          (input) =>
            input.workflowStatus === RoundWorkflowStatus.Approved &&
            input.isCurrentVersion === "1"
        )
        .map(
          (input) =>
            `${input.roundId}-${input.stakeholderCode}-${input.scenarioName}`
        )
    );

    const filteredInputRows = (inputRows as any[]).filter((input) => {
      if (
        input.isRevisionRequested === true &&
        input.isCurrentVersion !== "1"
      ) {
        return false;
      }

      return true;
    });

    // const uniquePairs = [
    //   ...new Map(
    //     (inputRows as any[])
    //       .filter((i) => i.stakeholderCode && i.roundId)
    //       .map((i) => [
    //         `${i.roundId}-${i.stakeholderCode}`,
    //         { roundId: i.roundId, stakeholder_code: i.stakeholderCode }
    //       ])
    //   ).values()
    // ];

    const uniquePairs = [
      ...new Map(
        (filteredInputRows as any[])
          .filter((i) => i.stakeholderCode && i.roundId)
          .map((i) => [
            `${i.roundId}-${i.stakeholderCode}`,
            {
              roundId: i.roundId,
              stakeholder_code: i.stakeholderCode
            }
          ])
      ).values()
    ];


    const stakeholderLookup = new Map<string, any>();
    if (uniquePairs.length > 0) {
      const stakeholderRows = await this.stakeholderRepository.search({
        where: {
          deleted: false,
          [Op.or]: uniquePairs.map((p) => ({
            roundId: p.roundId,
            stakeholder_code: p.stakeholder_code
          }))
        }
      });
      for (const s of stakeholderRows) {
        const plain = s.get ? s.get({ plain: true }) : s;
        stakeholderLookup.set(
          `${plain.roundId}-${plain.stakeholder_code}`,
          plain
        );
      }
    }

    //const data = (inputRows as any[]).map((input) => {
    const data = (filteredInputRows as any[]).map((input) => {
      const stk = stakeholderLookup.get(
        `${input.roundId}-${input.stakeholderCode}`
      );
      return {
        id: input.id,
        opportunityId: input.opportunityId,
        opportunityTitle: input.opportunity?.title ?? null,
        opportunityCustomer: input.opportunity?.customer ?? null,
        opportunityLeadNumber: input.opportunity?.leadNumber ?? null,
        opportunityCountryCode: input.opportunity?.countryCode ?? null,
        roundId: input.roundId,
        roundNumber: input.round?.roundNumber ?? input.roundNumber,
        roundDescription: input.round?.description ?? null,
        stakeholder: input.stakeholder,
        stakeholderType: stk?.stakeholderType ?? null,
        description: stk?.description ?? null,
        stakeholderCode: input.stakeholderCode,
        scenarioName: input.scenarioName,
        revisionNumber: input.revisionNumber,
        isCurrentVersion: input.isCurrentVersion,
        isCurrentApproved: input.isCurrentApproved,
        fileRelPath: input.fileRelPath,
        approvedOn: input.approvedOn,
        submittedOn: input.submittedOn,
        userStatus: input.userStatus,
        workflowStatus: input.workflowStatus,
        isStandardRate: input.isStandardRate,
        isCopiedPreviousRound: input.isCopiedPreviousRound,
        inputType: input.input_type,
        revisionAttempt: input.revisionAttempt,
        lastRevisionAttempt: input.lastRevisionAttempt,
        versionNumber: input.versionNumber,
        submissionType: input.submissionType,
        submittedBy: input.submittedBy,
        approvedBy: input.approvedBy,
        notify_users: stk?.notify_users ?? null,
        additional_stakeholders: stk?.additionalStakeholders ?? null,
        dueDate: stk?.dueDate ?? null,
        draftDueDate: stk?.draftDueDate ?? null,
        isRevisionRequested: input.isRevisionRequested
      };
    });

    return { data, total, page, limit };

  }




  async getStakeholdersDueSoonReminders(): Promise<any> {
    debugger;
    const reminderDays =
      this.configService.getAppConfig().notifications?.dueDateReminderDays ?? 2;

    const now = new Date();
    const dueWindowEnd = new Date(
      now.getTime() + reminderDays * 24 * 60 * 60 * 1000
    );

    const stakeholders = await this.stakeholderRepository.search({
      where: {
        [Op.or]: [
          { dueDate: { [Op.lte]: dueWindowEnd } },
          { draftDueDate: { [Op.lte]: dueWindowEnd } }
        ],
        active: true,
        deleted: false
      },
      include: [
        {
          model: Opportunity,
          as: "opportunity",
          attributes: ["id", "title", "leadNumber", "countryCode", "customer"],
          required: true
        },
        {
          model: OpportunityRound,
          as: "round",
          attributes: [],
          where: { workflowStatus: { [Op.ne]: RoundWorkflowStatus.Completed } },
          required: true
        }
      ]
    });

    if (!stakeholders.length) return [];

    const workflowCondition = {
      [Op.or]: [
        {
          workflowStatus: {
            [Op.in]: [
              RoundWorkflowStatus.Created,
              RoundWorkflowStatus.Rejected,
              RoundWorkflowStatus.Retracted
            ]
          }
        },
        {
          workflowStatus: {
            [Op.in]: [
              RoundWorkflowStatus.Approved,
              RoundWorkflowStatus.DraftApproved
            ]
          },
          revisionAttempt: { [Op.gte]: 1 },
          isCurrentVersion: "1"
        }
      ]
    };

    const inputs = await this.inputRepository.search({
      where: {
        [Op.and]: [
          {
            [Op.or]: stakeholders.map((s) => ({
              roundId: s.roundId,
              stakeholderCode: s.stakeholder_code
            }))
          },
          workflowCondition,
          { active: true, deleted: false }
        ]
      }
    });

    const inputsByPair = new Map<string, OpportunityRoundInput[]>();
    for (const input of inputs) {
      const key = `${input.roundId}-${input.stakeholderCode}`;
      if (!inputsByPair.has(key)) inputsByPair.set(key, []);
      inputsByPair.get(key).push(input);
    }

    const scenarioDescByPair = new Map<string, Map<string, string>>();
    for (const s of stakeholders) {
      const key = `${s.roundId}-${s.stakeholder_code}`;
      const descMap = new Map<string, string>();
      for (const scenario of s.applicableScenarios ?? []) {
        descMap.set(scenario.name, scenario.desc);
      }
      scenarioDescByPair.set(key, descMap);
    }

    const byGroup = new Map<
      string,
      {
        opportunityId: number;
        opportunityTitle: string;
        opportunityLeadNumber: string;
        opportunityCountryCode: string;
        opportunityCustomer: string;
        opportunityRegion: string;
        roundId: number;
        roundNumber: number;
        dueDate: Date;
        emails: Set<string>;
        pendingTasks: {
          stakeholderCode: string;
          stakeholder: string;
          scenarioName: string;
          scenarioDesc: string | null;
          fileRelPath: string | null;
          submissionType: string | null;
          versionNumber: string | null;
          stakeholderDueDate: Date | null;
          stakeholderDraftDueDate: Date | null;
        }[];
      }
    >();

    for (const stk of stakeholders) {
      const pairKey = `${stk.roundId}-${stk.stakeholder_code}`;
      const matchingInputs = inputsByPair.get(pairKey);
      if (!matchingInputs || matchingInputs.length === 0) continue;

      const groupKey = `${stk.opportunityId}-${stk.roundId}`;
      if (!byGroup.has(groupKey)) {
        const opp = stk.opportunity as any;
        byGroup.set(groupKey, {
          opportunityId: stk.opportunityId,
          opportunityTitle: opp?.title ?? null,
          opportunityLeadNumber: opp?.leadNumber ?? null,
          opportunityCountryCode: opp?.countryCode ?? null,
          opportunityCustomer: opp?.customer ?? null,
          opportunityRegion: opp?.region ?? null,
          roundId: stk.roundId,
          roundNumber: stk.roundNumber,
          dueDate: stk.dueDate,
          emails: new Set(),
          pendingTasks: []
        });
      }

      const group = byGroup.get(groupKey);
      const scenarioDescMap = scenarioDescByPair.get(pairKey);

      for (const user of [
        ...(stk.additionalStakeholders ?? []),
        ...(stk.notify_users ?? [])
      ]) {
        if (user?.email) group.emails.add(user.email.toLowerCase());
      }

      for (const input of matchingInputs) {
        const effectiveDueDate =
          input.submissionType === SubmissionType.Draft
            ? (stk.draftDueDate ?? stk.dueDate ?? null)
            : (stk.dueDate ?? null);

        if (!effectiveDueDate || new Date(effectiveDueDate) > dueWindowEnd)
          continue;

        group.pendingTasks.push({
          stakeholderCode: input.stakeholderCode,
          stakeholder: input.stakeholder,
          scenarioName: input.scenarioName,
          scenarioDesc: scenarioDescMap?.get(input.scenarioName) ?? null,
          fileRelPath: input.fileRelPath ?? null,
          submissionType: input.submissionType ?? null,
          versionNumber: input.versionNumber ?? null,
          stakeholderDueDate: stk.dueDate ?? null,
          stakeholderDraftDueDate: stk.draftDueDate ?? null
        });
      }
    }

    const resultData = [...byGroup.values()]
      .filter((g) => g.pendingTasks.length > 0)
      .sort((a, b) => a.opportunityId - b.opportunityId)
      .map((g) => ({
        opportunityId: g.opportunityId,
        opportunityTitle: g.opportunityTitle,
        opportunityLeadNumber: g.opportunityLeadNumber,
        opportunityCountryCode: g.opportunityCountryCode,
        opportunityCustomer: g.opportunityCustomer,
        opportunityRegion: g.opportunityRegion,
        roundId: g.roundId,
        roundNumber: g.roundNumber,
        dueDate: g.dueDate,
        pendingTasks: g.pendingTasks,
        emails: [...g.emails]
      }));

    // return resultData;
    debugger;
    await this.buildDueDateReminderEmails(resultData);
    return { message: "Reminder notification has been sent" };
  }

  async buildDueDateReminderEmails(opportunities: any): Promise<any> {
    debugger;
    if (!opportunities.length) return [];

    const stakeholderDashboardUrl = `${this.cfg.sharePointUrl}/SitePages/prism.aspx#/opportunities/stakeholders`;
    const pricerUsers =
      await this.sharepointPermissionService.getUsersFromSharePointGroup(
        PermissionEnum.Pricing
      );
    const ccEmail = pricerUsers?.map((x: any) => x.Email) ?? [];

    return opportunities.map(async (g: any) => {
      const costInputFolderUrl = `${this.cfg.sharePointUrl}/${g.opportunityRegion}/${g.opportunityCustomer}/${g.opportunityTitle}/RND ${g.roundNumber}`;

      const taskRows = g.pendingTasks
        .map((t: any, i: any) => {
          const costInputStakeholderFolderUrl = `${this.cfg.sharePointUrl}/${g.opportunityRegion}/${g.opportunityCustomer}/${g.opportunityTitle}/RND ${g.roundNumber}/${t.stakeholderCode}`;
          const templateDataSet =
            `${t.stakeholder}: ${t.scenarioName} - ${t.scenarioDesc ?? ""}`.trimEnd();
          const isDraft = t.submissionType === SubmissionType.Draft;
          const stakeholderLabel = [
            t.stakeholderCode,
            t.versionNumber || null,
            isDraft ? "(Draft)" : null
          ]
            .filter(Boolean)
            .join(" - ");
          const taskDueDate = isDraft
            ? (t.stakeholderDraftDueDate ?? t.stakeholderDueDate)
            : t.stakeholderDueDate;
          const dueDateLabel = taskDueDate
            ? new Date(taskDueDate).toISOString().split("T")[0]
            : "";
          const bg = i % 2 === 0 ? "#ffffff" : "#f9fafb";
          return `
          <tr style="background-color:${bg};">
            <td style="padding:10px 14px;font-size:13px;color:#374151;border-bottom:1px solid #e5e7eb;">${stakeholderLabel}</td>
            <td style="padding:10px 14px;font-size:13px;color:#374151;border-bottom:1px solid #e5e7eb;"><a href="${costInputStakeholderFolderUrl}">${templateDataSet}</a></td>
            <td style="padding:10px 14px;font-size:13px;color:#374151;border-bottom:1px solid #e5e7eb;">${dueDateLabel}</td>
          </tr>`;
        })
        .join("");

      await this.sharedNotificationService.sendNotification(
        g.opportunityId,
        NOTIFICATION_ENTITY_TYPE.PRISM_OPPORTUNITY,
        {
          to: [...g.emails],
          cc: [...ccEmail]
        },
        NOTIFICATION_TEMPLATES.PRISM_STAKEHOLDER_REMINDER,
        {
          OpportunityLabel: g.opportunityTitle,
          RoundNumber: g.roundNumber,
          TaskRows: taskRows,
          CostInputFolderUrl: costInputFolderUrl,
          StakeholderDashboardUrl: stakeholderDashboardUrl
        },
        null
      );
    });
  }
}
