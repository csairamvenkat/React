import {
  Column,
  DataType,
  ForeignKey,
  BelongsTo,
  Table
} from "sequelize-typescript";
import { BaseModel } from "../../shared/models/base.model";
import { Opportunity } from "../../opportunity/models/opportunity.model";
import { OpportunityRound } from "./opportunity-round.model";
import { OpportunityRoundStakeholder } from "./opportunity-round-stakeholder.model";

@Table({
  tableName: "opportunity_round_input",
  timestamps: false
})
export class OpportunityRoundInput extends BaseModel<OpportunityRoundInput> {
  @ForeignKey(() => Opportunity)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "opportunity_id"
  })
  opportunityId: number;

  @ForeignKey(() => OpportunityRound)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "round_id"
  })
  roundId: number;

  @Column({
    type: DataType.SMALLINT,
    allowNull: true,
    field: "round_number"
  })
  roundNumber: number;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "stakeholder"
  })
  stakeholder: string;

  @Column({
    type: DataType.INTEGER,
    allowNull: true,
    field: "revision_number"
  })
  revisionNumber: number;

  @Column({
    type: DataType.STRING(1),
    allowNull: true,
    field: "is_current_version"
  })
  isCurrentVersion: string;

  @Column({
    type: DataType.STRING(1),
    allowNull: true,
    field: "is_current_approved"
  })
  isCurrentApproved: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "scenario_name"
  })
  scenarioName: string;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: "file_rel_path"
  })
  fileRelPath: string;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "processed_data"
  })
  processedData: any;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "exported_on"
  })
  exportedOn: Date;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "submitted_on"
  })
  submittedOn: Date;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "user_status"
  })
  userStatus: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "workflow_status"
  })
  workflowStatus: string;

  @Column({
    type: DataType.STRING(1),
    allowNull: true,
    field: "is_standard_rate"
  })
  isStandardRate: string;

  @Column({
    type: DataType.STRING(1),
    allowNull: true,
    field: "is_copied_previous_round"
  })
  isCopiedPreviousRound: string;

  @Column({
    type: DataType.BIGINT,
    allowNull: true,
    field: "data_round_id"
  })
  dataRoundId: number;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "input_type"
  })
  input_type: string;

  @Column({
    type: DataType.STRING(25),
    allowNull: true,
    field: "stakeholder_code"
  })
  stakeholderCode: string;

  @Column({
    type: DataType.BIGINT,
    allowNull: true,
    field: "revision_attempt"
  })
  revisionAttempt: number;

  @Column({
    type: DataType.DATE(3),
    allowNull: true,
    field: "last_revision_attempt"
  })
  lastRevisionAttempt: Date;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "approved_on"
  })
  approvedOn: Date;

  @Column({
    type: DataType.BOOLEAN,
    allowNull: true,
    field: "is_revision_requested"
  })
  isRevisionRequested: Boolean;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "version_number"
  })
  versionNumber: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "submission_type"
  })
  submissionType: string;

  @BelongsTo(() => Opportunity, "opportunityId")
  opportunity: Opportunity;

  @BelongsTo(() => OpportunityRound, "roundId")
  round: OpportunityRound;

  @BelongsTo(() => OpportunityRoundStakeholder, {
    foreignKey: { name: "stakeholderCode", field: "stakeholder_code" },
    constraints: false
  })
  stakeholderData: OpportunityRoundStakeholder;

  @Column({
    field: "input_required",
    type: DataType.BOOLEAN,
    defaultValue: true,
    allowNull: false
  })
  public inputRequired: boolean;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "submitted_by"
  })
  submittedBy: any;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "approved_by"
  })
  approvedBy: any;
}
