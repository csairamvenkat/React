import {
  Column,
  DataType,
  ForeignKey,
  BelongsTo,
  Table
} from "sequelize-typescript";
import { BaseModel } from "../../shared/models/base.model";
import { Opportunity } from "../../opportunity/models/opportunity.model";
import { OpportunityRound } from "./opportunity-round.model";

@Table({
  tableName: "output_log",
  timestamps: false
})
export class OutputLog extends BaseModel<OutputLog> {
  @ForeignKey(() => Opportunity)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "opportunity_id"
  })
  opportunityId: number;

  @ForeignKey(() => OpportunityRound)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "round_id"
  })
  roundId: number;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "file_name"
  })
  fileName: string;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: "file_rel_path"
  })
  fileRelPath: string;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "processed_data"
  })
  processedData: any;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "extrated_on"
  })
  extratedOn: Date;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "extrated_by"
  })
  extratedBy: string;

  @BelongsTo(() => Opportunity, "opportunityId")
  opportunity: Opportunity;

  @BelongsTo(() => OpportunityRound, "roundId")
  round: OpportunityRound;
}
