import {
  Column,
  DataType,
  ForeignKey,
  BelongsTo,
  HasMany,
  Table
} from "sequelize-typescript";
import { BaseModel } from "../../shared/models/base.model";
import { Opportunity } from "../../opportunity/models/opportunity.model";
import { OpportunityRoundStakeholder } from "./opportunity-round-stakeholder.model";
import { OpportunityRoundInput } from "./opportunity-round-input.model";

export interface Scenario {
  name: string;
  desc: string;
}

@Table({
  tableName: "opportunity_round",
  timestamps: false
})
export class OpportunityRound extends BaseModel<OpportunityRound> {
  @ForeignKey(() => Opportunity)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "opportunity_id"
  })
  opportunityId: number;

  @Column({
    type: DataType.SMALLINT,
    allowNull: true,
    field: "round_number"
  })
  roundNumber: number;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: "description"
  })
  description: string;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "customer_submission_date"
  })
  customerSubmissionDate: Date;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "scenario_list"
  })
  scenarioList: Scenario[];

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "user_status"
  })
  userStatus: string;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "workflow_status"
  })
  workflowStatus: string;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "template_due_date"
  })
  templateDueDate: Date;

  @BelongsTo(() => Opportunity, "opportunityId")
  opportunity: Opportunity;

  @HasMany(() => OpportunityRoundStakeholder, "roundId")
  stakeholders: OpportunityRoundStakeholder[];

  @HasMany(() => OpportunityRoundInput, "roundId")
  inputs: OpportunityRoundInput[];
}
