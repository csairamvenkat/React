import {
  Column,
  DataType,
  ForeignKey,
  BelongsTo,
  HasMany,
  Table
} from "sequelize-typescript";
import { BaseModel } from "../../shared/models/base.model";
import { Opportunity } from "../../opportunity/models/opportunity.model";
import { OpportunityRound, Scenario } from "./opportunity-round.model";
import { OpportunityRoundInput } from "./opportunity-round-input.model";
import { UserDto } from "../../opportunity/dtos/bid-team-member.dto";

@Table({
  tableName: "opportunity_round_stakeholder",
  timestamps: false
})
export class OpportunityRoundStakeholder extends BaseModel<OpportunityRoundStakeholder> {
  @ForeignKey(() => Opportunity)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "opportunity_id"
  })
  opportunityId: number;

  @ForeignKey(() => OpportunityRound)
  @Column({
    type: DataType.BIGINT,
    allowNull: false,
    field: "round_id"
  })
  roundId: number;

  @Column({
    type: DataType.SMALLINT,
    allowNull: true,
    field: "round_number"
  })
  roundNumber: number;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "stakeholder"
  })
  stakeholder: string;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "stakeholder_type"
  })
  stakeholderType: string;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: "description"
  })
  description: string;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "additional_stakeholders"
  })
  additionalStakeholders: UserDto[];

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "applicable_scenarios"
  })
  applicableScenarios: Scenario[];

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "due_date"
  })
  dueDate: Date;

  @Column({
    type: DataType.JSONB,
    allowNull: true,
    field: "notify_users"
  })
  notify_users: UserDto[];

  @Column({
    type: DataType.STRING(25),
    allowNull: true,
    field: "stakeholder_code"
  })
  stakeholder_code: string;

  @Column({
    type: DataType.BOOLEAN,
    allowNull: true,
    field: "collect_draft_input"
  })
  collectDraftInput: boolean;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "draft_due_date"
  })
  draftDueDate: Date;

  @BelongsTo(() => Opportunity, "opportunityId")
  opportunity: Opportunity;

  @BelongsTo(() => OpportunityRound, "roundId")
  round: OpportunityRound;

  @HasMany(() => OpportunityRoundInput, "stakeholder")
  inputs: OpportunityRoundInput[];
}
