import { Module } from '@nestjs/common';
import { GraphUserController } from './controllers/graph-user.controller';
import { GraphUserService } from './services/graph-user.service';
import { MSGraphApiClient } from 'src/shared/clients';

@Module({
	controllers: [GraphUserController],
	providers: [GraphUserService, MSGraphApiClient],
})
export class GraphUserModule {}
