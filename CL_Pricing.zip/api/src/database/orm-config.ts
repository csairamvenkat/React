const models = [
];

export const getSequelizeOrmConfig = (enableSSL: boolean = false, schema: string = 'public') => {
	const baseDialectOptions = {
		prependSearchPath: true,
	};

	const sslConfig = enableSSL
		? {
			ssl: true,
			dialectOptions: {
				...baseDialectOptions,
				ssl: {
					require: true,
				},
			},
		}
		: {
			dialectOptions: baseDialectOptions,
		};

	return {
		synchronize: false,
		autoLoadModels: true,
		models,
		searchPath: schema,
		define: {
			schema: schema,
		},
		...sslConfig,
	};
};
