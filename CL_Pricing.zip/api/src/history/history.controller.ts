import {
  Body,
  Controller,
  Post,
  UseGuards,
} from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from "@nestjs/swagger";
import { AuthGuard } from "@nestjs/passport";

import { HistoryService } from "./history.service";
import { CreateHistoryDto } from "./dtos/create-history.dto";
import { CurrentContext } from "../shared/types/current-context.type";
import { Context } from "../shared/decorators/current-context.decorator";
import { History } from "./models/history.model";

@ApiTags("History")
@ApiBearerAuth()
@UseGuards(AuthGuard("oauth-bearer"))
@Controller("history")
export class HistoryController {
  constructor(
    private readonly historyService: HistoryService
  ) {}

  @Post()
  @ApiOperation({
    summary: "Create a history record",
  })
  @ApiResponse({
    status: 201,
    description: "History record created successfully",
  })
  async createHistory(
    @Body() createDto: CreateHistoryDto,
    @Context() context: CurrentContext
  ): Promise<History> {
    return this.historyService.createHistory(
      createDto,
      context
    );
  }
}