import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
} from "class-validator";

export class CreateHistoryDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  entity_type: string;

  @IsInt()
  @IsNotEmpty()
  entity_id: number;

  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  action_performed: string;

  @IsString()
  @IsOptional()
  action_comments?: string;

  @IsDateString()
  @IsOptional()
  action_date?: string;

  @IsObject()
  @IsOptional()
  additional_info?: Record<string, any>;
}