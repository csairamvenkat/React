import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { History } from "./models/history.model";
import { CreateHistoryDto } from "./dtos/create-history.dto";
import { CurrentContext } from "../shared/types/current-context.type";

@Injectable()
export class HistoryService {
  constructor(
    @InjectModel(History)
    private readonly historyModel: typeof History
  ) { }

  async createHistory(
    createDto: CreateHistoryDto,
    currentContext: CurrentContext
  ): Promise<History> {
    const history = new History();

    // history.entityType = createDto.entity_type;
    history.entityId = createDto.entity_id;
    // history.actionPerformed = createDto.action_performed;
    // history.actionComments = createDto.action_comments;

    history.actionDate = createDto.action_date
      ? new Date(createDto.action_date)
      : new Date();

    history.createdBy =
      currentContext.user.upn?.toLowerCase() ||
      currentContext.user.username;

    history.createdOn = new Date();

    history.additionalInfo = createDto.additional_info;

    return history.save();
  }

  async logHistory(
    currentContext: CurrentContext,
    entityType: string,
    entityId: number,
    action: string,
    comments: string,
    additionalInfo?: Record<string, any>
  ) {
    return this.createHistory(
      {
        entity_type: entityType,
        entity_id: entityId,
        action_performed: action,
        action_comments: comments,
        additional_info: additionalInfo
      },
      currentContext
    );
  }
  getChangedFields(
    oldObject: any,
    newObject: any,
    fields: string[]
  ): Record<string, any> {
    const changedFields: Record<string, any> = {};

    for (const field of fields) {
      const oldValue = oldObject?.[field];
      const newValue = newObject?.[field];

      if (
        JSON.stringify(oldValue) !==
        JSON.stringify(newValue)
      ) {
        changedFields[field] = {
          old_value: oldValue,
          new_value: newValue
        };
      }
    }

    return changedFields;
  }
}