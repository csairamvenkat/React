import { Column, DataType, Table, Model } from "sequelize-typescript";
import {
  HistoryEntityType,
  HistoryActionPerformed,
  HistoryActionComments,
} from "../../shared/enums/history.enum";

@Table({
  tableName: "history",
  schema: "cl_pricing",
  timestamps: false,
})
export class History extends Model<History> {
  @Column({
    type: DataType.BIGINT,
    autoIncrement: true,
    primaryKey: true,
  })
  id: number;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "entity_type",
  })
  entityType: HistoryEntityType;

  @Column({
    type: DataType.BIGINT,
    allowNull: true,
    field: "entity_id",
  })
  entityId: number;

  @Column({
    type: DataType.STRING(50),
    allowNull: true,
    field: "action_performed",
  })
  actionPerformed: HistoryActionPerformed;

  @Column({
    type: DataType.STRING,
    allowNull: true,
    field: "action_comments",
  })
  actionComments: HistoryActionComments;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "action_date",
  })
  actionDate: Date;

  @Column({
    type: DataType.STRING(255),
    allowNull: true,
    field: "created_by",
  })
  createdBy: string;

  @Column({
    type: DataType.DATE,
    allowNull: true,
    field: "created_on",
  })
  createdOn: Date;

  @Column({
    type: DataType.JSON,
    allowNull: true,
    field: "additional_info",
  })
  additionalInfo: any;
}