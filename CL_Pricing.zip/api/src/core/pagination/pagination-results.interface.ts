export interface PaginationResultInterface<PaginationEntity> {
	records: PaginationEntity[];
	total: number;
	next?: string;
	previous?: string;
}

export interface PaginationParms {
	limit: number;
	page: number;
}
