import { Controller, Post, Body, UseGuards } from "@nestjs/common";
import { SchedulerService } from "../services";
import { AuthGuard } from "@nestjs/passport";
import { SharepointPermissionGuard } from "src/sharepoint-permission/guards/sharepoint-permission.guard";
import { PermissionEnum } from "src/shared/enums/permission-status.enum";
import { RequireSharePointGroup } from "src/sharepoint-permission/decorators/require-sharepoint-group.decorator";

@Controller("scheduler")
@UseGuards(AuthGuard("oauth-bearer"))
export class SchedulerController {
  constructor(private readonly schedulerService: SchedulerService) {}

  @Post("run-all")
  @UseGuards(SharepointPermissionGuard)
  @RequireSharePointGroup(PermissionEnum.Pricing)
  async runScheduler(): Promise<any> {
    return this.schedulerService.runScheduler();
    // return { message: 'Reminder notification has been sent' };
  }
}
