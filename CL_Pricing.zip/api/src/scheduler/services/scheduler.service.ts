import { Injectable, Logger } from '@nestjs/common';
import * as _ from 'lodash';
import { OpportunityRoundService } from 'src/opportunity-round/opportunity-round.service';
import { SYSTEM_USER } from 'src/shared/constants';

@Injectable()
export class SchedulerService {
	private readonly logger = new Logger(SchedulerService.name);

	constructor(
		private readonly roundService: OpportunityRoundService,
	) {		
	}

	public async runScheduler() {
		try {
			return await this.getStakeholdersDueSoonReminders();
		} catch (error: any) {
		}
	}

	private async getStakeholdersDueSoonReminders() {
		this.logger.log('Starting to get stakeholders');
		try {
			return await this.roundService.getStakeholdersDueSoonReminders();
			
		} catch (error: any) {
			this.logger.error(`Error while getting stakeholders: ${error.message}`);
		}
	}
}