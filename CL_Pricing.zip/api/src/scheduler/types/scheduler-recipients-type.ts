export type SchedulerRecipients = {
    to: string[],
    cc: string[],
    bcc: string[],
}