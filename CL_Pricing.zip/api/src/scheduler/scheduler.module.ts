import { Module } from '@nestjs/common';
import { SchedulerService } from './services';
import { SchedulerController } from './controllers';
import { AdminApiClient, MSGraphApiClient, NotificationApiClient } from 'src/shared/clients';
import { ConfigModule } from 'src/config/config.module';
import { OpportunityRoundModule } from 'src/opportunity-round/opportunity-round.module';
import { SharepointPermissionModule } from 'src/sharepoint-permission/sharepoint-permission.module';

@Module({
  imports: [
    ConfigModule,
    OpportunityRoundModule,
    SharepointPermissionModule,
  ],
  controllers: [SchedulerController],
  providers: [
    SchedulerService,
    AdminApiClient,
    MSGraphApiClient,
    NotificationApiClient,
  ],
  exports: [
    SchedulerService,
  ]
})
export class SchedulerModule { }
