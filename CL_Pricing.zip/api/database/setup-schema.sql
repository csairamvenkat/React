-- Create cl_pricing schema
CREATE SCHEMA IF NOT EXISTS cl_pricing;

-- Set search path
SET search_path TO cl_pricing;

-- Grant permissions (adjust username as needed)
GRANT USAGE ON SCHEMA cl_pricing TO devapps_user;
GRANT ALL PRIVILEGES ON SCHEMA cl_pricing TO devapps_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cl_pricing TO devapps_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA cl_pricing TO devapps_user;

-- Verify schema creation
SELECT schema_name FROM information_schema.schemata WHERE schema_name = 'cl_pricing';

-- Add stakeholder_code to opportunity_round_input (run once if column does not exist)
ALTER TABLE cl_pricing.opportunity_round_input
  ADD COLUMN IF NOT EXISTS stakeholder_code VARCHAR(25);

-- Move stakeholder_type from opportunity_round_input to opportunity_round_stakeholder (run once if column does not exist)
ALTER TABLE cl_pricing.opportunity_round_stakeholder
  ADD COLUMN IF NOT EXISTS stakeholder_type VARCHAR(50);

-- Backfill stakeholder_type on opportunity_round_stakeholder from existing opportunity_round_input rows
UPDATE cl_pricing.opportunity_round_stakeholder s
SET stakeholder_type = i.stakeholder_type
FROM cl_pricing.opportunity_round_input i
WHERE i.stakeholder_code = s.stakeholder_code
  AND i.round_id = s.round_id
  AND i.stakeholder_type IS NOT NULL
  AND s.stakeholder_type IS NULL;

-- Once verified, the old column can be dropped:
-- ALTER TABLE cl_pricing.opportunity_round_input DROP COLUMN IF EXISTS stakeholder_type;

-- Add description to opportunity_round_stakeholder (run once if column does not exist)
ALTER TABLE cl_pricing.opportunity_round_stakeholder
  ADD COLUMN IF NOT EXISTS description VARCHAR;

-- Add region to opportunity
ALTER TABLE cl_pricing.opportunity
  ADD COLUMN IF NOT EXISTS region VARCHAR(50);

UPDATE cl_pricing.opportunity
SET region = 'EUR'
WHERE region IS NULL;
