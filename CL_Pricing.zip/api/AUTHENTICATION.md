# API Authentication Guide

This API supports **two authentication methods** for different use cases:

1. **Azure AD OAuth (for SPFx SharePoint)** - User-based authentication
2. **Service Account Token (for Power Automate)** - System-based authentication

---

## 🔐 Authentication Methods

### 1️⃣ Azure AD OAuth - SPFx SharePoint (User Authentication)

**Use Case:** SharePoint Framework (SPFx) applications calling APIs on behalf of the current logged-in user.

#### How it Works:
- SPFx applications acquire an Azure AD access token for the current user
- The token is sent in the `Authorization` header as a Bearer token
- The API validates the token against Azure AD
- User context is extracted from the token

#### Implementation in SPFx:

```typescript
import { AadHttpClient, HttpClientResponse } from '@microsoft/sp-http';

export class OpportunityService {
  private aadHttpClient: AadHttpClient;

  constructor(context: WebPartContext) {
    // Initialize AAD HTTP Client
    this.aadHttpClient = await context.aadHttpClientFactory.getClient(
      'https://your-api-url.com' // Your API URL
    );
  }

  async createOpportunity(data: any): Promise<any> {
    const response: HttpClientResponse = await this.aadHttpClient.post(
      'https://your-api-url.com/api/opportunity',
      AadHttpClient.configurations.v1,
      {
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      }
    );

    return response.json();
  }
}
```

#### Manual API Call (for testing):

```bash
# Get Azure AD token first
TOKEN="<your-azure-ad-access-token>"

# Call API
curl -X POST https://your-api-url.com/api/opportunity \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "leadNumber": "LEAD-2025-001",
    "customer": "Acme Corp",
    "title": "Q1 Pricing"
  }'
```

---

### 2️⃣ Service Account Token - Power Automate (System Authentication)

**Use Case:** Power Automate flows and background processes that run without user context.

#### How it Works:
- A pre-configured service account token is used
- The token is sent in the `Authorization` header as a Bearer token
- The API validates against the configured service account token
- System context is used (not tied to a specific user)

#### Setup Service Account Token:

##### Option 1: Environment Variable (Recommended for Production)
```bash
# Set environment variable
export SERVICE_ACCOUNT_TOKEN="your-secure-token-here"
```

##### Option 2: Configuration File (for Development)
Add to `config.json`:
```json
{
  "serviceAccount": {
    "token": "your-service-account-token",
    "enabled": true
  }
}
```

⚠️ **Security Note:** Never commit the actual token to source control! Use environment variables in production.

#### Implementation in Power Automate:

**Step 1: Store Token in Environment Variable**
1. Go to Power Automate → Solutions → Environment Variables
2. Create new variable: `ServiceAccountToken`
3. Set value to your service account token

**Step 2: Configure HTTP Action**

```json
{
  "method": "POST",
  "uri": "https://your-api-url.com/api/opportunity",
  "headers": {
    "Authorization": "Bearer @{variables('ServiceAccountToken')}",
    "Content-Type": "application/json"
  },
  "body": {
    "leadNumber": "LEAD-2025-001",
    "customer": "Acme Corp",
    "title": "Q1 Pricing"
  }
}
```

#### Manual API Call (for testing):

```bash
# Using service account token
SERVICE_TOKEN="your-service-account-token"

curl -X POST https://your-api-url.com/api/opportunity \
  -H "Authorization: Bearer $SERVICE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "leadNumber": "LEAD-2025-001",
    "customer": "Acme Corp",
    "title": "Q1 Pricing"
  }'
```

---

## 🔧 API Endpoints

All endpoints accept **BOTH** authentication methods. The API will automatically detect which method you're using.

### Available Endpoints:

#### Opportunity APIs
- `POST /api/opportunity` - Create opportunity
- `GET /api/opportunity/:id` - Get opportunity by ID
- `GET /api/opportunity` - Get all opportunities

#### Opportunity Round APIs
- `POST /api/opportunity-round` - Create round with scenarios and stakeholders
- `POST /api/opportunity-round/stakeholder-input` - Complete stakeholder input
- `POST /api/opportunity-round/output-log` - Generate output log
- `GET /api/opportunity-round/:id` - Get round by ID
- `GET /api/opportunity-round/opportunity/:opportunityId` - Get rounds for opportunity
- `GET /api/opportunity-round/:roundId/inputs` - Get stakeholder inputs
- `GET /api/opportunity-round/:roundId/output-logs` - Get output logs

---

## 🛡️ Security Best Practices

### For SPFx Applications:
1. ✅ Always use AadHttpClient (handles token acquisition automatically)
2. ✅ Token is tied to the logged-in user
3. ✅ Tokens expire automatically (handled by SPFx)
4. ✅ User permissions are enforced

### For Power Automate:
1. ✅ Store token in environment variables (NOT in flow)
2. ✅ Use different tokens for Dev/Test/Prod environments
3. ✅ Rotate tokens regularly
4. ✅ Limit service account permissions to minimum required
5. ❌ Never hardcode tokens in flows
6. ❌ Never commit tokens to source control

---

## 🧪 Testing Authentication

### Test with User Token (SPFx):
```bash
# Get token from https://jwt.ms or your SPFx app
curl -H "Authorization: Bearer <azure-ad-token>" \
  https://your-api-url.com/api/opportunity
```

### Test with Service Account Token:
```bash
curl -H "Authorization: Bearer <service-account-token>" \
  https://your-api-url.com/api/opportunity
```

### Expected Response:
- ✅ **200/201**: Success
- ❌ **401**: Invalid or expired token
- ❌ **403**: Valid token but insufficient permissions

---

## 📋 Token Format

### Azure AD Token (User):
```
eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6I...
```
- JWT format
- Contains user claims (name, email, roles, etc.)
- Expires after 1 hour (renewed automatically by SPFx)

### Service Account Token (System):
```
your-configured-service-account-token-string
```
- Plain string (can be any format you configure)
- No expiration (unless you implement rotation)
- Represents system/service account

---

## 🔍 Debugging

### Check Authentication Type:
The API internally tracks which authentication method was used. You can add logging in your controllers:

```typescript
@Post()
async createOpportunity(
  @Body() createDto: CreateOpportunityDto,
  @Context() context: CurrentContext,
  @AuthType() authType: string, // 'user' or 'service-account'
) {
  console.log(`Request authenticated via: ${authType}`);
  // authType will be 'user' for SPFx or 'service-account' for Power Automate
}
```

### Common Issues:

#### 401 Unauthorized
- **Cause**: Missing or invalid token
- **Fix**: Ensure `Authorization: Bearer <token>` header is present

#### 403 Forbidden
- **Cause**: Valid token but wrong scope/permissions
- **Fix**: Check Azure AD app registration permissions

#### Token Expired
- **Cause**: Azure AD token older than 1 hour
- **Fix**: SPFx should auto-renew; if testing manually, get a fresh token

---

## 🚀 Quick Start

### For Developers (SPFx):
1. Use `AadHttpClient` from SPFx
2. Point to your API URL
3. Done! Authentication handled automatically

### For Automation (Power Automate):
1. Set `SERVICE_ACCOUNT_TOKEN` environment variable
2. Use HTTP action with `Authorization: Bearer <token>`
3. Done!

---

## 📞 Support

For authentication issues:
1. Check token in [https://jwt.ms](https://jwt.ms) (for Azure AD tokens)
2. Verify API URL and endpoint
3. Check network tab for 401/403 responses
4. Review API logs for authentication errors
