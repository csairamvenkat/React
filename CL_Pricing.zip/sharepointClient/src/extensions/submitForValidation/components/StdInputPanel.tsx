import * as React from 'react';
import { Panel, PanelType } from '@fluentui/react/lib/Panel';
import { TextField } from '@fluentui/react/lib/TextField';
import { Dropdown, IDropdownOption } from '@fluentui/react/lib/Dropdown';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { Stack } from '@fluentui/react/lib/Stack';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';

export interface IStdInputPanelProps {
  isOpen: boolean;
  title: string;
  onDismiss: () => void;
  onSubmit: (args: {
    fileTitle: string;
    fileDescription: string;
    countryId: number;
    versionNumber: string;
  }) => Promise<void>;

  countryOptions: IDropdownOption[];

  versionOptions: IDropdownOption[];

  defaultValues?: {
    fileTitle?: string;
    fileDescription?: string;
    countryId?: number;
    versionNumber?: string;
  };
}

const StdInputPanel: React.FC<IStdInputPanelProps> = (props) => {
  const [fileTitle, setFileTitle] = React.useState(props.defaultValues?.fileTitle || '');
  const [fileDescription, setFileDescription] = React.useState(props.defaultValues?.fileDescription || '');
  const [countryId, setCountryId] = React.useState<number | undefined>(props.defaultValues?.countryId);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const [versionNumber, setVersionNumber] = React.useState(
    props.defaultValues?.versionNumber || ''
  );

  const canSubmit =
    !!fileTitle &&
    !!countryId &&
    !!versionNumber;

  const handleSubmit = async () => {
    if (isSubmitting || !canSubmit) return;

    setIsSubmitting(true);

    try {
      await props.onSubmit({
        fileTitle,
        fileDescription,
        countryId: Number(countryId),
        versionNumber
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Panel
      isOpen={props.isOpen}
      onDismiss={props.onDismiss}
      type={PanelType.medium}
      headerText={props.title}
    >
      <Stack tokens={{ childrenGap: 16 }}>
        <TextField
          label="File title"
          value={fileTitle}
          onChange={(_, v) => setFileTitle(v || '')}
          required
          disabled={isSubmitting}
        />
        <TextField
          label="Description"
          value={fileDescription}
          multiline
          rows={4}
          onChange={(_, v) => setFileDescription(v || '')}
          disabled={isSubmitting}
        />
        <Dropdown
          label="Country"
          placeholder="Choose"
          options={props.countryOptions}
          selectedKey={countryId}
          onChange={(_, opt) => setCountryId(Number(opt?.key))}
          required
          disabled={isSubmitting}
        />
        <Dropdown
          label="Version Number"
          placeholder="Select Version"
          options={props.versionOptions}
          selectedKey={versionNumber}
          onChange={(_, opt) =>
            setVersionNumber(String(opt?.key))
          }
          required
          disabled={isSubmitting}
        />
        <PrimaryButton
          text={isSubmitting ? 'Submitting…' : 'Validate & Submit'}
          disabled={!canSubmit || isSubmitting}
          onClick={handleSubmit}
          onRenderIcon={() => isSubmitting ? <Spinner size={SpinnerSize.xSmall} /> : null}
        />
      </Stack>
    </Panel>
  );
};

export default StdInputPanel;