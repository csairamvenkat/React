import * as React from 'react';

import {
  Dialog,
  DialogType,
  DialogFooter
} from '@fluentui/react/lib/Dialog';

import {
  PrimaryButton,
  DefaultButton
} from '@fluentui/react/lib/Button';

import {
  TextField
} from '@fluentui/react/lib/TextField';

import {
  Spinner,
  SpinnerSize
} from '@fluentui/react/lib/Spinner';


export interface IRenameDialogProps {
  isOpen: boolean;
  title: string;
  currentFileName: string;
  onDismiss: () => void;
  onSave: (newFileName: string) => Promise<void>;
}


const RenameDialog: React.FC<IRenameDialogProps> = (props) => {

  const [fileName, setFileName] =
    React.useState<string>(
      props.currentFileName || ''
    );

  const [isSaving, setIsSaving] =
    React.useState<boolean>(false);

  const [errorMessage, setErrorMessage] =
    React.useState<string>('');


  React.useEffect(() => {

    setFileName(
      props.currentFileName || ''
    );

    setErrorMessage('');

  }, [props.currentFileName]);


  // --------------------------------------------------
  // File Name Validation
  // --------------------------------------------------
  const validateFileName = (value: string): string => {

    const trimmedValue = value.trim();

    // Required
    if (!trimmedValue) {
      return 'File name is required.';
    }

    // Maximum 80 characters
    if (trimmedValue.length > 80) {
      return 'File name cannot exceed 80 characters.';
    }

    // Characters not allowed by SharePoint
    const invalidFileNameCharacters =
      /[#%*:<>?\/\\|+']/g;

    const invalidCharactersFound =
      trimmedValue.match(invalidFileNameCharacters);

    if (invalidCharactersFound) {

      // Remove duplicate invalid characters
      const uniqueInvalidCharacters =
        invalidCharactersFound
          .filter(
            (char, index, array) =>
              array.indexOf(char) === index
          )
          .join(' ');

      return (
        `File name contains invalid character(s): ${uniqueInvalidCharacters}`
      );
    }

    return '';
  };


  // --------------------------------------------------
  // Save
  // --------------------------------------------------
  const handleSave = async () => {

    const trimmedFileName =
      fileName.trim();

    const validationError =
      validateFileName(trimmedFileName);

    if (validationError) {

      setErrorMessage(
        validationError
      );

      return;
    }

    setErrorMessage('');
    setIsSaving(true);

    try {

      await props.onSave(
        trimmedFileName
      );

    } finally {

      setIsSaving(false);

    }
  };


  // --------------------------------------------------
  // Dialog
  // --------------------------------------------------
  return (
    <Dialog
      hidden={!props.isOpen}
      onDismiss={props.onDismiss}
      dialogContentProps={{
        type: DialogType.normal,
        title: props.title
      }}
      modalProps={{
        isBlocking: true
      }}
      minWidth="500px"
    >

      <TextField
        label="File Name"
        required
        value={fileName}
        disabled={isSaving}
        errorMessage={errorMessage}
        onChange={(_, value) => {

          setFileName(
            value || ''
          );

          setErrorMessage('');

        }}
      />

      <DialogFooter>

        <PrimaryButton
          text={
            isSaving
              ? 'Saving…'
              : 'Save'
          }
          disabled={
            isSaving ||
            !fileName.trim()
          }
          onClick={handleSave}
          onRenderIcon={() =>
            isSaving
              ? (
                <Spinner
                  size={SpinnerSize.xSmall}
                />
              )
              : null
          }
        />

        <DefaultButton
          text="Cancel"
          disabled={isSaving}
          onClick={props.onDismiss}
        />

      </DialogFooter>

    </Dialog>
  );
};


export default RenameDialog;