import * as React from 'react';
import { MessageBar, MessageBarType } from '@fluentui/react/lib/MessageBar';
import { Panel, PanelType } from '@fluentui/react/lib/Panel';
import { Dropdown, IDropdownOption } from '@fluentui/react/lib/Dropdown';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { TextField } from '@fluentui/react/lib/TextField';
import { Stack } from '@fluentui/react/lib/Stack';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { ExtensionContext } from '@microsoft/sp-extension-base';
import { AadHttpClient, HttpClientResponse } from '@microsoft/sp-http';
import { ChoiceGroup, IChoiceGroupOption } from '@fluentui/react/lib/ChoiceGroup';

export interface ISubmitArgs {
  scenarioName: string;
  scenarioDescription?: string;
  comment: string;
  isRevision: boolean;
  isDraft: boolean;
  selection: {
    opportunityId: number;
    roundId: number;
    roundNumber: number;
    stakeholder: string;
    leadPricerEmail: string;
    stakeholderEmails: string;
    opportunityName: string;
    stakeholderInputTempName: string;
    customerName: string;
    regionName: string;
    countryName?: string;
    bidTeamMembers?: any;
    additionalTeamMembers?: any;
    versionNumber?: string;
    stakeholderType?: string;
  };
}

export interface IPanelUIProps {
  isOpen: boolean;
  title: string;
  apiBaseUrl?: string;
  apiResource: string;
  apiUrl?: string;
  currentWebUrl: string;
  currentFolderUrl: string;
  context: ExtensionContext;
  onDismiss: () => void;
  onSubmit: (args: ISubmitArgs) => Promise<void>;
}

type OpportunityApiModel = {
  opportunityId: string | number;
  opportunityName: string;
  roundId: string | number;
  roundNumber: number;
  lead_pricer: {
    email: string,
    login_id: string,
    name: string
  }[];
  customer?: string;
  roundDescription?: string;
  stakeholders?: {
    id: string | number;
    stakeholder: string;
    collectDraftInput?: boolean | null;
    stakeholderType?: string;
    additionalStakeholders?: {
      email: string,
      login_id: string,
      name: string
    }[];
    notify_users?: {
      email: string,
      login_id: string,
      name: string
    }[];
    stakeholder_code: string;
    dueDate?: string;
    applicableScenarios?: {
      name: string;
      desc?: string;
    }[];
  }[];
  inputs?: {
    id: string | number;
    opportunityId: string | number;
    roundId: string | number;
    roundNumber: number;
    stakeholder: string;
    stakeholderCode: string;
    inputRequired: boolean;
    revisionNumber: number;
    versionNumber: string;
    isCurrentVersion: string;
    isCurrentApproved: string;
    scenarioName: string;
    fileRelPath: string;
    exportedOn: string;
    userStatus: string;
    workflowStatus: string;
    isStandardRate: string;
    isCopiedPreviousRound: string;
    dataRoundId: string;
    notifyUsers: {
      name: string;
      email: string;
      login_id: string;
    }[];
    inputType: string;
    submissionType: string;
    active: boolean;
    deleted: boolean;
    createdOn: string;
    createdBy: string | null;
  }[];
  scenarios?: {
    name: string;
    desc?: string;
  }[];
};

const PanelUI: React.FC<IPanelUIProps> = (props) => {
  const [loading, setLoading] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [scenarioOptions, setScenarioOptions] = React.useState<IDropdownOption[]>([]);
  const [selectedScenarioKey, setSelectedScenarioKey] = React.useState<string | number | undefined>(undefined);
  const [comment, setComment] = React.useState('');
  const [isRevision] = React.useState(false);
  const [isDraft, setIsDraft] = React.useState(false);
  const [approvedFinalScenarios, setApprovedFinalScenarios] =
    React.useState<Set<string>>(new Set());
  const [
    stakeholderNodeCollectDraftInput,
    setStakeholderNodeCollectDraftInput
  ] = React.useState(false);
  const [inputTypeByScenario, setInputTypeByScenario] = React.useState<Map<string, string>>(new Map());

  const [inputRequiredByScenario, setInputRequiredByScenario] =
    React.useState<Map<string, boolean>>(new Map());

  const [submissionTypeByScenario, setSubmissionTypeByScenario] =
    React.useState<Map<string, string[]>>(new Map());

  const finalAlreadyApproved =
    !!selectedScenarioKey &&
    approvedFinalScenarios.has(
      String(selectedScenarioKey)
    );
  // const showDraftCheckbox =
  //   !!selectedScenarioKey &&
  //   stakeholderNodeCollectDraftInput &&
  //   inputTypeByScenario.get(
  //     String(selectedScenarioKey)
  //   ) === "CollectInput" &&
  //   !finalAlreadyApproved;
  // const submissionOptions: IChoiceGroupOption[] = showDraftCheckbox
  //   ? [
  //     { key: 'Draft', text: 'Draft' },
  //     { key: 'Final', text: 'Final' }
  //   ]
  //   : [
  //     { key: 'Final', text: 'Final' }
  //   ];

  // const selectedInputRequired =
  //   selectedScenarioKey
  //     ? inputRequiredByScenario.get(
  //       String(selectedScenarioKey)
  //     ) === true
  //     : false;

  const selectedSubmissionTypes =
    selectedScenarioKey
      ? submissionTypeByScenario.get(
        String(selectedScenarioKey)
      ) || []
      : [];

  const submissionOptions: IChoiceGroupOption[] =
    selectedSubmissionTypes.map(type => ({
      key: type,
      text: type
    }));


  const [resolved, setResolved] = React.useState<{
    opportunityId: number;
    roundId: number;
    roundNumber: number;
    stakeholder: string;
    leadPricerEmail: string;
    stakeholderEmails: string;
    opportunityName: string;
    stakeholderInputTempName: string;
    customerName: string;
    regionName: string;
    countryName?: string;
    bidTeamMembers?: any;
    additionalTeamMembers?: any;
    versionNumber?: string;
    stakeholderType?: string;
  } | null>(null);

  React.useEffect(() => {
    let isMounted = true;

    const parseFolder = (folderUrl: string) => {
      const parts = (folderUrl || "").split("/").filter(Boolean);
      const n = parts.length;
      const stakeholderFolder = parts[n - 2] || "";
      const roundFolder = parts[n - 3] || "";
      const opportunityFolder = parts[n - 4] || "";
      const customerName = parts[n - 5] || "";
      const regionName = parts[n - 6] || "";

      let roundNumber = 0;
      const m = roundFolder.match(/(\d+)/);
      if (m && m[1]) roundNumber = Number(m[1]);

      return { stakeholderFolder, roundNumber, opportunityFolder, customerName, regionName };
    };

    async function load() {
      if (!props.apiUrl || !props.currentFolderUrl) return;

      setLoading(true);
      try {
        const { stakeholderFolder, roundNumber, opportunityFolder, customerName, regionName } = parseFolder(props.currentFolderUrl);

        const client: AadHttpClient = await props.context.aadHttpClientFactory.getClient(props.apiResource);

        const response: HttpClientResponse = await client.post(
          props.apiUrl,
          AadHttpClient.configurations.v1,
          {
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              opportunityName: opportunityFolder
            })
          }
        );

        const data: OpportunityApiModel[] = await response.json();

        const oppData = data.find(
          d =>
            Number(d.roundNumber) === Number(roundNumber) &&
            (d.stakeholders || []).some(s => s.stakeholder_code === stakeholderFolder)
        );

        if (!oppData) {
          if (isMounted) {
            setScenarioOptions([]);
            setResolved(null);
            setSelectedScenarioKey(undefined);
          }
          return;
        }

        const datasetInputTypeMap = new Map<string, string>();
        //const inputRequiredMap = new Map<string, boolean>();
        const submissionTypeMap = new Map<string, string[]>();
        const approvedFinalSet = new Set<string>();

        (oppData.inputs || [])
          .filter(
            i =>
              i.stakeholderCode?.toLowerCase() ===
              stakeholderFolder.toLowerCase()
          )
          .forEach(i => {

            datasetInputTypeMap.set(
              i.scenarioName,
              i.inputType
            );

            if (i.inputRequired === true) {
              const existingSubmissionTypes =
                submissionTypeMap.get(i.scenarioName) || [];

              if (!existingSubmissionTypes.includes(i.submissionType)) {
                existingSubmissionTypes.push(i.submissionType);
              }

              submissionTypeMap.set(
                i.scenarioName,
                existingSubmissionTypes
              );
            }

            if (
              i.inputType === "CollectInput" &&
              i.workflowStatus === "Approved"
            ) {
              approvedFinalSet.add(i.scenarioName);
            }
          });

        setApprovedFinalScenarios(
          approvedFinalSet
        );

        setInputTypeByScenario(datasetInputTypeMap);
        setSubmissionTypeByScenario(submissionTypeMap);

        const stakeholderNode = (oppData.stakeholders || []).find(
          s => s.stakeholder_code === stakeholderFolder
        );

        const currentInput = (oppData.inputs || []).find(
          i =>
            i.stakeholderCode?.toLowerCase() === stakeholderFolder.toLowerCase() &&
            i.inputRequired === true &&
            i.workflowStatus !== "Cancelled"
        );

        const versionNumber = currentInput?.versionNumber || "";

        setStakeholderNodeCollectDraftInput(
          stakeholderNode?.collectDraftInput === true
        );

        if (stakeholderNode?.collectDraftInput !== true) {
          setIsDraft(false);
        }

        const stakeholderInputTempName = stakeholderNode?.stakeholder || "";

        const validInputScenarios = (oppData.inputs || [])
          .filter(i =>
            i.stakeholderCode?.toLowerCase() === stakeholderFolder.toLowerCase() &&
            i.inputRequired === true
          )
          .map(i => i.scenarioName);

        const collectOnly = (stakeholderNode?.applicableScenarios || [])
          .filter(s => validInputScenarios.includes(s.name))
          .sort((a, b) =>
            a.name.localeCompare(b.name, undefined, { sensitivity: "base" })
          );

        const truncate = (str = "", max = 40) =>
          str.length > max ? str.substring(0, max) + "…" : str;

        const options: IDropdownOption[] =
          collectOnly.map(s => ({
            key: s.name,
            text: `${s.name} - ${truncate(s.desc)}`,

            data: {
              fullDesc: s.desc || "",
              inputType:
                datasetInputTypeMap.get(s.name)
            }
          }));

        if (isMounted) {
          setScenarioOptions(options);

          const uniqueEmailsleadPricer = Array.from(
            new Set(oppData.lead_pricer.map((u) => u.email).filter(Boolean))
          );

          const stakeholderType = stakeholderNode?.stakeholderType ?? "";

          const allStakholderEmail = Array.from(
            new Set(stakeholderNode?.notify_users?.map((u) => u.email).filter(Boolean))
          );

          const allAdditionalStakeholderEmails = Array.from(
            new Set(stakeholderNode?.additionalStakeholders?.map((u) => u.email).filter(Boolean))
          );

          const NotifyUsersEmailString = Array.from(
            new Set([...allStakholderEmail, ...allAdditionalStakeholderEmails])
          ).join(";");

          const uniqueEmailsleadPricerString = uniqueEmailsleadPricer.join(";");

          setResolved({
            opportunityId: Number(oppData.opportunityId),
            roundId: Number(oppData.roundId),
            roundNumber: Number(oppData.roundNumber),
            stakeholder: stakeholderFolder,
            leadPricerEmail: uniqueEmailsleadPricerString,
            stakeholderEmails: NotifyUsersEmailString,
            opportunityName: opportunityFolder,
            stakeholderInputTempName,
            customerName,
            regionName,
            additionalTeamMembers: allAdditionalStakeholderEmails,
            versionNumber,
            stakeholderType
          });

          const response1: HttpClientResponse = await client.get(
            props.apiBaseUrl + `/opportunity/${oppData.opportunityId}`,
            AadHttpClient.configurations.v1,
            {
              headers: {
                "Content-Type": "application/json"
              }
            }
          );

          const dataofOppo: any = await response1.json();

          const emailArray: string[] = (dataofOppo.bid_team_members ?? []).map(
            (member: any) => member.email
          );

          setResolved((prev: any) => ({
            ...prev,
            countryName: dataofOppo.country,
            bidTeamMembers: emailArray
          }));

        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, [props.apiUrl, props.currentFolderUrl]);

  React.useEffect(() => {

    if (
      scenarioOptions.length > 0 &&
      selectedScenarioKey === undefined
    ) {
      setSelectedScenarioKey(
        scenarioOptions[0].key
      );
    }

  }, [scenarioOptions]);

  // React.useEffect(() => {

  //   if (!showDraftCheckbox) {
  //     setIsDraft(false);
  //   }

  // }, [showDraftCheckbox]);

  React.useEffect(() => {
    if (selectedSubmissionTypes.length === 1) {
      setIsDraft(selectedSubmissionTypes[0] === "Draft");
    } else if (selectedSubmissionTypes.length === 0) {
      setIsDraft(false);
    }
  }, [selectedSubmissionTypes]);

  const handleSubmit = async () => {
    if (!resolved || !selectedScenarioKey) return;

    setIsSubmitting(true);
    try {
      const selected = scenarioOptions.find(o => o.key === selectedScenarioKey);

      await props.onSubmit({
        scenarioName: String(selectedScenarioKey),
        scenarioDescription: selected?.data?.fullDesc || "",
        comment,
        isRevision,
        isDraft,
        selection: resolved
      });
    } finally {
      setIsSubmitting(false);
    }
  };


  const selectedInputType =
    selectedScenarioKey
      ? inputTypeByScenario.get(
        String(selectedScenarioKey)
      )
      : "";

  const inputTypeLabel =
    selectedInputType === "CollectInput"
      ? "Collect Input"
      : selectedInputType === "useStandardInput"
        ? "Use Standard Input"
        : selectedInputType === "usePreviousRoundInput"
          ? "Use Previous Round Input"
          : "";

  return (
    <Panel
      isOpen={props.isOpen}
      onDismiss={props.onDismiss}
      type={PanelType.medium}
      headerText={props.title}
    >
      <Stack tokens={{ childrenGap: 16 }}>
        <Dropdown
          label="Select Dataset"
          placeholder={
            loading
              ? "Loading…"
              : scenarioOptions.length === 0
                ? "No Required Input found, kindly contact your Pricer"
                : "Choose"
          }
          options={scenarioOptions}
          disabled={loading || isSubmitting || !resolved || scenarioOptions.length === 0}
          selectedKey={selectedScenarioKey}
          onChange={(_, opt) => setSelectedScenarioKey(opt?.key)}
        />

        {selectedScenarioKey && (
          <div
            style={{
              fontSize: "12px",
              color: "#666"
            }}
          >
            Input Type: {inputTypeLabel}
          </div>
        )}
        {/*
        {!loading && resolved && selectedScenarioKey && (
          <ChoiceGroup
            label="Submission Type"
            selectedKey={isDraft ? 'Draft' : 'Final'}
            options={submissionOptions}
            disabled={isSubmitting}
            styles={{
              flexContainer: {
                display: 'flex',
                flexDirection: 'row',
                gap: 20
              }
            }}
            onChange={(_, option) => {
              setIsDraft(option?.key === 'Draft');
            }}
          />
        )}
        */}

        {!loading &&
          resolved &&
          selectedScenarioKey &&
          submissionOptions.length > 0 && (
            <ChoiceGroup
              label="Submission Type"
              selectedKey={isDraft ? "Draft" : "Final"}
              options={submissionOptions}
              disabled={isSubmitting}
              styles={{
                flexContainer: {
                  display: 'flex',
                  flexDirection: 'row',
                  gap: 20
                }
              }}
              onChange={(_, option) => {
                setIsDraft(option?.key === 'Draft');
              }}
            />
          )}

        {
          selectedScenarioKey &&
          finalAlreadyApproved &&
          resolved?.stakeholderType !== "Adhoc" && (
            <span
              style={{
                fontSize: "12px",
                color: "#d13438",
                fontWeight: 600
              }}
            >
              Final submission has already been approved for this dataset.
              Draft submission is no longer allowed. If changes are required,
              please submit a revision against the approved final submission.
            </span>
          )
        }

        {
          selectedScenarioKey &&
          !finalAlreadyApproved &&
          (
            selectedInputType === "useStandardInput" ||
            selectedInputType === "usePreviousRoundInput"
          ) && (
            <span
              style={{
                fontSize: "12px",
                color: "#d13438",
                fontWeight: 600
              }}
            >
              Draft submission is not available for this dataset.
            </span>
          )
        }

        <TextField
          label="Comments"
          multiline
          rows={4}
          value={comment}
          disabled={isSubmitting}
          onChange={(_, v) => setComment(v || "")}
        />
        <MessageBar
          messageBarType={MessageBarType.warning}
          isMultiline={true}
          styles={{
            root: {
              marginTop: "4px",
              marginBottom: "8px"
            },
            content: {
              fontSize: "16px",
              lineHeight: "1.45"
            }
          }}
        >
          <div>
            <p style={{ margin: "0 0 14px 0" }}>
              Please review your submission file and make sure the following requirements are met:
            </p>

            <ul
              style={{
                marginTop: 0,
                marginBottom: "16px",
                paddingLeft: "28px"
              }}
            >
              {resolved?.stakeholderType !== "Adhoc" && (
                <li style={{ marginBottom: "4px" }}>
                  <strong>Use the standard Excel template</strong> provided for the submission.
                </li>
              )}

              <li style={{ marginBottom: "4px" }}>
                <strong>Remove any extra images, pictures, or embedded objects</strong> from the file,
                as these may prevent the file from being submitted successfully.
              </li>

              <li style={{ marginBottom: "4px" }}>
                <strong>Check all links</strong> and make sure there are no broken, invalid, or unnecessary
                links in the file.
              </li>

              <li style={{ marginBottom: "4px" }}>
                <strong>Make sure all required information is completed</strong> in the appropriate
                sections of the template.
              </li>
            </ul>

            <p
              style={{
                margin: 0,
                fontWeight: 600
              }}
            >
              Please review your file carefully and confirm the above before clicking Submit.
            </p>
          </div>
        </MessageBar>



        <PrimaryButton
          text={isSubmitting ? "Submitting…" : "Submit"}
          disabled={!selectedScenarioKey || !resolved || isSubmitting}
          onClick={handleSubmit}
          onRenderIcon={() =>
            isSubmitting ? <Spinner size={SpinnerSize.xSmall} /> : null
          }
        />
      </Stack>
    </Panel>
  );
};

export default PanelUI;