import {
  BaseListViewCommandSet,
  IListViewCommandSetListViewUpdatedParameters,
  IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { SPPermission } from '@microsoft/sp-page-context';
import { AadHttpClient, HttpClientResponse, SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";

import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Dialog } from '@microsoft/sp-dialog';
import { IDropdownOption } from '@fluentui/react/lib/Dropdown';
import PanelUI, { IPanelUIProps, ISubmitArgs } from './components/PanelUI';
import StdInputPanel, { IStdInputPanelProps } from './components/StdInputPanel';
import { OverlaySpinner } from './ui/OverlaySpinner';

export interface ISubmitToFlowProps {
  flowUrlStandard: any;
  allowedLibraryNameContains?: string[];
  allowedFolderContains?: string[];
  filesOnly?: boolean;
  apiUrl?: string;
  apiResource: string;
  flowUrl?: string;
  apiBaseUrl?: string;
  submitEndpoint?: string;
  retractEndpoint?: string;
  FileRefV: string;
  settingsListName?: string;
  settingsColumnName?: string;

  standardLibraryNameContains?: string[];
  standardListIds?: string[];

  standardFlowUrl?: string;
  standardSubmitEndpoint?: string;

  fieldNames?: {
    fileTitle: string;
    fileDescription: string;
    country: string;
    VersionNumber: string;
  };
}

const LOG_SOURCE = 'SubmitForValidationCommandSet';

const FIELD_STATUS = 'status';
const FIELD_PROCESSING = 'ProcessingState';
const FIELD_REVISION = 'RevisionNumber';
const FIELD_SCENARIO = 'scenario';
const FIELD_SCENARIO_DESC = 'scenarioDescription';

type ProcessingState = 'None' | 'InProcess' | 'Completed' | 'Failed';

export default class SubmitForValidationCommandSet
  extends BaseListViewCommandSet<ISubmitToFlowProps> {

  private _container: HTMLDivElement | null = null;

  private _permissionCache = new Map<string, boolean>();

  private _permissionPromiseCache = new Map<string, Promise<void>>();

  private _lastPermissionKey: string | null = null;

  private _lastSelectedItemId: number | null = null;

  private _folderPermissionCache = new Map<string, boolean>();

  private _folderPermissionPromiseCache = new Map<string, Promise<void>>();

  public async onInit(): Promise<void> {

    if (!this.properties.allowedLibraryNameContains) this.properties.allowedLibraryNameContains = [];
    if (!this.properties.allowedFolderContains) this.properties.allowedFolderContains = [];
    if (this.properties.filesOnly === undefined) this.properties.filesOnly = true;
    if (!this.properties.submitEndpoint) this.properties.submitEndpoint = 'opportunity-round/stakeholder-input/submit';
    if (!this.properties.retractEndpoint) this.properties.retractEndpoint = 'opportunity-round/stakeholder-input/retract';
    if (!this.properties.standardLibraryNameContains) this.properties.standardLibraryNameContains = [];
    if (!this.properties.standardListIds) this.properties.standardListIds = [];
    if (!this.properties.standardSubmitEndpoint) this.properties.standardSubmitEndpoint = 'standard-input';
    if (!this.properties.fieldNames) {
      this.properties.fieldNames = {
        fileTitle: 'fileTitle',
        fileDescription: 'fileDescription',
        country: 'country',
        VersionNumber: 'VersionNumber'
      };
    }

    await this._loadAllowedFolderCodes();
    return Promise.resolve();
  }

  // Check if combination of selected version, submission type script exists for given stakeholder in sp doc library.
  private async _checkScriptExists(
    stakeholder: string,
    versionNumber: string,
    submissionType: string
  ): Promise<boolean> {

    const siteUrl = this.context.pageContext.web.absoluteUrl;
    const webServerRelativeUrl =
      this.context.pageContext.web.serverRelativeUrl;

    const scriptFolder =
      `${webServerRelativeUrl}/Scripts/${stakeholder}`;

    const escapeOData = (value: string): string =>
      value.replace(/'/g, "''");

    const url =
      `${siteUrl}/_api/web/lists/getbytitle('Scripts')/items` +
      `?$select=Id,FileLeafRef,FileRef,VersionNumber,Status,ScriptType` +
      `&$filter=` +
      `FileDirRef eq '${escapeOData(scriptFolder)}'` +
      ` and VersionNumber eq '${escapeOData(versionNumber)}'` +
      ` and Status eq '${escapeOData(submissionType)}'` +
      ` and ScriptType eq 'Submit'`;

    const response = await this.context.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1,
      {
        headers: {
          Accept: "application/json;odata=nometadata"
        }
      }
    );

    if (!response.ok) {
      throw new Error(
        `Unable to check Scripts library (${response.status})`
      );
    }

    const data = await response.json();

    return Array.isArray(data.value) && data.value.length > 0;
  }

  private async _loadAllowedFolderCodes(): Promise<void> {
    try {
      const listName = this.properties.settingsListName || "InputTemplate";
      const fieldName = this.properties.settingsColumnName || "Code";
      const url =
        `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=${fieldName}`;
      const res = await this.context.spHttpClient.get(url, SPHttpClient.configurations.v1);
      if (!res.ok) {
        console.error("Failed to load folder codes:", await res.text());
        return;
      }
      const data = await res.json();
      const codes = (data.value || [])
        .map((item: any) => item[fieldName])
        .filter((v: string) => !!v);
      this.properties.allowedFolderContains = codes;

    } catch (err) {
      console.error("Error loading folder codes:", err);
    }
  }


  private _getFolderFromFileRef(fileRef: string): string {
    if (!fileRef || fileRef.lastIndexOf('/') === -1) return '';
    return fileRef.substring(0, fileRef.lastIndexOf('/'));
  }


  public onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void {

    const submitCmd = this.tryGetCommand('SubmitToFlow');
    const retractCmd = this.tryGetCommand('RetractSubmission');
    const validateStdCmd = this.tryGetCommand('SubmitfileStandardInput');
    const opportunityDetailPageCmd = this.tryGetCommand('OpportunityDetailPage');
    //const RenameCmd = this.tryGetCommand('Rename');
    const oneSelected = (event.selectedRows?.length ?? 0) === 1;
    if (!oneSelected) {
      submitCmd && (submitCmd.visible = false);
      retractCmd && (retractCmd.visible = false);
      validateStdCmd && (validateStdCmd.visible = false);
      opportunityDetailPageCmd && (opportunityDetailPageCmd.visible = false);
      //RenameCmd && (RenameCmd.visible = false);
      this._lastPermissionKey = null;
      this._lastSelectedItemId = null
      return;
    }

    const row = event.selectedRows[0];
    const itemId = Number(row.getValueByName('ID'));

    if (this._lastSelectedItemId === itemId) {
      return;
    }
    this._lastSelectedItemId = itemId;

    const fsObjType = row.getValueByName('FSObjType');
    const isFile = (fsObjType === 0 || fsObjType === '0');
    const isFolder = (fsObjType === 1 || fsObjType === '1');

    // if (RenameCmd) {
    //   RenameCmd.visible = oneSelected;
    // }

    const listTitle = this.context.pageContext.list?.title || '';
    const listTitleLower = listTitle.toLowerCase();

    const listId = this.context.pageContext.list?.id?.toString() || 'unknown';
    const cacheKey = `${listId}_${itemId}`;


    if (isFolder && this._lastPermissionKey === cacheKey) {
      this._lastPermissionKey = null;
    }


    const statusValue = (row.getValueByName(FIELD_STATUS) || '').toString();
    const retractAllowedStatus =
      (statusValue === "Pending Approval");
    const submitAllowedStatus =
      (statusValue === "Draft" ||
        statusValue === "Rejected" ||
        statusValue === "Validation Failed" ||
        statusValue === "Retracted");
    const submitStandardAllowedStatus =
      (statusValue === "Draft" ||
        statusValue === "Validation Failed");

    const libTokens = this.properties.allowedLibraryNameContains || [];
    const libraryNameMatch =
      libTokens.length === 0
        ? true
        : libTokens.some(t => listTitleLower.includes((t || '').toLowerCase()));
    const fileRef = (row.getValueByName && row.getValueByName('FileRef')) || '';

    const folderRef = this._getFolderFromFileRef(fileRef);
    const folderCacheKey = `${listId}_${folderRef}`;

    const folderCached = this._folderPermissionCache.get(folderCacheKey);
    const folderChecking = this._folderPermissionPromiseCache.has(folderCacheKey);

    if (folderCached === undefined && !folderChecking && folderRef) {

      const promise = this._hasEditPermissionOnFolder(fileRef)
        .then(result => {
          this._folderPermissionCache.set(folderCacheKey, result);
        })
        .finally(() => {
          this._folderPermissionPromiseCache.delete(folderCacheKey);
          this.raiseOnChange();
        });

      this._folderPermissionPromiseCache.set(folderCacheKey, promise);
    }

    const path = (fileRef || '').toString().toLowerCase();
    const folderTokens = this.properties.allowedFolderContains || [];
    const folderMatch =
      folderTokens.length === 0
        ? true
        : folderTokens.some(t => path.includes((t || '').toLowerCase()));
    let isFileOk = true;
    if (this.properties.filesOnly) {
      const fsObjType = row.getValueByName('FSObjType');
      isFileOk = (fsObjType === 0 || fsObjType === '0');
    }
    const procVal = (row.getValueByName(FIELD_PROCESSING) || '').toString();
    const notInProcess = procVal !== 'InProcess';


    const checkoutUser = row.getValueByName('CheckoutUser');
    const currentUserEmail =
      this.context.pageContext.user?.email?.toLowerCase();

    const isCheckedOutByOther =
      checkoutUser &&
      checkoutUser.email &&
      checkoutUser.email.toLowerCase() !== currentUserEmail;

    if (isCheckedOutByOther) {
      submitCmd && (submitCmd.visible = false);
    }

    //Rename Visibility
    // if (RenameCmd) {
    //   RenameCmd.visible =
    //     oneSelected &&
    //     libraryNameMatch &&
    //     !isCheckedOutByOther &&
    //     notInProcess &&
    //     ['Draft', 'Rejected', 'Retracted'].includes(statusValue) &&
    //     (isFile || isFolder);
    // }


    // if (submitCmd) {
    //   submitCmd.visible = oneSelected && libraryNameMatch && folderMatch && isFileOk && submitAllowedStatus && notInProcess;
    // }

    // if (submitCmd) {
    //   submitCmd.visible =
    //     oneSelected &&
    //     isFileOk &&
    //     submitAllowedStatus &&
    //     folderCached === true;
    // }

    if (submitCmd) {
      submitCmd.visible =
        oneSelected &&
        isFileOk &&
        libraryNameMatch &&
        // folderMatch &&
        submitAllowedStatus &&
        notInProcess &&
        !isCheckedOutByOther;
    }



    // if (submitCmd) {
    //   submitCmd.visible =
    //     oneSelected &&
    //     isFileOk &&
    //     submitAllowedStatus;

    //   submitCmd.disabled = folderCached === undefined || folderCached === false;
    //   submitCmd.title =
    //     folderCached === undefined
    //       ? "Checking access..."
    //       : folderCached === false
    //         ? "You do not have permission"
    //         : "Submit for validation";
    // }

    // if (retractCmd) {
    //   retractCmd.visible = oneSelected && libraryNameMatch && folderMatch && isFileOk && retractAllowedStatus;
    // }

    // if (retractCmd) {
    //   retractCmd.visible =
    //     oneSelected &&
    //     isFileOk &&
    //     retractAllowedStatus &&
    //     folderCached === true;
    // }

    // if (retractCmd) {
    //   retractCmd.visible =
    //     oneSelected &&
    //     isFileOk &&
    //     retractAllowedStatus;

    //   retractCmd.disabled = folderCached === undefined || folderCached === false;
    //   retractCmd.title =
    //     folderCached === undefined
    //       ? "Checking access..."
    //       : folderCached === false
    //         ? "You do not have permission"
    //         : "Retract submission";
    // }

    if (retractCmd) {
      retractCmd.visible =
        oneSelected &&
        isFileOk &&
        retractAllowedStatus;
    }

    // const validateStdCmd = this.tryGetCommand('SubmitfileStandardInput');
    if (validateStdCmd) {
      const listId = (this.context.pageContext.list?.id?.toString() || '').toLowerCase();
      // const stdIdMatch = (this.properties.standardListIds || [])
      //   .some(id => (id || '').toLowerCase() === listId);
      const stdNameMatch = (this.properties.standardLibraryNameContains || []).length === 0
        ? true
        : (this.properties.standardLibraryNameContains || [])
          .some(t => listTitle.toLowerCase().includes((t || '').toLowerCase()));
      // const standardLibraryMatch = stdIdMatch || stdNameMatch;
      const standardLibraryMatch = stdNameMatch;

      validateStdCmd.visible = oneSelected && isFileOk && standardLibraryMatch && folderMatch && submitStandardAllowedStatus;
    }

    // const opportunityDetailPageCmd = this.tryGetCommand('OpportunityDetailPage');
    if (opportunityDetailPageCmd) {
      if (!oneSelected) {
        opportunityDetailPageCmd.visible = false;
      } else {
        const row = event.selectedRows[0];

        const fsObjType = row.getValueByName('FSObjType');
        const isFolder = (fsObjType === 1 || fsObjType === '1');

        const listTitle = (this.context.pageContext.list?.title || '').toLowerCase();
        const libTokens = this.properties.allowedLibraryNameContains || [];
        const libraryNameMatch =
          libTokens.length === 0
            ? true
            : libTokens.some(t => listTitle.includes((t || '').toLowerCase()));

        const fileRef: string = String(row.getValueByName('FileRef') || '');
        const isOppLevel = this._isOpportunityFolder(fileRef);

        opportunityDetailPageCmd.visible = isFolder && libraryNameMatch && isOppLevel;
      }
    }

  }

  public async onExecute(event: IListViewCommandSetExecuteEventParameters): Promise<void> {
    const selected = event.selectedRows[0];
    if (!selected) return;

    const listTitle = this.context.pageContext.list?.title || '';
    const itemId = Number(selected.getValueByName('ID'));
    const fileRef = String(selected.getValueByName('FileRef') || '');

    try {
      this._showToastLoader("Checking permissions...");

      switch (event.itemId) {

        case 'SubmitToFlow': {
          const canEditFile = await this._hasEditPermissionOnItem(listTitle, itemId);
          if (!canEditFile) {
            this._hideToastLoader(0);
            await Dialog.alert("You don't have permission to submit this file.");
            return;
          }
          this._hideToastLoader(0);
          this._handleSubmit(selected);
          break;
        }

        case 'RetractSubmission': {
          const canEditFolder = await this._hasEditPermissionOnFolder(fileRef);
          if (!canEditFolder) {
            this._hideToastLoader(0);
            await Dialog.alert("You don't have permission to retract this submission.");
            return;
          }
          this._hideToastLoader(0);
          this._handleRetract(selected);
          break;
        }

        case 'SubmitfileStandardInput': {
          const canEditFile = await this._hasEditPermissionOnItem(listTitle, itemId);
          if (!canEditFile) {
            this._hideToastLoader(0);
            await Dialog.alert("You don't have permission to modify this file.");
            return;
          }
          this._hideToastLoader(0);
          this._handleValidateStandardInputfile(selected);
          break;
        }

        case 'OpportunityDetailPage': {
          this._hideToastLoader(0);
          this._handleOpenDynamicUrlForFolder(selected);
          break;
        }

        // case 'Rename': {
        //   this._hideToastLoader(0);
        //   this._handleRename(selected);
        //   break;
        // }
      }

    } catch (err: any) {
      this._hideToastLoader(0);
      await Dialog.alert(err?.message || "Unexpected error occurred.");
    }
  }

  private async _handleSubmit(selectedRow: any): Promise<void> {
    this.properties.FileRefV = selectedRow.getValueByName('FileRef');
    const payloadFileInfo = {
      ID: selectedRow.getValueByName('ID'),
      FileLeafRef: selectedRow.getValueByName('FileLeafRef'),
      FileRef: selectedRow.getValueByName('FileRef'),
      ContentTypeId: selectedRow.getValueByName('ContentTypeId')
    };

    // Selected File Name Validation
    const fileName = String(payloadFileInfo.FileLeafRef || '').trim();

    // File name length validation
    if (fileName.length > 80) {
      await Dialog.alert(
        'File name cannot exceed 80 characters. Please rename the file and try again.'
      );
      return;
    }

    // Invalid file name characters
    const invalidFileNameCharacters = /[#%*:<>?\/\\|+']/g;

    const invalidCharactersFound = fileName.match(invalidFileNameCharacters);

    if (invalidCharactersFound) {
      const uniqueInvalidCharacters = invalidCharactersFound
        .filter((char, index, array) => array.indexOf(char) === index)
        .join(' ');

      await Dialog.alert(
        `File name contains invalid characters.\n\nInvalid character(s) found: ${uniqueInvalidCharacters}\n\nThese characters are not allowed: # % * : < > ? / \\ | + '\n\nUpdate the filename and resubmit.`
      );

      return;
    }


    if (!this._container) {
      this._container = document.createElement('div');
      document.body.appendChild(this._container);
    }
    const onDismiss = () => {
      if (this._container) ReactDom.unmountComponentAtNode(this._container);
    };
    const onSubmit = async (args: ISubmitArgs) => {
      try {
        if (!this.properties.apiBaseUrl) {
          await Dialog.alert('API Base URL is not configured.');
          return;
        }
        if (!this.properties.flowUrl) {
          await Dialog.alert('Flow URL is not configured.');
          return;
        }
        const listTitle = this.context.pageContext.list?.title || '';
        const itemId = Number(payloadFileInfo.ID);
        const itemInfo = await this._getItemInfo(listTitle, itemId);
        const processingState: ProcessingState = (itemInfo?.[FIELD_PROCESSING] || 'None') as ProcessingState;
        if (processingState === 'InProcess') {
          await Dialog.alert('This file is already under automated validation.');
          return;
        }
        const currentFileRef: string = payloadFileInfo.FileRef || '';
        const currentDir: string = this._getFileDirRefFromFileRef(currentFileRef);
        const pendingSameScenario = await this._findPendingInSameFolderAndScenario({
          listTitle,
          fileDirRef: currentDir,
          scenarioKey: args.scenarioName,
          excludeItemId: itemId
        });
        if (pendingSameScenario.length > 0) {
          await Dialog.alert('A file with the same dataset is already pending approval in this folder. Please retract the existing submission before uploading a new file for validation.');
          return;
        }
        const submissionType = args.isDraft ? "Draft" : "Final";
        if (submissionType === "Draft") {

          const finalAlreadyApproved =
            await this._hasApprovedFinalSubmission({
              listTitle,
              fileDirRef: currentDir,
              scenarioKey: args.scenarioName,
              excludeItemId: itemId
            });

          if (finalAlreadyApproved) {
            await Dialog.alert(
              "A Final submission for this dataset has already been approved. Draft submissions are no longer allowed."
            );
            return;
          }
        }
        //let vNumber = args.selection.versionNumber;
        const vNumber = String(args.selection.versionNumber || "").trim();
        let flowJson: any = null;
        let processedData: any = {};

        const scriptExists = await this._checkScriptExists(
          args.selection.stakeholder,
          vNumber,
          submissionType
        );
        if (args.selection.stakeholderType != "Adhoc") {
          const scriptExists = await this._checkScriptExists(
            args.selection.stakeholder,
            vNumber,
            submissionType
          );

          if (!scriptExists) {
            await Dialog.alert(
              `No Submit script is available for ${args.selection.stakeholder} with Version ${vNumber} and Status ${submissionType}. Please contact your Pricer.`
            );
            return;
          }
        }

        if (args.selection.stakeholderType != "Adhoc") {
          const flowBody = {
            eventType: 'submitForValidation',
            fileInfo: payloadFileInfo,
            scenarioFormKey: args.scenarioName,
            scenarioFormDescription: args.scenarioDescription,
            ValidationComment: args.comment,
            listTitle,
            triggeredBy: this.context.pageContext.user?.displayName,
            triggeredByLogin: this.context.pageContext.user?.loginName,
            leadPricerEmail: args.selection.leadPricerEmail,
            StakeholderEmails: args.selection.stakeholderEmails,
            opportunityName: args.selection.opportunityName,
            stakeholderInputTemplateName: args.selection.stakeholderInputTempName,
            mainOpportunityFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + args.selection.regionName + "/" + args.selection.customerName + "/" + args.selection.opportunityName,
            costInputTemplateFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + args.selection.regionName + "/" + args.selection.customerName + "/" + args.selection.opportunityName + "/RND " + args.selection.roundNumber + "/" + args.selection.stakeholder,
            webValidationUrl: this.context.pageContext.web.serverRelativeUrl,
            timestamp: new Date().toISOString(),
            opportunityId: args.selection.opportunityId,
            roundId: args.selection.roundId,
            roundNumber: args.selection.roundNumber,
            stakeholder: args.selection.stakeholder,
            fileRelPath: payloadFileInfo.FileRef,
            siteUrl: (window as any)._spPageContextInfo.webAbsoluteUrl,
            countryName: args.selection.countryName,
            bidTeamMembers: args.selection.bidTeamMembers,
            additionalTeamMembers: args.selection.additionalTeamMembers,
            submissionType,
            versionNumber: vNumber,
            stakeholderType: args.selection.stakeholderType
          };
          const flowHttpRes = await fetch(this.properties.flowUrl!, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(flowBody)
          });
          if (!flowHttpRes.ok) {
            const txt = await flowHttpRes.text();
            throw new Error(`Flow call failed (${flowHttpRes.status}): ${txt}`);
          }

          try { flowJson = await flowHttpRes.json(); } catch { flowJson = null; }
          processedData = (flowJson && typeof flowJson === 'object')
            ? (() => { const c = { ...flowJson }; delete (c as any).success; return c; })()
            : null;
          if (!processedData || typeof processedData !== 'object') {
            await Dialog.alert('Your file could not be processed and has been rejected during technical validation.Please review the issues, update your file, and submit again. If needed, please contact your pricer for support.');
            return;
          }
        }
        const submitBody = {
          opportunityId: args.selection.opportunityId,
          roundId: args.selection.roundId,
          roundNumber: args.selection.roundNumber,
          stakeholderCode: args.selection.stakeholder,
          scenarioName: args.scenarioName,
          fileRelPath: payloadFileInfo.FileRef,
          processedData: processedData,
          userStatus: 'Submitted',
          versionNumber: vNumber,
          submissionType
        };
        const submitRes = await this._callApi(this.properties.submitEndpoint!, submitBody);
        if (submitRes.error) {
          throw new Error(submitRes.message || 'Submit failed.');
        }
        const submitJson = submitRes.data || {};
        const revisionNumberFromSubmit: number = Number(submitJson.revisionNumber);
        const flowBodyRevision = {
          eventType: 'setRevisionNo',
          fileInfo: payloadFileInfo,
          webValidationUrl: this.context.pageContext.web.serverRelativeUrl,
          timestamp: new Date().toISOString(),
          opportunityId: args.selection.opportunityId,
          roundId: args.selection.roundId,
          roundNumber: args.selection.roundNumber,
          stakeholder: args.selection.stakeholder,
          fileRelPath: payloadFileInfo.FileRef,
          siteUrl: (window as any)._spPageContextInfo.webAbsoluteUrl,
          RevisionNo: revisionNumberFromSubmit,
          scenarioFormKey: args.scenarioName,
          scenarioFormDescription: args.scenarioDescription,
          ValidationComment: args.comment,
          listTitle,
          triggeredBy: this.context.pageContext.user?.displayName,
          triggeredByLogin: this.context.pageContext.user?.loginName,
          leadPricerEmail: args.selection.leadPricerEmail,
          StakeholderEmails: args.selection.stakeholderEmails,
          opportunityName: args.selection.opportunityName,
          stakeholderInputTemplateName: args.selection.stakeholderInputTempName,
          mainOpportunityFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + args.selection.regionName + "/" + args.selection.customerName + "/" + args.selection.opportunityName,
          costInputTemplateFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + args.selection.regionName + "/" + args.selection.customerName + "/" + args.selection.opportunityName + "/RND " + args.selection.roundNumber + "/" + args.selection.stakeholder,
          countryName: args.selection.countryName,
          bidTeamMembers: args.selection.bidTeamMembers,
          additionalTeamMembers: args.selection.additionalTeamMembers,
          submissionType,
          versionNumber: vNumber,
          stakeholderType: args.selection.stakeholderType
        };
        const flowHttpResRe = fetch(this.properties.flowUrl!, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(flowBodyRevision)
        });
        // if (!flowHttpResRe.ok) {
        //   const txt = flowHttpResRe.text();
        //   throw new Error(`Flow call failed (${flowHttpResRe.status}): ${txt}`);
        // }
        if (args.selection.stakeholderType != "Adhoc") {
          await Dialog.alert('Your file has been successfully processed. Technical validations have passed and your input has been uploaded. The pricer has been notified and will proceed with validation');
        } else {
          await Dialog.alert('Your file has been successfully processed and your input has been uploaded. The pricer has been notified and will proceed with validation');
        }
        this._refreshView();
        onDismiss();
      } catch (e) {
        await Dialog.alert(`Error: ${(e as Error).message}`);
      }
    };

    const element: React.ReactElement<IPanelUIProps> = React.createElement(
      PanelUI,
      {
        isOpen: true,
        title: 'Submit For Validation',
        apiBaseUrl: this.properties.apiBaseUrl,
        apiResource: this.properties.apiResource,
        apiUrl: this.properties.apiUrl,
        currentWebUrl: this.context.pageContext.web.absoluteUrl,
        currentFolderUrl: this.properties.FileRefV,
        //fileName: payloadFileInfo.FileLeafRef,
        context: this.context,
        onDismiss,
        onSubmit
      }
    );
    ReactDom.render(element, this._container);
  }

  private async _handleRetract(selectedRow: any): Promise<void> {
    try {
      if (!this.properties.apiBaseUrl) {
        await Dialog.alert('API Base URL is not configured.');
        return;
      }


      const listTitle = this.context.pageContext.list?.title || '';
      const itemId = Number(selectedRow.getValueByName('ID'));
      const fileRef = String(selectedRow.getValueByName('FileRef') || '');

      const versionNumber = String(selectedRow.getValueByName('versionNumber') || '');
      const submissionType = String(selectedRow.getValueByName('submissionType') || '');

      const confirm = window.confirm(
        'Are you sure you want to retract this submission?'
      );

      if (!confirm) return;

      OverlaySpinner.show('Retracting the file...');


      OverlaySpinner.show('Retracting the file...');

      const resolved = await this._resolveSelectionFromFolder(fileRef);
      if (!resolved) {
        throw new Error(
          'Unable to resolve opportunity/round/stakeholder from folder path.'
        );
      }

      const scenarioFromItem =
        (selectedRow.getValueByName(FIELD_SCENARIO) || '').toString();

      const scenarioName =
        scenarioFromItem || resolved.defaultScenarioKey || '';


      const scenarioDescFromItem =
        (selectedRow.getValueByName(FIELD_SCENARIO_DESC) || '').toString();

      const scenarioDesc =
        scenarioDescFromItem || resolved.defaultScenarioKeyDesc || '';


      if (!scenarioName) {
        throw new Error(
          'Dataset key is missing on the item. Please open the panel and submit once.'
        );
      }

      const retractRes = await this._callApi(
        this.properties.retractEndpoint!,
        {
          opportunityId: resolved.opportunityId,
          roundId: resolved.roundId,
          stakeholderCode: resolved.stakeholderFolder,
          roundNumber: resolved.roundNumber,
          scenarioName,
          versionNumber,
          submissionType
        },
        { treat404AsSuccess: false }
      );

      if (retractRes.error && retractRes.statusCode === 404) {
        throw new Error('Nothing to retract for this item (not found).');
      }


      if (retractRes.error) {
        throw new Error(retractRes.message || 'Retract failed.');
      }


      const payloadFileInfo = {
        ID: selectedRow.getValueByName('ID'),
        FileLeafRef: selectedRow.getValueByName('FileLeafRef'),
        FileRef: selectedRow.getValueByName('FileRef'),
        ContentTypeId: selectedRow.getValueByName('ContentTypeId')
      };
      // const trigerbyEmail = this.context.pageContext.user?.loginName;
      const flowBody = {
        eventType: 'retractSubmission',
        fileInfo: payloadFileInfo,
        listTitle,
        webValidationUrl: this.context.pageContext.web.serverRelativeUrl,
        siteUrl: (window as any)._spPageContextInfo.webAbsoluteUrl,
        opportunityName: resolved.opportunityName,
        stakeholderInputTemplateName: resolved.stakeholderInputTempName,
        mainOpportunityFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + resolved.regionName + "/" + resolved.customerName + "/" + resolved.opportunityName,
        costInputTemplateFolderLink: (window as any)._spPageContextInfo.webAbsoluteUrl + "/" + resolved.regionName + "/" + resolved.customerName + "/" + resolved.opportunityName + "/RND " + resolved.roundNumber + "/" + resolved.stakeholderFolder,
        triggeredBy: this.context.pageContext.user?.displayName,
        triggeredByLogin: resolved.notifyUsersEmail,
        leadPricerEmail: resolved.leadPricerEmail,
        scenarioFormKey: scenarioName,
        scenarioFormDescription: scenarioDesc,
        roundNumber: resolved.roundNumber,
      };
      const flowHttpRes = await fetch(this.properties.flowUrl!, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(flowBody)
      });


      if (!flowHttpRes.ok) {
        const txt = await flowHttpRes.text();
        await this._updateItemFields(listTitle, itemId, {
          [FIELD_PROCESSING]: 'Failed',
          [FIELD_STATUS]: 'Retract Failed'
        });
        throw new Error(`Flow call failed (${flowHttpRes.status}): ${txt}`);
      }
      await this._updateItemFields(listTitle, itemId, {
        [FIELD_PROCESSING]: 'None',
        [FIELD_STATUS]: 'Retracted'
      });

      OverlaySpinner.hide();

      await Dialog.alert('Your submission has been successfully retracted. The pricer has been notified and will no longer proceed with validation of this file. Please update your input and submit again when ready.');
      this._refreshView();


    } catch (err) {
      OverlaySpinner.hide();
      OverlaySpinner.hide();
      await Dialog.alert(`Error: ${(err as Error).message}`);
    }
  }

  private async _handleValidateStandardInputfile(selectedRow: any): Promise<void> {
    try {
      const listTitle = this.context.pageContext.list?.title || '';
      const itemId = Number(selectedRow.getValueByName('ID'));
      const fileRef: string = String(selectedRow.getValueByName('FileRef') || '');
      const fileLeafRef: string = String(selectedRow.getValueByName('FileLeafRef') || '');
      const contentTypeId: string = String(selectedRow.getValueByName('ContentTypeId') || '');

      const f = this.properties.fieldNames!;
      const stdItem = await this._getStdFields(listTitle, itemId, f);

      const countryChoices = await this._getCountryLookupChoices(listTitle, f.country);

      const partsFile = fileRef.split('/').filter(Boolean);

      const stakeholderFolderCurrent =
        partsFile[partsFile.length - 2];

      const versionOptions =
        await this._getVersionChoices(
          stakeholderFolderCurrent
        );

      if (!this._container) {
        this._container = document.createElement('div');
        document.body.appendChild(this._container);
      }

      const onDismiss = () => {
        if (this._container) ReactDom.unmountComponentAtNode(this._container);
      };

      const onSubmit = async (args: { fileTitle: string; fileDescription: string; countryId: number; versionNumber: string; }) => {
        await this._updateItemFields(listTitle, itemId, {
          [f.fileTitle]: args.fileTitle,
          [f.fileDescription]: args.fileDescription,
          [`${f.country}Id`]: args.countryId,
          [f.VersionNumber]: args.versionNumber,
        });

        const standardFlowUrl = this.properties.flowUrlStandard || this.properties.flowUrlStandard;
        if (!standardFlowUrl) {
          await Dialog.alert('Flow URL (standardFlowUrl / flowUrl) is not configured.');
          return;
        }

        const selectedCountry = countryChoices.find(c => c.id === args.countryId);
        const submissionType = "Final";
        const flowBody = {
          eventType: 'validateStandardInputfile',
          listTitle,
          itemId,
          fileInfo: {
            ID: itemId,
            FileLeafRef: fileLeafRef,
            FileRef: fileRef,
            ContentTypeId: contentTypeId
          },
          fields: {
            fileTitle: args.fileTitle,
            fileDescription: args.fileDescription,
            countryId: selectedCountry?.id,
            countryName: selectedCountry?.title,
            countryCode: selectedCountry?.code
          },
          triggeredBy: this.context.pageContext.user?.displayName,
          triggeredByLogin: this.context.pageContext.user?.loginName,
          webServerRelativeUrl: this.context.pageContext.web.serverRelativeUrl,
          timestamp: new Date().toISOString(),
          siteUrl: (window as any)._spPageContextInfo.webAbsoluteUrl,
          stakeholder: stakeholderFolderCurrent,
          versionNumber: args.versionNumber,
          submissionType: submissionType
        };

        const flowHttpRes = await fetch(standardFlowUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(flowBody)
        });
        if (!flowHttpRes.ok) {
          const txt = await flowHttpRes.text();
          throw new Error(`Flow call failed (${flowHttpRes.status}): ${txt}`);
        }

        let flowJson: any = null;
        try { flowJson = await flowHttpRes.json(); } catch { flowJson = null; }

        if (!this.properties.apiBaseUrl) {
          await Dialog.alert('API Base URL is not configured.');
          return;
        }

        const standardSubmitEndpoint = this.properties.standardSubmitEndpoint!;
        const countryCode = selectedCountry ? selectedCountry.code : '';
        const parts = fileRef.split('/').filter(Boolean);
        const stakeholderFolder = parts[parts.length - 2];

        const submitPayload = {
          stakeholder: stakeholderFolder,
          fileRelPath: fileRef,
          title: args.fileTitle,
          description: args.fileDescription,
          countryCode: countryCode,
          processedData:
            flowJson && typeof flowJson === "object"
              ? flowJson
              : null,
          versionNumber: args.versionNumber
        };

        const submitRes = await this._callApi(standardSubmitEndpoint, submitPayload);
        if (submitRes.error) {
          throw new Error(submitRes.message || 'Standard input submit failed.');
        }

        await Dialog.alert('Validated and submitted successfully.');
        this._refreshView();
        onDismiss();
      };

      const element: React.ReactElement<IStdInputPanelProps> =
        React.createElement(
          StdInputPanel,
          {
            isOpen: true,
            title: 'Validate standard input file',
            onDismiss,
            onSubmit,

            countryOptions: countryChoices.map(c => ({
              key: c.id,
              text: c.title
            })),

            versionOptions,

            defaultValues: {
              fileTitle: stdItem.fileTitle || '',
              fileDescription: stdItem.fileDescription || '',
              countryId: stdItem.countryId,
              versionNumber: ''
            }
          }
        );
      ReactDom.render(element, this._container);

    } catch (e) {
      await Dialog.alert(`Error: ${(e as Error).message}`);
    }
  }

  // private async _handleRename(selectedRow: any): Promise<void> {

  //   try {

  //     const itemId = Number(
  //       selectedRow.getValueByName('ID')
  //     );

  //     const currentFileName = String(
  //       selectedRow.getValueByName('FileLeafRef') || ''
  //     );

  //     const fileRef = String(
  //       selectedRow.getValueByName('FileRef') || ''
  //     );

  //     if (!itemId) {
  //       await Dialog.alert(
  //         'Unable to determine the selected file ID.'
  //       );
  //       return;
  //     }

  //     if (!currentFileName) {
  //       await Dialog.alert(
  //         'Unable to determine the current file name.'
  //       );
  //       return;
  //     }

  //     if (!this._container) {
  //       this._container = document.createElement('div');
  //       document.body.appendChild(this._container);
  //     }

  //     const onDismiss = () => {

  //       if (this._container) {
  //         ReactDom.unmountComponentAtNode(
  //           this._container
  //         );
  //       }

  //     };

  //     const onSave = async (
  //       newFileName: string
  //     ): Promise<void> => {

  //       const flowUrl = this.properties.flowUrl;

  //       if (!flowUrl) {
  //         await Dialog.alert(
  //           'Power Automate Flow URL is not configured.'
  //         );
  //         return;
  //       }

  //       try {

  //         const flowPayload = {

  //           itemId,
  //           currentFileName,
  //           newFileName,
  //           fileRef,
  //           eventType: "Rename",
  //           //common Flow fields
  //           siteUrl:
  //             this.context.pageContext.web.absoluteUrl,

  //           webServerRelativeUrl:
  //             this.context.pageContext.web.serverRelativeUrl,

  //           listTitle:
  //             this.context.pageContext.list?.title || '',

  //           triggeredBy:
  //             this.context.pageContext.user?.displayName || '',

  //           triggeredByLogin:
  //             this.context.pageContext.user?.loginName || '',

  //           timestamp:
  //             new Date().toISOString()
  //         };

  //         // console.log(
  //         //   'Rename Flow Payload:',
  //         //   flowPayload
  //         // );

  //         const response = await fetch(
  //           flowUrl,
  //           {
  //             method: 'POST',

  //             headers: {
  //               'Content-Type': 'application/json'
  //             },

  //             body: JSON.stringify(
  //               flowPayload
  //             )
  //           }
  //         );

  //         if (!response.ok) {

  //           const errorText =
  //             await response.text();

  //           throw new Error(
  //             `Rename Flow failed (${response.status}): ${errorText}`
  //           );
  //         }

  //         onDismiss();
  //         await Dialog.alert(
  //           'File rename request submitted successfully.'
  //         );

  //         this._refreshView();

  //       } catch (error: any) {

  //         console.error(
  //           'Rename Flow Error:',
  //           error
  //         );

  //         await Dialog.alert(
  //           error?.message ||
  //           'Failed to submit rename request.'
  //         );
  //       }
  //     };
  //     const element: React.ReactElement<IRenameDialogProps> =
  //       React.createElement(
  //         RenameDialog,
  //         {
  //           isOpen: true,
  //           title: 'Rename File',
  //           currentFileName,
  //           onDismiss,
  //           onSave
  //         }
  //       );

  //     ReactDom.render(
  //       element,
  //       this._container
  //     );

  //   } catch (err: any) {

  //     await Dialog.alert(
  //       `Unable to open Rename: ${err?.message || 'Unknown error'
  //       }`
  //     );

  //   }
  // }

  private async _handleOpenDynamicUrlForFolder(selectedRow: any): Promise<void> {
    try {
      this._showToastLoader("Opening opportunity detail page....");

      const apiUrl = this.properties.apiUrl;
      if (!apiUrl) {
        await Dialog.alert("API URL is not configured.");
        return;
      }

      const fileRef: string = String(selectedRow.getValueByName('FileRef') || '');
      if (!this._isOpportunityFolder(fileRef)) {
        await Dialog.alert("Please select an opportunity folder.");
        return;
      }

      const oppFolderName: string = String(selectedRow.getValueByName("FileLeafRef") || "").trim();

      const client: AadHttpClient = await this.context.aadHttpClientFactory.getClient(this.properties.apiResource);

      const response: HttpClientResponse = await client.post(
        apiUrl,
        AadHttpClient.configurations.v1,
        {
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            opportunityName: oppFolderName
          })
        }
      );

      const data: any[] = await response.json();
      if (!Array.isArray(data) || data.length === 0) {
        await Dialog.alert("API returned no results.");
        return;
      }

      const first = data[0];

      const opportunityId = first?.opportunityId;

      if (!opportunityId) {
        await Dialog.alert("Opportunity ID not found in API response.");
        return;
      }

      const baseUrl = this.context.pageContext.web.absoluteUrl.replace(/\/$/, "");
      const pageName = "PRISM.aspx";

      const finalUrl = `${baseUrl}/SitePages/${pageName}#/opportunities/${opportunityId}`;

      window.open(finalUrl, "_blank", "noopener,noreferrer");

      this._hideToastLoader(1500);

    } catch (err: any) {
      console.error(err);
      await Dialog.alert("Failed to open dynamic opportunity page.");
    }
  }

  private _apiUrl(path: string): string {
    const base = (this.properties.apiBaseUrl || '').replace(/\/+$/, '');
    const tail = (path || '').replace(/^\/+/, '');
    return `${base}/${tail}`;
  }

  private async _callApi(
    path: string,
    body: any,
    options?: { treat404AsSuccess?: boolean }
  ): Promise<{ error?: boolean; message?: string; data?: any; statusCode?: number }> {

    const url = this._apiUrl(path);

    let response: HttpClientResponse;
    try {

      const client: AadHttpClient = await this.context.aadHttpClientFactory.getClient(this.properties.apiResource);

      response = await client.post(
        url,
        AadHttpClient.configurations.v1,
        {
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(body || {})
        }
      );

    } catch (err: any) {
      return {
        error: true,
        message: err?.message || "Network error calling API",
        statusCode: 0
      };
    }

    const statusCode = response.status;
    let json: any = null;

    try {
      json = await response.json();
    } catch { }

    if (statusCode < 200 || statusCode >= 300) {

      if (statusCode === 404 && options?.treat404AsSuccess) {
        return { error: false, data: json, statusCode };
      }

      const message = json?.message
        ? Array.isArray(json.message)
          ? json.message.join("; ")
          : String(json.message)
        : "API error";

      return { error: true, message, data: json, statusCode };
    }

    return { error: false, data: json, statusCode };
  }

  private async _getItemInfo(listTitle: string, itemId: number): Promise<any> {
    const url =
      `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items(${itemId})` +
      `?$select=Id,Title,FileRef,FileLeafRef,${FIELD_STATUS},${FIELD_PROCESSING},${FIELD_REVISION},${FIELD_SCENARIO}`;
    const res: SPHttpClientResponse = await this.context.spHttpClient.get(url, SPHttpClient.configurations.v1);
    if (!res.ok) throw new Error(`Failed to read item ${itemId} (${res.status})`);
    return await res.json();
  }

  private async _updateItemFields(listTitle: string, itemId: number, fields: Record<string, any>): Promise<void> {
    const url = `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items(${itemId})`;
    const res = await this.context.spHttpClient.post(url, SPHttpClient.configurations.v1, {
      headers: {
        'Content-Type': 'application/json;odata=nometadata',
        'IF-MATCH': '*',
        'X-HTTP-Method': 'MERGE'
      },
      body: JSON.stringify(fields)
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`Failed to update fields: ${t}`);
    }
  }

  // private _refreshView(): void {
  //   [
  //     "[data-automationid='Refresh']",
  //     "[data-automation-key='refreshCommand']",
  //     "[title='Refresh']"
  //   ].forEach(sel => {
  //     const el = document.querySelector(sel);
  //     if (el) (el as HTMLElement).click();
  //   });
  // }

  private _refreshView(): void {
    let refreshed = false;

    [
      "[data-automationid='Refresh']",
      "[data-automation-key='refreshCommand']",
      "[title='Refresh']"
    ].forEach(sel => {
      const el = document.querySelector(sel);
      if (el && !refreshed) {
        refreshed = true;
        (el as HTMLElement).click();
      }
    });

    setTimeout(() => {
      if (!refreshed) {
        window.location.reload();
      }
    }, 1500);
  }

  private _getFileDirRefFromFileRef(fileRef: string): string {
    if (!fileRef) return '';
    const lastSlash = fileRef.lastIndexOf('/');
    return lastSlash > 0 ? fileRef.substring(0, lastSlash) : '';
  }

  private async _resolveSelectionFromFolder(fileRef: string): Promise<{
    opportunityId: number;
    roundId: number;
    roundNumber: number;
    stakeholderFolder: string;
    defaultScenarioKey?: string;
    defaultScenarioKeyDesc?: string;
    opportunityName: string;
    stakeholderInputTempName: string;
    regionName: string;
    customerName: string;
    leadPricerEmail: string;
    notifyUsersEmail: string;
  } | null> {
    try {
      if (!this.properties.apiUrl) return null;
      const parts = (fileRef || '').split('/').filter(Boolean);
      const n = parts.length;
      const stakeholderFolder = parts[n - 2] || '';
      const roundFolder = parts[n - 3] || '';
      const opportunityFolder = parts[n - 4] || '';
      const customerName = parts[n - 5] || "";
      const regionName = parts[n - 6] || "";
      const m = roundFolder.match(/(\d+)/);
      const roundNumber = m && m[1] ? Number(m[1]) : 0;
      const client: AadHttpClient = await this.context.aadHttpClientFactory.getClient(this.properties.apiResource);
      const res = await client.post(
        this.properties.apiUrl,
        AadHttpClient.configurations.v1,
        {
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ opportunityName: opportunityFolder })
        }
      );
      if (!res.ok) return null;
      const data: any[] = await res.json();
      const rec = data.find((d: any) =>
        Number(d.roundNumber) === Number(roundNumber) &&
        (d.stakeholders || []).some((s: any) => s.stakeholder_code === stakeholderFolder)
      );
      if (!rec) return null;
      let defaultScenarioKey: string | undefined;
      let defaultScenarioKeyDesc: string | undefined;
      const stNode = (rec.stakeholders || []).find((s: any) => s.stakeholder_code === stakeholderFolder);
      const stakeholderInputTempName = stNode?.stakeholder || "";
      if (stNode?.applicableScenarios?.length) {
        defaultScenarioKey = stNode.applicableScenarios[0]?.name;
        defaultScenarioKeyDesc = stNode.applicableScenarios[0]?.decc;
      } else if (rec.scenarios?.length) {
        defaultScenarioKey = rec.scenarios[0]?.name;
        defaultScenarioKey = rec.scenarios[0]?.desc;
      }
      const uniqueEmailsleadPricer = Array.from(
        new Set(rec.lead_pricer.map((u: any) => u.email).filter(Boolean)));
      const uniqueEmailsleadPricerString = uniqueEmailsleadPricer.join(";");
      const emailString = Array.from(
        new Set([
          ...(stNode?.notify_users ?? []).map((u: any) => u.email),
          ...(stNode?.additionalStakeholders ?? []).map((u: any) => u.email)
        ].filter(Boolean))
      ).join(";");
      return {
        opportunityId: Number(rec.opportunityId),
        roundId: Number(rec.roundId),
        roundNumber: Number(rec.roundNumber),
        stakeholderFolder,
        defaultScenarioKey,
        defaultScenarioKeyDesc,
        opportunityName: opportunityFolder,
        stakeholderInputTempName,
        regionName,
        customerName,
        leadPricerEmail: uniqueEmailsleadPricerString,
        notifyUsersEmail: emailString
      };
    } catch {
      return null;
    }
  }

  private async _findPendingInSameFolderAndScenario(params: {
    listTitle: string;
    fileDirRef: string;
    scenarioKey: string;
    excludeItemId: number;
  }): Promise<any[]> {
    const { listTitle, fileDirRef, scenarioKey, excludeItemId } = params;
    if (!fileDirRef || !scenarioKey) return [];
    const escapedDir = (fileDirRef || '').replace(/'/g, "''");
    const escapedScenario = (scenarioKey || '').replace(/'/g, "''");
    const url =
      `${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
      `?$select=Id,FileRef,FileLeafRef,${FIELD_STATUS},${FIELD_SCENARIO}` +
      `&$filter=FileDirRef eq '${escapedDir}'` +
      ` and ${FIELD_SCENARIO} eq '${escapedScenario}'` +
      ` and ${FIELD_STATUS} eq 'Pending Approval'` +
      ` and Id ne ${excludeItemId}` +
      `&$top=1`;
    const res = await this.context.spHttpClient.get(url, SPHttpClient.configurations.v1);
    if (!res.ok) return [];
    const json = await res.json();
    return Array.isArray(json?.value) ? json.value : [];
  }

  private async _retractBeforeSubmit(items: any[], scenarioName: string): Promise<void> {
    for (const it of items) {
      const itemId = Number(it.Id);
      const listTitle = this.context.pageContext.list?.title || '';
      const fileRef = String(it.FileRef || '');
      const resolved = await this._resolveSelectionFromFolder(fileRef);
      if (!resolved) {
        console.warn(`Skip retract for item ${itemId} — unable to resolve selection from ${fileRef}`);
        continue;
      }
      await this._updateItemFields(listTitle, itemId, {
        [FIELD_PROCESSING]: 'None',
        [FIELD_STATUS]: 'Retracted'
      });
    }
  }

  private async _getStdFields(
    listTitle: string,
    itemId: number,
    f: { fileTitle: string; fileDescription: string; country: string }
  ): Promise<{ fileTitle?: string; fileDescription?: string; countryId?: number; countryTitle?: string }> {
    const select =
      `Id,${f.fileTitle},${f.fileDescription},${f.country}/Id,${f.country}/Title`;
    const url =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items(${itemId})?` +
      `$select=${select}&$expand=${f.country}`;
    const res = await this.context.spHttpClient.get(url, SPHttpClient.configurations.v1);
    if (!res.ok) throw new Error(`Failed to read item ${itemId} (${res.status})`);
    const raw = await res.json();
    const d = raw?.d || raw;
    const countryVal = d?.[f.country] || null;
    return {
      fileTitle: d?.[f.fileTitle],
      fileDescription: d?.[f.fileDescription],
      countryId: countryVal?.Id,
      countryTitle: countryVal?.Title
    };
  }

  private async _getCountryLookupChoices(
    listTitle: string,
    countryInternalName: string
  ): Promise<{
    code: string; id: number; title: string
  }[]> {
    const fieldUrl =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/fields/getbyinternalnameortitle('${encodeURIComponent(countryInternalName)}')` +
      `?$select=TypeAsString,LookupList,LookupField`;
    const fieldRes = await this.context.spHttpClient.get(fieldUrl, SPHttpClient.configurations.v1);
    if (!fieldRes.ok) throw new Error(`Failed to read lookup field ${countryInternalName} (${fieldRes.status})`);
    const fieldRaw = await fieldRes.json();
    const field = fieldRaw?.d || fieldRaw;
    if ((field?.TypeAsString || '').toLowerCase() !== 'lookup') {
      throw new Error(`Field ${countryInternalName} is not a Lookup.`);
    }
    const lookupListId = (field.LookupList || '').replace(/[{}]/g, '');
    const lookupField = field.LookupField || 'Title';
    const itemsUrl =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists(guid'${lookupListId}')/items?$select=Id,${lookupField},Code&$orderby=${lookupField} asc&$top=5000`;
    const itemsRes = await this.context.spHttpClient.get(itemsUrl, SPHttpClient.configurations.v1);
    if (!itemsRes.ok) throw new Error(`Failed to read lookup items (${itemsRes.status})`);
    const itemsRaw = await itemsRes.json();
    const rows = itemsRaw?.value || itemsRaw?.d?.results || [];
    return rows.map((r: any) => ({
      id: Number(r.Id),
      title: String(r[lookupField] ?? ''),
      code: r.Code
    }));
  }

  private _getListRoot(): string {
    const listAny: any = this.context.pageContext.list as any;
    const fromCtx = (listAny && (listAny.serverRelativeUrl || listAny.rootFolder?.serverRelativeUrl)) || '';
    if (fromCtx) return fromCtx;
    const webRoot = this.context.pageContext.web.serverRelativeUrl.replace(/\/$/, '');
    const title = (this.context.pageContext.list?.title || '').replace(/^\//, '');
    return `${webRoot}/${title}`;
  }

  private _countSegments(p: string): number {
    return (p || '').split('/').filter(Boolean).length;
  }

  private _relativeDepthToListRoot(path: string): number {
    const root = this._getListRoot();
    const nPath = this._countSegments(path);
    const nRoot = this._countSegments(root);
    return nPath - nRoot;
  }

  private _isOpportunityFolder(folderRef: string): boolean {
    const path = (folderRef || '').replace(/\/$/, '');
    const depth = this._relativeDepthToListRoot(path);
    return depth === 2;
  }

  private _showToastLoader(message: string = "Loading…") {
    const old = document.querySelector("#spfx-toast-loader");
    if (old) old.remove();

    const div = document.createElement("div");
    div.id = "spfx-toast-loader";
    div.style.position = "fixed";
    div.style.top = "20px";
    div.style.right = "20px";
    div.style.zIndex = "999999";
    div.style.padding = "12px 18px";
    div.style.background = "rgba(0,0,0,0.75)";
    div.style.color = "white";
    div.style.borderRadius = "6px";
    div.style.display = "flex";
    div.style.alignItems = "center";
    div.style.boxShadow = "0 2px 6px rgba(0,0,0,0.3)";
    div.style.fontSize = "14px";

    div.innerHTML = `
    <div class="ms-Spinner ms-Spinner--small" style="margin-right:10px;"></div>
    <span>${message}</span>
  `;

    document.body.appendChild(div);
  }

  private _hideToastLoader(delay: number = 2000) {
    setTimeout(() => {
      const div = document.querySelector("#spfx-toast-loader");
      if (div) div.remove();
    }, delay);
  }

  private async _hasEditPermissionOnItem(
    listTitle: string,
    itemId: number
  ): Promise<boolean> {

    const url =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items(${itemId})/EffectiveBasePermissions`;

    const res = await this.context.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1
    );

    if (!res.ok) return false;

    const perms = await res.json();

    const permission = new SPPermission(perms);

    return (
      permission.hasPermission(SPPermission.editListItems) ||
      permission.hasPermission(SPPermission.addListItems) ||
      permission.hasPermission(SPPermission.manageLists)
    );
  }

  private async _hasEditPermissionOnFolder(folderRef: string): Promise<boolean> {

    if (!folderRef || folderRef.lastIndexOf('/') === -1) {
      return false;
    }

    const folderPath = folderRef.substring(0, folderRef.lastIndexOf('/'));

    const url =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/GetFolderByServerRelativePath(decodedurl='${folderPath}')/ListItemAllFields/EffectiveBasePermissions`;

    const res = await this.context.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1
    );

    if (!res.ok) return false;

    const perms = await res.json();
    const permission = new SPPermission(perms);

    return (
      permission.hasPermission(SPPermission.editListItems) ||
      permission.hasPermission(SPPermission.manageLists)
    );
  }

  private async _getVersionChoices(
    stakeholderCode: string
  ): Promise<IDropdownOption[]> {

    const url =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists/getbytitle('InputTemplate')/items` +
      `?$select=Id,Code,VersionNumber,Active` +
      `&$filter=Code eq '${stakeholderCode}' and Active eq 1`;

    const res = await this.context.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1
    );

    if (!res.ok) {
      throw new Error('Failed to load versions');
    }

    const data = await res.json();

    return (data.value || []).map((v: any) => ({
      key: v.VersionNumber,
      text: v.VersionNumber
    }));
  }

  private async _hasApprovedFinalSubmission(params: {
    listTitle: string;
    fileDirRef: string;
    scenarioKey: string;
    excludeItemId: number;
  }): Promise<boolean> {

    const { listTitle, fileDirRef, scenarioKey, excludeItemId } = params;

    const escapedDir = fileDirRef.replace(/'/g, "''");
    const escapedScenario = scenarioKey.replace(/'/g, "''");

    const url =
      `${this.context.pageContext.web.absoluteUrl}` +
      `/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
      `?$select=Id,Status,SubmissionType,scenario` +
      `&$filter=` +
      `FileDirRef eq '${escapedDir}'` +
      ` and scenario eq '${escapedScenario}'` +
      ` and Status eq 'Approved'` +
      ` and SubmissionType eq 'Final'` +
      ` and Id ne ${excludeItemId}` +
      `&$top=1`;

    const res = await this.context.spHttpClient.get(
      url,
      SPHttpClient.configurations.v1
    );

    if (!res.ok) {
      return false;
    }

    const json = await res.json();

    return (json.value || []).length > 0;
  }

}