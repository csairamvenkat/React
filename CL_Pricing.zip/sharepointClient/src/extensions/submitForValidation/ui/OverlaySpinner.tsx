import { Spinner, SpinnerSize } from '@fluentui/react';
import * as React from 'react';
import * as ReactDOM from 'react-dom';

export class OverlaySpinner {
  private static readonly containerId = 'spfx-overlay-spinner-root';
  private static visible = false;
  private static message = 'Please wait...';

  public static show(message: string = 'Please wait...'): void {
    this.message = message;

    const container = this.ensureContainer();
    this.render(container);

    if (!this.visible) {
      document.body.style.overflow = 'hidden';
      this.visible = true;
    }
  }

  public static update(message: string): void {
    if (!this.visible) return;

    this.message = message;
    const container = document.getElementById(this.containerId);
    if (container) {
      this.render(container);
    }
  }

  public static hide(): void {
    const container = document.getElementById(this.containerId);
    if (!container) return;

    ReactDOM.unmountComponentAtNode(container);
    document.body.style.overflow = '';
    this.visible = false;
  }

  private static ensureContainer(): HTMLElement {
    let container = document.getElementById(this.containerId);
    if (!container) {
      container = document.createElement('div');
      container.id = this.containerId;
      document.body.appendChild(container);
    }
    return container;
  }

  private static render(container: HTMLElement): void {
    ReactDOM.render(
      <div style={overlayStyle} role="alert" aria-live="assertive">
        <div style={spinnerWrapperStyle}>
          <Spinner label={this.message} size={SpinnerSize.large} />
        </div>
      </div>,
      container
    );
  }
}

const overlayStyle: React.CSSProperties = {
  position: 'fixed',
  inset: 0,
  backgroundColor: 'rgba(255, 255, 255, 0.75)',
  zIndex: 100000,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  pointerEvents: 'all'
};

const spinnerWrapperStyle: React.CSSProperties = {
  backgroundColor: '#ffffff',
  padding: 24,
  borderRadius: 8,
  boxShadow: '0 6px 18px rgba(0,0,0,0.15)',
  minWidth: 260,
  textAlign: 'center'
};