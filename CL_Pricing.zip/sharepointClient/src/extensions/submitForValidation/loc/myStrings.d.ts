declare interface ISubmitForValidationCommandSetStrings {
  Command1: string;
  Command2: string;
}

declare module 'SubmitForValidationCommandSetStrings' {
  const strings: ISubmitForValidationCommandSetStrings;
  export = strings;
}
