import { Opportunity } from "./Models";

export interface IDataProvider {
    list(): Promise<Opportunity[]>;
    get(id: number): Promise<Opportunity | undefined>;
    create(payload: Omit<Opportunity, 'id'>): Promise<Opportunity>;
    update(id: number, patch: Partial<Opportunity>): Promise<Opportunity | null>;
    remove(id: number): Promise<void>;
}