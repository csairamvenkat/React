import * as React from 'react';
import { Opportunity } from "./Models";
import { IDataProvider } from './DataProvider';
import { LocalDataProvider } from '../../api/LocalDataProvider'; 

type OpportunitiesState = {
    provider: IDataProvider;
    opportunities: Opportunity[]
    refresh: () => Promise<void>;
    create: (data: Omit<Opportunity, 'id'>) => Promise<Opportunity>;
    update: (id: number, patchL: Partial<Opportunity>) => Promise<Opportunity | null>;
    remove: (id: number) => Promise<void>;
    byId: (id: number) => Opportunity | undefined;
}

const Ctx = React.createContext<OpportunitiesState | null>(null);

export const OpportunitiesProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
    
    const [provider] = React.useState<IDataProvider>(() => new LocalDataProvider());
    
    const [opportunities, setOpportunities] = React.useState<Opportunity[]>([]);

    const refresh = React.useCallback(async () => {
        setOpportunities(await provider.list());
    }, [provider]);

    React.useEffect(() => { void refresh(); }, [refresh]);

    const create = async(data: Omit<Opportunity, 'id'>) => {
        const created = await provider.create(data);
        await refresh();
        return created;
    };

    const update = async(id: number, patch: Partial<Opportunity>) => {
        const updated = await provider.update(id, patch);
        await refresh();
        return updated;
    };

    const remove = async (id: number) => {
        await provider.remove(id);
        await refresh();
    };

    const byId = (id: number) => opportunities.find(o => o.id === id);

    return (
        <Ctx.Provider value={{ provider, opportunities, refresh, create, update, remove, byId }}>
            {children}
        </Ctx.Provider>
    )
}

export function useOpportunities(){
    const ctx = React.useContext(Ctx);
    if (!ctx) throw new Error('UseOpportunities must be used within OpportunitiesProvier')
        return ctx;
}