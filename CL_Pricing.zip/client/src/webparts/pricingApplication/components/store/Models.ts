import { IPersonaProps } from "@fluentui/react";

export interface AdHocPerson {
  id: number;
  loginName?: string;
  displayName?: string;
  email?: string;
}

export interface Opportunity {
  bid_team_members?: [];
  lead_pricer?: { name: string; email: string; login_id: string }[];
  id: number;
  title: string;
  region?: string;
  leadNumber: string;
  customer: string;
  opportunityName?: string;
  country: string;
  countryCode: string;
  project_name: string;
  adhocPeople?: [];
  status?: string;
  active?: boolean;
  deleted?: boolean;
  createdBy?: string;
  createdDate?: string;
  modifiedOn?: string;
  modifiedBy?: string;
}

// export interface Round {
//     id: number;
//     opportunityId: number;
//     name: string;
//     createdOn?: string;
// }


export type InputOption =
  | "CollectInput"
  | "useStandardInput"
  | "usePreviousRoundInput";

export interface ApplicableScenarioPayload {
  name: ScenarioKey;
  desc: string;
  input_type: InputOption;
  isStandardRate: boolean;
  isCopiedPreviousRound: boolean;
  referenceData: number | null;
}

export interface UpdateInputTemplatePayload {
  opportunityId: number;
  roundId: number;
  stakeholder: string;
  stakeholder_code: string;
  dueDate?: string;
  notify_users: {
    login_id: string;
    name: string;
    email: string;
  }[];
  additionalStakeholders: {
    login_id: string;
    name: string;
    email: string;
  }[];
  applicableScenarios: ApplicableScenarioPayload[];
}

export interface ChangeVersionPayload {
  opportunityId: number;
  roundId: number;
  stakeholder_code: string;
  stakeholderType: string;
  description?: string;
  dueDate?: string;
  collectDraftInput?: boolean;
  draftDueDate?: string;
  versionNumber: string;
  notify_users: ChangeVersionUser[];
  additionalStakeholders: ChangeVersionUser[];
  applicableScenarios: ChangeVersionScenario[];
}

export interface ChangeVersionUser {
  name: string;
  email: string;
  login_id: string;
}

export interface ChangeVersionScenario {
  name: string;
  desc: string;
  isStandardRate: boolean;
  isCopiedPreviousRound: boolean;
  referenceData?: number | null;
  input_type: string;
}


export interface updateRound {
  opportunityId: string | undefined;
  roundId: number;
  stakeholder: string;
  stakeholder_code: string | undefined;
  input_type: string;
  dueDate: string | undefined;
  applicableScenarios: {
    name: ScenarioKey;
    desc: string;
  }[];
  notify_users: {
    login_id: string;
    name: string;
    email: string;
  }[];
  additionalStakeholders: {
    login_id: string;
    name: string;
    email: string;
  }[];
  isStandardRate: boolean;
  copyType: string;
}

export interface StandardTemplate {
  id: number;
  title: string;
  stakehostakeholder: string;
}

export interface FileItem {
  id: string | number;
  name: string;
  url: string;
  fileRelPath: string;
  size?: number | null;
  modified?: string | null;
  status?: string | null;
  scenario?: string | null;
  isCurrentVersion?: number;
  isCurrentApproved?: number;
  listItemId?: number | null;
  uploadedBy?: { name?: string; email?: string };
  modifiedBy?: { name?: string; email?: string };
}

export interface Round {
  id?: number;
  opportunityId?: number;
  roundNumber?: number;
  name?: string;
  description?: string;
  customerSubmissionDate?: string;
  scenarioList?: ScenarioRow[];
  stakeholders?: any;
  createdOn?: string;
}
export type ScenarioKey = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I' | 'J';

export interface ScenarioRow {
  name: ScenarioKey;
  description?: string;
}

export interface StakeholderRow {
  enabled: boolean;
  stakeholderName?: string;
  inputOption?: string;
  adHocStakeholderNames?: string;
  dueDate?: string;
  applicableScenarios: ScenarioKey[];
}

export interface Template {
  id: number;
  roundId: number;
  name: string;
  createdOn?: string;
}

export interface TemplatePost {

  opportunityId: number;
  roundId: number;
  roundNumber: number;
  stakeholder?: string;
  stakeholderCode?: string;
  revisionNumber?: number;
  scenarioName?: string;
  fileRelPath: string;
  processedData?: [];
  userStatus: string;
  workflowStatus: string;
  versionNumber?: string | null;
  submissionType?: string;
}

export interface RejectStakeholderInput {
  opportunityId: number,
  roundId: number,
  roundNumber: number,
  stakeholderCode?: string,
  scenarioName?: string,
  versionNumber?: string | null;
  submissionType?: string;
}

export interface GenerateOutput {
  roundId: number;
  stakeholder: string;
  scenarios: ScenarioKey[];
}

export type ScenarioConfig = {
  inputOption: InputOption;
  standardReferenceId?: number | null;
  previousRoundId?: number | null;
  standardInputTemplateTitle?: string;
  inputRequired?: boolean;
  workflowStatus?: string;
  scenarioDescription?: string;
  revisionAttempt?: string | null;

  versionSelections?: string[];
  submissionTypes?: string[];
  collectDraftInput?: boolean;
  draftDueDate?: Date | null;
};


export type RemainingStakeholder = {
  stakeholderName: string;
  stakeholderCode: string;
  groupIds: number[];
  showStandard: boolean;
};

export type DraftRow = {
  enabled: boolean;
  stakeholderName: string;
  stakeholderCode: string;
  applicableScenarios: ScenarioKey[];
  scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>>;
  dueDate: Date | null;
  groupUsers: IPersonaProps[];
  notifyUsers: IPersonaProps[];
  additionalTeam: IPersonaProps[];
  inputTemplateVersions?: {
    Id: number;
    VersionNumber: string;
    DraftApplicable: boolean;
    Active: boolean;
  }[];

  commonVersionSelections?: string;
  collectDraftInput?: boolean;
  commonDraftDueDate?: Date | null;
};

export interface AddInputTemplateDrawerProps {
  open: boolean;
  onClose: () => void;
  onFlowReady: (flowPayload: any) => void;
  oppId: number;
  roundId: number;
  roundNumber: number;
  opportunityName: string;
  backendRound: any;
  allOpportunityRounds?: any[];
  currentRoundDetail: any;
  opportunityCountryName: string;
  leadPricerEmail: string;
  bidTeamEmail: string[];
  customer: string;
  prevRoundScenarioMap: Map<string, Set<ScenarioKey>>;
  prevRoundApprovedScenarioMap: Map<string, Set<ScenarioKey>>;
  prevRoundId?: number;
  scenarios: { key: ScenarioKey; description?: string }[];
  remainingStakeholders: RemainingStakeholder[];
  spfxContext: any;
  api: any;
  onSaveSuccess: (rows: DraftRow[]) => Promise<void>;
}

export type EditInputTemplateModel = {
  stakeholderName: string;
  stakeholderCode: string;

  dueDate: Date | null;

  existingScenarios: ScenarioKey[];
  newScenarios: ScenarioKey[];

  scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>>;

  notifyUsers: IPersonaProps[];
  additionalTeam: IPersonaProps[];

  commonVersionSelections?: string;

  originalVersion?: string;

  versionChanged?: boolean

  collectDraftInput?: boolean;

  commonDraftDueDate?: Date | null;
};



interface RoundViewModel {
  roundId: number;
  opportunityId: number;
  scenarios: { key: ScenarioKey; description?: string }[];
  inputTemplates: any[];
}


export type EditResult = {
  editor: EditInputTemplateModel;
};


export interface TemplateCatalog {
  stakeholderName: string;
  stakeholderCode: string;
  groupIds: number[];
  versions: {
    versionNumber: string;
    showStandard: boolean;
  }[];
}

export interface EditInputTemplateDrawerProps {
  open: boolean;
  onClose: () => void;
  round: RoundViewModel;
  backendRound: any;
  currentRoundDetail: any;
  roundNumber: number;
  templateCatalog: Map<string, TemplateCatalog>;
  prevRoundScenarioMap: Map<string, Set<ScenarioKey>>;
  prevRoundApprovedScenarioMap: Map<string, Set<ScenarioKey>>;
  spfxContext: any;
  prevRoundId: number;
  api: any;
  onSaveSuccess: (editor: EditInputTemplateModel) => Promise<void>;
  }


export interface ScenarioDto {
  name: string;
  desc: string;
}

export interface RoundMainInfo {
  description?: string;
  customerSubmissionDate?: string;
  inputDueDate?: string;
  scenarioList?: ScenarioDto[];
}
export interface GenerateOutputLogRequest {
  opportunityId: number;
  roundId: number;
  fileRelPath: string;
  processedData: any;
  extractedOn: string;
  extractedBy: string;
}

export interface OutputLog {
  id: number;
  opportunityId: number;
  roundId: number;
  fileName: string;
  fileRelPath: string;
  processedData: any;
  extractedOn: string;
  extractedBy: string;
  active: boolean;
  deleted: boolean;
  createdOn: string;
  createdBy: string;
  modifiedOn: string;
  modifiedBy: string;
}



// export interface FileItem {
//     name: string;
//     url: string;
//     size?: number;
//     modified?: string;
//     status: string;
// }