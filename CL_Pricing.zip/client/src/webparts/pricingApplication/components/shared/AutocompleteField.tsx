/**
 * AutocompleteField - Reusable autocomplete text field with debouncing and caching
 * Extracted from CreateOpportunity customer field
 * Features: debouncing, caching, keyboard navigation, loading states
 */

import * as React from 'react';
import {
  TextField,
  ITextField,
  Callout,
  FocusZone,
  FocusZoneDirection,
  List,
  Spinner,
  DirectionalHint,
  mergeStyles,
} from '@fluentui/react';
import { colors, shadows, borderRadius, transitions } from '../../theme/tokens';

export interface IAutocompleteFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  onSearch: (query: string, limit: number, signal: AbortSignal) => Promise<string[]>;
  onBlur?: () => void;
  required?: boolean;
  placeholder?: string;
  description?: string;
  errorMessage?: string;
  maxLength?: number;
  minChars?: number;
  debounceMs?: number;
  cacheTtlMs?: number;
  showNewItemBanner?: boolean;
  newItemBannerText?: string;
}

const CACHE_TTL_MS = 2 * 60 * 1000; // 2 minutes
const MIN_CHARS = 3;
const IDLE_DELAY_MS = 450;

export const AutocompleteField: React.FC<IAutocompleteFieldProps> = ({
  label,
  value,
  onChange,
  onSearch,
  onBlur,
  required = false,
  placeholder,
  description,
  errorMessage,
  maxLength,
  minChars = MIN_CHARS,
  debounceMs = IDLE_DELAY_MS,
  cacheTtlMs = CACHE_TTL_MS,
  showNewItemBanner = false,
  newItemBannerText = 'This will be treated as a new item.',
}) => {
  const tfRef = React.useRef<ITextField | null>(null);
  const anchorRef = React.useRef<HTMLDivElement | null>(null);

  const [suggestions, setSuggestions] = React.useState<string[]>([]);
  const [isSuggestionsOpen, setIsSuggestionsOpen] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [hasBlurred, setHasBlurred] = React.useState(false);
  const [activeIndex, setActiveIndex] = React.useState<number>(-1);

  const debounceIdRef = React.useRef<number | null>(null);
  const abortRef = React.useRef<AbortController | null>(null);
  const reqIdRef = React.useRef(0);
  const prevLenRef = React.useRef(0);
  const cacheRef = React.useRef<Map<string, { items: string[]; ts: number }>>(new Map());
  const lastFetchedRef = React.useRef<string>('');
  const inflightRef = React.useRef<Set<string>>(new Set());

  const rowClass = mergeStyles({
    padding: '8px 12px',
    cursor: 'pointer',
    transition: `all ${transitions.fast}`,
    selectors: {
      '&.active': {
        background: colors.secondary,
        borderLeft: `3px solid ${colors.primary}`,
      },
      '&:hover': {
        background: colors.neutralLighterAlt,
        transform: 'translateX(2px)',
      },
    },
  });

  const isExactMatch = suggestions.some(
    (t) => t.toLowerCase() === value.trim().toLowerCase()
  );
  const showBanner = showNewItemBanner && hasBlurred && value.trim().length > 0 && !isExactMatch;

  const fetchSuggestions = async (q: string, limit: number) => {
    const query = (q ?? '').trim();
    if (query.length < minChars) return;

    // Check cache
    const cached = cacheRef.current.get(query);
    const now = Date.now();
    if (cached && now - cached.ts < cacheTtlMs) {
      setSuggestions(cached.items);
      setActiveIndex(cached.items.length ? 0 : -1);
      setIsSuggestionsOpen(true);
      lastFetchedRef.current = query;
      return;
    }

    // Prevent duplicate requests
    if (inflightRef.current.has(query)) return;

    try {
      inflightRef.current.add(query);
      setIsLoading(true);

      // Cancel previous request
      abortRef.current?.abort();
      const ac = new AbortController();
      abortRef.current = ac;

      const myId = ++reqIdRef.current;

      const items = await onSearch(query, limit, ac.signal);

      if (ac.signal.aborted || myId !== reqIdRef.current) return;

      // Cache results
      cacheRef.current.set(query, { items, ts: now });

      setSuggestions(items);
      setActiveIndex(items.length ? 0 : -1);
      setIsSuggestionsOpen(true);
      lastFetchedRef.current = query;
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error('Autocomplete search failed:', err);
      }
    } finally {
      inflightRef.current.delete(query);
      if (reqIdRef.current !== 0 && !abortRef.current?.signal.aborted) {
        setIsLoading(false);
      }
    }
  };

  React.useEffect(() => {
    if (debounceIdRef.current) {
      window.clearTimeout(debounceIdRef.current);
      debounceIdRef.current = null;
    }

    const query = value.trim();
    const len = query.length;

    if (len < minChars) {
      setSuggestions([]);
      setActiveIndex(-1);
      setIsSuggestionsOpen(false);
      abortRef.current?.abort();
      setIsLoading(false);
      prevLenRef.current = len;
      return;
    }

    // Immediate fetch on crossing threshold
    if (prevLenRef.current < minChars && len >= minChars) {
      void fetchSuggestions(query, 10);
    } else {
      // Use cached results if applicable
      if (
        lastFetchedRef.current &&
        query.startsWith(lastFetchedRef.current) &&
        suggestions.length > 0
      ) {
        // Already have results
      } else {
        void fetchSuggestions(query, 10);
      }
    }

    // Debounced fetch
    debounceIdRef.current = window.setTimeout(() => {
      void fetchSuggestions(query, 5);
    }, debounceMs);

    prevLenRef.current = len;

    return () => {
      if (debounceIdRef.current) {
        window.clearTimeout(debounceIdRef.current);
        debounceIdRef.current = null;
      }
    };
  }, [value, suggestions.length, minChars, debounceMs]);

  const handleChange = (_: any, v?: string) => {
    const val = maxLength ? (v ?? '').slice(0, maxLength) : (v ?? '');
    onChange(val);
    setHasBlurred(false);
  };

  const handleFocus = () => {
    setHasBlurred(false);
    if (value.length >= minChars && (suggestions.length || isLoading)) {
      setIsSuggestionsOpen(true);
    }
  };

  const handleBlur: React.FocusEventHandler<HTMLInputElement> = () => {
    setTimeout(() => {
      const active = document.activeElement as HTMLElement | null;
      const insideCallout = !!active?.closest?.('[role="listbox"]');
      if (!insideCallout) {
        setIsSuggestionsOpen(false);
        setHasBlurred(true);
        if (onBlur) onBlur();
      }
    }, 0);
  };

  const handleKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
    if (!isSuggestionsOpen || (!suggestions.length && !isLoading)) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((i) => {
        const next = i < 0 ? 0 : Math.min(i + 1, Math.max(suggestions.length - 1, 0));
        return next;
      });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter') {
      if (activeIndex >= 0 && suggestions.length) {
        e.preventDefault();
        const pick = suggestions[activeIndex];
        onChange(pick);
        setIsSuggestionsOpen(false);
        setHasBlurred(false);
        tfRef.current?.focus();
      }
    } else if (e.key === 'Escape') {
      setIsSuggestionsOpen(false);
    }
  };

  const handleSuggestionClick = (idx: number) => {
    if (idx < 0 || idx >= suggestions.length) return;
    const pick = suggestions[idx];
    onChange(pick);
    setIsSuggestionsOpen(false);
    setHasBlurred(false);
    tfRef.current?.focus();
  };

  const renderSuggestion = (item?: string, index?: number) => {
    if (item === undefined || index === undefined) return null;
    const isActive = index === activeIndex;
    return (
      <div
        key={`${item}_${index}`}
        role="option"
        aria-selected={isActive}
        className={`${rowClass} ${isActive ? 'active' : ''}`}
        onMouseDown={(e) => e.preventDefault()} // keep focus behavior stable
        onClick={() => handleSuggestionClick(index)}
      >
        {item}
      </div>
    );
  };

  return (
    <div style={{ position: 'relative', width: '100%' }}>
      <div
        ref={anchorRef}
        style={{
          position: 'relative',
          overflow: 'visible',
          width: '100%',
        }}
      >
        <TextField
          componentRef={tfRef}
          label={label}
          required={required}
          value={value}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          autoComplete="off"
          placeholder={placeholder}
          description={
            value.length < minChars
              ? description || `Type at least ${minChars} characters to search`
              : description
          }
          errorMessage={errorMessage}
          maxLength={maxLength}
        />
        {isSuggestionsOpen && (
          <Callout
            doNotLayer={true}
            target={anchorRef.current}
            isBeakVisible={false}
            gapSpace={0}
            directionalHint={DirectionalHint.bottomLeftEdge}
            directionalHintFixed={true}
            onDismiss={() => setIsSuggestionsOpen(false)}
            calloutWidth={anchorRef.current?.offsetWidth}
            styles={{
              root: { zIndex: 1000 },
              calloutMain: {
                maxHeight: 250,
                overflowY: 'auto',
                border: `1px solid ${colors.borderPrimary}`,
                background: colors.white,
                borderRadius: borderRadius.md,
                boxShadow: shadows.lg,
              },
            }}
          >
            {value.length < minChars ? (
              <div style={{ padding: 12, color: colors.textSecondary }}>
                Type at least {minChars} characters to search
              </div>
            ) : isLoading ? (
              <div style={{ padding: 12 }}>
                <Spinner label="Searching..." />
              </div>
            ) : suggestions.length === 0 ? (
              <div style={{ padding: 12, color: colors.textSecondary }}>No matches</div>
            ) : (
              <FocusZone direction={FocusZoneDirection.domOrder}>
                <List items={suggestions} onRenderCell={renderSuggestion} />
              </FocusZone>
            )}
          </Callout>
        )}
      </div>
      {showBanner && (
        <div style={{ color: colors.warning, marginTop: 4, fontSize: 12 }}>
          {newItemBannerText}
        </div>
      )}
    </div>
  );
};
