/**
 * Shared Components - Export barrel file
 * Centralized exports for all shared/reusable components
 */

export { PageContainer } from './PageContainer';
export type { IPageContainerProps, PageContainerSize } from './PageContainer';

export { FormSection } from './FormSection';
export type { IFormSectionProps } from './FormSection';

export { DataCard } from './DataCard';
export type { IDataCardProps } from './DataCard';

export { StatusBadge } from './StatusBadge';
export type { IStatusBadgeProps, StatusType } from './StatusBadge';

export { EmptyState } from './EmptyState';
export type { IEmptyStateProps } from './EmptyState';

export { LoadingState, SkeletonLoader } from './LoadingState';
export type { ILoadingStateProps, ISkeletonLoaderProps } from './LoadingState';

export { ActionBar } from './ActionBar';
export type { IActionBarProps } from './ActionBar';

export { FluentPagination } from './FluentPagination';
export type { IFluentPaginationProps } from './FluentPagination';

export { Wizard } from './Wizard';
export type { IWizardProps, IWizardStep } from './Wizard';

export { AutocompleteField } from './AutocompleteField';
export type { IAutocompleteFieldProps } from './AutocompleteField';
