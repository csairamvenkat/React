/**
 * DataCard - Card component for displaying data sections
 * Used in detail pages and stakeholder cards
 */

import * as React from 'react';
import { Stack, Text, IStackStyles, IStackTokens } from '@fluentui/react';
import { colors, spacing, shadows, borderRadius, transitions } from '../../theme/tokens';

export interface IDataCardProps {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
  elevated?: boolean;
  hoverable?: boolean;
  onClick?: () => void;
  header?: React.ReactNode;
  footer?: React.ReactNode;
}

export const DataCard: React.FC<IDataCardProps> = ({
  title,
  subtitle,
  children,
  className,
  elevated = false,
  hoverable = false,
  onClick,
  header,
  footer,
}) => {
  const [isHovered, setIsHovered] = React.useState(false);

  const containerStyles: IStackStyles = {
    root: {
      backgroundColor: colors.backgroundPrimary,
      border: `1px solid ${colors.borderPrimary}`,
      borderRadius: borderRadius.md,
      padding: spacing.md,
      boxShadow: elevated ? shadows.card : 'none',
      transition: `box-shadow ${transitions.smooth}, transform ${transitions.smooth}`,
      cursor: onClick ? 'pointer' : 'default',
      transform: hoverable && isHovered ? 'translateY(-4px)' : 'none',

      ':hover': hoverable ? {
        boxShadow: shadows.cardHover,
      } : {},
    },
  };

  const tokens: IStackTokens = {
    childrenGap: spacing.md,
  };

  const handleMouseEnter = () => {
    if (hoverable) setIsHovered(true);
  };

  const handleMouseLeave = () => {
    if (hoverable) setIsHovered(false);
  };

  return (
    <Stack
      styles={containerStyles}
      tokens={tokens}
      className={className}
      onClick={onClick}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {header}

      {(title || subtitle) && (
        <Stack tokens={{ childrenGap: spacing.xs }}>
          {title && (
            <Text
              variant="xLarge"
              styles={{
                root: {
                  fontWeight: 600,
                  color: colors.textPrimary,
                },
              }}
            >
              {title}
            </Text>
          )}
          {subtitle && (
            <Text
              variant="medium"
              styles={{
                root: {
                  color: colors.textSecondary,
                },
              }}
            >
              {subtitle}
            </Text>
          )}
        </Stack>
      )}

      <Stack>{children}</Stack>

      {footer}
    </Stack>
  );
};
