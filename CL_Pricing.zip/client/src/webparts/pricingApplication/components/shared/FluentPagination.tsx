/**
 * FluentPagination - Fluent UI based pagination component
 * Replaces native HTML pagination with proper Fluent UI buttons
 */

import * as React from 'react';
import { Stack, IconButton, Text, Dropdown, IDropdownOption, IStackTokens } from '@fluentui/react';
import { colors, spacing, shadows, transitions } from '../../theme/tokens';

export interface IFluentPaginationProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  pageSizeOptions?: number[];
  showPageSize?: boolean;
}

export const FluentPagination: React.FC<IFluentPaginationProps> = ({
  currentPage,
  totalPages,
  pageSize,
  totalItems,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 25, 50, 100],
  showPageSize = true,
}) => {
  const tokens: IStackTokens = {
    childrenGap: spacing.sm,
  };

  const pageSizeDropdownOptions: IDropdownOption[] = pageSizeOptions.map((size) => ({
    key: size,
    text: `${size} per page`,
  }));

  const handlePageSizeChange = (_event: React.FormEvent<HTMLDivElement>, option?: IDropdownOption) => {
    if (option && onPageSizeChange) {
      onPageSizeChange(Number(option.key));
    }
  };

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisiblePages = 5;

    if (totalPages <= maxVisiblePages) {
      // Show all pages if total is less than max visible
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);

      let startPage = Math.max(2, currentPage - 1);
      let endPage = Math.min(totalPages - 1, currentPage + 1);

      // Adjust range if near the beginning or end
      if (currentPage <= 3) {
        endPage = 4;
      } else if (currentPage >= totalPages - 2) {
        startPage = totalPages - 3;
      }

      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pages.push('...');
      }

      // Add middle pages
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }

      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pages.push('...');
      }

      // Always show last page
      pages.push(totalPages);
    }

    return pages;
  };

  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, totalItems);

  return (
    <Stack
      horizontal
      verticalAlign="center"
      horizontalAlign="space-between"
      tokens={tokens}
      styles={{
        root: {
          padding: spacing.md,
          borderTop: `1px solid ${colors.borderPrimary}`,
          flexWrap: 'wrap',
          gap: spacing.md,
        },
      }}
    >
      {/* Page size selector */}
      {showPageSize && onPageSizeChange && (
        <Stack horizontal verticalAlign="center" tokens={{ childrenGap: spacing.sm }}>
          <Dropdown
            options={pageSizeDropdownOptions}
            selectedKey={pageSize}
            onChange={handlePageSizeChange}
            styles={{
              dropdown: { width: 140 },
            }}
          />
        </Stack>
      )}

      {/* Page info */}
      <Text
        variant="small"
        styles={{
          root: {
            color: colors.textSecondary,
          },
        }}
      >
        Showing {startItem}-{endItem} of {totalItems}
      </Text>

      {/* Pagination controls */}
      <Stack horizontal tokens={{ childrenGap: spacing.xs }} verticalAlign="center">
        {/* Previous button */}
        <IconButton
          iconProps={{ iconName: 'ChevronLeft' }}
          disabled={currentPage === 1}
          onClick={() => onPageChange(currentPage - 1)}
          title="Previous page"
        />

        {/* Page numbers */}
        {getPageNumbers().map((page, index) => {
          if (page === '...') {
            return (
              <Text
                key={`ellipsis-${index}`}
                styles={{
                  root: {
                    padding: '0 8px',
                    color: colors.textSecondary,
                  },
                }}
              >
                ...
              </Text>
            );
          }

          const pageNumber = page as number;
          const isActive = pageNumber === currentPage;

          return (
            <IconButton
              key={pageNumber}
              text={String(pageNumber)}
              onClick={() => onPageChange(pageNumber)}
              styles={{
                root: {
                  minWidth: 32,
                  backgroundColor: isActive ? colors.primary : 'transparent',
                  color: isActive ? colors.white : colors.textPrimary,
                  border: isActive ? 'none' : `1px solid ${colors.borderPrimary}`,
                  transition: `all ${transitions.fast}`,
                  boxShadow: isActive ? shadows.primaryGlow : 'none',
                },
                rootHovered: {
                  backgroundColor: isActive ? colors.primaryDark : colors.neutralLighter,
                  color: isActive ? colors.white : colors.textPrimary,
                  transform: 'scale(1.05)',
                },
              }}
              title={`Page ${pageNumber}`}
            />
          );
        })}

        {/* Next button */}
        <IconButton
          iconProps={{ iconName: 'ChevronRight' }}
          disabled={currentPage === totalPages}
          onClick={() => onPageChange(currentPage + 1)}
          title="Next page"
        />
      </Stack>
    </Stack>
  );
};
