/**
 * Wizard - Multi-step wizard component
 * Provides step navigation, progress indicator, and step validation
 * Used in CreateRound and other multi-step forms
 */

import * as React from 'react';
import {
  Stack,
  Text,
  PrimaryButton,
  DefaultButton,
  Icon,
  IStackStyles,
  IStackTokens,
  ProgressIndicator,
} from '@fluentui/react';
import { colors, spacing, shadows, borderRadius, transitions } from '../../theme/tokens';

export interface IWizardStep {
  key: string;
  label: string;
  icon?: string;
  description?: string;
  validate?: () => boolean | Promise<boolean>;
  onEnter?: () => void;
  onExit?: () => void;
}

export interface IWizardProps {
  steps: IWizardStep[];
  currentStep: number;
  onStepChange: (step: number) => void;
  onComplete: () => void;
  onCancel?: () => void;
  children: React.ReactNode;
  completeText?: string;
  nextText?: string;
  previousText?: string;
  cancelText?: string;
  allowSkipSteps?: boolean;
  showProgress?: boolean;
}

export const Wizard: React.FC<IWizardProps> = ({
  steps,
  currentStep,
  onStepChange,
  onComplete,
  onCancel,
  children,
  completeText = 'Complete',
  nextText = 'Next',
  previousText = 'Previous',
  cancelText = 'Cancel',
  allowSkipSteps = false,
  showProgress = true,
}) => {
  const [validating, setValidating] = React.useState(false);
  const stepIndicatorsRef = React.useRef<HTMLDivElement>(null);

  const scrollToTop = () => {
    // Scroll the window to the very top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Also scroll any scrollable ancestor container (e.g. SharePoint/SPFx panels)
    if (stepIndicatorsRef.current) {
      let el: HTMLElement | null = stepIndicatorsRef.current.parentElement;
      while (el) {
        const { overflowY, overflow } = window.getComputedStyle(el);
        const isScrollable = (overflowY === 'auto' || overflowY === 'scroll' || overflow === 'auto' || overflow === 'scroll');
        if (isScrollable && el.scrollTop > 0) {
          el.scrollTo({ top: 0, behavior: 'smooth' });
          break;
        }
        el = el.parentElement;
      }
    }
  };

  const isFirstStep = currentStep === 0;
  const isLastStep = currentStep === steps.length - 1;
  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleNext = async () => {
    const step = steps[currentStep];

    if (step.validate) {
      setValidating(true);
      try {
        const isValid = await step.validate();
        if (!isValid) {
          setValidating(false);
          return;
        }
      } catch (error) {
        console.error('Validation error:', error);
        setValidating(false);
        return;
      }
      setValidating(false);
    }

    if (step.onExit) {
      step.onExit();
    }

    if (isLastStep) {
      onComplete();
    } else {
      const nextStep = currentStep + 1;
      if (steps[nextStep].onEnter) {
        steps[nextStep].onEnter();
      }
      onStepChange(nextStep);
      scrollToTop();
    }
  };

  const handlePrevious = () => {
    const step = steps[currentStep];
    if (step.onExit) {
      step.onExit();
    }

    const prevStep = currentStep - 1;
    if (steps[prevStep].onEnter) {
      steps[prevStep].onEnter();
    }
    onStepChange(prevStep);
    scrollToTop();
  };

  const handleStepClick = (index: number) => {
    if (allowSkipSteps && index !== currentStep) {
      const step = steps[currentStep];
      if (step.onExit) {
        step.onExit();
      }

      if (steps[index].onEnter) {
        steps[index].onEnter();
      }
      onStepChange(index);
    }
  };

  const containerStyles: IStackStyles = {
    root: {
      backgroundColor: colors.backgroundPrimary,
      borderRadius: borderRadius.lg,
      padding: spacing.lg,
      boxShadow: shadows.card,
    },
  };

  const tokens: IStackTokens = {
    childrenGap: spacing.lg,
  };

  return (
    <Stack styles={containerStyles} tokens={tokens}>
      {/* Progress bar */}
      {showProgress && (
        <ProgressIndicator
          percentComplete={progress / 100}
          styles={{
            root: {
              marginBottom: spacing.sm,
            },
          }}
        />
      )}

      {/* Step indicators */}
      <div ref={stepIndicatorsRef}>
      <Stack
        horizontal
        horizontalAlign="space-between"
        tokens={{ childrenGap: spacing.sm }}
        styles={{
          root: {
            overflowX: 'auto',
            '@media (max-width: 767px)': {
              flexWrap: 'wrap',
            },
          },
        }}
      >
        {steps.map((step, index) => {
          const isActive = index === currentStep;
          const isCompleted = index < currentStep;
          const isClickable = allowSkipSteps;

          return (
            <Stack
              key={step.key}
              horizontal
              verticalAlign="center"
              tokens={{ childrenGap: spacing.sm }}
              styles={{
                root: {
                  padding: spacing.sm,
                  borderRadius: borderRadius.md,
                  backgroundColor: isActive
                    ? colors.secondary
                    : isCompleted
                    ? colors.successLight
                    : colors.neutralLighter,
                  border: `2px solid ${
                    isActive
                      ? colors.primary
                      : isCompleted
                      ? colors.success
                      : colors.borderPrimary
                  }`,
                  cursor: isClickable ? 'pointer' : 'default',
                  flex: 1,
                  minWidth: '150px',
                  transition: `all ${transitions.smooth}`,
                  boxShadow: isActive ? shadows.primaryGlow : shadows.xs,
                  ':hover': isClickable ? {
                    transform: 'translateY(-2px)',
                    boxShadow: shadows.md,
                  } : {},
                },
              }}
              onClick={() => handleStepClick(index)}
            >
              {/* Step number or checkmark */}
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: '50%',
                  backgroundColor: isActive
                    ? colors.primary
                    : isCompleted
                    ? colors.success
                    : colors.neutralTertiary,
                  color: colors.white,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 600,
                  boxShadow: isActive ? shadows.primaryGlow : isCompleted ? shadows.accentGlow : shadows.sm,
                  transition: `all ${transitions.smooth}`,
                }}
              >
                {isCompleted ? (
                  <Icon iconName="CheckMark" />
                ) : step.icon ? (
                  <Icon iconName={step.icon} />
                ) : (
                  index + 1
                )}
              </div>

              {/* Step label */}
              <Stack>
                <Text
                  variant="medium"
                  styles={{
                    root: {
                      fontWeight: isActive ? 600 : 400,
                      color: isActive ? colors.primary : colors.textPrimary,
                    },
                  }}
                >
                  {step.label}
                </Text>
                {step.description && (
                  <Text
                    variant="small"
                    styles={{
                      root: {
                        color: colors.textSecondary,
                      },
                    }}
                  >
                    {step.description}
                  </Text>
                )}
              </Stack>
            </Stack>
          );
        })}
      </Stack>
      </div>

      {/* Step content */}
      <Stack
        styles={{
          root: {
            minHeight: '300px',
            padding: spacing.md,
          },
        }}
      >
        {children}
      </Stack>

      {/* Navigation buttons */}
      <Stack
        horizontal
        horizontalAlign="space-between"
        tokens={{ childrenGap: spacing.sm }}
        styles={{
          root: {
            borderTop: `1px solid ${colors.borderPrimary}`,
            paddingTop: spacing.md,
          },
        }}
      >
        {/* Left side: Cancel button */}
        <Stack horizontal tokens={{ childrenGap: spacing.sm }}>
          {onCancel && (
            <DefaultButton
              text={cancelText}
              onClick={onCancel}
              iconProps={{ iconName: 'Cancel' }}
            />
          )}
        </Stack>

        {/* Right side: Previous/Next buttons */}
        <Stack horizontal tokens={{ childrenGap: spacing.sm }}>
          {!isFirstStep && (
            <DefaultButton
              text={previousText}
              onClick={handlePrevious}
              iconProps={{ iconName: 'ChevronLeft' }}
            />
          )}

          <PrimaryButton
            text={isLastStep ? completeText : nextText}
            onClick={handleNext}
            disabled={validating}
            iconProps={{
              iconName: isLastStep ? 'CheckMark' : 'ChevronRight',
            }}
            styles={{
              rootHovered: {
                backgroundColor: colors.primaryDark,
              },
            }}
          />
        </Stack>
      </Stack>
    </Stack>
  );
};
