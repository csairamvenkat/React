/**
 * ActionBar - Standardized action button placement
 * Handles Save/Cancel/Delete button groups with consistent styling
 */

import * as React from 'react';
import { Stack, PrimaryButton, DefaultButton, IconButton, IStackStyles, IStackTokens } from '@fluentui/react';
import { colors, spacing, shadows, transitions } from '../../theme/tokens';

export interface IActionBarProps {
  onSave?: () => void | Promise<void>;
  onCancel?: () => void;
  onDelete?: () => void;
  saveText?: string;
  cancelText?: string;
  deleteText?: string;
  saveDisabled?: boolean;
  deleteDisabled?: boolean;
  loading?: boolean;
  sticky?: boolean;
  align?: 'left' | 'right' | 'center' | 'between';
  children?: React.ReactNode;
}

export const ActionBar: React.FC<IActionBarProps> = ({
  onSave,
  onCancel,
  onDelete,
  saveText = 'Save',
  cancelText = 'Cancel',
  deleteText = 'Delete',
  saveDisabled = false,
  deleteDisabled = false,
  loading = false,
  sticky = false,
  align = 'right',
  children,
}) => {
  const containerStyles: IStackStyles = {
    root: {
      padding: spacing.md,
      backgroundColor: colors.backgroundPrimary,
      borderTop: `1px solid ${colors.borderPrimary}`,
      ...(sticky && {
        position: 'sticky',
        bottom: 0,
        zIndex: 100,
        boxShadow: '0 -4px 16px 0 rgba(0, 0, 0, 0.12)',
      }),
    },
  };

  const tokens: IStackTokens = {
    childrenGap: spacing.sm,
  };

  const getHorizontalAlign = () => {
    switch (align) {
      case 'left':
        return 'start';
      case 'center':
        return 'center';
      case 'right':
        return 'end';
      case 'between':
        return 'space-between';
      default:
        return 'end';
    }
  };

  return (
    <Stack
      horizontal
      horizontalAlign={getHorizontalAlign()}
      verticalAlign="center"
      styles={containerStyles}
      tokens={tokens}
    >
      {/* Left-aligned content (like delete button) */}
      {onDelete && align === 'between' && (
        <DefaultButton
          text={deleteText}
          iconProps={{ iconName: 'Delete' }}
          onClick={onDelete}
          disabled={deleteDisabled || loading}
          styles={{
            root: {
              color: colors.error,
              borderColor: colors.error,
              transition: `all ${transitions.smooth}`,
            },
            rootHovered: {
              color: colors.errorDark,
              borderColor: colors.errorDark,
              transform: 'translateY(-1px)',
              boxShadow: shadows.sm,
            },
          }}
        />
      )}

      {/* Custom children */}
      {children}

      {/* Right-aligned actions */}
      <Stack horizontal tokens={tokens}>
        {onCancel && (
          <DefaultButton
            text={cancelText}
            onClick={onCancel}
            disabled={loading}
          />
        )}

        {onSave && (
          <PrimaryButton
            text={saveText}
            iconProps={{ iconName: 'Save' }}
            onClick={onSave}
            disabled={saveDisabled || loading}
            styles={{
              root: {
                transition: `all ${transitions.smooth}`,
                boxShadow: shadows.button,
              },
              rootHovered: {
                transform: 'translateY(-1px)',
                boxShadow: shadows.buttonHover,
              },
            }}
          />
        )}

        {onDelete && align !== 'between' && (
          <IconButton
            iconProps={{ iconName: 'Delete' }}
            title={deleteText}
            onClick={onDelete}
            disabled={deleteDisabled || loading}
            styles={{
              root: {
                color: colors.error,
                transition: `all ${transitions.fast}`,
              },
              rootHovered: {
                color: colors.errorDark,
                transform: 'scale(1.1)',
              },
            }}
          />
        )}
      </Stack>
    </Stack>
  );
};
