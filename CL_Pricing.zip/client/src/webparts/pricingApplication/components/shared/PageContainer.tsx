/**
 * PageContainer - Responsive page wrapper component
 * Provides consistent max-width and padding for all pages
 */

import * as React from 'react';
import { Stack, IStackStyles } from '@fluentui/react';
import { containerWidths } from '../../theme/tokens';

export type PageContainerSize = 'sm' | 'md' | 'lg' | 'xl' | 'full';

export interface IPageContainerProps {
  children: React.ReactNode;
  size?: PageContainerSize;
  className?: string;
  noPadding?: boolean;
}

const sizeMap: Record<PageContainerSize, string> = {
  sm: containerWidths.sm,
  md: containerWidths.md,
  lg: containerWidths.lg,
  xl: containerWidths.xl,
  full: containerWidths.full,
};

export const PageContainer: React.FC<IPageContainerProps> = ({
  children,
  size = 'lg',
  className,
  noPadding = false,
}) => {
  const containerStyles: IStackStyles = {
    root: {
      maxWidth: sizeMap[size],
      width: '100%',
      margin: '0 auto',
      padding: noPadding ? 0 : '0 16px',

      // Responsive padding
      '@media (max-width: 767px)': {
        padding: noPadding ? 0 : '0 8px',
      },
    },
  };

  return (
    <Stack styles={containerStyles} className={className}>
      {children}
    </Stack>
  );
};
