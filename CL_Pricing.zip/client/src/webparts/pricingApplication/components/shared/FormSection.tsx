/**
 * FormSection - Reusable form section wrapper with consistent spacing
 * Provides optional collapsible behavior and clear visual grouping
 */

import * as React from 'react';
import { Stack, Text, Icon, IconButton, IStackStyles, IStackTokens } from '@fluentui/react';
import { colors, spacing, shadows, borderRadius, transitions } from '../../theme/tokens';

export interface IFormSectionProps {
  title?: string;
  description?: string;
  children: React.ReactNode;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  required?: boolean;
  icon?: string;
  className?: string;
}

export const FormSection: React.FC<IFormSectionProps> = ({
  title,
  description,
  children,
  collapsible = false,
  defaultCollapsed = false,
  required = false,
  icon,
  className,
}) => {
  const [collapsed, setCollapsed] = React.useState(defaultCollapsed);

  const containerStyles: IStackStyles = {
    root: {
      padding: spacing.md,
      backgroundColor: colors.backgroundPrimary,
      border: `1px solid ${colors.borderPrimary}`,
      borderRadius: borderRadius.md,
      marginBottom: spacing.md,
      boxShadow: shadows.sm,
      transition: `box-shadow ${transitions.smooth}`,
      ':hover': {
        boxShadow: shadows.md,
      },
    },
  };

  const headerStyles: IStackStyles = {
    root: {
      cursor: collapsible ? 'pointer' : 'default',
      userSelect: 'none',
    },
  };

  const tokens: IStackTokens = {
    childrenGap: spacing.sm,
  };

  const handleToggle = () => {
    if (collapsible) {
      setCollapsed(!collapsed);
    }
  };

  return (
    <Stack styles={containerStyles} tokens={tokens} className={className}>
      {(title || description) && (
        <Stack
          horizontal
          verticalAlign="center"
          styles={headerStyles}
          onClick={handleToggle}
          tokens={{ childrenGap: spacing.sm }}
        >
          {icon && (
            <Icon
              iconName={icon}
              styles={{
                root: {
                  fontSize: 20,
                  color: colors.primary,
                },
              }}
            />
          )}
          <Stack grow styles={{ root: { flex: 1 } }}>
            {title && (
              <Text
                variant="large"
                styles={{
                  root: {
                    fontWeight: 600,
                    color: colors.textPrimary,
                  },
                }}
              >
                {title}
                {required && (
                  <span style={{ color: colors.error, marginLeft: 4 }}>*</span>
                )}
              </Text>
            )}
            {description && (
              <Text
                variant="small"
                styles={{
                  root: {
                    color: colors.textSecondary,
                  },
                }}
              >
                {description}
              </Text>
            )}
          </Stack>
          {collapsible && (
            <IconButton
              iconProps={{
                iconName: collapsed ? 'ChevronDown' : 'ChevronUp',
              }}
              styles={{
                root: {
                  color: colors.neutralSecondary,
                },
              }}
              onClick={(e) => {
                e.stopPropagation();
                handleToggle();
              }}
            />
          )}
        </Stack>
      )}
      {!collapsed && (
        <Stack
          tokens={tokens}
          styles={{
            root: {
              animation: `fadeIn ${transitions.smooth}`,
            },
          }}
        >
          {children}
        </Stack>
      )}
    </Stack>
  );
};
