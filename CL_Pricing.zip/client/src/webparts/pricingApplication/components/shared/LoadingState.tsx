/**
 * LoadingState - Consistent loading indicators
 * Provides spinners and skeleton loaders
 */

import * as React from 'react';
import { Stack, Spinner, SpinnerSize, Text, IStackTokens, ShimmeredDetailsList } from '@fluentui/react';
import { colors, spacing, borderRadius } from '../../theme/tokens';

export interface ILoadingStateProps {
  text?: string;
  size?: 'small' | 'medium' | 'large';
  overlay?: boolean;
}

const sizeMap = {
  small: SpinnerSize.small,
  medium: SpinnerSize.medium,
  large: SpinnerSize.large,
};

export const LoadingState: React.FC<ILoadingStateProps> = ({
  text = 'Loading...',
  size = 'medium',
  overlay = false,
}) => {
  const tokens: IStackTokens = {
    childrenGap: spacing.md,
  };

  const content = (
    <Stack
      horizontalAlign="center"
      verticalAlign="center"
      tokens={tokens}
      styles={{
        root: {
          padding: spacing.xl,
          minHeight: overlay ? '100%' : '200px',
        },
      }}
    >
      <Spinner size={sizeMap[size]} label={text} />
    </Stack>
  );

  if (overlay) {
    return (
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {content}
      </div>
    );
  }

  return content;
};

/**
 * SkeletonLoader - Placeholder UI while content is loading
 */
export interface ISkeletonLoaderProps {
  rows?: number;
  height?: number;
}

export const SkeletonLoader: React.FC<ISkeletonLoaderProps> = ({
  rows = 3,
  height = 40,
}) => {
  return (
    <Stack tokens={{ childrenGap: spacing.sm }}>
      {Array.from({ length: rows }).map((_, index) => (
        <div
          key={index}
          style={{
            height: `${height}px`,
            backgroundColor: colors.neutralLighter,
            borderRadius: borderRadius.md,
            animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
          }}
        />
      ))}
      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }
      `}</style>
    </Stack>
  );
};
