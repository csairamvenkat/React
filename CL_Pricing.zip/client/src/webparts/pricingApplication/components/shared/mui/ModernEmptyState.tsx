/**
 * ModernEmptyState - Advanced empty state component
 * Sophisticated design with illustrations and actions
 */

import * as React from 'react';
import {
  Box,
  Typography,
  alpha,
  useTheme,
  keyframes,
} from '@mui/material';
import { ModernButton } from './ModernButton';
import SearchOffIcon from '@mui/icons-material/SearchOff';
import InboxIcon from '@mui/icons-material/Inbox';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import CloudOffIcon from '@mui/icons-material/CloudOff';

export interface IModernEmptyStateProps {
  type?: 'empty' | 'search' | 'error' | 'offline' | 'access';
  title: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
  animated?: boolean;
}

const float = keyframes`
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
`;

const pulse = keyframes`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
`;

export const ModernEmptyState: React.FC<IModernEmptyStateProps> = ({
  type = 'empty',
  title,
  description,
  actionText,
  onAction,
  icon,
  animated = true,
}) => {
  const theme = useTheme();

  const getDefaultIcon = () => {
    switch (type) {
      case 'search':
        return <SearchOffIcon sx={{ fontSize: 80 }} />;
      case 'error':
        return <ErrorOutlineIcon sx={{ fontSize: 80 }} />;
      case 'offline':
        return <CloudOffIcon sx={{ fontSize: 80 }} />;
      default:
        return <InboxIcon sx={{ fontSize: 80 }} />;
    }
  };

  const displayIcon = icon || getDefaultIcon();

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        py: 8,
        px: 4,
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Background decoration */}
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: `radial-gradient(circle, ${alpha(theme.palette.primary.main, 0.05)} 0%, transparent 70%)`,
          animation: animated ? `${pulse} 3s ease-in-out infinite` : 'none',
        }}
      />

      {/* Icon container */}
      <Box
        sx={{
          width: 120,
          height: 120,
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)}, ${alpha(theme.palette.secondary.main, 0.1)})`,
          color: theme.palette.primary.main,
          mb: 3,
          position: 'relative',
          zIndex: 1,
          animation: animated ? `${float} 3s ease-in-out infinite` : 'none',
          boxShadow: `0 8px 32px ${alpha(theme.palette.primary.main, 0.2)}`,
          '&::before': {
            content: '""',
            position: 'absolute',
            top: -4,
            left: -4,
            right: -4,
            bottom: -4,
            borderRadius: '50%',
            border: `2px dashed ${alpha(theme.palette.primary.main, 0.2)}`,
            animation: animated ? 'spin 20s linear infinite' : 'none',
          },
          '@keyframes spin': {
            from: { transform: 'rotate(0deg)' },
            to: { transform: 'rotate(360deg)' },
          },
        }}
      >
        {displayIcon}
      </Box>

      {/* Content */}
      <Typography
        variant="h5"
        fontWeight={700}
        color="text.primary"
        sx={{ mb: 1, position: 'relative', zIndex: 1 }}
      >
        {title}
      </Typography>

      {description && (
        <Typography
          variant="body1"
          color="text.secondary"
          sx={{
            maxWidth: 480,
            mb: 3,
            lineHeight: 1.6,
            position: 'relative',
            zIndex: 1,
          }}
        >
          {description}
        </Typography>
      )}

      {actionText && onAction && (
        <ModernButton
          variant="gradient"
          glow
          onClick={onAction}
          sx={{
            position: 'relative',
            zIndex: 1,
          }}
        >
          {actionText}
        </ModernButton>
      )}
    </Box>
  );
};
