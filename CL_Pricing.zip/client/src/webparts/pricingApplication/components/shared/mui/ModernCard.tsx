/**
 * ModernCard - Advanced MUI Card component
 * Sophisticated design with glassmorphism and animations
 */

import * as React from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardActions,
  Typography,
  Box,
  alpha,
  useTheme,
} from '@mui/material';

export interface IModernCardProps {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  headerAction?: React.ReactNode;
  icon?: React.ReactNode;
  elevated?: boolean;
  hoverable?: boolean;
  gradient?: boolean;
  onClick?: () => void;
  sx?: any;
}

export const ModernCard: React.FC<IModernCardProps> = ({
  title,
  subtitle,
  children,
  actions,
  headerAction,
  icon,
  elevated = true,
  hoverable = false,
  gradient = false,
  onClick,
  sx = {},
}) => {
  const theme = useTheme();

  return (
    <Card
      onClick={onClick}
      elevation={elevated ? 2 : 0}
      sx={{
        borderRadius: 4,
        background: gradient
          ? `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.05)} 0%, ${alpha(theme.palette.secondary.main, 0.05)} 100%)`
          : 'background.paper',
        border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        cursor: onClick ? 'pointer' : 'default',
        position: 'relative',
        overflow: 'clip',
        ...(hoverable && {
          '&:hover': {
            transform: 'translateY(-8px)',
            boxShadow: theme.shadows[8],
            '&::before': {
              opacity: 1,
            },
          },
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
            opacity: 0,
            transition: 'opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          },
        }),
        ...sx,
      }}
    >
      {(title || subtitle || icon) && (
        <CardHeader
          avatar={
            icon ? (
              <Box
                sx={{
                  width: 48,
                  height: 48,
                  borderRadius: 3,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.light})`,
                  color: 'white',
                  boxShadow: `0 4px 12px ${alpha(theme.palette.primary.main, 0.3)}`,
                }}
              >
                {icon}
              </Box>
            ) : undefined
          }
          title={
            title && (
              <Typography variant="h6" fontWeight={600}>
                {title}
              </Typography>
            )
          }
          subheader={subtitle}
          action={headerAction}
          sx={{
            '& .MuiCardHeader-content': {
              overflow: 'hidden',
            },
          }}
        />
      )}
      <CardContent>{children}</CardContent>
      {actions && <CardActions sx={{ px: 2, pb: 2 }}>{actions}</CardActions>}
    </Card>
  );
};
