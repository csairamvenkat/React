/**
 * ModernButton - Advanced MUI Button with sophisticated styling
 * Features: gradients, loading states, animations
 */

import * as React from 'react';
import { Button, CircularProgress, alpha, useTheme } from '@mui/material';
import type { ButtonProps } from '@mui/material';

export interface IModernButtonProps extends Omit<ButtonProps, 'variant'> {
  loading?: boolean;
  gradient?: boolean;
  glow?: boolean;
  variant?: 'contained' | 'outlined' | 'text' | 'gradient';
}

export const ModernButton: React.FC<IModernButtonProps> = ({
  loading = false,
  gradient = false,
  glow = false,
  variant = 'contained',
  disabled,
  children,
  sx = {},
  ...props
}) => {
  const theme = useTheme();

  const getVariantStyles = () => {
    if (variant === 'gradient' || gradient) {
      return {
        background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.light} 100%)`,
        color: '#ffffff !important',
        border: 'none',
        boxShadow: glow
          ? `0 4px 20px ${alpha(theme.palette.primary.main, 0.4)}`
          : theme.shadows[2],
        '& .MuiButton-startIcon, & .MuiButton-endIcon': {
          color: '#ffffff',
        },
        '&:hover': {
          background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 100%)`,
          boxShadow: `0 6px 24px ${alpha(theme.palette.primary.main, 0.5)}`,
          color: '#ffffff !important',
        },
        '&.Mui-disabled': {
          background: alpha(theme.palette.primary.main, 0.3),
          color: alpha('#ffffff', 0.5),
        },
      };
    }
    return {};
  };

  return (
    <Button
      variant={variant === 'gradient' ? 'contained' : variant}
      disabled={disabled || loading}
      sx={{
        position: 'relative',
        overflow: 'hidden',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        ...getVariantStyles(),
        ...(loading && {
          pointerEvents: 'none',
        }),
        '&::after': {
          content: '""',
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: 0,
          height: 0,
          borderRadius: '50%',
          background: alpha('#fff', 0.3),
          transform: 'translate(-50%, -50%)',
          transition: 'width 0.6s, height 0.6s',
        },
        '&:active::after': {
          width: '300px',
          height: '300px',
          transition: 'width 0s, height 0s',
        },
        ...sx,
      }}
      {...props}
    >
      {loading && (
        <CircularProgress
          size={20}
          sx={{
            position: 'absolute',
            color: variant === 'gradient' || gradient ? '#ffffff' : 'inherit',
          }}
        />
      )}
      <span
        style={{
          opacity: loading ? 0 : 1,
          transition: 'opacity 0.2s',
          color: variant === 'gradient' || gradient ? '#ffffff' : 'inherit',
        }}
      >
        {children}
      </span>
    </Button>
  );
};
