/**
 * ModernLoadingState - Advanced loading indicators
 * Features: skeleton screens, shimmer effects, and spinners
 */

import * as React from 'react';
import {
  Box,
  CircularProgress,
  Skeleton,
  Stack,
  Typography,
  alpha,
  useTheme,
  keyframes,
} from '@mui/material';

export interface IModernLoadingStateProps {
  type?: 'spinner' | 'skeleton' | 'shimmer';
  text?: string;
  rows?: number;
  height?: number;
  overlay?: boolean;
}

const shimmer = keyframes`
  0% {
    background-position: -1000px 0;
  }
  100% {
    background-position: 1000px 0;
  }
`;

export const ModernLoadingState: React.FC<IModernLoadingStateProps> = ({
  type = 'spinner',
  text = 'Loading...',
  rows = 3,
  height = 60,
  overlay = false,
}) => {
  const theme = useTheme();

  const renderSpinner = () => (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 3,
        p: 6,
      }}
    >
      <Box sx={{ position: 'relative' }}>
        <CircularProgress
          size={60}
          thickness={4}
          sx={{
            color: theme.palette.primary.main,
            animationDuration: '1.5s',
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            bottom: 0,
            right: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <CircularProgress
            size={40}
            thickness={4}
            variant="determinate"
            value={30}
            sx={{
              color: alpha(theme.palette.primary.main, 0.3),
            }}
          />
        </Box>
      </Box>
      {text && (
        <Typography
          variant="body1"
          color="text.secondary"
          fontWeight={500}
        >
          {text}
        </Typography>
      )}
    </Box>
  );

  const renderSkeleton = () => (
    <Stack spacing={2}>
      {Array.from({ length: rows }).map((_, index) => (
        <Box key={index}>
          <Skeleton
            variant="rectangular"
            height={height}
            sx={{
              borderRadius: 3,
              bgcolor: alpha(theme.palette.primary.main, 0.05),
            }}
            animation="wave"
          />
        </Box>
      ))}
    </Stack>
  );

  const renderShimmer = () => (
    <Stack spacing={2}>
      {Array.from({ length: rows }).map((_, index) => (
        <Box
          key={index}
          sx={{
            height: `${height}px`,
            borderRadius: 3,
            background: `linear-gradient(90deg,
              ${alpha(theme.palette.primary.main, 0.05)} 0px,
              ${alpha(theme.palette.primary.main, 0.15)} 50%,
              ${alpha(theme.palette.primary.main, 0.05)} 100%)`,
            backgroundSize: '1000px 100%',
            animation: `${shimmer} 2s infinite linear`,
          }}
        />
      ))}
    </Stack>
  );

  const content = (() => {
    switch (type) {
      case 'skeleton':
        return renderSkeleton();
      case 'shimmer':
        return renderShimmer();
      default:
        return renderSpinner();
    }
  })();

  if (overlay) {
    return (
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: alpha(theme.palette.background.default, 0.9),
          backdropFilter: 'blur(8px)',
          zIndex: theme.zIndex.modal,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {content}
      </Box>
    );
  }

  return content;
};

/**
 * Content Placeholder - Skeleton for specific content types
 */
export const ContentPlaceholder: React.FC<{
  type: 'card' | 'table' | 'form' | 'text';
}> = ({ type }) => {
  const theme = useTheme();

  if (type === 'card') {
    return (
      <Box
        sx={{
          p: 3,
          borderRadius: 4,
          border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        }}
      >
        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
          <Skeleton variant="circular" width={48} height={48} />
          <Box sx={{ flex: 1 }}>
            <Skeleton variant="text" width="60%" height={24} />
            <Skeleton variant="text" width="40%" height={20} />
          </Box>
        </Box>
        <Skeleton variant="rectangular" height={120} sx={{ borderRadius: 2, mb: 2 }} />
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Skeleton variant="rectangular" width={80} height={36} sx={{ borderRadius: 1 }} />
          <Skeleton variant="rectangular" width={80} height={36} sx={{ borderRadius: 1 }} />
        </Box>
      </Box>
    );
  }

  if (type === 'table') {
    return (
      <Stack spacing={1}>
        <Skeleton variant="rectangular" height={56} sx={{ borderRadius: 2 }} />
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} variant="rectangular" height={52} />
        ))}
      </Stack>
    );
  }

  if (type === 'form') {
    return (
      <Stack spacing={3}>
        {Array.from({ length: 4 }).map((_, i) => (
          <Box key={i}>
            <Skeleton variant="text" width={120} height={24} sx={{ mb: 1 }} />
            <Skeleton variant="rectangular" height={56} sx={{ borderRadius: 2 }} />
          </Box>
        ))}
      </Stack>
    );
  }

  return (
    <Stack spacing={1}>
      {Array.from({ length: 3 }).map((_, i) => (
        <Skeleton key={i} variant="text" height={24} />
      ))}
    </Stack>
  );
};
