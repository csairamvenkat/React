/**
 * ModernTextField - Advanced MUI TextField with sophisticated styling
 * Features: floating labels, helper icons, character counter
 */

import * as React from 'react';
import {
  TextField,
  InputAdornment,
  Typography,
  Box,
  alpha,
  useTheme,
} from '@mui/material';
import type { TextFieldProps } from '@mui/material';

export interface IModernTextFieldProps extends Omit<TextFieldProps, 'variant'> {
  helperIcon?: React.ReactNode;
  showCharacterCount?: boolean;
  gradient?: boolean;
}

export const ModernTextField: React.FC<IModernTextFieldProps> = ({
  helperIcon,
  showCharacterCount = false,
  gradient = false,
  helperText,
  inputProps,
  ...props
}) => {
  const theme = useTheme();
  const [focused, setFocused] = React.useState(false);
  const value = props.value as string || '';
  const maxLength = inputProps?.maxLength;

  return (
    <Box sx={{ position: 'relative', width: '100%' }}>
      <TextField
        {...props}
        variant="outlined"
        fullWidth
        onFocus={(e) => {
          setFocused(true);
          props.onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          props.onBlur?.(e);
        }}
        InputProps={{
          ...props.InputProps,
          startAdornment: helperIcon ? (
            <InputAdornment position="start">
              <Box
                sx={{
                  color: focused ? 'primary.main' : 'text.secondary',
                  transition: 'color 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                }}
              >
                {helperIcon}
              </Box>
            </InputAdornment>
          ) : props.InputProps?.startAdornment,
        }}
        inputProps={{
          ...inputProps,
        }}
        sx={{
          '& .MuiOutlinedInput-root': {
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            backgroundColor: gradient
              ? `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.02)} 0%, ${alpha(theme.palette.secondary.main, 0.02)} 100%)`
              : 'background.paper',
            '&:hover': {
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: theme.palette.primary.light,
                borderWidth: 2,
              },
            },
            '&.Mui-focused': {
              backgroundColor: alpha(theme.palette.primary.main, 0.03),
              boxShadow: `0 0 0 4px ${alpha(theme.palette.primary.main, 0.1)}`,
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: theme.palette.primary.main,
                borderWidth: 2,
              },
            },
          },
          '& .MuiInputLabel-root': {
            fontWeight: 500,
            '&.Mui-focused': {
              fontWeight: 600,
              color: theme.palette.primary.main,
            },
          },
          ...props.sx,
        }}
      />
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mt: 0.5,
          px: 1.5,
        }}
      >
        {helperText && (
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ flex: 1 }}
          >
            {helperText}
          </Typography>
        )}
        {showCharacterCount && maxLength && (
          <Typography
            variant="caption"
            sx={{
              color: value.length > maxLength * 0.9 ? 'warning.main' : 'text.secondary',
              fontWeight: 500,
              ml: 'auto',
            }}
          >
            {value.length} / {maxLength}
          </Typography>
        )}
      </Box>
    </Box>
  );
};
