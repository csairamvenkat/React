/**
 * ModernAutocomplete - Advanced autocomplete with search
 * Features: debouncing, async loading, sophisticated styling
 */

import * as React from 'react';
import {
  Autocomplete,
  TextField,
  CircularProgress,
  Paper,
  alpha,
  useTheme,
  Popper,
  PopperProps,
} from '@mui/material';

export interface IModernAutocompleteProps<T> {
  label: string;
  value: T | null;
  onChange: (value: T | null) => void;
  onSearch: (query: string) => Promise<T[]>;
  getOptionLabel: (option: T) => string;
  onInputChange?: (text: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: boolean;
  helperText?: string;
  minChars?: number;
  debounceMs?: number;
  freeSolo?: boolean;
  renderOption?: (props: any, option: T) => React.ReactNode;
}

// Custom styled Popper for dropdown
const CustomPopper = (props: PopperProps) => {
  const theme = useTheme();
  return (
    <Popper
      {...props}
      sx={{
        '& .MuiPaper-root': {
          borderRadius: 3,
          mt: 1,
          boxShadow: `0 8px 32px ${alpha(theme.palette.common.black, 0.15)}`,
          border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        },
        ...props.sx,
      }}
      placement="bottom-start"
    />
  );
};

export function ModernAutocomplete<T>({
  label,
  value,
  onChange,
  onSearch,
  getOptionLabel,
  onInputChange,
  placeholder,
  required = false,
  disabled = false,
  error = false,
  helperText,
  minChars = 2,
  debounceMs = 400,
  freeSolo = false,
  renderOption,
}: IModernAutocompleteProps<T>) {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [options, setOptions] = React.useState<T[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [inputValue, setInputValue] = React.useState('');
  const debounceRef = React.useRef<number>();

  React.useEffect(() => {
    if (inputValue.length < minChars) {
      setOptions([]);
      return;
    }

    setLoading(true);

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(async () => {
      try {
        const results = await onSearch(inputValue);
        setOptions(results);
      } catch (error) {
        console.error('Autocomplete search error:', error);
        setOptions([]);
      } finally {
        setLoading(false);
      }
    }, debounceMs);

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [inputValue, minChars, debounceMs, onSearch]);

  return (
    <Autocomplete
      fullWidth
      open={open}
      onOpen={() => setOpen(true)}
      onClose={() => setOpen(false)}
      value={value}
      onChange={(_, newValue) => onChange(newValue as T | null)}
      inputValue={inputValue}
      onInputChange={(_, newInputValue) => {
        setInputValue(newInputValue);
        if (typeof newInputValue === "string" && onInputChange) {
          onInputChange(newInputValue);
        }
      }}
      options={options}
      loading={loading}
      getOptionLabel={(option) => (typeof option === 'string' ? option : getOptionLabel(option as T))}
      disabled={disabled}
      freeSolo={freeSolo}
      PopperComponent={CustomPopper}
      renderOption={
        renderOption ||
        ((props, option) => (
          <li
            {...props}
            style={{
              padding: '12px 16px',
              transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
              ...props.style,
            }}
          >
            {getOptionLabel(option)}
          </li>
        ))
      }
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={placeholder}
          required={required}
          error={error}
          helperText={
            helperText ||
            (inputValue.length > 0 && inputValue.length < minChars
              ? `Type at least ${minChars} characters to search`
              : '')
          }
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
          sx={{
            '& .MuiOutlinedInput-root': {
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              backgroundColor: alpha(theme.palette.background.paper, 0.8),
              '&:hover': {
                backgroundColor: theme.palette.background.paper,
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme.palette.primary.light,
                  borderWidth: 2,
                },
              },
              '&.Mui-focused': {
                backgroundColor: theme.palette.background.paper,
                boxShadow: `0 0 0 4px ${alpha(theme.palette.primary.main, 0.1)}`,
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme.palette.primary.main,
                  borderWidth: 2,
                },
              },
            },
            '& .MuiInputLabel-root': {
              fontWeight: 500,
              '&.Mui-focused': {
                fontWeight: 600,
                color: theme.palette.primary.main,
              },
            },
          }}
        />
      )}
      PaperComponent={(props) => (
        <Paper
          {...props}
          sx={{
            '& .MuiAutocomplete-listbox': {
              '& .MuiAutocomplete-option': {
                '&[aria-selected="true"]': {
                  backgroundColor: alpha(theme.palette.primary.main, 0.12),
                  borderLeft: `3px solid ${theme.palette.primary.main}`,
                },
                '&.Mui-focused, &:hover': {
                  backgroundColor: alpha(theme.palette.primary.main, 0.08),
                  transform: 'translateX(4px)',
                },
              },
            },
          }}
        />
      )}
    />
  );
}
