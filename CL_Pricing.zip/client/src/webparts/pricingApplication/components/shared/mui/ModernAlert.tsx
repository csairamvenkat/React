/**
 * ModernAlert - Advanced alert/notification component
 * Sophisticated design with icons and animations
 */

import * as React from 'react';
import {
  Alert,
  AlertTitle,
  Collapse,
  IconButton,
  alpha,
  useTheme,
} from '@mui/material';
import type { AlertProps } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

export interface IModernAlertProps extends AlertProps {
  title?: string;
  onClose?: () => void;
  autoHideDuration?: number;
  elevated?: boolean;
  gradient?: boolean;
}

export const ModernAlert: React.FC<IModernAlertProps> = ({
  title,
  children,
  onClose,
  autoHideDuration,
  elevated = false,
  gradient = false,
  severity = 'info',
  sx = {},
  ...props
}) => {
  const theme = useTheme();
  const [open, setOpen] = React.useState(true);

  React.useEffect(() => {
    if (autoHideDuration && autoHideDuration > 0) {
      const timer = setTimeout(() => {
        setOpen(false);
        if (onClose) {
          setTimeout(onClose, 300); // Wait for collapse animation
        }
      }, autoHideDuration);

      return () => clearTimeout(timer);
    }
  }, [autoHideDuration, onClose]);

  const handleClose = () => {
    setOpen(false);
    if (onClose) {
      setTimeout(onClose, 300);
    }
  };

  const getGradientStyles = () => {
    if (!gradient) return {};

    const colorMap = {
      success: [theme.palette.success.main, theme.palette.success.light],
      error: [theme.palette.error.main, theme.palette.error.light],
      warning: [theme.palette.warning.main, theme.palette.warning.light],
      info: [theme.palette.info.main, theme.palette.info.light],
    };

    const colors = colorMap[severity as keyof typeof colorMap] || colorMap.info;

    return {
      background: `linear-gradient(135deg, ${alpha(colors[0], 0.1)}, ${alpha(colors[1], 0.05)})`,
      borderLeft: `4px solid ${colors[0]}`,
    };
  };

  return (
    <Collapse in={open}>
      <Alert
        {...props}
        severity={severity}
        action={
          onClose && (
            <IconButton
              size="small"
              onClick={handleClose}
              sx={{
                color: 'inherit',
                '&:hover': {
                  backgroundColor: alpha(theme.palette.common.black, 0.1),
                },
              }}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          )
        }
        sx={{
          borderRadius: 3,
          boxShadow: elevated ? theme.shadows[2] : 'none',
          '& .MuiAlert-icon': {
            fontSize: 24,
          },
          '& .MuiAlert-message': {
            width: '100%',
          },
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:hover': {
            transform: 'translateX(4px)',
          },
          ...getGradientStyles(),
          ...sx,
        }}
      >
        {title && (
          <AlertTitle
            sx={{
              fontWeight: 700,
              fontSize: '1rem',
              mb: title && children ? 1 : 0,
            }}
          >
            {title}
          </AlertTitle>
        )}
        {children}
      </Alert>
    </Collapse>
  );
};
