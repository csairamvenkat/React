/**
 * ModernStepper - Advanced multi-step wizard with sophisticated design
 * Features: validation, animations, progress tracking
 */

import * as React from 'react';
import {
  Box,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Paper,
  Typography,
  alpha,
  useTheme,
  StepConnector,
  stepConnectorClasses,
  styled,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { ModernButton } from './ModernButton';

export interface IModernStepperStep {
  label: string;
  description?: string;
  icon?: React.ReactNode;
  content: React.ReactNode;
  validate?: () => boolean | Promise<boolean>;
  optional?: boolean;
}

export interface IModernStepperProps {
  steps: IModernStepperStep[];
  orientation?: 'horizontal' | 'vertical';
  onComplete: () => void;
  onCancel?: () => void;
  completeText?: string;
  nextText?: string;
  backText?: string;
  cancelText?: string;
  showProgress?: boolean;
  completeDisabled?: boolean;
  loading?: boolean;
}

const ModernStepConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.primary.light})`,
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: `linear-gradient(90deg, ${theme.palette.success.main}, ${theme.palette.success.light})`,
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: alpha(theme.palette.divider, 0.2),
    borderRadius: 1,
  },
}));

export const ModernStepper: React.FC<IModernStepperProps> = ({
  steps,
  orientation = 'horizontal',
  onComplete,
  onCancel,
  completeText = 'Complete',
  nextText = 'Next',
  backText = 'Back',
  cancelText = 'Cancel',
  showProgress = true,
  completeDisabled = false,
  loading = false,
}) => {
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const [validating, setValidating] = React.useState(false);
  const topRef = React.useRef<HTMLDivElement>(null);

  const scrollToTop = () => {
    // Walk up the DOM to find and scroll any scrollable ancestor
    if (topRef.current) {
      let el: HTMLElement | null = topRef.current.parentElement;
      while (el && el !== document.body) {
        const { overflowY, overflow } = window.getComputedStyle(el);
        if ((overflowY === 'auto' || overflowY === 'scroll' || overflow === 'auto' || overflow === 'scroll') && el.scrollHeight > el.clientHeight) {
          el.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
        el = el.parentElement;
      }
    }
    // Fallback: scroll the window
    window.scrollTo({ top: 0, behavior: 'smooth' });
    document.documentElement.scrollTo({ top: 0, behavior: 'smooth' });
    document.body.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isLastStep = activeStep === steps.length - 1;
  const progress = ((activeStep + 1) / steps.length) * 100;

  const handleNext = async () => {
    const currentStep = steps[activeStep];

    if (currentStep.validate) {
      setValidating(true);
      try {
        const isValid = await currentStep.validate();
        if (!isValid) {
          setValidating(false);
          return;
        }
      } catch (error) {
        console.error('Validation error:', error);
        setValidating(false);
        return;
      }
      setValidating(false);
    }

    if (isLastStep) {
      onComplete();
    } else {
      setActiveStep((prev) => prev + 1);
      scrollToTop();
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    scrollToTop();
  };

  const handleStepClick = (index: number) => {
    if (index < activeStep) {
      setActiveStep(index);
    }
  };

  return (
    <Box ref={topRef}>
      {showProgress && orientation === 'horizontal' && (
        <Box
          sx={{
            mb: 4,
            p: 3,
            borderRadius: 3,
            background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.05)}, ${alpha(theme.palette.secondary.main, 0.05)})`,
            border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body2" fontWeight={600} color="primary">
              Step {activeStep + 1} of {steps.length}
            </Typography>
            <Typography variant="body2" fontWeight={600} color="primary">
              {Math.round(progress)}%
            </Typography>
          </Box>
          <Box
            sx={{
              height: 8,
              borderRadius: 4,
              backgroundColor: alpha(theme.palette.primary.main, 0.1),
              overflow: 'hidden',
            }}
          >
            <Box
              sx={{
                height: '100%',
                width: `${progress}%`,
                background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.primary.light})`,
                borderRadius: 4,
                transition: 'width 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                boxShadow: `0 0 12px ${alpha(theme.palette.primary.main, 0.5)}`,
              }}
            />
          </Box>
        </Box>
      )}

      <Stepper
        activeStep={activeStep}
        orientation={orientation}
        connector={<ModernStepConnector />}
        sx={{
          mb: 4,
          ...(orientation === 'horizontal' && {
            '.MuiStepLabel-root': {
              cursor: 'pointer',
            },
          }),
        }}
      >
        {steps.map((step, index) => {
          const isCompleted = index < activeStep;
          const isActive = index === activeStep;

          return (
            <Step key={step.label} completed={isCompleted}>
              <StepLabel
                onClick={() => handleStepClick(index)}
                optional={
                  step.optional ? (
                    <Typography variant="caption">Optional</Typography>
                  ) : undefined
                }
                StepIconComponent={() => (
                  <Box
                    sx={{
                      width: 44,
                      height: 44,
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      background: isCompleted
                        ? `linear-gradient(135deg, ${theme.palette.success.main}, ${theme.palette.success.light})`
                        : isActive
                          ? `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.light})`
                          : alpha(theme.palette.divider, 0.2),
                      color: isCompleted || isActive ? 'white' : 'text.secondary',
                      fontWeight: 600,
                      fontSize: '1rem',
                      boxShadow: isActive
                        ? `0 4px 16px ${alpha(theme.palette.primary.main, 0.4)}`
                        : isCompleted
                          ? `0 4px 16px ${alpha(theme.palette.success.main, 0.3)}`
                          : 'none',
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    }}
                  >
                    {isCompleted ? (
                      <CheckCircleIcon sx={{ fontSize: 24 }} />
                    ) : step.icon ? (
                      step.icon
                    ) : (
                      index + 1
                    )}
                  </Box>
                )}
                sx={{
                  '.MuiStepLabel-label': {
                    fontWeight: isActive ? 600 : 400,
                    fontSize: isActive ? '1rem' : '0.938rem',
                    color: isActive
                      ? 'primary.main'
                      : isCompleted
                        ? 'success.main'
                        : 'text.secondary',
                  },
                }}
              >
                <Typography variant="subtitle1" fontWeight={isActive ? 600 : 500}>
                  {step.label}
                </Typography>
                {step.description && (
                  <Typography variant="caption" color="text.secondary">
                    {step.description}
                  </Typography>
                )}
              </StepLabel>
              {orientation === 'vertical' && (
                <StepContent>
                  {step.content}
                </StepContent>
              )}
            </Step>
          );
        })}
      </Stepper>

      {orientation === 'horizontal' && (
        <Paper
          elevation={0}
          sx={{
            p: 4,
            mb: 3,
            borderRadius: 3,
            border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
            background: `linear-gradient(135deg, ${alpha(theme.palette.background.paper, 0.8)}, ${alpha(theme.palette.background.default, 0.8)})`,
            minHeight: 300,
          }}
        >
          {steps[activeStep].content}
        </Paper>
      )}

      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          pt: 2,
        }}
      >
        <Box sx={{ display: 'flex', gap: 1 }}>
          {onCancel && (
            <ModernButton variant="outlined" onClick={onCancel}>
              {cancelText}
            </ModernButton>
          )}
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {activeStep > 0 && (
            <ModernButton variant="outlined" onClick={handleBack}>
              {backText}
            </ModernButton>
          )}
          <ModernButton
            variant="gradient"
            glow
            onClick={handleNext}
            // loading={validating}
            loading={loading || validating}
            disabled={loading || completeDisabled}

          >
            {isLastStep ? completeText : nextText}
          </ModernButton>
        </Box>
      </Box>

    </Box>
  );
};
