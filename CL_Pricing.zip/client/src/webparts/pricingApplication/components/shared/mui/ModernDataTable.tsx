import * as React from 'react';
import {
  DataGrid,
  GridColDef,
  GridRowsProp,
  GridPaginationModel,
} from '@mui/x-data-grid';
import { Box, alpha, useTheme } from '@mui/material';

export interface IModernDataTableProps {
  rows: GridRowsProp;
  columns: GridColDef[];
  freezeColumns?: {
    field: string;
    left: number;
  }[];
  loading?: boolean;
  pagination?: boolean;
  pageSizeOptions?: number[];
  onRowClick?: (row: any) => void;
  autoHeight?: boolean;
  checkboxSelection?: boolean;
  onSelectionChange?: (selectedIds: any[]) => void;
  elevation?: number;
  serverPagination?: boolean;
  rowCount?: number;
  paginationModel?: GridPaginationModel;
  onPaginationModelChange?: (model: GridPaginationModel) => void;
  page?: number;
  pageSize?: number;
  onPageChange?: (newPage: number) => void;
  onPageSizeChange?: (newSize: number) => void;
  sx?: any;
  tableMinWidth?: number;
  getRowClassName?: (params: any) => string;
  filterModel?: any;
  onFilterModelChange?: (model: any) => void;
  getRowHeight?: any;
}

export const ModernDataTable: React.FC<IModernDataTableProps> = ({
  rows,
  columns,
  freezeColumns = [],
  loading = false,
  pagination = true,
  pageSizeOptions = [10, 25, 50, 100],
  onRowClick,
  autoHeight = false,
  checkboxSelection = false,
  onSelectionChange,
  elevation = 0,
  serverPagination = false,
  rowCount,
  paginationModel,
  onPaginationModelChange,
  page,
  pageSize,
  onPageChange,
  onPageSizeChange,
  sx,
  tableMinWidth,
  getRowClassName,
  getRowHeight,
  filterModel,
  onFilterModelChange,

}) => {
  const theme = useTheme();

  const [localPagination, setLocalPagination] = React.useState<GridPaginationModel>({
    page: 0,
    pageSize: pageSize ?? 10,
  });

  const effectiveModel: GridPaginationModel = serverPagination
    ? paginationModel ?? { page: page ?? 0, pageSize: pageSize ?? 10 }
    : localPagination;

  const handlePaginationModelChange = (model: GridPaginationModel) => {
    if (serverPagination) {
      onPaginationModelChange?.(model);
      if (typeof model.page === 'number') onPageChange?.(model.page);
      if (typeof model.pageSize === 'number') onPageSizeChange?.(model.pageSize);
    } else {
      setLocalPagination(model);
    }
  };

  return (
    <Box
      sx={{
        overflowX: 'auto',
        borderRadius: 4,
        border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
        backgroundColor: 'background.paper',
        boxShadow: elevation > 0 ? theme.shadows[elevation] : 'none',
        ...sx,
      }}
    >
      <Box sx={{ minWidth: tableMinWidth ?? 'auto', width: '100%' }}>
        <DataGrid
          key={`pg-${effectiveModel.page}-ps-${effectiveModel.pageSize}`}
          rows={rows}
          columns={columns}
          loading={loading}
          getRowHeight={getRowHeight}
          pagination
          paginationMode={serverPagination ? 'server' : 'client'}
          paginationModel={effectiveModel}
          filterModel={filterModel}
          onFilterModelChange={onFilterModelChange}
          onPaginationModelChange={handlePaginationModelChange}
          rowCount={serverPagination ? rowCount : undefined}
          pageSizeOptions={pageSizeOptions}
          getRowId={(r: any) => r.id ?? r._id ?? r.uuid ?? r.key ?? r.Id ?? r.ID}
          autoHeight={autoHeight}
          checkboxSelection={checkboxSelection}
          disableRowSelectionOnClick={!onRowClick}
          onRowSelectionModelChange={(ids) => onSelectionChange?.(ids as any)}
          onRowClick={(params) => onRowClick?.(params.row)}
          getRowClassName={getRowClassName}
          // disableVirtualization
          sx={{
            border: 'none',

            ...freezeColumns.reduce((acc, col, index) => {
              acc[`& .MuiDataGrid-columnHeader[data-field="${col.field}"]`] = {
                position: 'sticky',
                left: col.left,
                zIndex: 1000 + index,
                backgroundColor: theme.palette.background.paper,
              };

              acc[`& .MuiDataGrid-cell[data-field="${col.field}"]`] = {
                position: 'sticky',
                left: col.left,
                zIndex: 10 + index,
                backgroundColor: theme.palette.background.paper,
              };

              return acc;
            }, {} as any),
            '& .MuiDataGrid-virtualScroller': {
              overflow: 'auto',
            },


            '& .MuiDataGrid-columnHeaders': {
              position: 'sticky',
              top: 0,
              zIndex: 2,
              backgroundColor: theme.palette.background.paper,
            },

            '& .MuiDataGrid-footerContainer': {
              position: 'sticky',
              bottom: 0,
              zIndex: 2,
              backgroundColor: theme.palette.background.paper,
              borderTop: `2px solid ${alpha(theme.palette.divider, 0.1)}`
            },


            // '& .MuiDataGrid-main': {
            //   overflow: 'visible',
            // },

            // '& .MuiDataGrid-cell': {
            //   backgroundClip: 'padding-box',
            // },


            '& .MuiDataGrid-main .MuiDataGrid-columnHeaders': {
              backgroundColor: alpha(theme.palette.primary.main, 0.04),
              borderRadius: 0,
            },
            '& .MuiDataGrid-columnHeader, & .MuiDataGrid-cell': {
              '&:focus, &:focus-within': { outline: 'none' },
            },
            '& .MuiDataGrid-cell': {
              borderColor: alpha(theme.palette.divider, 0.06),
              backgroundClip: 'padding-box',
            },
            '& .MuiDataGrid-row': {
              transition: 'background-color 0.2s ease',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.04),
                cursor: onRowClick ? 'pointer' : 'default',
              },
              '&.Mui-selected': {
                backgroundColor: alpha(theme.palette.primary.main, 0.08),
                '&:hover': { backgroundColor: alpha(theme.palette.primary.main, 0.12) },
              },
              '&.row-inactive': {
                backgroundColor: alpha(theme.palette.grey[500], 0.08),
                borderLeft: `3px solid ${theme.palette.grey[400]}`,
                '& .MuiDataGrid-cell': {
                  color: theme.palette.grey[400],
                },
                '&:hover': {
                  backgroundColor: alpha(theme.palette.grey[500], 0.13),
                },
              },
            }
            // '& .MuiDataGrid-footerContainer': {
            //   borderTop: `2px solid ${alpha(theme.palette.divider, 0.1)}`,
            //   backgroundColor: alpha(theme.palette.background.default, 0.5),
            // },
          }}
        />
      </Box>
    </Box>
  );
};
