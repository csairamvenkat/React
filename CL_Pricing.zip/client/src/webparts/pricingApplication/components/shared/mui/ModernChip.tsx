/**
 * ModernChip - Advanced status badge with sophisticated styling
 * Features: gradients, icons, animations
 */

import * as React from 'react';
import { Chip, alpha, useTheme } from '@mui/material';
import type { ChipProps } from '@mui/material';

export type ChipVariantType = 'success' | 'error' | 'warning' | 'info' | 'default' | 'primary' | 'secondary';

export interface IModernChipProps extends Omit<ChipProps, 'color'> {
  colorVariant?: ChipVariantType;
  gradient?: boolean;
  glow?: boolean;
  pulse?: boolean;
}

export const ModernChip: React.FC<IModernChipProps> = ({
  colorVariant = 'default',
  gradient = false,
  glow = false,
  pulse = false,
  sx = {},
  ...props
}) => {
  const theme = useTheme();

  const getColorStyles = () => {
    let backgroundColor: string;
    let textColor: string;
    let borderColor: string;

    switch (colorVariant) {
      case 'success':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.success.main}, ${theme.palette.success.light})`
          : alpha(theme.palette.success.main, 0.12);
        textColor = gradient ? 'white' : theme.palette.success.dark;
        borderColor = theme.palette.success.main;
        break;
      case 'error':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.error.main}, ${theme.palette.error.light})`
          : alpha(theme.palette.error.main, 0.12);
        textColor = gradient ? 'white' : theme.palette.error.dark;
        borderColor = theme.palette.error.main;
        break;
      case 'warning':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.warning.main}, ${theme.palette.warning.light})`
          : alpha(theme.palette.warning.main, 0.12);
        textColor = gradient ? 'white' : theme.palette.warning.dark;
        borderColor = theme.palette.warning.main;
        break;
      case 'info':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.info.main}, ${theme.palette.info.light})`
          : alpha(theme.palette.info.main, 0.12);
        textColor = gradient ? 'white' : theme.palette.info.dark;
        borderColor = theme.palette.info.main;
        break;
      case 'primary':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.primary.light})`
          : alpha(theme.palette.primary.main, 0.12);
        textColor = gradient ? 'white' : theme.palette.primary.dark;
        borderColor = theme.palette.primary.main;
        break;
      case 'secondary':
        backgroundColor = gradient
          ? `linear-gradient(135deg, ${theme.palette.secondary.main}, ${theme.palette.secondary.light})`
          : alpha(theme.palette.secondary.main, 0.12);
        textColor = gradient ? theme.palette.secondary.contrastText : theme.palette.text.primary;
        borderColor = theme.palette.secondary.main;
        break;
      default:
        backgroundColor = alpha(theme.palette.text.primary, 0.08);
        textColor = theme.palette.text.primary;
        borderColor = alpha(theme.palette.text.primary, 0.2);
    }

    return { backgroundColor, textColor, borderColor };
  };

  const { backgroundColor, textColor, borderColor } = getColorStyles();

  return (
    <Chip
      {...props}
      sx={{
        fontWeight: 600,
        fontSize: '0.813rem',
        height: 28,
        borderRadius: 2,
        background: backgroundColor,
        color: textColor,
        border: `1px solid ${alpha(borderColor, 0.3)}`,
        boxShadow: glow ? `0 4px 12px ${alpha(borderColor, 0.3)}` : 'none',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        ...(pulse && {
          animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
          '@keyframes pulse': {
            '0%, 100%': {
              opacity: 1,
            },
            '50%': {
              opacity: 0.7,
            },
          },
        }),
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: `0 6px 16px ${alpha(borderColor, 0.4)}`,
        },
        '& .MuiChip-icon': {
          color: textColor,
        },
        '& .MuiChip-deleteIcon': {
          color: textColor,
          '&:hover': {
            color: textColor,
            opacity: 0.8,
          },
        },
        ...sx,
      }}
    />
  );
};
