/**
 * StatusBadge - Color-coded status indicators
 * Used for file status, round status, and other state indicators
 */

import * as React from 'react';
import { Text, Icon } from '@fluentui/react';
import { colors, shadows, transitions } from '../../theme/tokens';

export type StatusType = 'success' | 'error' | 'warning' | 'info' | 'neutral' | 'pending' | 'active' | 'inactive';

export interface IStatusBadgeProps {
  status: StatusType;
  text: string;
  icon?: string;
  size?: 'small' | 'medium' | 'large';
}

const statusConfig: Record<StatusType, { backgroundColor: string; color: string; borderColor: string }> = {
  success: {
    backgroundColor: colors.successLight,
    color: colors.successDark,
    borderColor: colors.success,
  },
  error: {
    backgroundColor: colors.errorLight,
    color: colors.errorDark,
    borderColor: colors.error,
  },
  warning: {
    backgroundColor: colors.warningLight,
    color: colors.neutralPrimary,
    borderColor: colors.warning,
  },
  info: {
    backgroundColor: colors.infoLight,
    color: colors.infoDark,
    borderColor: colors.info,
  },
  neutral: {
    backgroundColor: colors.neutralLighter,
    color: colors.neutralPrimary,
    borderColor: colors.neutralTertiary,
  },
  pending: {
    backgroundColor: colors.warningLight,
    color: colors.neutralPrimary,
    borderColor: colors.warning,
  },
  active: {
    backgroundColor: colors.successLight,
    color: colors.successDark,
    borderColor: colors.success,
  },
  inactive: {
    backgroundColor: colors.neutralLighter,
    color: colors.neutralSecondary,
    borderColor: colors.neutralTertiary,
  },
};

const sizeConfig = {
  small: {
    fontSize: '12px',
    padding: '2px 8px',
    iconSize: 12,
  },
  medium: {
    fontSize: '14px',
    padding: '4px 12px',
    iconSize: 14,
  },
  large: {
    fontSize: '16px',
    padding: '6px 16px',
    iconSize: 16,
  },
};

export const StatusBadge: React.FC<IStatusBadgeProps> = ({
  status,
  text,
  icon,
  size = 'medium',
}) => {
  const config = statusConfig[status];
  const sizeStyles = sizeConfig[size];

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        backgroundColor: config.backgroundColor,
        color: config.color,
        border: `1px solid ${config.borderColor}`,
        borderRadius: '12px',
        padding: sizeStyles.padding,
        fontSize: sizeStyles.fontSize,
        fontWeight: 500,
        whiteSpace: 'nowrap',
        boxShadow: shadows.xs,
        transition: `all ${transitions.fast}`,
      }}
    >
      {icon && (
        <Icon
          iconName={icon}
          styles={{
            root: {
              fontSize: sizeStyles.iconSize,
              color: config.color,
            },
          }}
        />
      )}
      <Text
        styles={{
          root: {
            color: config.color,
            fontSize: sizeStyles.fontSize,
            fontWeight: 500,
          },
        }}
      >
        {text}
      </Text>
    </span>
  );
};
