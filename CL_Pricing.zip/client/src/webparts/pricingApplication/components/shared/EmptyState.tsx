/**
 * EmptyState - Better empty state display
 * Replaces basic "No records found" messages with more engaging UI
 */

import * as React from 'react';
import { Stack, Text, PrimaryButton, Icon, IStackTokens } from '@fluentui/react';
import { colors, spacing, shadows, transitions } from '../../theme/tokens';

export interface IEmptyStateProps {
  icon?: string;
  title: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
  imageUrl?: string;
}

export const EmptyState: React.FC<IEmptyStateProps> = ({
  icon = 'EmptyRecycleBin',
  title,
  description,
  actionText,
  onAction,
  imageUrl,
}) => {
  const tokens: IStackTokens = {
    childrenGap: spacing.md,
  };

  return (
    <Stack
      horizontalAlign="center"
      verticalAlign="center"
      tokens={tokens}
      styles={{
        root: {
          padding: spacing.xxl,
          minHeight: '300px',
        },
      }}
    >
      {imageUrl ? (
        <img
          src={imageUrl}
          alt={title}
          style={{
            maxWidth: '200px',
            opacity: 0.6,
          }}
        />
      ) : (
        <div
          style={{
            width: 80,
            height: 80,
            borderRadius: '50%',
            backgroundColor: colors.neutralLighter,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: spacing.md,
            boxShadow: shadows.sm,
          }}
        >
          <Icon
            iconName={icon}
            styles={{
              root: {
                fontSize: 40,
                color: colors.neutralTertiary,
              },
            }}
          />
        </div>
      )}

      <Text
        variant="xLarge"
        styles={{
          root: {
            fontWeight: 600,
            color: colors.textPrimary,
            textAlign: 'center',
          },
        }}
      >
        {title}
      </Text>

      {description && (
        <Text
          variant="medium"
          styles={{
            root: {
              color: colors.textSecondary,
              textAlign: 'center',
              maxWidth: '400px',
            },
          }}
        >
          {description}
        </Text>
      )}

      {actionText && onAction && (
        <PrimaryButton
          text={actionText}
          onClick={onAction}
          iconProps={{ iconName: 'Add' }}
          styles={{
            root: {
              marginTop: spacing.md,
              transition: `all ${transitions.smooth}`,
              boxShadow: shadows.button,
            },
            rootHovered: {
              transform: 'translateY(-2px)',
              boxShadow: shadows.buttonHover,
            },
          }}
        />
      )}
    </Stack>
  );
};
