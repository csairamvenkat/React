import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  TextField,
  InputAdornment,
  IconButton,
  Tooltip,
  Stack,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import VisibilityIcon from '@mui/icons-material/Visibility';
import { GridColDef } from '@mui/x-data-grid';
import { Round } from '../store/Models';
import { ApiDataProvider } from '../../api/ApiDataProvider';
import {
  ModernButton,
  ModernDataTable,
  ModernAlert,
  ModernLoadingState,
  ModernEmptyState,
} from '../shared/mui';

export default function RoundListView({
  opportunityId,
  pageSize = 10,
  showToolbar = true
}: {
  opportunityId?: number;
  pageSize?: number;
  showToolbar?: boolean;
}) {
  const { id: idFromRoute } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const cfg = (window as any).TENANT_CONFIG;
  const api = React.useMemo(
    () => new ApiDataProvider(
      (window as any).spfxContext,
      { resource: cfg.apiResource, baseUrl: cfg.apiBaseUrl }
    ),
    [cfg]
  );

  const [loadingRound, setLoadingRound] = React.useState(false);
  const oppId = opportunityId ?? Number(idFromRoute);
  const [items, setItems] = React.useState<Round[]>([]);
  const [filter, setFilter] = React.useState('');
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);
  const [hasAccess, setHasAccess] = React.useState(false);
  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasUncompletedRound, setHasUncompletedRound] = React.useState(false);
  const ALLOWED_GROUP_NAME = 'Pricing';

  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) throw new Error('Failed to fetch user groups');

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === 'Pricing'
        );

        if (active) setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        if (active) setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const load = React.useCallback(async () => {
    try {
      setLoadingRound(true);
      const data = await api.getRounds(oppId, 1, 100); // Load all rounds
      const list = Array.isArray(data) ? data : [];
      setItems(list);

      const uncompletedRound = list.some(
        (r: any) =>
          String(r.workflowStatus ?? "").trim().toLowerCase() !== "completed"
      );

      setHasUncompletedRound(uncompletedRound);

    } catch (err: any) {
      setToast({ severity: 'error', text: `Load failed: ${err.message}` });
    } finally {
      setLoadingRound(false);
    }
  }, [api, oppId]);

  React.useEffect(() => { void load(); }, [load]);

  const filtered = React.useMemo(() => {
    if (loadingRound) return items;
    const f = filter.toLowerCase();
    return items.filter(r =>
      [r.id?.toString(), r.name].some(v => (v ?? '').toLowerCase().includes(f))
    );
  }, [filter, items, loadingRound]);

  const columns: GridColDef[] = [
    {
      field: 'roundNumber',
      headerName: 'Round Number',
      width: 140,
    },
    {
      field: 'userStatus',
      headerName: 'Round Status',
      width: 160,
    },
    {
      field: 'description',
      headerName: 'Description',
      flex: 1,
      minWidth: 200,
    },
    {
      field: 'customerSubmissionDate',
      headerName: 'Customer Submission Date',
      width: 200,
      renderCell: (params) =>
        params.value ? new Date(params.value as string).toLocaleDateString() : '—',
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 100,
      sortable: false,
      renderCell: (params) => (
        <Tooltip title="View Round" arrow>
          <IconButton
            size="small"
            onClick={() => navigate(`/opportunities/${oppId}/rounds/${params.row.id}`)}
            sx={{
              color: 'primary.main',
              '&:hover': {
                backgroundColor: 'primary.light',
                color: 'white',
                transform: 'scale(1.1)',
              },
              transition: 'all 0.2s',
            }}
          >
            <VisibilityIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      ),
    },
  ];

  if (loadingRound) {
    return <ModernLoadingState type="shimmer" rows={4} height={80} />;
  }


  if (permissionLoading) {
    return <ModernLoadingState type="spinner" />;
  }


  return (
    <Stack spacing={2}>
      {toast && (
        <ModernAlert
          severity={toast.severity}
          onClose={() => setToast(null)}
          elevated
          gradient
        >
          {toast.text}
        </ModernAlert>
      )}

      {showToolbar && (
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            placeholder="Search rounds…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'primary.main' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              minWidth: 250,
              '& .MuiOutlinedInput-root': {
                backgroundColor: 'background.paper',
              },
            }}
          />
          {hasAccess && (
            <Tooltip
              title={
                hasUncompletedRound
                  ? "Cannot create a new round because the previous round is not completed."
                  : "Add Round"
              }
              arrow
            >
              <span>
                <ModernButton
                  variant="gradient"
                  glow
                  startIcon={<AddIcon />}
                  disabled={hasUncompletedRound}
                  onClick={() => navigate(`/opportunities/${oppId}/rounds/new`)}
                >
                  Add Round
                </ModernButton>
              </span>
            </Tooltip>
          )}
        </Box>
      )}

      {!loadingRound && items.length === 0 ? (
        <>
          {hasAccess && (
            <ModernEmptyState
              type="empty"
              title="No rounds found"
              description="Get started by creating a pricing round for this opportunity."
              actionText="Add Round"
              onAction={() => navigate(`/opportunities/${oppId}/rounds/new`)}
              animated
            />
          )}</>

      ) : filtered.length === 0 && filter ? (
        <ModernEmptyState
          type="search"
          title="No matching rounds"
          description={`No rounds match your search term "${filter}".`}
          animated
        />
      ) : (
        <ModernDataTable
          rows={filtered.map((r) => ({ ...r, id: r.id || 0 }))}
          columns={columns}
          loading={loadingRound}
          pagination
          pageSize={pageSize}
          pageSizeOptions={[10, 25, 50]}
          onRowClick={(row) => navigate(`/opportunities/${oppId}/rounds/${row.id}`)}
          autoHeight
          elevation={2}
        />
      )}
    </Stack>
  );
}