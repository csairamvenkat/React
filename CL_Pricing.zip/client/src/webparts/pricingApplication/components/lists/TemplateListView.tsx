import * as React from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  TextField,
  InputAdornment,
  Stack,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { GridColDef } from '@mui/x-data-grid';
import { Template } from '../store/Models';
import { ApiDataProvider } from '../../api/ApiDataProvider';
import {
  ModernDataTable,
  ModernAlert,
  ModernLoadingState,
  ModernEmptyState,
} from '../shared/mui';

export default function TemplateListView({
  opportunityId,
  roundId: roundIdProp,
  pageSize = 10,
  showToolbar = true,
  showAddButton = true,
  renderActions
}: {
  opportunityId?: number;
  roundId?: number;
  pageSize?: number;
  showToolbar?: boolean;
  showAddButton?: boolean;
  renderActions?: (t: Template, ctx: { opportunityId: number; roundId: number; cfg: any; reload: () => Promise<void> }) => React.ReactNode;
}) {
  const { id: idFromRoute, roundId: roundFromRoute } = useParams<{ id: string; roundId: string }>();
  const cfg = (window as any).TENANT_CONFIG;
  const api = React.useMemo(
    () => new ApiDataProvider(
      (window as any).spfxContext,
      { resource: cfg.apiResource, baseUrl: cfg.apiBaseUrl }
    ),
    [cfg]
  );

  const oppId = opportunityId ?? Number(idFromRoute);
  const roundId = roundIdProp ?? Number(roundFromRoute);

  const [items, setItems] = React.useState<Template[]>([]);
  const [filter, setFilter] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const load = React.useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getTemplates(roundId, 1, 100);
      setItems(data.items);
    } catch (err: any) {
      setToast({ severity: 'error', text: `Load failed: ${err.message}` });
    } finally {
      setLoading(false);
    }
  }, [api, roundId]);

  React.useEffect(() => { void load(); }, [load]);

  const filtered = React.useMemo(() => {
    const f = filter.toLowerCase();
    return items.filter(t =>
      [t.id.toString(), t.name].some(v => (v ?? '').toLowerCase().includes(f))
    );
  }, [filter, items]);

  const baseColumns: GridColDef[] = [
    {
      field: 'id',
      headerName: 'Template ID',
      width: 120,
    },
    {
      field: 'name',
      headerName: 'Name',
      flex: 1,
      minWidth: 200,
    },
  ];

  const actionColumn: GridColDef | null = renderActions
    ? {
        field: 'actions',
        headerName: 'Actions',
        width: 360,
        sortable: false,
        renderCell: (params) => renderActions(params.row as Template, { opportunityId: oppId, roundId, cfg, reload: load })
      }
    : null;

  const columns = actionColumn ? [...baseColumns, actionColumn] : baseColumns;

  if (loading) {
    return <ModernLoadingState type="shimmer" rows={4} height={80} />;
  }

  return (
    <Stack spacing={2}>
      {toast && (
        <ModernAlert
          severity={toast.severity}
          onClose={() => setToast(null)}
          elevated
          gradient
        >
          {toast.text}
        </ModernAlert>
      )}

      {showToolbar && (
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            placeholder="Search templates…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'primary.main' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              minWidth: 250,
              '& .MuiOutlinedInput-root': {
                backgroundColor: 'background.paper',
              },
            }}
          />
        </Box>
      )}

      {!loading && items.length === 0 ? (
        <ModernEmptyState
          type="empty"
          title="No templates found"
          description="Templates will appear here once they are added to this round."
          animated
        />
      ) : filtered.length === 0 && filter ? (
        <ModernEmptyState
          type="search"
          title="No matching templates"
          description={`No templates match your search term "${filter}".`}
          animated
        />
      ) : (
        <ModernDataTable
          rows={filtered}
          columns={columns}
          loading={loading}
          pagination
          pageSize={pageSize}
          pageSizeOptions={[10, 25, 50]}
          autoHeight
          elevation={2}
        />
      )}
    </Stack>
  );
}