import * as React from 'react';
import { Stack, IconButton, Text, useTheme } from '@fluentui/react';
import { colors } from '../../theme/tokens';

export function Pagination({
  page, total, pageSize, onChange
}: { page: number; total: number; pageSize: number; onChange: (p: number) => void; }) {
  const theme = useTheme();
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const maxButtons = 7;
  const start = Math.max(1, page - Math.floor(maxButtons / 2));
  const end = Math.min(totalPages, start + maxButtons - 1);
  const pages = Array.from({ length: end - start + 1 }, (_, i) => start + i);

  return (
    <Stack
      horizontal
      verticalAlign="center"
      tokens={{ childrenGap: 6 }}
      styles={{ root: { marginTop: 10 } }}
    >
      <IconButton
        iconProps={{ iconName: 'DoubleChevronLeft' }}
        disabled={page <= 1}
        onClick={() => onChange(1)}
        title="First page"
      />
      <IconButton
        iconProps={{ iconName: 'ChevronLeft' }}
        disabled={page <= 1}
        onClick={() => onChange(page - 1)}
        title="Previous page"
      />
      {pages.map(p => (
        <IconButton
          key={p}
          text={String(p)}
          onClick={() => onChange(p)}
          styles={{
            root: {
              minWidth: 32,
              backgroundColor: p === page ? theme.palette.themePrimary : 'transparent',
              color: p === page ? theme.palette.white : theme.palette.neutralPrimary,
              fontWeight: p === page ? 600 : 400,
              border: p === page ? 'none' : `1px solid ${colors.borderPrimary}`,
            },
            rootHovered: {
              backgroundColor: p === page ? theme.palette.themeDark : colors.neutralLighter,
              color: p === page ? theme.palette.white : theme.palette.neutralPrimary,
            },
          }}
          title={`Page ${p}`}
        />
      ))}
      <IconButton
        iconProps={{ iconName: 'ChevronRight' }}
        disabled={page >= totalPages}
        onClick={() => onChange(page + 1)}
        title="Next page"
      />
      <IconButton
        iconProps={{ iconName: 'DoubleChevronRight' }}
        disabled={page >= totalPages}
        onClick={() => onChange(totalPages)}
        title="Last page"
      />
      <Text
        variant="small"
        styles={{ root: { marginLeft: 8, color: colors.textSecondary } }}
      >
        Total {total} • Page {page}/{totalPages}
      </Text>
    </Stack>
  );
}