import * as React from 'react';
import { MessageBar, MessageBarType, Stack } from '@fluentui/react';

export function Toast({
    text,
    type = MessageBarType.success,
    onDismiss
}:{
    text: string;
    type?: MessageBarType;
    onDismiss?: () => void;
})
{
    return (
        <Stack>
            <MessageBar messageBarType={type} isMultiline={false} onDismiss={onDismiss}>
                {text}
            </MessageBar>
        </Stack>
    );
}