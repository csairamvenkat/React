import * as React from 'react';

export interface CrumbNames {
  customerName?: string;
  opportunityName?: string;
  roundName?: string;
  templateName?: string;
  stakeholderName?: string; 
}

type CrumbContextType = {
  names: CrumbNames;
  setNames: (update: CrumbNames | ((prev: CrumbNames) => CrumbNames)) => void;
};

const CrumbContext = React.createContext<CrumbContextType | undefined>(undefined);

export function CrumbProvider({ children }: { children: React.ReactNode }) {
  const [names, setNamesState] = React.useState<CrumbNames>(() => {
    const saved = localStorage.getItem("crumb-names");
    return saved ? JSON.parse(saved) : {};
  });

  const setNames = React.useCallback(
    (update: CrumbNames | ((prev: CrumbNames) => CrumbNames)) => {
      setNamesState(prev => {
        const newValue =
          typeof update === "function" ? update(prev) : { ...prev, ...update };
        localStorage.setItem("crumb-names", JSON.stringify(newValue));
        return newValue;
      });
    },
    []
  );

  const value = React.useMemo(() => ({ names, setNames }), [names, setNames]);

  return <CrumbContext.Provider value={value}>{children}</CrumbContext.Provider>;
}

export function useCrumbs(): CrumbContextType {
  const ctx = React.useContext(CrumbContext);
  if (!ctx) throw new Error("useCrumbs must be used within CrumbProvider");
  return ctx;
}