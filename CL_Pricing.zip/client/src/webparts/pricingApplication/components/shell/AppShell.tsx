/**
 * Modern AppShell with Material-UI
 * Advanced layout with sophisticated design
 */

import * as React from 'react';
import { ThemeProvider, CssBaseline, Fab, Tooltip, alpha, useTheme, Zoom } from '@mui/material';
import { Box, Container, Paper } from '@mui/material';
import { useLocation, useParams } from 'react-router-dom';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Crumbs } from './Crumbs';
import { muiTheme } from '../../theme/muiTheme';

function findScrollContainer(el: HTMLElement | null): HTMLElement | null {
  let node = el?.parentElement ?? null;
  while (node && node !== document.body) {
    const { overflowY, overflow } = window.getComputedStyle(node);
    const scrollable = overflowY === 'auto' || overflowY === 'scroll' || overflow === 'auto' || overflow === 'scroll';
    if (scrollable && node.scrollHeight > node.clientHeight) return node;
    node = node.parentElement;
  }
  return null;
}

function ScrollToTopFab({ anchorRef }: { anchorRef: React.RefObject<HTMLDivElement> }) {
  const theme = useTheme();
  const [show, setShow] = React.useState(false);
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const containerRef = React.useRef<HTMLElement | null>(null);

  React.useEffect(() => {
    // Delay slightly so the DOM is fully rendered
    const timer = setTimeout(() => {
      const found = findScrollContainer(anchorRef.current);
      containerRef.current = found;

      const target: EventTarget = found ?? window;

      const onScroll = () => {
        const scrollTop = found ? found.scrollTop : window.scrollY;
        setShow(scrollTop > 100);
      };

      target.addEventListener('scroll', onScroll);
      onScroll(); // run once to set initial state

      return () => target.removeEventListener('scroll', onScroll);
    }, 300);

    return () => clearTimeout(timer);
  }, [anchorRef]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      // const open =
      //   document.querySelector(".MuiDrawer-root") !== null;
      const open =
        document.querySelector(".MuiDrawer-root .MuiPaper-root") !== null;

      setDrawerOpen(open);
    }, 200);

    return () => clearInterval(interval);
  }, []);

  const handleClick = () => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      document.documentElement.scrollTo({ top: 0, behavior: 'smooth' });
      document.body.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  if (drawerOpen) {
    return null;
  }

  return (
    !drawerOpen && (
      <Zoom in={show}>
        <Tooltip title="Scroll to top" placement="left">
          <Fab
            onClick={handleClick}
            size="medium"
            sx={{
              position: 'fixed',
              bottom: 32,
              right: 32,
              zIndex: 9999,
              backgroundColor: alpha(theme.palette.primary.main, 0.12),
              backdropFilter: 'blur(8px)',
              border: `1px solid ${alpha(theme.palette.primary.main, 0.4)}`,
              color: theme.palette.primary.main,
              boxShadow: `0 4px 20px ${alpha(theme.palette.primary.main, 0.25)}`,
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.22),
                boxShadow: `0 6px 24px ${alpha(theme.palette.primary.main, 0.4)}`,
                transform: 'translateY(-3px)',
              },
            }}
          >
            <KeyboardArrowUpIcon sx={{ fontSize: 28 }} />
          </Fab>
        </Tooltip>
      </Zoom>
    )
  );
}

export default function AppShell({ children, showHeader = true, }: { children: React.ReactNode; showHeader?: boolean; }) {
  const location = useLocation();
  const { id, roundId, templateId } = useParams<{ id?: string; roundId?: string; templateId?: string; }>();
  const anchorRef = React.useRef<HTMLDivElement>(null);
  const sentinelRef = React.useRef<HTMLDivElement>(null);
  const headerRef = React.useRef<HTMLDivElement>(null);
  const [isSticky, setIsSticky] = React.useState(false);
  const [headerHeight, setHeaderHeight] = React.useState(0);
  const [stickyRect, setStickyRect] = React.useState<{ top: number; left: number; width: number }>({ top: 0, left: 0, width: 0 });

  // Capture measurements at the exact moment sticky kicks in (sentinel exits viewport).
  // This ensures top/left/width reflect the actual layout at scroll time, not stale mount values.
  React.useEffect(() => {
    if (!showHeader || !sentinelRef.current) return;
    const scrollRoot = findScrollContainer(anchorRef.current);
    const observer = new IntersectionObserver(
      ([entry]) => {
        const sticky = !entry.isIntersecting;
        if (sticky && headerRef.current) {
          const rect = headerRef.current.getBoundingClientRect();
          setStickyRect({ top: rect.top, left: rect.left, width: rect.width });
          setHeaderHeight(rect.height);
        }
        setIsSticky(sticky);
      },
      { root: scrollRoot, threshold: 0 }
    );
    observer.observe(sentinelRef.current);
    return () => observer.disconnect();
  }, [showHeader]);

  // Re-measure on resize only when not sticky (fixed position skews measurements)
  React.useEffect(() => {
    const handleResize = () => {
      if (isSticky || !headerRef.current) return;
      const rect = headerRef.current.getBoundingClientRect();
      setStickyRect({ top: rect.top, left: rect.left, width: rect.width });
      setHeaderHeight(rect.height);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isSticky]);

  // Reset sticky on route change
  React.useEffect(() => {
    setIsSticky(false);
    const container = findScrollContainer(anchorRef.current);
    if (container) {
      container.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    } else {
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
      document.documentElement.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
      document.body.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    }
  }, [location.pathname]);


  return (
    <ThemeProvider theme={muiTheme}>
      <CssBaseline />
      <Box
        ref={anchorRef}
        sx={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)',
          py: 3,
          pl: 0,
          pr: 0,
          m: 0,
        }}
      >
        <Container maxWidth="xl">
          {showHeader && (
            <>
              {/* Sentinel: when this scrolls out of view, header goes sticky */}
              <Box ref={sentinelRef} sx={{ height: '1px', visibility: 'hidden' }} />

              {/* Spacer holds the header's space in normal flow when it goes fixed */}
              {isSticky && <Box sx={{ height: headerHeight, mb: 3 }} />}

              <Paper
                ref={headerRef}
                elevation={0}
                sx={{
                  ...(isSticky
                    ? {
                        position: 'fixed',
                        top: stickyRect.top - 33,
                        left: stickyRect.left,
                        width: stickyRect.width,
                        zIndex: 1000,
                      }
                    : {
                        position: 'relative',
                        mb: 3,
                      }),
                  p: 2,
                  borderRadius: 3,
                  background: 'rgba(255, 255, 255, 0.95)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid',
                  borderColor: isSticky ? '#f2f2f2 !important' : 'divider',
                }}
              >
                <Crumbs
                  id={id ? Number(id) : undefined}
                  roundId={roundId ? Number(roundId) : undefined}
                  templateId={templateId ? Number(templateId) : undefined}
                  pathname={location.pathname}
                />
              </Paper>
            </>
          )}
          <Box>{children}</Box>
        </Container>
      </Box>
      <ScrollToTopFab anchorRef={anchorRef} />
    </ThemeProvider>
  );
}
