import * as React from 'react';
import { Breadcrumb, IBreadcrumbItem } from '@fluentui/react';
import { useNavigate } from 'react-router-dom';
import { useCrumbs } from './CrumbContext';


export function Crumbs({
  id, roundId, templateId, pathname
}: { id?: number; roundId?: any; templateId?: any; pathname?: string; }) {
  const navigate = useNavigate();
  const { names } = useCrumbs();
  // const oppLabel = id ? (names.opportunityName ?? `OPP-${id}`) : undefined;
  // const rndLabel = roundId ? (names.roundName ?? `RND-${roundId}`) : undefined;
  // const tmpLabel = templateId ? (names.templateName ?? `TMP-${templateId}`) : undefined;

  const oppLabel = id ? (names.opportunityName) : undefined;
  const rndLabel = roundId ? (names.roundName) : undefined;
  const tmpLabel = roundId ? (names.templateName) : undefined;
  //const stkLabel = names.stakeholderName;
  const stkLabel = pathname?.includes('/stakeholders')? 'Stakeholders' : names.stakeholderName;

  const items = React.useMemo<IBreadcrumbItem[]>(() => {

    const crumbs: IBreadcrumbItem[] = [
      { text: 'Opportunities', key: 'opps', onClick: () => navigate('/opportunities') }
    ];

    if (id) {
      crumbs.push({
        text: oppLabel!, key: `opp-${id}`,
        onClick: () => navigate(`/opportunities/${id}`)
      });
    }

    if (id && pathname?.includes('/rounds')) {
      crumbs.push({
        text: 'Rounds', key: `opp-${id}-rounds`,
        onClick: () => navigate(`/opportunities/${id}/rounds`)
      });
    }

    if (id && roundId) {
      crumbs.push({
        text: rndLabel!, key: `opp-${id}-rnd-${roundId}`,
        onClick: () => navigate(`/opportunities/${id}/rounds/${roundId}`)
      });
    }

    //Stakeholder Breadcrumb
    if (pathname?.includes('/stakeholders')) {
      crumbs.push({
        text: stkLabel || 'Stakeholders',
        key: `opp-stakeholder`,
        onClick: () =>
          navigate(`/opportunities/stakeholders`)
      });
    }

    // if (id && roundId && pathname?.includes('/templates')) {
    //   crumbs.push({
    //     text: templateId, key: `opp-${id}-rnd-${roundId}-templates`,
    //     onClick: () => navigate(`/opportunities/${id}/rounds/${roundId}`)
    //   });
    // }

    if (id && roundId && pathname?.includes('/templates')) {
      crumbs.push({
        text: tmpLabel!, key: `opp-${id}-rnd-${roundId}-tmp-${tmpLabel}`,
        onClick: () => navigate(`/opportunities/${id}/rounds/${rndLabel}/templates/${tmpLabel}/files`)
      });
    }

    // if (pathname?.endsWith('/files')) {
    //   crumbs.push({ text: 'Files', key: 'files' });
    // }
    return crumbs;
  }, [navigate, id, roundId, templateId, pathname, oppLabel, rndLabel, tmpLabel,names.stakeholderName]);

  return <Breadcrumb items={items} maxDisplayedItems={6} ariaLabel="Breadcrumb" />;
}