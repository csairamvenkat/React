import * as React from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
// import { OpportunitiesProvider } from './store/OpportunitiesContext';
import AppShell from './shell/AppShell';

import MainDashboard from './pages/MainDashboard/MainDashboard';
import CreateOpportunity from './pages/CreateOpportunity/CreateOpportunity';
import OpportunityDetailPage from './pages/OpportunityDetailPage/OpportunityDetailPage';
import EditOpportunity from './pages/EditOpportunity/EditOpportunity';

import RoundList from './pages/RoundList/RoundList';
import CreateRound from './pages/CreateRound/CreateRound';
import RoundDetailPage from './pages/RoundDetailPage/RoundDetailPage';

import TemplateList from './pages/TemplateList/TemplateList';
import TemplateFilesPage from './pages/TemplateFilesPage/TemplateFilesPage';
import { CrumbProvider } from './shell/CrumbContext';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import StakeHolderDetailsPage from './pages/StakeHolderDetails/StakeHolderDetailsPage';
import { Box } from '@mui/material';

function ShellRoute({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>;
}


function StakeholderRoute() {
  const location = useLocation();

  const [isPricer, setIsPricer] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    const state = location.state as any;

    if (typeof state?.isPricer === 'boolean') {
      setIsPricer(state.isPricer);
      return;
    }

    (async () => {
      try {
        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const res = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title`,
          {
            headers: { Accept: 'application/json;odata=nometadata' },
            credentials: 'same-origin',
          }
        );

        const data = await res.json();
        const isMember = data.value.some(
          (g: any) => g.Title === 'Pricing'
        );

        setIsPricer(isMember);
      } catch (e) {
        console.error('Role check failed', e);
        setIsPricer(false);
      }
    })();
  }, [location.state]);


  if (isPricer === null) {
    return (
      <AppShell showHeader={false}>
        <Box sx={{ p: 4, textAlign: 'center' }}>
          Loading...
        </Box>
      </AppShell>
    );
  }

  return (
    <AppShell showHeader={isPricer}>
      <StakeHolderDetailsPage />
    </AppShell>
  );

}


export default function AppRouter() {
  return (
    <HashRouter>
      <CrumbProvider>
        <Routes>
          <Route path="/" element={<Navigate to="/opportunities" />} />
          <Route path="/opportunities" element={<ShellRoute><MainDashboard /></ShellRoute>} />
          <Route path="/opportunities/new" element={<ShellRoute><CreateOpportunity /></ShellRoute>} />
          <Route path="/opportunities/:id" element={<ShellRoute><OpportunityDetailPage /></ShellRoute>} />
          <Route path="/opportunities/:id/edit" element={<ShellRoute><EditOpportunity /></ShellRoute>} />
          <Route path="/opportunities/:id/rounds" element={<ShellRoute><RoundList /></ShellRoute>} />
          <Route path="/opportunities/:id/rounds/new" element={<ShellRoute><CreateRound /></ShellRoute>} />
          <Route path="/opportunities/:id/rounds/:roundId" element={<ShellRoute><RoundDetailPage /></ShellRoute>} />
          <Route path="/opportunities/:id/rounds/:roundId/templates/:templateId/files" element={<ShellRoute><TemplateFilesPage /></ShellRoute>} />
          {/* <Route path="/opportunities/stakeholders" element={<ShellRoute><StakeHolderDetailsPage /></ShellRoute>} /> */}
          <Route path="/opportunities/stakeholders" element={<StakeholderRoute />} />


        </Routes>
      </CrumbProvider>
    </HashRouter>
  );
}