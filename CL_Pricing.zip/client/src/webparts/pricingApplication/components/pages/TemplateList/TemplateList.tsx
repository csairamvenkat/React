import * as React from 'react';
import TemplateListView from '../../lists/TemplateListView';
 
export default function TemplateList() {
  return <TemplateListView showToolbar={true} showAddButton={true} />;
}