import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  TextField,
  InputAdornment,
  Fade,
  Switch,
  FormControlLabel,
  styled,
  Chip,
} from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import { GridColDef } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import BusinessIcon from '@mui/icons-material/Business';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AssignmentIcon from '@mui/icons-material/Assignment';
import { Opportunity } from '../../store/Models';
import { ApiDataProvider } from '../../../api/ApiDataProvider';
import {
  ModernCard,
  ModernButton,
  ModernDataTable,
  ModernLoadingState,
  ModernEmptyState,
  ModernAlert,
  ModernChip,
} from '../../shared/mui';
import { Handshake } from '@mui/icons-material';

const StatusToggle = styled(Switch)(() => ({
  width: 92,
  height: 32,
  padding: 0,

  '& .MuiSwitch-switchBase': {
    padding: 4,
    margin: 0,
    transitionDuration: '300ms',
    transform: 'translateX(0px)',

    '&.Mui-checked': {
      transform: 'translateX(58px)',

      '& + .MuiSwitch-track': {
        backgroundColor: '#4caf50',
        opacity: 1,
      },
    },
  },

  /* White knob same as Opportunity Detail */
  '& .MuiSwitch-thumb': {
    width: 24,
    height: 24,
    backgroundColor: '#fff',
    boxShadow: '0 1px 4px rgba(0,0,0,0.30)',
  },

  '& .MuiSwitch-track': {
    borderRadius: 999,
    backgroundColor: '#bdbdbd',
    opacity: 1,
    position: 'relative',

    '&:before': {
      content: '"Active"',
      position: 'absolute',
      left: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      opacity: 0,
    },

    '&:after': {
      content: '"Inactive"',
      position: 'absolute',
      right: 8,
      top: '50%',
      transform: 'translateY(-50%)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      opacity: 0,
    },
  },

  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track:before': {
    opacity: 1,
  },

  '& .MuiSwitch-switchBase:not(.Mui-checked) + .MuiSwitch-track:after': {
    opacity: 1,
  },
}));

export default function MainDashboard() {
  const navigate = useNavigate();
  const cfg = (window as any).TENANT_CONFIG;
  const ALLOWED_GROUP_NAME = 'Pricing';

  const api = React.useMemo(
    () =>
      new ApiDataProvider((window as any).spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl,
      }),
    [cfg.apiBaseUrl, cfg.apiResource]
  );

  const [loading, setLoading] = React.useState(false);
  const [items, setItems] = React.useState<Opportunity[]>([]);
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const [paginationModel, setPaginationModel] = React.useState({ page: 0, pageSize: 10 });
  const [totalRecords, setTotalRecords] = React.useState(0);

  const [filter, setFilter] = React.useState('');
  const [search, setSearch] = React.useState('');
  const [myOppsOnly, setMyOppsOnly] = React.useState(false);
  const [isActiveOnly, setIsActiveOnly] = React.useState(true);

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);


  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);


  React.useEffect(() => {
    if (!hasAccess) return;
    const t = setTimeout(() => setSearch(filter.trim()), 350);
    return () => clearTimeout(t);
  }, [filter, hasAccess]);

  React.useEffect(() => {
    if (!hasAccess) return;
    setPaginationModel((prev) => ({ ...prev, page: 0 }));
  }, [search, myOppsOnly, isActiveOnly, hasAccess]);

  React.useEffect(() => {

    if (!hasAccess) return;

    let active = true;

    (async () => {
      try {
        setLoading(true);

        const payload: any = {
          page_number: paginationModel.page + 1,
          page_size: paginationModel.pageSize,
          ...(search && { search_text: search }),
          ...(myOppsOnly && { is_lead_pricer: true }),
          is_active: isActiveOnly,
        };
        const res = await api.getOpportunities(payload);
        const list = Array.isArray(res?.data) ? res.data : [];
        const total = Number(res?.total_records ?? 0);
        if (!active) return;
        setItems(list);
        setTotalRecords(total);
      } catch (err: any) {
        if (!active) return;
        console.error('[MainDashboard] Load failed:', err);
        setToast({ severity: 'error', text: `Load failed: ${err.message}` });
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [paginationModel.page, paginationModel.pageSize, api, search, myOppsOnly, isActiveOnly, hasAccess]);


  React.useEffect(() => {
    if (!permissionLoading && !hasAccess) {
      navigate('/opportunities/stakeholders', { replace: true, state: { isPricer: hasAccess } });
    }
  }, [permissionLoading, hasAccess, navigate]);


  const handleStatusToggle = (checked: boolean) => {
    setIsActiveOnly(checked);

    setToast({
      severity: 'info',
      text: checked
        ? 'Showing Active Records'
        : 'Showing Inactive Records',
    });
  };
  const stats = React.useMemo(() => {
    const total = totalRecords;
    const now = new Date();
    const thisMonth = items.filter(
      (o: any) =>
        o?.createdOn &&
        new Date(o.createdOn).getMonth() === now.getMonth() &&
        new Date(o.createdOn).getFullYear() === now.getFullYear()
    ).length;
    const activeRounds = items.reduce((sum: number, o: any) => sum + (o?.roundCount || 0), 0);
    return { total, thisMonth, activeRounds };
  }, [items, totalRecords]);

  const columns: GridColDef[] = [
    {
      field: 'title',
      headerName: 'Opportunity Name',
      headerAlign: 'left',
      align: 'left',
      flex: 1,
      minWidth: 400,
      renderCell: (params) => (
        <Typography variant="body2" fontWeight={500} sx={{ cursor: 'pointer' }}
          onClick={() => navigate(`/opportunities/${params.row.id}`)}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: 'customer', headerName: 'Customer', width: 150, headerAlign: 'center',
      align: 'center', renderCell: (params) => (
        <Box
          sx={{
            width: '100%',
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <Typography variant="body2">
            {params.value}
          </Typography>
        </Box>
      ),
    },
    {
      field: 'active',
      headerName: 'Status',
      headerAlign: 'center',
      align: 'center',
      width: 100,
      sortable: false,
      renderCell: (params) => (
        <Box
          sx={{
            width: '100%',
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <ModernChip
            label={params.value === false ? 'Inactive' : 'Active'}
            colorVariant={params.value === false ? 'default' : 'success'}
            size="small"
          />
        </Box>
      ),
    },
    {
      field: 'createdOn',
      headerName: 'Created Date',
      headerAlign: 'center',
      align: 'center',
      width: 120,
      renderCell: (params) => (
        <Box
          sx={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100%',
          }}
        >
          <Typography variant="body2" color="text.secondary">
            {params.value ? new Date(params.value).toLocaleDateString() : '-'}
          </Typography>
        </Box>
      ),
    },
    {
      field: 'lead_pricer',
      headerName: 'Lead Pricer',
      headerAlign: 'center',
      align: 'center',
      width: 150,
      sortable: false,
      renderCell: (params) => {
        const pricers: { name: string }[] = params.value ?? [];
        const names = pricers.map((p) => p.name).filter(Boolean).join(', ');
        return (
          <Typography variant="body2" color="text.secondary">
            {names || '-'}
          </Typography>
        );
      },
    },
  ];

  if (permissionLoading) {
    return (
      <Box sx={{ p: 4 }}>
        <ModernLoadingState type="spinner" />
      </Box>
    );
  }

  if (!hasAccess) {
    // return (
    //   <Fade in>
    //     <Box
    //       sx={{
    //         p: 4,
    //         display: 'flex',
    //         // justifyContent: 'right',
    //         // alignItems: 'right',
    //       }}
    //     >
    //       <Box
    //         sx={{
    //           p: 2,
    //           display: 'flex',
    //           justifyContent: 'flex-end',
    //         }}
    //       >
    //         <ModernButton
    //           variant="gradient"
    //           glow
    //           size="medium"
    //           sx={{
    //             // minWidth: 180,
    //             // height: 40,
    //           }}
    //           onClick={() => navigate(`/opportunities/stakeholders`)}
    //         >
    //           Stakeholder Dashboard
    //         </ModernButton>
    //       </Box>
    //       <Box
    //         sx={{
    //           p: 4,
    //           display: 'flex',
    //           justifyContent: 'center',
    //           alignItems: 'center',
    //         }}
    //       >
    //         <ModernEmptyState
    //           type="access"
    //           title="Access denied"
    //           description="You do not have permission to view this page. Please contact your SharePoint administrator."
    //         />
    //       </Box>
    //     </Box>
    //   </Fade>
    // );
    return (
      <Fade in>
        <Box
          sx={{
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
          }}
        >
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'flex-end',
            }}
          >
            <ModernButton
              variant="gradient"
              glow
              size="medium"
              sx={{
                minWidth: 200,
              }}
              onClick={() =>
                navigate('/opportunities/stakeholders', {
                  state: { isPricer: hasAccess },
                })
              }
            >
              Stakeholder Dashboard
            </ModernButton>
          </Box>

          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <ModernEmptyState
              type="access"
              title="Access denied"
              description="You do not have permission to view this page. Please contact your SharePoint administrator."
            />
          </Box>
        </Box>
      </Fade>
    );
  }

  if (loading && items.length === 0) {
    return (
      <Box sx={{ p: 3 }}>
        <ModernLoadingState type="shimmer" rows={5} height={80} />
      </Box>
    );
  }

  return (
    <Fade in timeout={500}>
      <Box sx={{ p: 0 }}>
        {toast && (
          <Box sx={{ mb: 3 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )}
        <ModernCard gradient elevated sx={{ mb: 3 }}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: 2,
            }}
          >
            <Box>
              <Typography variant="h4" fontWeight={700} gutterBottom>
                Opportunities Dashboard
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Manage pricing opportunities and track their progress
              </Typography>
            </Box>
            <Box
              sx={{
                display: 'flex',
                gap: 2,
                alignItems: 'center',
                ml: 'auto',
              }}
            >
              <ModernButton
                variant="gradient"
                glow
                //startIcon={<AddIcon />}
                onClick={() => navigate('/opportunities/stakeholders', {
                  state: { isPricer: hasAccess },
                })}
              >
                StakeHolder Dashboard
              </ModernButton>

              <ModernButton
                variant="gradient"
                glow
                startIcon={<AddIcon />}
                onClick={() => navigate('/opportunities/new')}
              >
                Create Opportunity
              </ModernButton>
            </Box>
          </Box>
        </ModernCard>
        {/* <Box sx={{ display: 'flex', gap: 3, mb: 3, flexWrap: 'wrap' }}>
          <Box sx={{ flex: '1 1 300px', minWidth: 0 }}>
            <ModernCard hoverable>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 56,
                    height: 56,
                    borderRadius: 3,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'linear-gradient(135deg, #1e1450, #3d2fa0)',
                    color: 'white',
                    boxShadow: '0 4px 16px rgba(30, 20, 80, 0.3)',
                  }}
                >
                  <BusinessIcon sx={{ fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="h4" fontWeight={700}>{stats.total}</Typography>
                  <Typography variant="body2" color="text.secondary">Total Opportunities</Typography>
                </Box>
              </Box>
            </ModernCard>
          </Box>
          <Box sx={{ flex: '1 1 300px', minWidth: 0 }}>
            <ModernCard hoverable>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 56,
                    height: 56,
                    borderRadius: 3,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'linear-gradient(135deg, #107C10, #13a313)',
                    color: 'white',
                    boxShadow: '0 4px 16px rgba(16, 124, 16, 0.3)',
                  }}
                >
                  <TrendingUpIcon sx={{ fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="h4" fontWeight={700}>{stats.thisMonth}</Typography>
                  <Typography variant="body2" color="text.secondary">This Month</Typography>
                </Box>
              </Box>
            </ModernCard>
          </Box>
          <Box sx={{ flex: '1 1 300px', minWidth: 0 }}>
            <ModernCard hoverable>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box
                  sx={{
                    width: 56,
                    height: 56,
                    borderRadius: 3,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'linear-gradient(135deg, #0078d4, #005a9e)',
                    color: 'white',
                    boxShadow: '0 4px 16px rgba(0, 120, 212, 0.3)',
                  }}
                >
                  <AssignmentIcon sx={{ fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="h4" fontWeight={700}>{stats.activeRounds}</Typography>
                  <Typography variant="body2" color="text.secondary">Active Rounds</Typography>
                </Box>
              </Box>
            </ModernCard>
          </Box>
        </Box> */}
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            placeholder="Search opportunities by name, lead number, or customer..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'primary.main' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                backgroundColor: 'background.paper',
              },
            }}
          />
          <Box sx={{ mt: 1.5, display: 'flex', alignItems: 'center', gap: 1 }}>
            <Chip
              icon={<PersonIcon sx={{ fontSize: '16px !important' }} />}
              label="My Opportunities (Lead Pricer)"
              onClick={() => setMyOppsOnly((v) => !v)}
              variant={myOppsOnly ? 'filled' : 'outlined'}
              color={myOppsOnly ? 'primary' : 'default'}
              size="small"
              sx={{
                fontWeight: myOppsOnly ? 600 : 400,
                transition: 'all 0.2s ease',
                cursor: 'pointer',
              }}
            />
            <Box sx={{ ml: 'auto' }}>
              <FormControlLabel
                label=""
                sx={{ m: 0, mr: 3, }}
                control={
                  <StatusToggle
                    checked={isActiveOnly}
                    onChange={(e) =>
                      handleStatusToggle(
                        e.target.checked
                      )
                    }
                  />
                }
              />
            </Box>
          </Box>
        </Box>
        {totalRecords === 0 && !loading ? (
          <ModernEmptyState
            type="empty"
            title="No opportunities found"
            description="Get started by creating your first opportunity to track pricing rounds and datasets."
            actionText="Create Opportunity"
            onAction={() => navigate('/opportunities/new')}
            animated
          />
        ) : items.length === 0 && search ? (
          <ModernEmptyState
            type="search"
            title="No matching opportunities"
            description={`No opportunities match your search term "${search}". Try a different search.`}
            animated
          />
        ) : (
          <ModernDataTable
            sx={{
              '& .MuiDataGrid-columnHeaderTitleContainer': {
                justifyContent: 'center',
              },

              '& .MuiDataGrid-columnHeaderTitle': {
                fontWeight: 700,
                textAlign: 'center',
                width: '100%',
              },

              '& .MuiDataGrid-cell': {
                display: 'flex',
                alignItems: 'center',
              },
            }}
            rows={items.map((item, idx) => ({
              ...item,
              id: (item as any).id ?? `${paginationModel.page}-${idx}`,
            }))}
            columns={columns}
            getRowClassName={(params) => params.row.active === false ? 'row-inactive' : ''}
            loading={loading}
            serverPagination
            rowCount={totalRecords}
            paginationModel={paginationModel}
            onPaginationModelChange={(model) => {
              if (model.pageSize !== paginationModel.pageSize) {
                setPaginationModel({ page: 0, pageSize: model.pageSize });
              } else {
                setPaginationModel(model);
              }
            }}
            pageSizeOptions={[10, 25, 50, 100]}
            autoHeight
            elevation={2}
          />
        )}
      </Box>
    </Fade>
  );
}