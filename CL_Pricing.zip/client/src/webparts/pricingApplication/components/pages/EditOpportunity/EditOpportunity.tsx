import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  MenuItem,
  Divider,
  Fade,
  Stack,
  Autocomplete,
  TextField,
  LinearProgress,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import InfoIcon from '@mui/icons-material/Info';
import PeopleIcon from '@mui/icons-material/People';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import { SPHttpClient } from '@microsoft/sp-http';

import { ApiDataProvider } from '../../../api/ApiDataProvider';
import { useCrumbs } from '../../shell/CrumbContext';
import {
  ModernCard,
  ModernButton,
  ModernTextField,
  ModernAlert,
  ModernLoadingState,
  ModernAutocomplete,
  ModernEmptyState,
} from '../../shared/mui';
import { has } from '@microsoft/sp-lodash-subset/lib/index';
import { triggerFlow } from '../../../flow/flowclient';

type PricerUser = { key: number; text: string; email: string; login: string };

const regionOptions = [{ value: 'EUR', label: 'EUR' }];

type CountryOption = {
  id: number;
  title: string;
  label: string;
  code: string;
  groupId?: number;
  groupTitle?: string;
};

export default function EditOpportunity() {
  const { id } = useParams();
  const navigate = useNavigate();
  const cfg = (window as any).TENANT_CONFIG;
  const ALLOWED_GROUP_NAME = 'Pricing';

  const api = React.useMemo(
    () =>
      new ApiDataProvider((window as any).spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl,
      }),
    [cfg]
  );

  const { setNames } = useCrumbs();

  const MAX_CUSTOMER = 20;
  const MAX_OPP = 30;
  const MAX_COMBINED = 40;

  const [loading, setLoading] = React.useState(true);
  const [submitting, setSubmitting] = React.useState(false);

  const [region, setRegion] = React.useState<string>('EUR');
  const [leadNumber, setLeadNumber] = React.useState<string>('');
  const [leadError, setLeadError] = React.useState<string | undefined>(undefined);
  const [customer, setCustomer] = React.useState<any | null>(null);
  const [customerError, setCustomerError] = React.useState<string | undefined>(undefined);

  const [projectName, setProjectName] = React.useState<string>('');
  const [oppError, setOppError] = React.useState<string | undefined>(undefined);

  const [countryOptions, setCountryOptions] = React.useState<CountryOption[]>([]);
  const [selectedCountry, setSelectedCountry] = React.useState<CountryOption | null>(null);
  const [loadingCountries, setLoadingCountries] = React.useState<boolean>(false);

  const [leadPricerOptions, setLeadPricerOptions] = React.useState<PricerUser[]>([]);
  const [loadingPricers, setLoadingPricers] = React.useState(false);
  const [selectedLeadPricer, setSelectedLeadPricer] = React.useState<PricerUser | null>(null);
  const [hasRounds, setHasRounds] = React.useState(false);

  const [originalCustomer, setOriginalCustomer] = React.useState('');
  const [originalProjectName, setOriginalProjectName] = React.useState('');
  const [originalCountryGroupCode, setOriginalCountryGroupCode] = React.useState('');
  const [originalCountryGroupId, setOriginalCountryGroupId] =
    React.useState<number | undefined>();

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);

  const sanitizeProjectName = (value: string) =>
    value.replace(/[^a-zA-Z0-9 _-]/g, "");

  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);


  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const customerText = React.useMemo(
    () =>
      typeof customer === "string"
        ? customer
        : customer?.label || "",
    [customer]
  );

  React.useEffect(() => {
    if (!hasAccess) return;
    void (async () => {
      try {
        setLoadingPricers(true);
        const ctx = (window as any).spfxContext;
        const url = `${cfg.siteUrl}/_api/web/sitegroups/GetByName('${encodeURIComponent(ALLOWED_GROUP_NAME)}')/users?$select=Id,Title,Email,LoginName`;
        const res = await ctx.spHttpClient.get(url, SPHttpClient.configurations.v1);
        if (!res.ok) throw new Error(`Pricing group users GET failed: ${res.status}`);
        const data = await res.json();
        const users: PricerUser[] = (data.value ?? []).map((u: any) => ({
          key: u.Id,
          text: u.Title || u.LoginName,
          email: u.Email,
          login: (u.LoginName as string).replace(/^i:0#\.f\|membership\|/i, ''),
        }));
        setLeadPricerOptions(users);
      } catch (err) {
        console.error('Failed to load pricer users:', err);
      } finally {
        setLoadingPricers(false);
      }
    })();
  }, [cfg.siteUrl, hasAccess]);

  const allowedOppLen = React.useMemo(
    () =>
      Math.min(
        MAX_OPP,
        Math.max(0, MAX_COMBINED - customerText.length)
      ),
    [customerText]
  );

  // const allowedOppLen = React.useMemo(
  //   () => Math.min(MAX_OPP, Math.max(0, MAX_COMBINED - customer.length)),
  //   [customer.length]
  // );

  const remainingChars = Math.max(0, allowedOppLen - projectName.length);
  const charPercentage =
    allowedOppLen > 0 ? ((allowedOppLen - remainingChars) / allowedOppLen) * 100 : 0;

  const handleCustomerSearch = React.useCallback(
    async (query: string): Promise<any[]> => {
      try {
        const resp = await api.searchCustomers(query, 10);
        const data = (resp as any)?.data || resp || [];
        return Array.isArray(data) ? data : [];
      } catch (error) {
        console.error('Customer search failed:', error);
        return [];
      }
    },
    [api]
  );

  const inferProjectName = (
    title?: string,
    lead?: string,
    cust?: string,
    code?: string
  ): string => {
    if (!title) return '';
    let t = title.trim();
    const leadPart = (lead || '').trim();
    const custPart = (cust || '').trim();

    const prefix = `${leadPart}${leadPart && custPart ? ' ' : ''}${custPart}`.trim();
    if (prefix && t.startsWith(prefix)) {
      t = t.slice(prefix.length).trim();
    }
    if (code && code.length > 0 && t.endsWith(code)) {
      t = t.slice(0, -code.length).trim();
    }
    return t.replace(/\s{2,}/g, ' ').trim();
  };

  const derivedTitle = React.useMemo(() => {
    const parts = [
      leadNumber?.trim(),
      customerText?.trim(),
      projectName?.trim(),
      selectedCountry?.code?.trim(),
    ].filter(Boolean);
    return parts.join(' ').replace(/\s{2,}/g, ' ').trim();
  }, [leadNumber, customerText, projectName, selectedCountry]);

  React.useEffect(() => {
    if (derivedTitle) setNames({ opportunityName: derivedTitle });
  }, [derivedTitle, setNames]);

  React.useEffect(() => {
    let didCancel = false;

    if (!hasAccess) return;

    (async () => {
      try {
        setLoading(true);

        const o = await api.getOpportunity(Number(id));
        if (didCancel) return;

        setLoadingCountries(true);
        const ctx = (window as any).spfxContext;
        const listTitle = 'Country';
        const groupField = 'AssociatedGroup';
        const url =
          `${cfg.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
          `?$select=Id,Title,Code,${groupField}/Id,${groupField}/Title&$expand=${groupField}`;

        const res = await ctx.spHttpClient.get(url, SPHttpClient.configurations.v1);
        if (!res.ok) throw new Error(`Countries GET failed ${res.status}`);
        const data = await res.json();
        const items = (data.value ?? data.d?.results ?? []) as any[];

        const options: CountryOption[] = items.map((it) => ({
          id: it.Id,
          title: it.Title,
          label: `${it.Title}${it.Code ? ` (${it.Code})` : ''}`,
          code: it.Code,
          groupId: it[groupField]?.Id as number | undefined,
          groupTitle: it[groupField]?.Title as string | undefined,
        }));
        if (didCancel) return;

        setCountryOptions(options);

        setRegion('EUR');
        setLeadNumber(o.leadNumber || '');
        // setCustomer(o.customer || '');
        setCustomer({
          label: o.customer || '',
          title: o.customer || ''
        });
        setCustomerError(undefined);

        const initialSelected =
          o.country ? options.find((opt) => opt.title === o.country) || null : null;
        setSelectedCountry(initialSelected);

        const inferred = inferProjectName(o.title, o.leadNumber, o.customer, initialSelected?.code);
        // setProjectName(inferred || '');

        setProjectName(o.project_name || '');

        setOriginalCustomer(o.customer || '');
        setOriginalProjectName(inferred || '');
        setOriginalCountryGroupId(initialSelected?.groupId);
        setOriginalCountryGroupCode(initialSelected?.code || '');

        if (o.lead_pricer?.length) {
          const lp = o.lead_pricer[0];
          setSelectedLeadPricer({
            key: 0,
            text: lp.name ?? '',
            email: lp.email ?? '',
            login: lp.login_id ?? '',
          });
        }

        // setToast({
        //   severity: 'warning',
        //   text:
        //     'Updating these fields will recalculate the Opportunity Name. SharePoint folder names will not be renamed automatically; update them manually if needed.',
        // });

        const rounds = await api.getRounds(Number(id), 1, 1);
        const listRound = Array.isArray(rounds) ? rounds : [];

        const roundsExist = listRound.length > 0;
        setHasRounds(roundsExist);

        if (roundsExist) {
          setToast({
            severity: 'warning',
            text: 'This opportunity already contains rounds. Project Name and Country cannot be modified. Only Lead Pricer can be updated.',
          });
        }

      } catch (err: any) {
        console.error(err);
        if (!didCancel) {
          setToast({ severity: 'error', text: `Failed to load opportunity: ${err.message}` });
        }
      } finally {
        if (!didCancel) {
          setLoading(false);
          setLoadingCountries(false);
        }
      }
    })();

    return () => {
      didCancel = true;
    };
  }, [api, id, cfg?.siteUrl, hasAccess]);


  const onLeadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 6);
    setLeadNumber(val);
    setLeadError(undefined);
  };

  const onLeadBlur = () => {
    if (leadNumber.length > 0 && leadNumber.length < 6) {
      const padded = '000000'.substring(0, 6 - leadNumber.length) + leadNumber;
      setLeadNumber(padded);
    }
  };

  const onProjectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value || "";

    const sanitized = sanitizeProjectName(rawValue);

    const val = sanitized.slice(0, allowedOppLen);

    setProjectName(val);
    setOppError(undefined);

    if (customerText.length + val.length > MAX_COMBINED) {
      setOppError(`Total length exceeds ${MAX_COMBINED} characters`);
    }
  };

  const isFormValid = hasRounds
    ? true
    : !!region &&
    !!leadNumber &&
    !!customer &&
    !customerError &&
    !!projectName &&
    !oppError &&
    customer.length + projectName.length <= MAX_COMBINED &&
    selectedCountry !== null;

  const onSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!isFormValid) return;

    try {
      setSubmitting(true);

      const payload = hasRounds
        ? {
          lead_pricer: selectedLeadPricer
            ? [
              {
                name: selectedLeadPricer.text,
                email: selectedLeadPricer.email,
                login_id: selectedLeadPricer.login,
              },
            ]
            : [],
        }
        : {
          customer: customer,
          title: derivedTitle,
          country: selectedCountry!.title,
          countryCode: selectedCountry!.code,
          project_name: projectName,
          lead_pricer: selectedLeadPricer
            ? [
              {
                name: selectedLeadPricer.text,
                email: selectedLeadPricer.email,
                login_id: selectedLeadPricer.login,
              },
            ]
            : [],
        };

      await api.updateOpportunity(Number(id), payload);

      const folderChanged =
        customerText !== originalCustomer ||
        projectName !== originalProjectName ||
        selectedCountry?.groupId !== originalCountryGroupId;

      const countryChanged =
        selectedCountry?.groupId !== originalCountryGroupId;

      if (folderChanged || countryChanged) {

        const flowPayload = {
          eventType: "OpportunityUpdate",
          oldFolderPath:
            `${cfg.serverRelativeLibrary}${originalCustomer}/${leadNumber} ${originalCustomer} ${originalProjectName} ${originalCountryGroupCode}`,
          newFolderPath:
            `${cfg.serverRelativeLibrary}${customerText}/${leadNumber} ${customerText} ${projectName} ${selectedCountry?.code}`,
          oldCountryGroupId: originalCountryGroupId,
          newCountryGroupId: selectedCountry?.groupId,
          countryChanged,
          folderChanged,
          siteUrl: `${cfg.siteUrl}`
        };

        // console.log(flowPayload)

        await triggerFlow(
          flowPayload,
          "OpportunityCreationFlow"
        );
      }

      setToast({ severity: 'success', text: 'Opportunity updated successfully.' });
      setTimeout(() => navigate(`/opportunities/${id}`), 100);
    } catch (err: any) {
      setToast({ severity: 'error', text: `Error: ${err.message}` });
    } finally {
      setSubmitting(false);
    }
  };

  if (permissionLoading) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernLoadingState type="spinner" />
      </Box>
    );
  }

  if (!hasAccess) {
    return (
      <Fade in>
        <Box
          sx={{
            p: 0,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <ModernEmptyState
            type="access"
            title="Access denied"
            description="You do not have permission to view this page. Please contact your SharePoint administrator."
          />
        </Box>
      </Fade>
    );
  }

  if (loading) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernLoadingState type="shimmer" rows={4} height={100} />
      </Box>
    );
  }

  return (
    <Fade in timeout={500}>
      <Box sx={{ p: 0 }}>
        {toast && (
          <Box sx={{ mb: 3 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )}

        <ModernCard
          icon={<EditIcon />}
          title="Edit Opportunity"
          subtitle="Update the opportunity details below"
          gradient
          elevated
          sx={{ mb: 3 }}
        >
          <Box />
        </ModernCard>

        <form onSubmit={onSubmit}>
          <Stack spacing={3}>
            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <InfoIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Basic Information
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Edit the regional and lead details
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
                  gap: 3,
                }}
              >
                <ModernTextField
                  label="Region"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  select
                  // required
                  disabled
                  helperText="Region cannot be changed"
                >
                  {regionOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </ModernTextField>

                <ModernTextField
                  label="Lead Number"
                  value={leadNumber}
                  onChange={onLeadChange}
                  onBlur={onLeadBlur}
                  // required
                  error={!!leadError}
                  // helperText={leadError || 'Enter the OneCRM Lead Number. If fewer than 6 digits, leading zeros are added automatically. If unavailable, use the OneCRM Opportunity Number or enter 0.'}
                  disabled
                  helperText="Lead number cannot be changed"
                  showCharacterCount
                  inputProps={{ maxLength: 6 }}
                />
              </Box>
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <PeopleIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Customer & Project
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Edit customer and project information
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Stack spacing={3}>
                <ModernAutocomplete
                  label="Customer"
                  value={customer}
                  disabled
                  onChange={(val) => {
                    setCustomer(val);
                    const text =
                      typeof val === "string"
                        ? val
                        : val?.label || "";
                    if (text.length > MAX_CUSTOMER) {
                      setCustomerError(`Max ${MAX_CUSTOMER} characters`);
                    } else {
                      setCustomerError(undefined);
                    }
                  }}
                  onSearch={handleCustomerSearch}
                  getOptionLabel={(option) =>
                    typeof option === "string"
                      ? option
                      : option?.label || ""
                  }
                  // required
                  error={!!customerError}
                  placeholder="Select a customer..."
                  helperText={
                    customerError ||
                    // "Please select a customer from the list"
                    "Customer cannot be changed"
                  }
                />

                <Box>
                  <ModernTextField
                    label="Project Name"
                    value={projectName}
                    onChange={onProjectChange}
                    disabled={hasRounds}
                    required
                    error={!!oppError}
                    helperText={
                      oppError ||
                      "Use the same project name as in CL Pricing JIRA. Do not include the Lead Number, Customer and Country, as these are automatically added to the full Opportunity and folder name."
                    }
                    inputProps={{ maxLength: allowedOppLen }}
                  />
                  <Box sx={{ mt: 1 }}>
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        mb: 0.5,
                      }}
                    >
                      <Typography variant="caption" color="text.secondary">
                        Combined length (Customer + Project)
                      </Typography>
                      <Typography
                        variant="caption"
                        fontWeight={600}
                        sx={{
                          color: remainingChars < 10 ? 'error.main' : 'primary.main',
                        }}
                      >
                        {remainingChars} characters remaining
                      </Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={charPercentage}
                      sx={{
                        height: 6,
                        borderRadius: 3,
                        backgroundColor: (theme) => theme.palette.grey[200],
                        '& .MuiLinearProgress-bar': {
                          borderRadius: 3,
                          background:
                            charPercentage > 90
                              ? 'linear-gradient(90deg, #d13438, #a4262c)'
                              : 'linear-gradient(90deg, #1e1450, #3d2fa0)',
                        },
                      }}
                    />
                  </Box>
                </Box>

                <ModernTextField
                  label="Opportunity Name (auto-generated)"
                  value={derivedTitle}
                  onChange={() => { }}
                  inputProps={{ readOnly: true }}
                  helperText="Opportunity Name is generated from Lead Number + Customer + Project Name + Country Code"
                />
              </Stack>
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <LocationOnIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Location
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Select the country for this opportunity
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Autocomplete
                options={countryOptions}
                value={selectedCountry}
                disabled={hasRounds}
                onChange={(_, newValue) => setSelectedCountry(newValue)}
                getOptionLabel={(option) => option?.label || ''}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Country"
                    placeholder={loadingCountries ? 'Loading countries...' : 'Select Country'}
                    required
                    disabled={loadingCountries || !countryOptions.length}
                  />
                )}
                loading={loadingCountries}
                clearOnEscape
                autoHighlight
                fullWidth
              />
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <PersonSearchIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Lead Pricer
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Select the lead pricer for this opportunity
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Autocomplete
                options={leadPricerOptions}
                value={selectedLeadPricer}
                onChange={(_, newValue) => setSelectedLeadPricer(newValue)}
                getOptionLabel={(o) => o.text}
                isOptionEqualToValue={(a, b) => a.login.toLowerCase() === b.login.toLowerCase()}
                loading={loadingPricers}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Lead Pricer"
                    placeholder={loadingPricers ? 'Loading pricers...' : 'Select a pricer'}
                  />
                )}
                fullWidth
                clearOnEscape
                autoHighlight
              />
            </ModernCard>

            <Box
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                gap: 2,
                p: 3,
                borderTop: '1px solid',
                borderColor: 'divider',
                backgroundColor: 'background.paper',
                borderRadius: 3,
                position: 'sticky',
                bottom: 0,
                zIndex: 10,
                boxShadow: '0 -4px 16px rgba(0, 0, 0, 0.1)',
              }}
            >
              <ModernButton
                variant="outlined"
                onClick={() => navigate(`/opportunities/${id}`)}
                disabled={submitting}
              >
                Cancel
              </ModernButton>
              <ModernButton
                variant="gradient"
                glow
                onClick={onSubmit}
                disabled={!isFormValid || submitting}
                loading={submitting}
              >
                Update Opportunity
              </ModernButton>
            </Box>
          </Stack>
        </form>
      </Box>
    </Fade>
  );
}