import * as React from 'react';
import RoundListView from '../../lists/RoundListView';
 
export default function RoundList() {
  return <RoundListView showToolbar={true} />;
}