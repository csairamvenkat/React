import * as React from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Box,
  Typography,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Select,
  FormControl,
  InputLabel,
  Chip,
  Stack,
  Divider,
  Fade,
  Tooltip,
  Autocomplete,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  CircularProgress,
  DialogActions,
  Button,
} from "@mui/material";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import InfoIcon from "@mui/icons-material/Info";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import PeopleIcon from "@mui/icons-material/People";
import AssignmentIcon from "@mui/icons-material/Assignment";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { SPHttpClient } from "@microsoft/sp-http";
import { ApiDataProvider } from "../../../api/ApiDataProvider";
import { triggerFlow } from "../../../flow/flowclient";
import {
  ModernCard,
  ModernButton,
  ModernTextField,
  ModernStepper,
  ModernAlert,
  ModernChip,
  ModernEmptyState,
  ModernLoadingState
} from "../../shared/mui";
import { IDropdownOption, IPersonaProps } from "@fluentui/react";
import {
  PeoplePicker,
  PrincipalType
} from "@pnp/spfx-controls-react/lib/PeoplePicker";

type ScenarioKey = "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H" | "I" | "J";
type InputOption =
  | "CollectInput"
  | "useStandardInput"
  | "usePreviousRoundInput";

interface Scenario {
  key: ScenarioKey;
  description: string;
  readOnly?: boolean;
}

interface StandardTemplateOption {
  id: string;
  title: string;
  stakeholder: string;
  versionNumber: string;
}

type ScenarioConfig = {
  inputOption?: InputOption | string;
  notifyUserPersonas?: IPersonaProps[];
  standardSelectedKey?: string;
  standardReferenceId?: number | null;
  previousRoundId?: number | null;
  //versionSelections?: string[];
  submissionTypes?: string[];
  collectDraftInput?: boolean;
  draftDueDate?: Date | null;
};

interface StakeholderRow {
  enabled: boolean;
  otherCode?: string;
  otherDescription?: string;
  usePreviousRound?: boolean;
  stakeholderName?: string;
  autoExpandedForNewScenarios?: boolean;
  stakeholderCode?: string;
  standardTemplateAvailable?: boolean | string;
  inputOption?: InputOption | string;
  notifyUserPersonas?: IPersonaProps[];
  additionalTeamPersonas?: IPersonaProps[];
  dueDate?: string;
  applicableScenarios: ScenarioKey[];
  groups?: { id: number; title: string }[];
  groupUsers?: { key: number; text: string; email?: string; login?: string }[];
  groupUsersPersona?: IPersonaProps[];
  directorySearchOptions?: IPersonaProps[];
  prevRoundSnapshot?: {
    referenceDataId: number | null;
    dueDate?: string;
    applicableScenarios?: ScenarioKey[];
    notifyUserPersonas?: IPersonaProps[];
    additionalTeamPersonas?: IPersonaProps[];
  };

  peoplePickerResetKey?: number;
  standardOptionsLoading?: boolean;
  standardOptionsError?: string | null;
  standardOptions?: StandardTemplateOption[] | null;
  standardSelectedKeys?: string[];
  standardOptionsLoaded?: boolean;
  standardUnavailable?: boolean;
  standardFetchAttempted?: boolean;

  copyType: string;
  referenceData: number;
  referenceDataId?: number | null;
  standardReferenceIds?: number[];
  standardReferenceId: number | null;

  inputTemplateVersions?: {
    Id: number;
    VersionNumber: string;
    DraftApplicable: boolean;
    Active: boolean;
  }[];

  commonVersionSelections?: string;
  collectDraftInput?: boolean;
  commonDraftDueDate?: Date | null;

  scenarioConfigs?: Partial<Record<ScenarioKey, ScenarioConfig>>;
}

type PreviousRoundStakeholder = {
  id: number;
  stakeholder_code?: string;
  stakeholder?: string;
  stakeholderType?: string;
  versionNumber?: string;
  enabled?: boolean;
  applicableScenarios?:
  | { name?: string; desc?: string }[]
  | { key?: string; desc?: string }[];
  //notify_users?: { id?: number; displayName?: string; email?: string }[];
  notifyUsers?: {
    id?: number | string;
    name?: string;
    displayName?: string;
    email?: string;
    login_id?: string;
  }[];
  additionalStakeholders?: {
    id?: string | number;
    displayName?: string;
    email?: string;
  }[];
  dueDate?: string;
  input_type?: InputOption | string;

  collectDraftInput?: boolean;
  draftDueDate?: string;


  roundId: number;
};

type PreviousRoundInput = {
  stakeholder?: string;
  scenarioName?: ScenarioKey | string;
  workflowStatus?: string;
  isCurrentApproved?: string;
  isCurrentVersion?: string;
  stakeholderCode: string;
  versionNumber?: string;
};

type PreviousRoundDetails = {
  roundNumber: number;
  scenarioList?: { name: string; desc?: string }[];
  stakeholders?: PreviousRoundStakeholder[];
  inputs?: PreviousRoundInput[];
};

const SCENARIO_KEYS: ScenarioKey[] = [
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J"
];
const STAKEHOLDER_LIST_TITLE = "InputTemplate";
const PEOPLE_GROUP_FIELD = "AssociatedGroup";

const INPUT_OPTIONS_ALL: IDropdownOption[] = [
  { key: "CollectInput", text: "Collect Input" },
  { key: "useStandardInput", text: "Use Standard Input" },
  { key: "usePreviousRoundInput", text: "Use Previous Round Input" }
];

const INPUT_OPTION_COLLECT_ONLY: IDropdownOption[] = [
  { key: "CollectInput", text: "Collect Input" }
];

const STANDARD_LIB_TITLE = "Standard Input Templates";
const STANDARD_STATUS_FIELD = "status";
const STANDARD_STATUS_VALIDATED = "validated";
const STANDARD_COUNTRY_LOOKUP_FIELD = "country";
const STANDARD_FILETITLE_FIELD = "fileTitle";


function nextScenarioKey(existing: Scenario[]): ScenarioKey | null {
  const used = new Set(existing.map((s) => s.key));
  return SCENARIO_KEYS.find((k) => !used.has(k)) || null;
}

function isStdTemplateAvailable(v: boolean | string | undefined) {
  if (typeof v === "boolean") return v;
  if (typeof v === "string")
    return v.toLowerCase() === "yes" || v.toLowerCase() === "true";
  return false;
}

function toGroupArray(pg: any): { Id: number; Title: string }[] {
  if (!pg) return [];
  if (Array.isArray(pg)) return pg.filter((g) => g && typeof g.Id === "number");
  if (typeof pg === "object" && typeof pg.Id === "number") return [pg];
  return [];
}

function toPersona(u: {
  key: number | string;
  text: string;
  email?: string;
  login?: string;
}): IPersonaProps {
  return {
    key: String(u.key),
    text: u.text,
    secondaryText: u.email || u.login,
    tertiaryText: u.login
  };
}

function directoryUserToPersona(u: {
  id?: string | number;
  displayName?: string;
  mail?: string;
  userPrincipalName?: string;
}): IPersonaProps {
  const key =
    u.id ??
    u.userPrincipalName ??
    u.mail ??
    Math.random().toString(36).slice(2);
  const email = u.mail || u.userPrincipalName;
  return {
    key: String(key),
    text: u.displayName || email || String(key),
    secondaryText: email || undefined,
    tertiaryText: u.userPrincipalName
  };
}

function toDateOnlyStr(d?: Date | null): string | undefined {
  if (!d) return undefined;
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function normalizeIso(s?: string): string | undefined {
  if (!s) return undefined;
  const trimmed = String(s).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    const d = new Date(trimmed + "T00:00:00");
    return isNaN(d.getTime()) ? undefined : d.toISOString();
  }
  const d = new Date(trimmed);
  return isNaN(d.getTime()) ? undefined : d.toISOString();
}

function isoFromDateOnlyStr(s?: string): string | undefined {
  if (!s) return undefined;
  const [y, m, d] = s.split("-").map((x) => Number(x));
  if (!y || !m || !d) return undefined;
  const dt = new Date(y, m - 1, d, 0, 0, 0, 0);
  return dt.toISOString();
}

function inputOptionToText(v?: string): string {
  switch (v) {
    case "CollectInput":
      return "Collect Input";
    case "useStandardInput":
      return "Use Standard Input";
    case "usePreviousRoundInput":
      return "Use Previous Round Input";
    default:
      return v || "-";
  }
}

function uniq<T>(arr: T[], keyFn: (x: T) => string): T[] {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const it of arr) {
    const k = keyFn(it);
    if (!seen.has(k)) {
      seen.add(k);
      out.push(it);
    }
  }
  return out;
}



export default function CreateRound() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const cfg = (window as any).TENANT_CONFIG;

  const ALLOWED_GROUP_NAME = "Pricing";

  const api = React.useMemo(
    () =>
      new ApiDataProvider((window as any).spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl
      }),
    [cfg]
  );

  const [existingTemplateCodes, setExistingTemplateCodes] = React.useState<string[]>([]);
  const [customer, setCustomer] = React.useState("");
  const [opportunityName, setOpportunityName] = React.useState("");
  const [leadPricerEmail, setLeadPricerEmail] = React.useState("");
  const [bidTeamEmail, setBidTeamEmail] = React.useState<string[]>([]);
  const [description, setDescription] = React.useState("");
  const [customerSubmissionDate, setCustomerSubmissionDate] =
    React.useState<Date | null>(null);

  const [templateDueDate, setTemplateDueDate] = React.useState<Date | null>(
    null
  );
  const prevTemplateDueDateRef = React.useRef<string | undefined>(undefined);

  const [scenarios, setScenarios] = React.useState<Scenario[]>([
    { key: "A", description: "" }
  ]);
  const [stakeholders, setStakeholders] = React.useState<StakeholderRow[]>([]);
  const [adhocCards, setAdhocCards] = React.useState<StakeholderRow[]>([]);
  const [activeVersions, setActiveVersions] = React.useState<string[]>([]);

  const [prevRoundVersionMap, setPrevRoundVersionMap] =
    React.useState<Map<string, string>>(new Map());

  const [otherCard, setOtherCard] =
    React.useState<StakeholderRow>({
      enabled: false,
      stakeholderName: "Other",
      stakeholderCode: "OTHER",
      applicableScenarios: [],
      notifyUserPersonas: [],
      additionalTeamPersonas: [],
      scenarioConfigs: {},
      dueDate: undefined,
      otherCode: "",
      copyType: "1",
      referenceData: 0,
      standardReferenceId: null
    });

  const [saving, setSaving] = React.useState(false);
  const [draftDueDateError, setDraftDueDateError] = React.useState<{
    [key: number]: string;
  }>({});

  const today = React.useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);
  const [roundNumber, setRoundNumber] = React.useState<number>(1);
  const [rounds, setRounds] = React.useState<any[]>([]);
  const [selectedRoundNumber, setSelectedRoundNumber] = React.useState<
    number | null
  >(null);
  const [toast, setToast] = React.useState<{
    severity: "success" | "error" | "warning" | "info";
    text: string;
  } | null>(null);
  const [prevRoundDetails, setPrevRoundDetails] =
    React.useState<PreviousRoundDetails | null>(null);
  const [initializedFromPrevious, setInitializedFromPrevious] =
    React.useState(false);
  const prevScenarioKeysRef = React.useRef<ScenarioKey[]>([]);
  const [opportunityCountryName, setOpportunityCountryNames] =
    React.useState("");

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);


  const [prevRoundApprovedScenarioMap, setPrevRoundApprovedScenarioMap] =
    React.useState<Map<string, Set<ScenarioKey>>>(new Map());

  const prevScenarioCountRef = React.useRef<number>(0);
  const [expandedDescriptions, setExpandedDescriptions] = React.useState<{ [key: string]: boolean }>({});
  const [folderCreationDialogOpen, setFolderCreationDialogOpen] =
    React.useState(false);

  const [previousRoundDialogOpen, setPreviousRoundDialogOpen] =
    React.useState(false);

  const [previousRoundCountdown, setPreviousRoundCountdown] =
    React.useState(10);

  const [pendingFlowPayload, setPendingFlowPayload] =
    React.useState<any>(null);

  const [pendingCreatedRound, setPendingCreatedRound] =
    React.useState<any>(null);

  const handleFolderDialogOk = async () => {
    setFolderCreationDialogOpen(false);

    if (!pendingFlowPayload || !pendingCreatedRound) {
      return;
    }
    navigate(
      `/opportunities/${id}/rounds/${pendingCreatedRound.id}`
    );
    // await triggerFlow(
    //   pendingFlowPayload,
    //   "RoundCreationFlow"
    // );


  };
  React.useEffect(() => {
    if (!folderCreationDialogOpen) return;

    const timer = setTimeout(() => {
      setFolderCreationDialogOpen(false);

      if (pendingCreatedRound) {
        navigate(
          `/opportunities/${id}/rounds/${pendingCreatedRound.id}`
        );
      }
    }, 25000);

    return () => {
      clearTimeout(timer);
    };
  }, [folderCreationDialogOpen, pendingCreatedRound, id, navigate]);

  React.useEffect(() => {
    if (!previousRoundDialogOpen) return;

    if (previousRoundCountdown <= 0) {
      navigate(`/opportunities/${id}`, {
        state: {
          previousRoundStillOpen: true
        }
      });
      return;
    }

    const timer = setTimeout(() => {
      setPreviousRoundCountdown((prev) => prev - 1);
    }, 1000);

    return () => {
      clearTimeout(timer);
    };
  }, [
    previousRoundDialogOpen,
    previousRoundCountdown,
    id,
    navigate
  ]);

  React.useEffect(() => {
    if (!hasAccess) return;

    void (async () => {
      try {
        const response = null;
        const active = (Array.isArray(response) ? response : [])
          .filter((v: any) => v.active === true)
          .map((v: any) => String(v.versionNumber));
        setActiveVersions(active.length ? active : ["1"]);
      } catch (e) {
        console.error("Failed loading versions", e);
        setActiveVersions(["1"]);
      }
    })();
  }, [api, hasAccess]);

  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: "application/json;odata=nometadata"
            },
            credentials: "same-origin"
          }
        );

        if (!response.ok) {
          throw new Error("Failed to fetch user groups");
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error("Permission check failed", error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const searchAdUsers = React.useCallback(
    async (term: string): Promise<IPersonaProps[]> => {
      try {
        if (!term || term.trim().length < 2) return [];
        const results = await (api as any).searchDirectoryUsers?.(term);
        if (Array.isArray(results)) {
          return results.map(directoryUserToPersona);
        }
        return [];
      } catch {
        return [];
      }
    },
    [api]
  );

  const peoplePickerContext = React.useMemo(
    () => ({
      absoluteUrl: (window as any).spfxContext?.pageContext?.web?.absoluteUrl,
      msGraphClientFactory: (window as any).spfxContext?.msGraphClientFactory,
      spHttpClient: (window as any).spfxContext?.spHttpClient
    }),
    []
  );

  React.useEffect(() => {
    if (!hasAccess) return;

    const currKeys = scenarios.map(s => s.key);
    const scenarioCountIncreased =
      scenarios.length > prevScenarioCountRef.current;

    if (!scenarioCountIncreased) {
      prevScenarioCountRef.current = scenarios.length;
      prevScenarioKeysRef.current = currKeys;
      return;
    }

    setStakeholders(prev =>
      prev.map(r => {
        if (!r.enabled) return r;
        if (!r.prevRoundSnapshot) return r;
        if (r.autoExpandedForNewScenarios) return r;

        const prevSelected = r.applicableScenarios ?? [];

        const hadAllPreviously =
          prevScenarioKeysRef.current.length > 0 &&
          prevScenarioKeysRef.current.every(k => prevSelected.includes(k));

        if (!hadAllPreviously) return r;

        const nextScenarios = Array.from(
          new Set([...prevSelected, ...currKeys])
        );

        const scenarioConfigs = { ...(r.scenarioConfigs ?? {}) };
        const approvedScenarios =
          prevRoundApprovedScenarioMap.get(norm(r.stakeholderCode)) ?? new Set();

        nextScenarios.forEach(k => {
          if (!scenarioConfigs[k] || scenarioConfigs[k]?.inputOption == null) {
            const canUsePrevious = approvedScenarios.has(k);
            scenarioConfigs[k] = {
              ...scenarioConfigs[k],
              inputOption: canUsePrevious
                ? "usePreviousRoundInput"
                : "CollectInput",
              previousRoundId: canUsePrevious
                ? r.prevRoundSnapshot?.referenceDataId ?? null
                : null,
              //versionSelections: [...activeVersions],
              submissionTypes: ["Draft", "Final"],
              collectDraftInput: false,
              draftDueDate: null
            };
          }
        });

        return {
          ...r,
          applicableScenarios: nextScenarios,
          scenarioConfigs,
          autoExpandedForNewScenarios: true
        };
      })
    );

    prevScenarioCountRef.current = scenarios.length;
    prevScenarioKeysRef.current = currKeys;
  }, [scenarios, hasAccess, prevRoundApprovedScenarioMap]);

  async function getUsersOfSharePointGroup(groupId: number) {
    const ctx = (window as any).spfxContext;
    const url = `${cfg.siteUrl}/_api/web/sitegroups/GetById(${groupId})/users?$select=Id,Title,Email,LoginName`;
    const res = await ctx.spHttpClient.get(url, SPHttpClient.configurations.v1);
    if (!res.ok) throw new Error(`Group users GET failed: ${res.status}`);
    const data = await res.json();
    const arr = (data.value ?? []) as any[];
    return arr.map((u) => ({
      key: u.Id,
      text: u.Title || u.LoginName,
      email: u.Email,
      login: u.LoginName
    }));
  }

  async function getUsersFromGroups(groupIds: number[]) {
    const all = await Promise.all(
      groupIds.map(async (gid) => {
        try {
          return await getUsersOfSharePointGroup(gid);
        } catch {
          return [] as {
            key: number;
            text: string;
            email?: string;
            login?: string;
          }[];
        }
      })
    );

    const flat = all.reduce(
      (acc, arr) => acc.concat(arr),
      [] as { key: number; text: string; email?: string; login?: string }[]
    );

    const seen = new Set<string>();
    const deduped: {
      key: number;
      text: string;
      email?: string;
      login?: string;
    }[] = [];
    for (const u of flat) {
      const k = String(u.key);
      if (!seen.has(k)) {
        seen.add(k);
        deduped.push(u);
      }
    }
    return deduped;
  }

  React.useEffect(() => {
    if (!hasAccess) return;
    (async () => {
      try {
        const ctx = (window as any).spfxContext;
        const endpoint =
          `${cfg.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(
            STAKEHOLDER_LIST_TITLE
          )}')/items` +
          `?$select=Title,Code,StandardTemplateAvailable,${PEOPLE_GROUP_FIELD}/Id,${PEOPLE_GROUP_FIELD}/Title` +
          `&$expand=${PEOPLE_GROUP_FIELD}`;
        const res = await ctx.spHttpClient.get(
          endpoint,
          SPHttpClient.configurations.v1
        );
        if (!res.ok) throw new Error(`Stakeholders GET failed: ${res.status}`);
        const data = await res.json();
        const items = (data.value ?? data.d?.results ?? []) as any[];
        const uniqueItems = Array.from(
          new Map(
            items.map(item => [item.Title, item])
          ).values()
        );

        setExistingTemplateCodes(
          uniqueItems
            .map(item => String(item.Code ?? "").trim().toLowerCase())
            .filter(Boolean)
        );

        setStakeholders(
          uniqueItems.map((it) => {
            const pgRaw = it[PEOPLE_GROUP_FIELD];
            const groups = toGroupArray(pgRaw);
            return {
              enabled: false,
              stakeholderName: it.Title,
              stakeholderCode: it.Code,
              standardTemplateAvailable: it.StandardTemplateAvailable,
              inputOption: undefined,
              dueDate: undefined,
              applicableScenarios: [],
              groups: groups.map((g) => ({ id: g.Id, title: g.Title })),
              groupUsers: undefined,
              groupUsersPersona: undefined,
              notifyUserPersonas: [],
              additionalTeamPersonas: [],
              directorySearchOptions: [],
              peoplePickerResetKey: 0,
              standardOptionsLoading: false,
              standardOptionsError: null,
              standardOptions: [],
              standardSelectedKeys: [],
              standardOptionsLoaded: false,
              standardUnavailable: false,
              standardFetchAttempted: false,
              referenceData: 0,
              copyType: "1",
              standardReferenceId: 0,

              scenarioConfigs: {}
            } as StakeholderRow;
          })
        );
      } catch (err: any) {
        setToast({
          severity: "warning",
          text: `Stakeholders load fallback: ${err.message}`
        });
      }
    })();
  }, [hasAccess]);

  React.useEffect(() => {
    if (!hasAccess) return;
    void (async () => {
      const o = await api.getOpportunity(Number(id));
      setCustomer(o.customer || "");
      setOpportunityName(o.title || "");
      const uniqueEmailsleadPricer = Array.from(
        new Set(o.lead_pricer?.map((u) => u.email).filter(Boolean)));
      const uniqueEmailsleadPricerString = uniqueEmailsleadPricer.join(";");
      setLeadPricerEmail(uniqueEmailsleadPricerString);
      const emailArray: string[] =
        o.bid_team_members?.map((member: any) => member.email) ?? [];
      setBidTeamEmail(emailArray);
      setOpportunityCountryNames(o.country || "");
    })();
  }, [api, id, hasAccess]);

  React.useEffect(() => {
    if (!hasAccess) return;
    (async () => {
      try {
        //debugger;
        const rounds = await (api as any).getRounds?.(Number(id));
        if (Array.isArray(rounds) && rounds.length > 0) {
          setRounds(rounds);
          // Check whether any existing/previous round is still open
          const openPreviousRound = rounds.find(
            (r: any) =>
              String(r.workflowStatus ?? "").trim().toLowerCase() !== "completed"
          );

          if (openPreviousRound) {
            setPreviousRoundCountdown(10);
            setPreviousRoundDialogOpen(true);
            return;
          }


          const maxRound = Math.max(
            ...rounds.map((r: any) => r.roundNumber || 0)
          );
          setRoundNumber(maxRound + 1);
          let prevDetail: PreviousRoundDetails | null = null;
          const prevRoundItem = rounds.find(
            (r: any) => r.roundNumber === maxRound
          );
          if (prevRoundItem && prevRoundItem.id) {
            prevDetail = await (api as any).getRound(prevRoundItem.id);
          }
          if (!prevDetail) {
            const prev = rounds.find(
              (r: any) => (r.roundNumber || 0) === maxRound
            );
            if (prev) {
              prevDetail = {
                roundNumber: maxRound,
                scenarioList: prev.scenarioList ?? prev.scenarios ?? [],
                stakeholders: prev.stakeholders ?? [],
                inputs: prev.inputs ?? []
              };
            }
          }
          if (prevDetail) setPrevRoundDetails(prevDetail);
        } else {
          setRoundNumber(1);
        }
      } catch {
        setRoundNumber(1);
      }
    })();
  }, [api, id, hasAccess]);

  // React.useEffect(() => {
  //   if (!hasAccess) return;
  //   if (initializedFromPrevious) return;
  //   if (scenarios.length === 0) return;
  //   if (roundNumber <= 1) return;
  //   if (!prevRoundDetails) return;
  //   if (stakeholders.length === 0) return;

  //   const approvedMap = buildApprovedScenarioMap(prevRoundDetails);

  //   const versionMap =
  //     buildPreviousVersionMap(prevRoundDetails);

  //   setPrevRoundVersionMap(versionMap);

  //   const prevScenarios = (prevRoundDetails.scenarioList ?? [])
  //     .map((s: any) => {
  //       const rawKey = s.name || s.key || s.scenario;
  //       const key = (rawKey || "").toUpperCase();
  //       if (!SCENARIO_KEYS.includes(key as ScenarioKey)) return null;

  //       return {
  //         key: key as ScenarioKey,
  //         description: s.desc ?? s.description ?? "",
  //         readOnly: true
  //       } as Scenario;
  //     })
  //     .filter(Boolean) as Scenario[];

  //   if (prevScenarios.length > 0) {
  //     setScenarios(prevScenarios);
  //   }

  //   const prevByCode = new Map<string, PreviousRoundStakeholder>();
  //   const prevByTitle = new Map<string, PreviousRoundStakeholder>();

  //   (prevRoundDetails.stakeholders ?? []).forEach(sh => {
  //     const code = getPrevCode(sh);
  //     const title = getPrevTitle(sh);
  //     if (code) prevByCode.set(norm(code), sh);
  //     if (title) prevByTitle.set(norm(title), sh);
  //   });

  //   setStakeholders(prev =>
  //     prev.map(row => {
  //       const prevSh =
  //         (row.stakeholderCode &&
  //           prevByCode.get(norm(row.stakeholderCode))) ||
  //         (row.stakeholderName &&
  //           prevByTitle.get(norm(row.stakeholderName)));

  //       if (!prevSh || prevSh.enabled === false) return row;

  //       const applicableScenarios = (prevSh.applicableScenarios ?? [])
  //         .map((s: any) => (s.name || s.key || "").toUpperCase())
  //         .filter(k =>
  //           SCENARIO_KEYS.includes(k as ScenarioKey)
  //         ) as ScenarioKey[];

  //       const notifyFromPrev: IPersonaProps[] =
  //         (prevSh.notify_users ?? []).map((u: any) =>
  //           toPersona({
  //             key: u.id ?? u.email ?? u.displayName,
  //             text: u.displayName ?? u.email,
  //             email: u.email
  //           })
  //         );

  //       const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

  //       const approvedScenarios =
  //         approvedMap.get(norm(row.stakeholderCode)) ?? new Set<ScenarioKey>();

  //       // applicableScenarios.forEach(sk => {

  //       //   const previousVersion =
  //       //     versionMap.get(norm(row.stakeholderCode));

  //       //   const currentVersion =
  //       //     row.commonVersionSelections ||
  //       //     row.inputTemplateVersions?.[0]?.VersionNumber;

  //       //   const canCopy =
  //       //     approvedScenarios.has(sk) &&
  //       //     previousVersion === currentVersion;

  //       //   // const canCopy = approvedScenarios.has(sk);

  //       //   scenarioConfigs[sk] = canCopy
  //       //     ? {
  //       //       inputOption: "usePreviousRoundInput",
  //       //       notifyUserPersonas: notifyFromPrev,
  //       //       previousRoundId: prevSh.roundId,
  //       //       standardSelectedKey: undefined,
  //       //       standardReferenceId: null
  //       //     }
  //       //     : {
  //       //       inputOption: "CollectInput",
  //       //       notifyUserPersonas: [],
  //       //       previousRoundId: null,
  //       //       standardSelectedKey: undefined,
  //       //       standardReferenceId: null
  //       //     };
  //       // });

  //       applicableScenarios.forEach(sk => {

  //         const previousVersion =
  //           versionMap.get(norm(row.stakeholderCode));

  //         const currentVersion =
  //           row.commonVersionSelections ||
  //           row.inputTemplateVersions?.[0]?.VersionNumber;

  //         // IMPORTANT:
  //         // This controls whether we can automatically select
  //         // "Use Previous Round Input".
  //         //
  //         // Keep this approval/version logic unchanged.
  //         const canUsePreviousRoundInput =
  //           approvedScenarios.has(sk) &&
  //           previousVersion === currentVersion;

  //         scenarioConfigs[sk] = canUsePreviousRoundInput
  //           ? {
  //             inputOption: "usePreviousRoundInput",
  //             notifyUserPersonas: notifyFromPrev,
  //             previousRoundId: prevSh.roundId,
  //             standardSelectedKey: undefined,
  //             standardReferenceId: null,
  //             submissionTypes: ["Draft", "Final"]
  //           }
  //           : {
  //             // Previous values are still copied, but because the
  //             // previous input is not approved, don't select
  //             // Use Previous Round Input automatically.
  //             inputOption: "CollectInput",
  //             notifyUserPersonas: notifyFromPrev,
  //             previousRoundId: null,
  //             standardSelectedKey: undefined,
  //             standardReferenceId: null,
  //             submissionTypes: ["Draft", "Final"]
  //           };
  //       });
  //       return {
  //         ...row,
  //         enabled: true,
  //         applicableScenarios,
  //         scenarioConfigs,
  //         dueDate:
  //           row.dueDate ??
  //           (templateDueDate
  //             ? templateDueDate.toISOString()
  //             : undefined),
  //         notifyUserPersonas: notifyFromPrev,
  //         prevRoundSnapshot: {
  //           applicableScenarios,
  //           notifyUserPersonas: notifyFromPrev,
  //           referenceDataId: prevSh.roundId,
  //           dueDate: undefined
  //         },
  //         peoplePickerResetKey: 0
  //       };
  //     })
  //   );
  //   setPrevRoundApprovedScenarioMap(approvedMap);
  //   setInitializedFromPrevious(true);
  // }, [
  //   hasAccess,
  //   initializedFromPrevious,
  //   roundNumber,
  //   prevRoundDetails,
  //   stakeholders.length,
  //   scenarios.length
  // ]);

  React.useEffect(() => {
    if (!hasAccess) return;
    if (initializedFromPrevious) return;
    if (scenarios.length === 0) return;
    if (roundNumber <= 1) return;
    if (!prevRoundDetails) return;
    if (stakeholders.length === 0) return;

    const approvedMap = buildApprovedScenarioMap(prevRoundDetails);
    const versionMap = buildPreviousVersionMap(prevRoundDetails);

    setPrevRoundVersionMap(versionMap);

    // ---------------------------------------------------------
    // 1. Copy previous round datasets
    // ---------------------------------------------------------
    const prevScenarios = (prevRoundDetails.scenarioList ?? [])
      .map((s: any) => {
        const rawKey = s.name || s.key || s.scenario;
        const key = (rawKey || "").toUpperCase();

        if (!SCENARIO_KEYS.includes(key as ScenarioKey)) {
          return null;
        }

        return {
          key: key as ScenarioKey,
          description: s.desc ?? s.description ?? "",
          readOnly: true
        } as Scenario;
      })
      .filter(Boolean) as Scenario[];

    if (prevScenarios.length > 0) {
      setScenarios(prevScenarios);
    }

    // ---------------------------------------------------------
    // 2. Create previous stakeholder lookup maps
    // ---------------------------------------------------------
    const prevByCode = new Map<string, PreviousRoundStakeholder>();
    const prevByTitle = new Map<string, PreviousRoundStakeholder>();

    (prevRoundDetails.stakeholders ?? []).forEach(sh => {
      const code = getPrevCode(sh);
      const title = getPrevTitle(sh);

      if (code) {
        prevByCode.set(norm(code), sh);
      }

      if (title) {
        prevByTitle.set(norm(title), sh);
      }
    });

    // ---------------------------------------------------------
    // 3. Copy previous values into non-Adhoc stakeholders
    // ---------------------------------------------------------
    setStakeholders(prev =>
      prev.map(row => {

        const prevSh =
          (row.stakeholderCode &&
            prevByCode.get(norm(row.stakeholderCode))) ||
          (row.stakeholderName &&
            prevByTitle.get(norm(row.stakeholderName)));

        // No previous stakeholder OR previous stakeholder was disabled
        if (!prevSh || prevSh.enabled === false) {
          return row;
        }

        // -----------------------------------------------------
        // Previous datasets
        // -----------------------------------------------------
        const applicableScenarios = (prevSh.applicableScenarios ?? [])
          .map((s: any) =>
            String(s.name || s.key || "").toUpperCase()
          )
          .filter(k =>
            SCENARIO_KEYS.includes(k as ScenarioKey)
          ) as ScenarioKey[];

        // -----------------------------------------------------
        // Previous Stakeholder Users
        // -----------------------------------------------------
        const notifyFromPrev: IPersonaProps[] =
          (prevSh.notifyUsers ?? []).map((u: any) =>
            toPersona({
              key: u.id ?? u.email ?? u.name,
              text: u.name ?? u.displayName ?? u.email ?? "",
              email: u.email,
              login: u.login_id
            })
          );

        // -----------------------------------------------------
        // Previous Extra Input Providers
        // -----------------------------------------------------
        const additionalFromPrev: IPersonaProps[] =
          (prevSh.additionalStakeholders ?? []).map((u: any) =>
            toPersona({
              key: u.id ?? u.email ?? u.name,
              text: u.name ?? u.displayName ?? u.email ?? "",
              email: u.email,
              login: u.login_id
            })
          );

        // -----------------------------------------------------
        // IMPORTANT:
        // Previous version is copied regardless of approval.
        // Approval only controls Use Previous Round Input.
        // -----------------------------------------------------
        const previousVersion =
          String(
            prevSh.versionNumber ??
            versionMap.get(norm(row.stakeholderCode)) ??
            ""
          ).trim();

        // -----------------------------------------------------
        // Previous due date
        // -----------------------------------------------------
        const previousDueDate =
          prevSh.dueDate ??
          row.dueDate ??
          (templateDueDate
            ? templateDueDate.toISOString()
            : undefined);

        // -----------------------------------------------------
        // Previous draft settings
        // -----------------------------------------------------
        const previousCollectDraftInput =
          prevSh.collectDraftInput ?? false;

        const previousDraftDueDate =
          prevSh.draftDueDate
            ? new Date(prevSh.draftDueDate)
            : null;

        // -----------------------------------------------------
        // Scenario configs
        // -----------------------------------------------------
        const scenarioConfigs: Partial<
          Record<ScenarioKey, ScenarioConfig>
        > = {};

        applicableScenarios.forEach(sk => {

          // KEEP EXISTING PREVIOUS-ROUND DROPDOWN LOGIC
          //
          // Only Approved + matching version gets
          // usePreviousRoundInput automatically.
          //
          // Otherwise CollectInput.
          const canUsePreviousRoundInput =
            approvedMap
              .get(norm(row.stakeholderCode))
              ?.has(sk) === true &&
            previousVersion !== "" &&
            previousVersion === row.commonVersionSelections;

          scenarioConfigs[sk] = {
            inputOption: "CollectInput",
            notifyUserPersonas: notifyFromPrev,
            previousRoundId: null,
            standardSelectedKey: undefined,
            standardReferenceId: null,
            submissionTypes: ["Draft", "Final"]
          };
        });

        return {
          ...row,

          // ---------------------------------------------------
          // ENABLE NON-ADHOC STAKEHOLDER
          // ---------------------------------------------------
          enabled: true,

          // ---------------------------------------------------
          // COPY PREVIOUS DATASET SELECTION
          // ---------------------------------------------------
          applicableScenarios,

          // ---------------------------------------------------
          // COPY VERSION
          // ---------------------------------------------------
          commonVersionSelections: previousVersion,

          // ---------------------------------------------------
          // COPY DUE DATE
          // ---------------------------------------------------
          dueDate: previousDueDate,

          // ---------------------------------------------------
          // COPY STAKEHOLDER USERS
          // ---------------------------------------------------
          notifyUserPersonas: notifyFromPrev,

          // ---------------------------------------------------
          // COPY EXTRA INPUT PROVIDERS
          // ---------------------------------------------------
          additionalTeamPersonas: additionalFromPrev,

          // ---------------------------------------------------
          // COPY DRAFT SETTINGS
          // ---------------------------------------------------
          collectDraftInput:
            previousCollectDraftInput,

          commonDraftDueDate:
            previousDraftDueDate,

          // ---------------------------------------------------
          // Keep snapshot for existing dropdown logic
          // ---------------------------------------------------
          prevRoundSnapshot: {
            applicableScenarios,

            notifyUserPersonas:
              notifyFromPrev,

            additionalTeamPersonas:
              additionalFromPrev,

            referenceDataId:
              prevSh.roundId,

            dueDate:
              previousDueDate
          },

          scenarioConfigs,

          peoplePickerResetKey:
            (row.peoplePickerResetKey ?? 0) + 1
        };
      })
    );

    setPrevRoundApprovedScenarioMap(approvedMap);
    setInitializedFromPrevious(true);

  }, [
    hasAccess,
    initializedFromPrevious,
    roundNumber,
    prevRoundDetails,
    stakeholders.length,
    scenarios.length,
    templateDueDate
  ]);

  React.useEffect(() => {
    if (!initializedFromPrevious) return;

    setStakeholders(prev =>
      prev.map(row => {
        if (!row.enabled) return row;

        let changed = false;

        const approvedScenarios =
          prevRoundApprovedScenarioMap.get(norm(row.stakeholderCode)) ??
          new Set<ScenarioKey>();

        const nextScenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {
          ...(row.scenarioConfigs || {})
        };

        (row.applicableScenarios || []).forEach(sk => {
          const cfg = nextScenarioConfigs[sk];
          if (!cfg) return;

          const previousVersion =
            prevRoundVersionMap.get(norm(row.stakeholderCode)) ?? "";

          const currentVersion =
            row.commonVersionSelections?.trim() ?? "";

          const canUsePrevious =
            approvedScenarios.has(sk) &&
            previousVersion !== "" &&
            currentVersion !== "" &&
            previousVersion === currentVersion;

          if (
            cfg.inputOption === "usePreviousRoundInput" &&
            !canUsePrevious
          ) {
            nextScenarioConfigs[sk] = {
              ...cfg,
              inputOption: "CollectInput",
              previousRoundId: null
            };
            changed = true;
          }
        });

        if (!changed) return row;

        return {
          ...row,
          scenarioConfigs: nextScenarioConfigs
        };
      })
    );
  }, [
    initializedFromPrevious,
    prevRoundApprovedScenarioMap
  ]);

  // function buildPreviousVersionMap(
  //   prevRoundDetails: PreviousRoundDetails | null
  // ): Map<string, string> {
  //   const map = new Map<string, string>();

  //   if (!prevRoundDetails?.inputs) {
  //     return map;
  //   }

  //   prevRoundDetails.inputs.forEach((inp: any) => {
  //     if (
  //       inp.workflowStatus === "Approved" &&
  //       inp.stakeholderCode &&
  //       inp.versionNumber
  //     ) {
  //       map.set(
  //         norm(inp.stakeholderCode),
  //         inp.versionNumber
  //       );
  //     }
  //   });

  //   return map;
  // }

  function buildPreviousVersionMap(
    prevRoundDetails: PreviousRoundDetails | null
  ): Map<string, string> {
    const map = new Map<string, string>();

    if (!prevRoundDetails) {
      return map;
    }

    // 1. First try to get version directly from previous stakeholders
    (prevRoundDetails.stakeholders ?? []).forEach((sh: any) => {
      const stakeholderCode = String(
        sh?.stakeholderCode ??
        sh?.stakeholder_code ??
        sh?.code ??
        ""
      ).trim();

      const version = String(
        sh?.versionNumber ??
        sh?.version_number ??
        sh?.version ??
        ""
      ).trim();

      if (stakeholderCode && version) {
        map.set(norm(stakeholderCode), version);
      }
    });

    // 2. Fallback to previous-round inputs
    // Prefer the input marked as the current version.
    (prevRoundDetails.inputs ?? []).forEach((inp: any) => {
      const stakeholderCode = String(
        inp?.stakeholderCode ??
        inp?.stakeholder_code ??
        inp?.code ??
        ""
      ).trim();

      const version = String(
        inp?.versionNumber ??
        inp?.version_number ??
        inp?.version ??
        ""
      ).trim();

      if (!stakeholderCode || !version) {
        return;
      }

      const key = norm(stakeholderCode);

      const isCurrentVersion =
        String(inp?.isCurrentVersion ?? "")
          .trim()
          .toLowerCase() === "yes" ||
        String(inp?.isCurrentVersion ?? "")
          .trim()
          .toLowerCase() === "true";

      // Only use input if stakeholder version was not already found,
      // or if this input explicitly represents the current version.
      if (!map.has(key) || isCurrentVersion) {
        map.set(key, version);
      }
    });

    return map;
  }

  function getLatestRevisionNumber(
    rounds: any[],
    opportunityId: number,
    stakeholderCode: string,
    dataset: string,
    inputType: string,
    versionNumber: string,
    submissionType: string
  ): number {
    const matchingInputs = (rounds ?? [])
      .flatMap((round: any) => round.inputs ?? [])
      .filter((input: any) =>
        String(input.opportunityId) === String(opportunityId) &&
        norm(input.stakeholderCode) === norm(stakeholderCode) &&
        norm(input.scenarioName) === norm(dataset) &&
        norm(input.inputType) === norm(inputType) &&
        norm(input.versionNumber) === norm(versionNumber) &&
        norm(input.submissionType) === norm(submissionType)
      );

    if (matchingInputs.length === 0) {
      return 1;
    }

    return Math.max(
      ...matchingInputs.map((input: any) =>
        Number(input.revisionNumber) || 0
      )
    );
  }

  function addScenario() {
    const next = nextScenarioKey(scenarios);
    if (!next) {
      setToast({
        severity: "warning",
        text: "Maximum of 10 datasets (A–J) reached."
      });
      return;
    }
    setScenarios((prev) => [
      ...prev,
      { key: next, description: "", readOnly: false }
    ]);
  }

  function removeLastScenario() {
    if (!scenarios.length) return;
    const idx = [...scenarios]
      .map((s, i) => ({ s, i }))
      .reverse()
      .find((x) => !x.s.readOnly)?.i;
    if (idx === undefined) {
      setToast({
        severity: "warning",
        text: "Datasets loaded from previous round cannot be removed."
      });
      return;
    }
    const removedKey = scenarios[idx].key;
    setScenarios((prev) => prev.filter((_, i) => i !== idx));
    setStakeholders((prev) =>
      prev.map((r) => ({
        ...r,
        applicableScenarios: r.applicableScenarios.filter(
          (k) => k !== removedKey
        ),
        scenarioConfigs: Object.fromEntries(
          Object.entries(r.scenarioConfigs || {}).filter(
            ([k]) => k !== removedKey
          )
        ) as Record<ScenarioKey, ScenarioConfig>
      }))
    );
  }

  function updateScenarioDescription(key: ScenarioKey, desc: string) {
    setScenarios((prev) =>
      prev.map((s) => (s.key === key ? { ...s, description: desc } : s))
    );
  }

  function setStakeholderRow(idx: number, patch: Partial<StakeholderRow>) {
    setStakeholders((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, ...patch } : r))
    );
  }

  // Adhoc Card 

  function addAdhocTemplate() {
    setAdhocCards(prev => [
      ...prev,
      {
        enabled: true,

        stakeholderName: "Other",

        stakeholderCode: "OTHER",
        usePreviousRound: false,

        applicableScenarios: [],

        additionalTeamPersonas: [],

        scenarioConfigs: {},

        dueDate: templateDueDate
          ? templateDueDate.toISOString()
          : undefined,
        otherCode: "",
        otherDescription: "",

        copyType: "1",

        referenceData: 0,

        standardReferenceId: null,

        commonVersionSelections: "",

        collectDraftInput: false,

        commonDraftDueDate: null
      }
    ]);
  }

  function updateAdhocCard(
    index: number,
    patch: Partial<StakeholderRow>
  ) {
    setAdhocCards(prev =>
      prev.map((card, i) =>
        i === index
          ? { ...card, ...patch }
          : card
      )
    );
  }

  function norm(s?: string) {
    return (s ?? "").trim().toLowerCase();
  }

  function getPrevCode(sh: any): string {
    return String(
      sh?.stakeholderCode ?? sh?.stakeholder_code ?? sh?.code ?? ""
    ).trim();
  }

  function getPrevTitle(sh: any): string {
    return String(
      sh?.stakeholder ?? sh?.stakeholder_title ?? sh?.title ?? ""
    ).trim();
  }
  function getPreviousAdhocDescription(sh: any): string {
    return String(
      sh?.description ??
      sh?.otherDescription ??
      sh?.other_description ??
      ""
    ).trim();
  }

  React.useEffect(() => {
    const newDateOnly = toDateOnlyStr(templateDueDate);
    const prevDateOnly = prevTemplateDueDateRef.current;

    setStakeholders((prev) =>
      prev.map((r) => {
        if (!r.enabled) return r;
        const rowDateOnly = r.dueDate
          ? toDateOnlyStr(new Date(r.dueDate))
          : undefined;

        const shouldSet =
          !r.dueDate || (prevDateOnly && rowDateOnly === prevDateOnly);

        if (shouldSet && newDateOnly) {
          return { ...r, dueDate: isoFromDateOnlyStr(newDateOnly) };
        }
        return r;
      })
    );

    prevTemplateDueDateRef.current = newDateOnly;
  }, [templateDueDate]);

  function filterPersonas(
    all: IPersonaProps[] | undefined,
    filterText: string,
    selected?: IPersonaProps[]
  ): IPersonaProps[] {
    if (!all) return [];
    const search = (filterText || "").toLowerCase();
    const filtered = all.filter(
      (p) =>
        (p.text || "").toLowerCase().includes(search) ||
        (p.secondaryText || "").toLowerCase().includes(search)
    );
    if (selected && selected.length > 0) {
      const selectedKeys = new Set(selected.map((s) => String(s.key)));
      return filtered.filter((p) => !selectedKeys.has(String(p.key)));
    }
    return filtered;
  }

  function getInputOptions(
    showStandard: boolean,
    roundNumber: number,
    canUsePrevious: boolean
  ) {
    const base: IDropdownOption[] = [
      { key: "CollectInput", text: "Collect Input" }
    ];
    if (showStandard) {
      base.push({ key: "useStandardInput", text: "Use Standard Input" });
    }
    if (roundNumber > 1 && canUsePrevious) {
      base.push({
        key: "usePreviousRoundInput",
        text: "Use Previous Round Input"
      });
    }
    return base;
  }

  function sanitizeInputOption(
    current: InputOption | string | undefined,
    options: IDropdownOption[]
  ): InputOption {
    const allowed = new Set(options.map((o) => String(o.key)));
    if (current && allowed.has(String(current))) return current as InputOption;
    return (
      (options.find((o) => o.key === "CollectInput")?.key as InputOption) ??
      "CollectInput"
    );
  }

  function normalizeCountryName(raw: string | undefined | null): string {
    if (!raw) return "";
    return raw
      .replace(/\s*\([^)]*\)\s*$/, "")
      .trim()
      .toLowerCase();
  }

  async function ensureGroupUsersLoadedForRow(
    idx: number,
    row: StakeholderRow
  ) {
    if (
      (row.groupUsersPersona && row.groupUsersPersona.length > 0) ||
      !row.groups ||
      row.groups.length === 0
    )
      return;

    try {
      const ids = row.groups
        .map((g) => g.id)
        .filter((n) => typeof n === "number");
      if (ids.length === 0) return;
      const users = await getUsersFromGroups(ids);
      const personas = users.map(toPersona);
      setStakeholderRow(idx, {
        groupUsers: users,
        groupUsersPersona: personas
      });
    } catch (err: any) {
      setToast({
        severity: "error",
        text: `Group users load failed: ${err.message}`
      });
    }
  }

  async function loadStandardTemplatesForStakeholder(
    idx: number,
    stakeholderCode: string
  ) {
    try {
      const response = await api.getStandardReference(Number(id));
      const refList = Array.isArray(response) ? response : [];

      const filtered = refList.filter(
        (item: any) =>
          String(item.stakeholder).toLowerCase() ===
          String(stakeholderCode).toLowerCase()
      );

      const options = filtered.map((item: any) => ({
        id: item.id,
        title: item.title,
        stakeholder: item.stakeholder,
        versionNumber: item.versionNumber
      }));

      setStakeholderRow(idx, {
        standardOptions: options,
        standardSelectedKeys: [],
        standardOptionsLoaded: true,
        standardUnavailable: options.length === 0,
        standardOptionsError:
          options.length === 0 ? "No standard templates available." : null
      });
    } catch (e: any) {
      setStakeholderRow(idx, {
        standardOptionsLoaded: true,
        standardUnavailable: true,
        standardOptionsError: e.message,
        standardOptions: []
      });
    }
  }
  async function loadInputTemplateVersions(
    idx: number,
    stakeholderName: string
  ) {
    try {
      // console.log("Loading versions for:", stakeholderName);
      const ctx = (window as any).spfxContext;
      const endpoint =
        `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
        `?$select=Id,Title,VersionNumber,DraftApplicable,Active` +
        `&$filter=Title eq '${stakeholderName}'`;
      const res = await ctx.spHttpClient.get(
        endpoint,
        SPHttpClient.configurations.v1
      );
      if (!res.ok) {
        throw new Error(
          `InputTemplate GET failed: ${res.status}`
        );
      }
      const data = await res.json();

      const activeVersions = ((data.value || []) as StakeholderRow["inputTemplateVersions"])
        ?.filter(v => v.Active) ?? [];

      let selectedVersion = "";

      if (activeVersions.length === 1) {
        selectedVersion = activeVersions[0].VersionNumber;
      }
      // console.log("Fetched:", stakeholderName, activeVersions);

      // setStakeholderRow(idx, {
      //   inputTemplateVersions: activeVersions,
      //   commonVersionSelections:
      //     activeVersions.length === 1
      //       ? activeVersions[0].VersionNumber
      //       : ""
      // });

      setStakeholders(prev =>
        prev.map((r, i) => {
          if (i !== idx) return r;

          const copiedPreviousVersion =
            r.commonVersionSelections?.trim() || "";

          const previousVersionStillExists =
            copiedPreviousVersion &&
            activeVersions.some(
              v => v.VersionNumber === copiedPreviousVersion
            );

          const selectedVersion =
            previousVersionStillExists
              ? copiedPreviousVersion
              : activeVersions.length === 1
                ? activeVersions[0].VersionNumber
                : "";

          return {
            ...r,
            inputTemplateVersions: activeVersions,
            commonVersionSelections: selectedVersion
          };
        })
      );

      // console.log(
      //   "Setting version:",
      //   stakeholderName,
      //   activeVersions.length === 1
      //     ? activeVersions[0].VersionNumber
      //     : ""
      // );




    } catch (err) {
      console.error(err);

      setStakeholderRow(idx, {
        inputTemplateVersions: []
      });
    }
  }
  React.useEffect(() => {
    stakeholders.forEach((row, idx) => {
      if (
        row.enabled &&
        (!row.inputTemplateVersions ||
          row.inputTemplateVersions.length === 0)
      ) {
        loadInputTemplateVersions(
          idx,
          row.stakeholderName || ""
        );
      }
    });
  }, [stakeholders]);

  function canUsePreviousRoundForAdhoc(
    adhocCode: string,
    scenarioKey: ScenarioKey
  ): boolean {
    if (roundNumber <= 1) return false;

    const normalizedCode = normalizeAdhocCode(adhocCode);

    if (!normalizedCode) return false;

    return (prevRoundDetails?.inputs ?? []).some((inp: any) => {
      const previousCode = normalizeAdhocCode(
        inp.stakeholderCode ?? inp.stakeholder_code ?? inp.stakeholder
      );

      const previousScenario = norm(
        inp.scenarioName ?? inp.scenario
      );

      const status = norm(
        inp.workflowStatus ?? inp.status
      );

      return (
        previousCode === normalizedCode &&
        previousScenario === norm(scenarioKey) &&
        status === "approved"
      );
    });
  }

  function getPreviousRoundIdForAdhoc(
    adhocCode: string
  ): number | null {
    const normalizedCode = normalizeAdhocCode(adhocCode);

    const previousStakeholder = (prevRoundDetails?.stakeholders ?? []).find(
      (sh: any) =>
        normalizeAdhocCode(
          sh.stakeholderCode ??
          sh.stakeholder_code ??
          sh.stakeholder
        ) === normalizedCode
    );

    return previousStakeholder?.roundId ?? null;
  }
  function getPreviousAdhocTemplates(): PreviousRoundStakeholder[] {
    if (roundNumber <= 1) return [];

    return (prevRoundDetails?.stakeholders ?? []).filter((sh: any) => {
      return String(sh.stakeholderType ?? "").trim().toLowerCase() === "adhoc";
    });
  }
  function getPreviousAdhocTemplatesForCard(
    currentIndex: number
  ): PreviousRoundStakeholder[] {
    const previousTemplates = getPreviousAdhocTemplates();

    // Collect templates already selected by OTHER adhoc cards
    const selectedByOtherCards = new Set(
      adhocCards
        .filter((_, index) => index !== currentIndex)
        .filter(card => card.usePreviousRound && card.otherCode?.trim())
        .map(card => normalizeAdhocCode(card.otherCode))
    );

    return previousTemplates.filter(template => {
      const code = getPrevCode(template);
      const name = getPrevTitle(template);

      const normalizedCode = normalizeAdhocCode(code);
      const normalizedName = normalizeAdhocCode(name);

      // Remove if this previous template is already selected
      // in another adhoc card
      return (
        !selectedByOtherCards.has(normalizedCode) &&
        !selectedByOtherCards.has(normalizedName)
      );
    });
  }
  function buildApprovedScenarioMap(
    prevRoundDetails: PreviousRoundDetails | null
  ): Map<string, Set<ScenarioKey>> {
    const map = new Map<string, Set<ScenarioKey>>();

    if (!prevRoundDetails?.inputs || !prevRoundDetails.stakeholders) return map;

    const nameToCode = new Map<string, string>();
    prevRoundDetails.stakeholders.forEach(sh => {
      if (sh.stakeholder && sh.stakeholder_code) {
        nameToCode.set(norm(sh.stakeholder), norm(sh.stakeholder_code));
      }
    });
    prevRoundDetails.inputs.forEach(inp => {
      if (
        inp.workflowStatus === "Approved" &&
        inp.scenarioName &&
        inp.stakeholder
      ) {
        const code = inp.stakeholderCode
          ? norm(inp.stakeholderCode)
          : nameToCode.get(norm(inp.stakeholder));
        if (!code) return;

        if (!map.has(code)) {
          map.set(code, new Set());
        }

        map.get(code)!.add(inp.scenarioName as ScenarioKey);
      }
    });

    return map;
  }


  const validateStep1 = (): boolean => {
    if (!description.trim()) {
      setToast({
        severity: "error",
        text: "Please enter a description for the round."
      });
      return false;
    }
    if (!customerSubmissionDate) {
      setToast({
        severity: "error",
        text: "Please select a customer submission date."
      });
      return false;
    }


    // const today = new Date();
    // today.setHours(0, 0, 0, 0);
    // if (
    //   templateDueDate &&
    //   templateDueDate <= today
    // ) {
    //   setToast({
    //     severity: "error",
    //     text: "Input Due Date must be a future date."
    //   });
    //   return false;
    // }


    if (templateDueDate) {
      const inputDueDate = new Date(templateDueDate);
      inputDueDate.setHours(0, 0, 0, 0);

      if (inputDueDate < today) {
        setToast({
          severity: "error",
          text: "Input Due Date cannot be a past date."
        });
        return false;
      }
    }
    setToast(null);
    return true;
  };

  const validateStep2 = (): boolean => {
    if (scenarios.length === 0) {
      setToast({
        severity: "warning",
        text: "Please add at least one dataset."
      });
      return false;
    }
    const onlyOneScenario = scenarios.length === 1;
    if (!onlyOneScenario) {
      const missing = scenarios.some(
        (s) => !s.description || !s.description.trim()
      );
      if (missing) {
        setToast({
          severity: "error",
          text: "Please provide a description for every dataset."
        });
        return false;
      }
    }
    // Auto-select the single dataset for all enabled stakeholders before entering step 3
    if (scenarios.length === 1) {
      const onlyKey = scenarios[0].key;
      setStakeholders((prev) =>
        prev.map((row) => {
          if (!row.enabled) return row;
          if (row.applicableScenarios?.length > 0) return row; // already has selection
          return {
            ...row,
            applicableScenarios: [onlyKey],
            scenarioConfigs: {
              ...(row.scenarioConfigs || {}),
              [onlyKey]: row.scenarioConfigs?.[onlyKey] ?? {
                inputOption: undefined
              }
            }
          };
        })
      );
    }

    setToast(null);
    return true;
  };
  // function isDuplicateAdhocName(
  //   currentIndex: number,
  //   name: string
  // ): boolean {
  //   const normalized = name.trim().toLowerCase();

  //   if (!normalized) return false;

  //   return adhocCards.some(
  //     (card, index) =>
  //       index !== currentIndex &&
  //       (card.otherCode ?? "").trim().toLowerCase() === normalized
  //   );
  // }

  // function isExistingTemplateCode(name: string): boolean {
  //   const value = name.trim().toLowerCase();

  //   if (!value) return false;

  //   return existingTemplateCodes.includes(value);
  // }

  function normalizeAdhocCode(name?: string): string {
    return (name ?? "")
      .replace(/[^a-zA-Z0-9]/g, "")
      .toLowerCase();
  }

  function isDuplicateAdhocName(
    currentIndex: number,
    name: string
  ): boolean {
    const normalizedCode = normalizeAdhocCode(name);

    if (!normalizedCode) return false;

    return adhocCards.some(
      (card, index) =>
        index !== currentIndex &&
        normalizeAdhocCode(card.otherCode) === normalizedCode
    );
  }

  function isExistingTemplateCode(name: string): boolean {
    const normalizedCode = normalizeAdhocCode(name);

    if (!normalizedCode) return false;

    return existingTemplateCodes.some(
      code => normalizeAdhocCode(code) === normalizedCode
    );
  }



  const validateStep3 = (): boolean => {
    const enabledStakeholders = stakeholders.filter((s) => s.enabled);

    if (otherCard.enabled) {

      if (!otherCard.otherCode?.trim()) {
        setToast({
          severity: "error",
          text: "Please enter Code for Other."
        });
        return false;
      }

      if (!otherCard.dueDate) {
        setToast({
          severity: "error",
          text: "Please select Due Date for Other."
        });
        return false;
      }
    }
    // if (enabledStakeholders.length === 0) {
    //   setToast({
    //     severity: "warning",
    //     text: "Please enable at least one stakeholder."
    //   });
    //   return false;
    // }

    if (enabledStakeholders.length === 0 && adhocCards.length === 0) {
      setToast({
        severity: "warning",
        text: "Please enable at least one stakeholder or add at least one Adhoc Template."
      });
      return false;
    }

    for (const sh of enabledStakeholders) {
      if (!sh.applicableScenarios || sh.applicableScenarios.length === 0) {
        setToast({
          severity: "error",
          text: `Stakeholder "${sh.stakeholderName}" must select at least one applicable dataset.`
        });
        return false;
      }

      if (!sh.dueDate) {
        setToast({
          severity: "error",
          text: `Stakeholder "${sh.stakeholderName}" is missing Due Date.`
        });
        return false;
      }

      const dueDate = new Date(sh.dueDate);
      dueDate.setHours(0, 0, 0, 0);

      if (dueDate < today) {
        setToast({
          severity: "error",
          text: `Stakeholder "${sh.stakeholderName}": Due Date cannot be a past date.`
        });
        return false;
      }

      const configs = sh.scenarioConfigs || {};
      for (const sk of sh.applicableScenarios) {
        const cfg = configs[sk] || {};
        if (!cfg.inputOption) {
          setToast({
            severity: "error",
            text: `Stakeholder "${sh.stakeholderName}" • Dataset ${sk}: Please select an Input Type.`
          });
          return false;
        }
        if (cfg.inputOption === "CollectInput") {

          if (
            sh.collectDraftInput &&
            !sh.commonDraftDueDate
          ) {
            setToast({
              severity: "error",
              text: `Stakeholder "${sh.stakeholderName}": Please select Draft Due Date.`
            });
            return false;
          }
          if (sh.collectDraftInput && sh.commonDraftDueDate) {
            const draftDueDate = new Date(sh.commonDraftDueDate);
            draftDueDate.setHours(0, 0, 0, 0);

            // Draft Due Date cannot be a past date
            if (draftDueDate < today) {
              setToast({
                severity: "error",
                text: `Stakeholder "${sh.stakeholderName}": Draft Due Date cannot be a past date.`
              });
              return false;
            }

            // Draft Due Date must be earlier than Due Date
            if (sh.dueDate) {
              const dueDate = new Date(sh.dueDate);
              dueDate.setHours(0, 0, 0, 0);

              if (draftDueDate >= dueDate) {
                setToast({
                  severity: "error",
                  text: `Stakeholder "${sh.stakeholderName}": Draft Due Date must be earlier than Due Date.`
                });
                return false;
              }
            }
          }

        }

        if (cfg.inputOption === "useStandardInput") {
          if (!cfg.standardSelectedKey) {
            setToast({
              severity: "error",
              text: `Stakeholder "${sh.stakeholderName}" • Dataset ${sk}: Please select a Standard Template.`
            });
            return false;
          }
        } else if (cfg.inputOption === "CollectInput") {
          const hasNotify =
            sh.notifyUserPersonas && sh.notifyUserPersonas.length > 0;
          const hasAdditionalMembers =
            sh.additionalTeamPersonas && sh.additionalTeamPersonas.length > 0;

          if (!hasNotify && !hasAdditionalMembers) {
            setToast({
              severity: "error",
              text: `Stakeholder "${sh.stakeholderName}": Please select either:
                - At least one Stakeholder User OR
                - At least one Extra Input Provider`
            });
            return false;
          }
        } else if (cfg.inputOption === "usePreviousRoundInput") {
        }
      }
    }
    for (let index = 0; index < adhocCards.length; index++) {
      const card = adhocCards[index];

      if (!card.otherCode?.trim()) {
        setToast({
          severity: "error",
          text: "Please enter Name for Adhoc Template."
        });
        return false;
      }

      if (isDuplicateAdhocName(index, card.otherCode ?? "")) {
        setToast({
          severity: "error",
          text: `Adhoc Template "${card.otherCode}" already exists. Please enter a unique name.`
        });
        return false;
      }
      if (isExistingTemplateCode(card.otherCode ?? "")) {
        setToast({
          severity: "error",
          text: `Adhoc Template "${card.otherCode}" already exists as an Input Template Code. Please choose another name.`
        });
        return false;
      }

      if (!card.applicableScenarios?.length) {
        setToast({
          severity: "error",
          text: `Adhoc Template "${card.otherCode || "New"}" must select at least one Applicable Dataset.`
        });
        return false;
      }

      if (!card.dueDate) {
        setToast({
          severity: "error",
          text: `Adhoc Template "${card.otherCode || "New"}" is missing Due Date.`
        });
        return false;
      }

      if (
        !card.additionalTeamPersonas ||
        card.additionalTeamPersonas.length === 0
      ) {
        setToast({
          severity: "error",
          text: `Adhoc Template "${card.otherCode || "New"}": Please select at least one Team Member.`
        });
        return false;
      }
    }
    setToast(null);
    return true;
  };
  function buildGroupedScenariosForFlow(
    row: StakeholderRow,
    scenarios: Scenario[]
  ) {
    const collectInputDatasets: {
      scenarioKey: string;
      scenarioDescription: string;
    }[] = [];

    const otherScenarioBlocks: any[] = [];

    (row.applicableScenarios ?? []).forEach(sk => {
      const cfg = row.scenarioConfigs?.[sk];
      if (!cfg) return;

      const scenario = scenarios.find(s => s.key === sk);
      const stakeholderCode =
        row.stakeholderCode === "OTHER"
          ? (row.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "")
          : row.stakeholderCode ?? "";
      const versionNumber = row.commonVersionSelections ?? "";
      const submissionType =
        cfg.inputOption === "CollectInput" && row.collectDraftInput
          ? "Draft"
          : "Final";
      const revisionNumber = getLatestRevisionNumber(
        rounds,
        Number(id),
        stakeholderCode,
        sk,
        cfg.inputOption ?? "",
        versionNumber,
        submissionType
      );
      console.log("REVISION DEBUG", {
        stakeholderCode,
        dataset: sk,
        inputType: cfg.inputOption,
        versionNumber,
        submissionType,
        revisionNumber
      });

      const baseScenario = {
        scenarioKey: sk,
        scenarioDescription: scenario?.description ?? "",
        inputOption: cfg.inputOption,
        notifyUsers: [],
        additionalTeamMembers: [],
        standardReferenceId: null,
        // Sending Prev round details for adhoc
        isCopiedPreviousRound:
          cfg.inputOption === "usePreviousRoundInput",

        previousRoundId:
          cfg.inputOption === "usePreviousRoundInput"
            ? cfg.previousRoundId ?? null
            : null,
        versionNo: versionNumber,
        submissionType,
        revisionNumber
      };

      if (cfg.inputOption === "CollectInput") {
        collectInputDatasets.push({
          scenarioKey: sk,
          scenarioDescription: scenario?.description ?? ""
        });
        return;
      }

      if (cfg.inputOption === "usePreviousRoundInput") {
        otherScenarioBlocks.push(baseScenario);
        return;
      }

      if (cfg.inputOption === "useStandardInput") {

        const selectedStandard =
          (row.standardOptions ?? []).find(
            o => String(o.id) === String(cfg.standardSelectedKey)
          ) ?? null;

        otherScenarioBlocks.push({
          ...baseScenario,
          // standardReferenceId: cfg.standardReferenceId ?? null
          standardReferenceId:
            cfg.standardReferenceId ??
            (cfg.standardSelectedKey ? Number(cfg.standardSelectedKey) : null),
          ...(selectedStandard
            ? { standardInputTemplateTitle: selectedStandard.title }
            : {})

        });
      }
    });

    const result: any[] = [...otherScenarioBlocks];

    if (collectInputDatasets.length > 0) {
      result.push({
        Dataset: collectInputDatasets,
        inputOption: "CollectInput",
        notifyUsers: (row.notifyUserPersonas ?? []).map(p => ({
          id: `i:0#.f|membership|${p.secondaryText}`,
          displayName: p.text,
          email: p.secondaryText
        })),
        additionalTeamMembers: (row.additionalTeamPersonas ?? []).map(p => ({
          id: `i:0#.f|membership|${p.secondaryText}`,
          displayName: p.text,
          email: p.secondaryText
        })),
        standardReferenceId: null,

        versionNo: row.commonVersionSelections ?? "",
        submissionType: row.collectDraftInput
          ? "Draft"
          : "Final"
      });
    }

    return result;
  }

  async function onComplete() {
    try {
      if (saving) return;

      //console.log("OTHER CARD", otherCard);
      //console.log("STAKEHOLDERS", stakeholders);

      // console.log("OTHER CARD AT SUBMIT", {
      //   stakeholderCode: otherCard.stakeholderCode,
      //   otherCode: otherCard.otherCode
      // });

      setSaving(true);
      setToast(null);

      const roundIdFolder = `RND ${("" + roundNumber).slice(-2)}`;
      // const enabledStakeholders = stakeholders.filter(
      //   (row) => row.enabled === true
      // );

      // const enabledStakeholders = [
      //   ...stakeholders.filter(row => row.enabled === true),
      //   ...(otherCard.enabled ? [otherCard] : [])
      // ];

      //#region  apipayload
      const enabledStakeholders = [
        ...stakeholders.filter(row => row.enabled),
        ...adhocCards
      ];
      const stakeholdersForApi = enabledStakeholders.map((row) => {

        const isAdhoc = row.stakeholderCode === "OTHER";

        const stakeholderName = isAdhoc
          ? row.otherCode ?? ""
          : row.stakeholderName ?? "";

        const stakeholderCode = isAdhoc
          ? (row.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "")
          : row.stakeholderCode ?? "";
        const applicableScenarioObjs = row.applicableScenarios.map(
          (scenarioKey) => {
            const scenario = scenarios.find((s) => s.key === scenarioKey);
            const cfg = row.scenarioConfigs?.[scenarioKey] || {};

            let referenceDataValue = null;

            if (cfg.inputOption === "useStandardInput") {
              referenceDataValue = cfg.standardReferenceId ?? null;
            }

            if (cfg.inputOption === "usePreviousRoundInput") {
              referenceDataValue = cfg.previousRoundId ?? null;
            }

            return {
              name: scenarioKey,
              desc: scenario?.description ?? "",
              isStandardRate: cfg.inputOption === "useStandardInput",
              isCopiedPreviousRound:
                cfg.inputOption === "usePreviousRoundInput",
              referenceData: Number(referenceDataValue),
              input_type: cfg.inputOption
            };
          }
        );


        // const usesCollectInput = row.applicableScenarios.some(sk => {
        //   const cfg = row.scenarioConfigs?.[sk];
        //   return cfg?.inputOption === "CollectInput";
        // });

        const usesCollectInput =
          //isAdhoc ||
          row.applicableScenarios.some(sk => {
            const cfg = row.scenarioConfigs?.[sk];
            return cfg?.inputOption === "CollectInput";
          });

        const notifyUsers = usesCollectInput
          ? (row.notifyUserPersonas ?? []).map(p => {
            const email =
              typeof p.secondaryText === "string"
                ? p.secondaryText.replace(/^i:0#\.f\|membership\|/i, "")
                : "";

            const loginId =
              typeof p.tertiaryText === "string" && p.tertiaryText.trim()
                ? p.tertiaryText.replace(/^i:0#\.f\|membership\|/i, "")
                : null;

            return {
              name: p.text || email,
              email,
              login_id: loginId
            };
          })
          : [];

        const additionalStakeholders = usesCollectInput ? (row.additionalTeamPersonas ?? []).map(p => {
          const email =
            typeof p.secondaryText === "string"
              ? p.secondaryText.replace(/^i:0#\.f\|membership\|/i, "")
              : "";

          // const loginId =
          //   typeof p.id === "string" && p.id.trim()
          //     ? p.id.replace(/^i:0#\.f\|membership\|/i, "")
          //     : null;
          const loginId =
            typeof p.tertiaryText === "string" && p.tertiaryText.trim()
              ? p.tertiaryText.replace(/^i:0#\.f\|membership\|/i, "")
              : p.secondaryText ?? null;

          return {
            name: p.text || email,
            email,
            login_id: loginId
          };
        })
          : [];

        // return {
        //   stakeholder: row.stakeholderName,
        //   //stakeholder_code: row.stakeholderCode ?? "",
        //   stakeholder_code:
        //     row.stakeholderCode === "OTHER"
        //       ? row.otherCode ?? ""
        //       : row.stakeholderCode ?? "",
        //   additionalStakeholders: additionalStakeholders,
        //   applicableScenarios: applicableScenarioObjs,
        //   dueDate: row.dueDate,
        //   notify_users: notifyUsers
        // };
        return {
          stakeholder: stakeholderName,

          stakeholder_code: stakeholderCode,

          additionalStakeholders: additionalStakeholders,

          applicableScenarios: applicableScenarioObjs,

          dueDate: row.dueDate,

          notify_users: notifyUsers,
          description: row.otherDescription ?? "",

          ...(!isAdhoc && {
            versionNumber: row.commonVersionSelections ?? "",
            collectDraftInput: row.collectDraftInput ?? false,
            draftDueDate: row.commonDraftDueDate
              ? new Date(row.commonDraftDueDate).toISOString()
              : null
          }),

          stakeholderType: isAdhoc ? "Adhoc" : "Standard"
        };
      });

      const apiPayload = {
        opportunityId: Number(id),
        roundNumber: roundNumber,
        description: description || undefined,
        customerSubmissionDate: customerSubmissionDate?.toISOString(),
        inputDueDate: templateDueDate?.toISOString(),
        scenarioList: scenarios.map((s) => ({
          name: s.key,
          desc: s.description
        })),
        stakeholders: stakeholdersForApi
      };

      const created = await api.createRound(apiPayload);

      //#endregion apipayload

      //#region  FlowPayload
      const flowStakeholders = enabledStakeholders.map((row) => {

        const notifyEmails = (row.notifyUserPersonas ?? [])
          .map(p => (p.secondaryText || "").trim())
          .filter(Boolean);

        const additionalEmails = (row.additionalTeamPersonas ?? [])
          .map(p => (p.secondaryText || "").trim())
          .filter(Boolean);

        const NotifyUsersEmailString = Array.from(
          new Set([...notifyEmails, ...additionalEmails])
        ).join(";");


        const stName = row.stakeholderCode === "OTHER"
          ? row.otherCode ?? ""
          : row.stakeholderName ?? "";

        const stCode = row.stakeholderCode === "OTHER"
          ? (row.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "")
          : row.stakeholderCode ?? "";

        const stType = row.stakeholderCode === "OTHER"
          ? "Adhoc" : "Standard"


        return {
          stakeholderName: stName,
          dueDate: row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "",
          stakeholderCode: stCode,
          stakeholderType: stType,
          scenarios: buildGroupedScenariosForFlow(row, scenarios),
          InputTemplateGroupIds: (row.groups ?? []).map((g) => g.id),
          editFolderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${roundIdFolder}/${stCode}`,
          additionalTeamMembers: (row.additionalTeamPersonas ?? []).map(
            (p) => ({
              id: String(p.secondaryText || ""),
              displayName: String(p.text || ""),
              email: String(p.secondaryText || "")
            })
          ),
          NotifyUsersEmailString,
          versionNumber:
            row.commonVersionSelections ?? "",

          collectDraftInput:
            row.collectDraftInput ?? false,

          draftDueDate:
            row.commonDraftDueDate
              ? new Date(row.commonDraftDueDate).toLocaleDateString()
              : "",
          description: row.otherDescription ?? "",
        };
      });

      const flowPayload = {
        region: "EUR",
        customer: `${customer}`,
        fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
        opportunityName: `${opportunityName}`,
        opportunityCountryName: opportunityCountryName,
        description: description,
        customerSubmissionDate: customerSubmissionDate?.toLocaleDateString(),
        roundIdFolder: roundIdFolder,
        roundNumber: roundNumber,
        siteUrl: `${cfg.siteUrl}`,
        scenarios: scenarios.map((s) => ({
          key: s.key,
          description: s.description ?? ""
        })),
        stakeholders: flowStakeholders,
        inputDueDate: templateDueDate?.toLocaleDateString(),
        folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
        leadPricerEmailString: leadPricerEmail,
        bidTeamMembers: bidTeamEmail,
      };



      // console.log("RoundCreationFlow Payload", flowPayload);
      setPendingFlowPayload(flowPayload);
      setPendingCreatedRound(created);

      // Trigger Power Automate immediately
      triggerFlow(
        flowPayload,
        "RoundCreationFlow"
      ).catch((err) => {
        console.error("RoundCreationFlow failed:", err);
      });

      setFolderCreationDialogOpen(true);
      // await triggerFlow(flowPayload, "RoundCreationFlow");
      //triggerFlow(flowPayload, "RoundCreationFlow");

      // setToast({ severity: "success", text: "Round created & Flow executed." });
      //navigate(`/opportunities/${id}/rounds/${created.id}`);

      //#endregion
    } catch (err: any) {
      setToast({ severity: "error", text: `Error: ${err.message}` || "An unexpected error occurred while creating the round." });
    } finally {
      setSaving(false);
    }
  }
  const futureDueDate = React.useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 1);
    return d;
  }, []);


  const renderStep1 = () => (
    <Fade in timeout={500}>
      <Box>
        <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}>
          <InfoIcon sx={{ color: "primary.main" }} />
          <Box>
            <Typography variant="h6" fontWeight={600}>
              Round Details
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Provide basic information about this pricing round
            </Typography>
          </Box>
          <Box sx={{ flex: 1 }} />
          <ModernChip
            label={`Round #${roundNumber}`}
            colorVariant="primary"
            size="small"
          />
        </Box>
        <Divider sx={{ my: 2 }} />
        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
          <ModernTextField
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
            required
            placeholder="Enter a detailed description of this round..."
          />
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
              label="Customer Submission Date"
              value={customerSubmissionDate}
              onChange={(newValue) => setCustomerSubmissionDate(newValue)}
              slotProps={{
                textField: {
                  required: true,
                  fullWidth: true,
                  variant: "outlined"
                }
              }}
            />
          </LocalizationProvider>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
              label="Input Due Date"
              minDate={today}
              value={templateDueDate}
              onChange={(newValue) => setTemplateDueDate(newValue)}
              slotProps={{
                textField: {
                  required: false,
                  fullWidth: true,
                  variant: "outlined",
                  helperText:
                    "This date will prefill Due Date for all input templates. You can change per-row later."
                }
              }}
            />
          </LocalizationProvider>
        </Box>
        {/* {toast && (
          <Box sx={{ mt: 2 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )} */}
      </Box>
    </Fade>
  );

  const renderStep2 = () => {
    const hasRemovable = scenarios.some((s) => !s.readOnly);
    return (
      <Fade in timeout={500}>
        <ModernCard elevated sx={{ p: 0 }}>
          <Box
            sx={{
              mb: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between"
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <AssignmentIcon sx={{ color: "primary.main" }} />
              <Box>
                <Typography variant="h6" fontWeight={600}>
                  Define Datasets
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {roundNumber > 1
                    ? "Loaded from the previous round; you can add more (A–J)."
                    : "Add up to 10 datasets (A–J) for this round"}
                </Typography>
              </Box>
            </Box>
            <Box sx={{ display: "flex", gap: 1 }}>
              <Tooltip title="Add Dataset" arrow>
                <span>
                  <ModernButton
                    variant="gradient"
                    size="small"
                    startIcon={<AddIcon />}
                    onClick={addScenario}
                    disabled={scenarios.length >= 10}
                  >
                    Add
                  </ModernButton>
                </span>
              </Tooltip>
              <Tooltip title="Remove Last (new only)" arrow>
                <span>
                  <ModernButton
                    variant="outlined"
                    size="small"
                    startIcon={<RemoveIcon />}
                    onClick={removeLastScenario}
                    disabled={!hasRemovable}
                  >
                    Remove
                  </ModernButton>
                </span>
              </Tooltip>
            </Box>
          </Box>
          <Divider sx={{ my: 2 }} />
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 2
            }}
          >
            {scenarios.map((scenario) => (
              <Box key={scenario.key}>
                <ModernCard
                  hoverable
                  sx={{
                    border: "2px solid",
                    borderColor: "primary.light",
                    backgroundColor: "background.paper"
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                      mb: 2
                    }}
                  >
                    <ModernChip
                      label={`Dataset ${scenario.key}`}
                      colorVariant="primary"
                      size="small"
                    />
                    {scenario.readOnly && (
                      <ModernChip
                        label="Previous Round"
                        colorVariant="info"
                        size="small"
                      />
                    )}
                  </Box>
                  <ModernTextField
                    label="Description"
                    value={scenario.description}
                    onChange={(e) =>
                      updateScenarioDescription(scenario.key, e.target.value)
                    }
                    multiline
                    rows={3}
                    placeholder={`Describe dataset ${scenario.key}...`}
                    fullWidth
                  />
                </ModernCard>
              </Box>
            ))}
          </Box>
          {scenarios.length === 0 && (
            <Box sx={{ py: 8, textAlign: "center", color: "text.secondary" }}>
              <AssignmentIcon sx={{ fontSize: 48, mb: 2, opacity: 0.3 }} />
              <Typography>
                No datasets yet. Click "Add" to create your first dataset.
              </Typography>
            </Box>
          )}
          {/* {toast && (
            <Box sx={{ mt: 2 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )} */}
        </ModernCard>
      </Fade>
    );
  };

  const renderStep3 = () => (
    <Fade in timeout={500}>
      <Box>
        <ModernCard elevated>
          <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}>
            <PeopleIcon sx={{ color: "primary.main" }} />
            <Box>
              <Typography variant="h6" fontWeight={600}>
                Configure Input Templates
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Enable stakeholders, select applicable datasets first, then
                configure per-dataset input.
              </Typography>
            </Box>
          </Box>
          <Divider sx={{ my: 2 }} />
          <Stack spacing={2}>
            {stakeholders.map((row, idx) => {
              const showStandard = isStdTemplateAvailable(
                row.standardTemplateAvailable
              );
              const hasPrevDataForThisRow =
                roundNumber > 1 &&
                !!(prevRoundDetails?.stakeholders ?? []).find(
                  (sh) =>
                    norm(getPrevCode(sh)) === norm(row.stakeholderCode) ||
                    norm(getPrevTitle(sh)) === norm(row.stakeholderName)
                );

              const handleEnableToggle = async (checked: boolean) => {
                if (checked) {
                  await loadInputTemplateVersions(
                    idx,
                    row.stakeholderName || ""
                  );
                  const templateDateIso = templateDueDate
                    ? templateDueDate.toISOString()
                    : undefined;

                  const prevScenarios =
                    row.prevRoundSnapshot?.applicableScenarios ?? [];

                  const stakeholderKey = norm(row.stakeholderCode);
                  const approvedScenarios =
                    prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set();

                  const autoScenarios: ScenarioKey[] = prevScenarios.length
                    ? Array.from(
                      new Set([
                        ...prevScenarios,
                        ...scenarios.map((s) => s.key)
                      ])
                    )
                    : scenarios.length === 1
                      ? [scenarios[0].key]
                      : [];

                  const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

                  autoScenarios.forEach((k) => {
                    const existedBefore = prevScenarios.includes(k);
                    const approvedBefore = approvedScenarios.has(k);

                    // const canUsePrevious = existedBefore && approvedBefore;

                    // scenarioConfigs[k] = {
                    //   inputOption: canUsePrevious
                    //     ? "usePreviousRoundInput"
                    //     : "CollectInput",
                    //   notifyUserPersonas: canUsePrevious
                    //     ? row.prevRoundSnapshot?.notifyUserPersonas ?? []
                    //     : [],
                    //   standardSelectedKey: undefined,
                    //   standardReferenceId: null,
                    //   previousRoundId: canUsePrevious
                    //     ? row.prevRoundSnapshot?.referenceDataId ?? null
                    //     : null
                    // };

                    const canUsePrevious = existedBefore && approvedBefore;

                    scenarioConfigs[k] = canUsePrevious
                      ? {
                        inputOption: "usePreviousRoundInput",
                        notifyUserPersonas: row.prevRoundSnapshot?.notifyUserPersonas ?? [],
                        previousRoundId: row.prevRoundSnapshot?.referenceDataId ?? null,
                        standardSelectedKey: undefined,
                        standardReferenceId: null,
                        submissionTypes: ["Draft", "Final"]
                      }
                      : {
                        inputOption: "CollectInput",
                        notifyUserPersonas: [],
                        previousRoundId: null,
                        standardSelectedKey: undefined,
                        standardReferenceId: null,
                        submissionTypes: ["Draft", "Final"]
                      };
                  });

                  setStakeholderRow(idx, {
                    enabled: true,
                    applicableScenarios: autoScenarios,
                    scenarioConfigs,
                    dueDate: row.dueDate ?? templateDateIso,

                    // NEW COMMON FIELDS
                    // commonVersionSelections: "",
                    // collectDraftInput: false,
                    // commonDraftDueDate: null
                    collectDraftInput: row.collectDraftInput ?? false,
                    commonDraftDueDate: row.commonDraftDueDate ?? null,
                  });

                  if (row.groups) {
                    const ids = row.groups
                      .map((g) => g.id)
                      .filter((n) => typeof n === "number");
                    if (row.groupUsers && row.groupUsersPersona) {
                      setStakeholderRow(idx, {
                        notifyUserPersonas: row.notifyUserPersonas ?? []
                      });
                    } else if (ids.length > 0) {
                      try {
                        const users = await getUsersFromGroups(ids);
                        const personas = users.map(toPersona);
                        setStakeholderRow(idx, {
                          groupUsers: users,
                          groupUsersPersona: personas
                        });
                      } catch (err: any) {
                        setToast({
                          severity: "error",
                          text: `Group users load failed: ${err.message}`
                        });
                      }
                    }
                  }
                } else {

                  setStakeholderRow(idx, {
                    enabled: false,
                    applicableScenarios: [],
                    scenarioConfigs: {},
                    autoExpandedForNewScenarios: false,
                    notifyUserPersonas: [],
                    additionalTeamPersonas: [],

                    // NEW COMMON FIELDS
                    commonVersionSelections: "",
                    collectDraftInput: false,
                    commonDraftDueDate: null
                  });

                }
              };

              const setScenarioConfig = (
                scenarioKey: ScenarioKey,
                patch: Partial<ScenarioConfig>
              ) => {
                setStakeholderRow(idx, {
                  scenarioConfigs: {
                    ...(row.scenarioConfigs || {}),
                    [scenarioKey]: {
                      ...(row.scenarioConfigs?.[scenarioKey] || {}),
                      ...patch
                    }
                  }
                });
              };

              const ensureScenarioEntry = (scenarioKey: ScenarioKey) => {
                if (!row.scenarioConfigs?.[scenarioKey]) {
                  setScenarioConfig(scenarioKey, {
                    inputOption:
                      row.scenarioConfigs?.[scenarioKey]?.inputOption ||
                      "CollectInput",
                    notifyUserPersonas: [],
                    standardSelectedKey: undefined,
                    standardReferenceId: null
                  });
                }
              };

              const onApplicableScenariosChange = (value: any) => {
                const nextSelected: ScenarioKey[] =
                  typeof value === "string"
                    ? (value.split(",") as ScenarioKey[])
                    : (value as ScenarioKey[]);

                const newConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> =
                  {};

                nextSelected.forEach((k) => {
                  const existing = row.scenarioConfigs?.[k];

                  newConfigs[k] = existing ?? {
                    inputOption: "CollectInput",
                    notifyUserPersonas: [],
                    standardSelectedKey: undefined,
                    standardReferenceId: null,
                    submissionTypes: ["Draft", "Final"]
                  };
                });

                setStakeholderRow(idx, {
                  applicableScenarios: nextSelected,
                  scenarioConfigs: newConfigs
                });
              };
              const firstScenario = row.applicableScenarios?.[0];


              const versionsToShow = (row.inputTemplateVersions ?? []).filter(
                v => v.Active
              );

              const selectedVersion =
                versionsToShow.length === 1
                  ? versionsToShow[0]
                  : versionsToShow.find(
                    v => v.VersionNumber === row.commonVersionSelections
                  );

              const draftApplicable =
                selectedVersion?.DraftApplicable ?? false;

              return (
                <ModernCard
                  key={`${row.stakeholderCode ?? idx}`}
                  hoverable
                  sx={{
                    border: row.enabled ? "2px solid" : "1px solid",
                    borderColor: row.enabled ? "primary.main" : "divider",
                    opacity: row.enabled ? 1 : 0.7
                  }}
                >
                  <Box
                    sx={{ display: "flex", flexDirection: "column", gap: 2 }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between"
                      }}
                    >
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={row.enabled}
                            onChange={(e) =>
                              handleEnableToggle(e.target.checked)
                            }
                          />
                        }
                        label={
                          <Typography fontWeight={600}>
                            {row.stakeholderName}
                          </Typography>
                        }
                      />
                      {row.enabled && (
                        <Stack direction="row" spacing={1} alignItems="center">
                          <ModernChip
                            label="Enabled"
                            colorVariant="success"
                            size="small"
                          />
                        </Stack>
                      )}
                    </Box>
                    {row.enabled && (
                      <Box sx={{ pl: 4, mb: 2 }}>
                        <Stack spacing={2} sx={{ maxWidth: 420 }}>

                          {/* ---------- Version ---------- */}
                          {versionsToShow.length > 1 ? (
                            <FormControl fullWidth>
                              <InputLabel
                                shrink
                                sx={{
                                  backgroundColor: "#fff",
                                  px: 0.5
                                }}
                              >
                                Version
                              </InputLabel>

                              <Select
                                value={row.commonVersionSelections ?? ""}
                                // onChange={(e) => {
                                //   setStakeholderRow(idx, {
                                //     commonVersionSelections: e.target.value as string
                                //   });
                                // }}
                                onChange={(e) => {
                                  const selectedVersion =
                                    e.target.value as string;

                                  const updatedConfigs = {
                                    ...(row.scenarioConfigs || {})
                                  };

                                  Object.keys(updatedConfigs).forEach(key => {
                                    const cfg =
                                      updatedConfigs[key as ScenarioKey];

                                    if (cfg?.inputOption === "useStandardInput") {
                                      cfg.standardSelectedKey = undefined;
                                      cfg.standardReferenceId = null;
                                    }
                                  });

                                  setStakeholderRow(idx, {
                                    commonVersionSelections: selectedVersion,
                                    scenarioConfigs: updatedConfigs
                                  });
                                }}
                                sx={{
                                  height: 56,
                                  borderRadius: 1
                                }}
                              >
                                {versionsToShow.map((v) => (
                                  <MenuItem
                                    key={v.Id}
                                    value={v.VersionNumber}
                                  >
                                    {v.VersionNumber}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                          ) : (
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                                minHeight: 40
                              }}
                            >
                              <Typography
                                variant="body1"
                                fontWeight={600}
                                sx={{ minWidth: 80 }}
                              >
                                Version:
                              </Typography>

                              <Typography variant="body1">
                                {versionsToShow[0]?.VersionNumber ?? "-"}
                              </Typography>
                            </Box>
                          )}

                          {/* ---------- Collect Draft Input ---------- */}
                          {selectedVersion?.DraftApplicable && (
                            <FormControlLabel
                              sx={{
                                m: 0
                              }}
                              control={
                                <Checkbox
                                  checked={row.collectDraftInput ?? false}
                                  onChange={(event, checked) => {
                                    setStakeholderRow(idx, {
                                      collectDraftInput: checked,
                                      commonDraftDueDate: checked
                                        ? row.commonDraftDueDate
                                        : null
                                    });
                                  }}
                                />
                              }
                              label="Collect Draft Input"
                            />
                          )}

                          {/* ---------- Draft Due Date ---------- */}
                          {selectedVersion?.DraftApplicable &&
                            row.collectDraftInput && (
                              <LocalizationProvider dateAdapter={AdapterDateFns}>
                                <DatePicker
                                  label="Draft Due Date"
                                  minDate={today}
                                  value={row.commonDraftDueDate ?? null}
                                  // onChange={(date) => {
                                  //   setStakeholderRow(idx, {
                                  //     commonDraftDueDate: date
                                  //   });
                                  // }}

                                  onChange={(date) => {
                                    if (!date) {
                                      setStakeholderRow(idx, {
                                        commonDraftDueDate: null
                                      });

                                      setDraftDueDateError(prev => ({
                                        ...prev,
                                        [idx]: ""
                                      }));

                                      return;
                                    }

                                    const selectedDraftDate = new Date(date);
                                    selectedDraftDate.setHours(0, 0, 0, 0);

                                    // Draft Due Date cannot be in the past
                                    if (selectedDraftDate < today) {
                                      setDraftDueDateError(prev => ({
                                        ...prev,
                                        [idx]: "Draft Due Date cannot be a past date."
                                      }));
                                      return;
                                    }

                                    // Draft Due Date must be earlier than Due Date
                                    if (row.dueDate) {
                                      const dueDate = new Date(row.dueDate);
                                      dueDate.setHours(0, 0, 0, 0);

                                      if (selectedDraftDate >= dueDate) {
                                        setDraftDueDateError(prev => ({
                                          ...prev,
                                          [idx]: "Draft Due Date must be earlier than Due Date."
                                        }));
                                        return;
                                      }
                                    }

                                    // Valid date
                                    setDraftDueDateError(prev => ({
                                      ...prev,
                                      [idx]: ""
                                    }));

                                    setStakeholderRow(idx, {
                                      commonDraftDueDate: date
                                    });
                                  }}
                                  slotProps={{
                                    textField: {
                                      fullWidth: true,
                                      required: true,

                                      error: !!draftDueDateError[idx],

                                      helperText: draftDueDateError[idx] || "",

                                      InputLabelProps: {
                                        shrink: true
                                      },

                                      sx: {
                                        "& .MuiOutlinedInput-root": {
                                          height: 56,
                                          borderRadius: 1
                                        }
                                      }
                                    }
                                  }}
                                />
                              </LocalizationProvider>
                            )}

                        </Stack>
                      </Box>
                    )}


                    {row.enabled && (
                      <Box sx={{ pl: 4 }}>
                        <Box sx={{ mt: 1 }}>
                          <FormControl fullWidth required>
                            <InputLabel>Applicable Datasets</InputLabel>
                            <Select
                              multiple
                              value={row.applicableScenarios}
                              onChange={(e) =>
                                onApplicableScenariosChange(e.target.value)
                              }
                              label="Applicable Datasets"
                              renderValue={(selected) => (
                                <Box
                                  sx={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    gap: 0.5
                                  }}
                                >
                                  {(selected as ScenarioKey[]).map((key) => {
                                    const dataset = scenarios.find((s) => s.key === key);

                                    return (
                                      <Chip
                                        key={key}
                                        size="small"
                                        label={
                                          key
                                        }
                                      />
                                    );
                                  })}
                                </Box>
                              )}
                            >

                              {scenarios.map((s) => {
                                const MAX_DESC_LENGTH = 40;

                                const shortDesc =
                                  s.description.length > MAX_DESC_LENGTH
                                    ? s.description.substring(0, MAX_DESC_LENGTH) + "..."
                                    : s.description;

                                return (
                                  <MenuItem key={s.key} value={s.key}>
                                    <Typography variant="body2">
                                      <strong>{s.key}</strong>
                                      {s.description ? ` - ${shortDesc}` : ""}
                                    </Typography>
                                  </MenuItem>
                                );
                              })}
                            </Select>
                            {!row.applicableScenarios?.length && (
                              <Typography
                                variant="caption"
                                color="error"
                                sx={{ mt: 0.5, display: "block" }}
                              >
                                Required: select at least one dataset.
                              </Typography>
                            )}
                          </FormControl>
                        </Box>

                        <Box
                          sx={{
                            mt: 2,
                            display: "flex",
                            flexDirection: "column",
                            gap: 2
                          }}
                        >
                          {row.applicableScenarios.map((sk) => {

                            const cfg = row.scenarioConfigs?.[sk] || {};
                            const isCollectInput =
                              cfg.inputOption === "CollectInput";

                            const stakeholderKey = norm(row.stakeholderCode);
                            // const approvedScenarios =
                            //   prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set<ScenarioKey>();

                            // const canUsePreviousForScenario = approvedScenarios.has(sk);

                            const approvedScenarios =
                              prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set<ScenarioKey>();

                            const previousVersion =
                              prevRoundVersionMap.get(stakeholderKey);

                            const currentVersion =
                              row.commonVersionSelections ||
                              row.inputTemplateVersions?.[0]?.VersionNumber ||
                              "";

                            const canUsePreviousForScenario =
                              approvedScenarios.has(sk) &&
                              previousVersion === currentVersion;

                            const rowInputOptions = getInputOptions(
                              showStandard,
                              roundNumber,
                              canUsePreviousForScenario
                            );

                            // const selectedInput: InputOption =
                            //   cfg.inputOption != null
                            //     ? (cfg.inputOption as InputOption)
                            //     : sanitizeInputOption(undefined, rowInputOptions)
                            const selectedInput: InputOption =
                              cfg.inputOption &&
                                rowInputOptions.some(
                                  option => String(option.key) === String(cfg.inputOption)
                                )
                                ? (cfg.inputOption as InputOption)
                                : "CollectInput";


                            const selectedIsStandard =
                              selectedInput === "useStandardInput";
                            const selectedIsCopy =
                              selectedInput === "usePreviousRoundInput";

                            return (
                              <Box
                                key={`${row.stakeholderCode ?? idx}-${sk}`}
                                sx={{
                                  p: 2,
                                  borderRadius: 2,
                                  backgroundColor: "background.default",
                                  border: "1px dashed",
                                  borderColor: "divider"
                                }}
                              >
                                <Box
                                  sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1,
                                    flexWrap: "wrap",
                                    mb: 1
                                  }}
                                >
                                  <Typography variant="subtitle2" fontWeight={600}>
                                    Dataset {sk} -
                                  </Typography>

                                  {(() => {
                                    const dataset = scenarios.find((s) => s.key === sk);
                                    const desc = dataset?.description || "";

                                    const isExpanded = expandedDescriptions[sk];

                                    const shortText =
                                      desc.length > 160
                                        ? desc.substring(0, 160) + "..."
                                        : desc;

                                    return (
                                      <>
                                        <Typography
                                          variant="body2"
                                          color="text.secondary"
                                          sx={{
                                            display: "inline",
                                            lineHeight: 1.6
                                          }}
                                        >
                                          {isExpanded ? desc : shortText}

                                          {desc.length > 160 && (
                                            <Box
                                              component="span"
                                              sx={{
                                                color: "primary.main",
                                                cursor: "pointer",
                                                fontWeight: 600,
                                                ml: 0.5
                                              }}
                                              onClick={() =>
                                                setExpandedDescriptions((prev) => ({
                                                  ...prev,
                                                  [sk]: !prev[sk]
                                                }))
                                              }
                                            >
                                              {isExpanded ? "Read Less" : "Read More"}
                                            </Box>
                                          )}
                                        </Typography>
                                      </>
                                    );
                                  })()}
                                </Box>

                                <Box
                                  sx={{
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: 2
                                  }}
                                >
                                  <Box
                                    sx={{
                                      display: "grid",
                                      gridTemplateColumns: {
                                        xs: "1fr",
                                        //      md: "repeat(3, minmax(180px, 1fr))"
                                        sm: "1fr 1fr"
                                      },
                                      gap: 2,
                                      width: "100%",
                                      alignItems: "start"
                                    }}
                                  >
                                    <FormControl fullWidth required sx={{
                                      minWidth: 0
                                    }}>
                                      <InputLabel>Input Type</InputLabel>
                                      <Select
                                        value={selectedInput}
                                        sx={{
                                          minWidth: 0,
                                          width: "100%"
                                        }}
                                        onChange={async (e) => {
                                          const v = e.target.value as InputOption;
                                          const sanitized = sanitizeInputOption(v, rowInputOptions);

                                          ensureScenarioEntry(sk);

                                          if (sanitized === "CollectInput") {
                                            await ensureGroupUsersLoadedForRow(idx, row);

                                            setScenarioConfig(sk, {
                                              inputOption: "CollectInput",
                                              notifyUserPersonas: cfg.notifyUserPersonas ?? [],
                                              previousRoundId: null,
                                              standardSelectedKey: undefined,
                                              standardReferenceId: null,
                                              submissionTypes: ["Draft", "Final"]
                                            });

                                            return;
                                          }

                                          if (sanitized === "usePreviousRoundInput") {
                                            setScenarioConfig(sk, {
                                              inputOption: "usePreviousRoundInput",
                                              notifyUserPersonas:
                                                row.prevRoundSnapshot?.notifyUserPersonas ?? [],
                                              previousRoundId:
                                                row.prevRoundSnapshot?.referenceDataId ?? null,
                                              standardSelectedKey: undefined,
                                              standardReferenceId: null
                                            });

                                            return;
                                          }

                                          if (sanitized === "useStandardInput") {
                                            if (!row.standardOptionsLoaded) {
                                              await loadStandardTemplatesForStakeholder(
                                                idx,
                                                row.stakeholderCode || ""
                                              );
                                            }

                                            setScenarioConfig(sk, {
                                              inputOption: "useStandardInput",
                                              notifyUserPersonas: [],
                                              standardSelectedKey: undefined,
                                              standardReferenceId: null,
                                              previousRoundId: null
                                            });

                                            return;
                                          }
                                        }}
                                        label="Input Type"
                                      >
                                        {rowInputOptions.map((opt) => (
                                          <MenuItem
                                            key={String(opt.key)}
                                            value={String(opt.key)}
                                          >
                                            {opt.text}
                                          </MenuItem>
                                        ))}
                                      </Select>
                                    </FormControl>

                                  </Box>

                                  {selectedIsStandard && (
                                    <Box
                                      sx={{
                                        gridColumn: { xs: "auto", sm: "1 / -1" }
                                      }}
                                    >
                                      <FormControl fullWidth required>
                                        <InputLabel>
                                          Standard Template
                                        </InputLabel>
                                        <Select
                                          value={cfg.standardSelectedKey || ""}
                                          onChange={(e) => {
                                            const selectedKey = e.target
                                              .value as string;
                                            setScenarioConfig(sk, {
                                              standardSelectedKey: selectedKey,
                                              standardReferenceId:
                                                Number(selectedKey)
                                            });
                                          }}
                                          label="Standard Template"
                                          disabled={
                                            row.standardUnavailable ||
                                            row.standardOptionsLoading
                                          }
                                        >
                                          {(row.standardOptions ?? [])
                                            .filter(
                                              opt =>
                                                opt.versionNumber ===
                                                row.commonVersionSelections
                                            )
                                            .map(opt => (
                                              <MenuItem
                                                key={opt.id}
                                                value={String(opt.id)}
                                              >
                                                {opt.title}
                                              </MenuItem>
                                            ))}
                                        </Select>
                                        <Typography
                                          variant="caption"
                                          color={
                                            row.standardUnavailable
                                              ? "error"
                                              : "text.secondary"
                                          }
                                          sx={{ mt: 0.5, display: "block" }}
                                        >
                                          {row.standardOptionsLoading
                                            ? "Loading standard templates..."
                                            : row.standardUnavailable
                                              ? "No validated standard templates found."
                                              : row.standardOptionsError
                                                ? row.standardOptionsError
                                                : (row.standardOptions ?? [])
                                                  .length === 0
                                                  ? "No validated standard templates found."
                                                  : "Select validated standard template."}
                                        </Typography>
                                      </FormControl>
                                    </Box>
                                  )}
                                </Box>
                              </Box>
                            );
                          })}
                        </Box>

                        <Box sx={{ gridColumn: { xs: "auto", sm: "1 / -1" }, mt: 2 }}>
                          <LocalizationProvider dateAdapter={AdapterDateFns}>
                            <DatePicker
                              label="Due Date"
                              minDate={today}
                              value={row.dueDate ? new Date(row.dueDate) : null}
                              // onChange={(newValue) =>
                              //   setStakeholderRow(idx, {
                              //     dueDate: newValue?.toISOString()
                              //   })
                              // }
                              onChange={(newValue) => {
                                if (!newValue) {
                                  setStakeholderRow(idx, {
                                    dueDate: undefined
                                  });
                                  return;
                                }

                                const selectedDueDate = new Date(newValue);
                                selectedDueDate.setHours(0, 0, 0, 0);

                                // Rule 1: Due Date cannot be past
                                if (selectedDueDate < today) {
                                  setToast({
                                    severity: "error",
                                    text: `Stakeholder "${row.stakeholderName}": Due Date cannot be a past date.`
                                  });
                                  return;
                                }

                                // Rule 2: Draft Due Date must be earlier than Due Date
                                if (row.commonDraftDueDate) {
                                  const draftDueDate = new Date(row.commonDraftDueDate);
                                  draftDueDate.setHours(0, 0, 0, 0);

                                  if (draftDueDate >= selectedDueDate) {
                                    setToast({
                                      severity: "error",
                                      text: `Stakeholder "${row.stakeholderName}": Draft Due Date must be earlier than Due Date.`
                                    });
                                    return;
                                  }
                                }

                                setToast(null);

                                setStakeholderRow(idx, {
                                  dueDate: newValue.toISOString()
                                });
                              }}
                              slotProps={{
                                textField: {
                                  required: true,
                                  fullWidth: true,
                                  variant: "outlined"
                                }
                              }}
                            />
                          </LocalizationProvider>

                          {row.applicableScenarios.some((sk) => {
                            const c = row.scenarioConfigs?.[sk] || {};
                            return (
                              c.inputOption === "CollectInput" || !c.inputOption
                            );
                          }) && (
                              <Box sx={{ mt: 2 }}>
                                <Autocomplete
                                  multiple
                                  options={row.groupUsersPersona ?? []}
                                  getOptionLabel={(o) => o.text || ""}
                                  value={row.notifyUserPersonas || []}
                                  onOpen={async () => {
                                    await ensureGroupUsersLoadedForRow(idx, row);
                                  }}
                                  onChange={(_, items) => {
                                    const unique = items.filter(
                                      (p, i, arr) =>
                                        arr.findIndex(
                                          (x) => String(x.key) === String(p.key)
                                        ) === i
                                    );
                                    setStakeholderRow(idx, {
                                      notifyUserPersonas: unique
                                    });
                                  }}
                                  renderTags={(value, getTagProps) =>
                                    value.map((option, index) => {
                                      const tagProps = getTagProps({ index });
                                      return (
                                        <Chip
                                          key={String(option.key)}
                                          className={tagProps.className}
                                          disabled={tagProps.disabled}
                                          onDelete={tagProps.onDelete}
                                          label={
                                            option.text || option.secondaryText
                                          }
                                          size="small"
                                        />
                                      );
                                    })
                                  }
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      label="Stakeholder Users"
                                      error={
                                        !row.notifyUserPersonas ||
                                        row.notifyUserPersonas.length === 0
                                      }

                                      helperText={
                                        (row.additionalTeamPersonas?.length ??
                                          0) > 0
                                          ? undefined
                                          : !row.notifyUserPersonas ||
                                            row.notifyUserPersonas.length === 0
                                            ? "Required unless you add at least one Extra Input Provider"
                                            : undefined
                                      }
                                    />
                                  )}
                                />

                                <Box sx={{ position: "relative", mt: 2 }}>
                                  <Box
                                    sx={{
                                      border: "1px solid rgba(0, 0, 0, 0.23)",
                                      borderRadius: 1,
                                      px: 1.75,
                                      pt: 1.5,
                                      pb: 0.75,
                                      "&:hover": {
                                        borderColor: "rgba(0, 0, 0, 0.87)"
                                      },
                                      "& .ms-BasePicker-text": {
                                        border: "none !important",
                                        "&::after": { display: "none !important" }
                                      }
                                    }}
                                  >
                                    <Typography
                                      variant="caption"
                                      sx={{
                                        position: "absolute",
                                        top: -9,
                                        left: 10,
                                        px: 0.5,
                                        backgroundColor: "background.paper",
                                        color: "rgba(0, 0, 0, 0.6)",
                                        fontSize: "0.75rem",
                                        lineHeight: 1,
                                        pointerEvents: "none"
                                      }}
                                    >
                                      Extra Input Provider
                                    </Typography>
                                    <PeoplePicker
                                      key={row.peoplePickerResetKey ?? 0}
                                      context={peoplePickerContext as any}
                                      personSelectionLimit={100}
                                      principalTypes={[PrincipalType.User]}
                                      showtooltip={true}
                                      resolveDelay={500}
                                      onChange={(items: IPersonaProps[] = []) => {
                                        setStakeholderRow(idx, {
                                          additionalTeamPersonas: items
                                        });
                                      }}
                                      styles={{
                                        root: { width: "100%" },
                                        input: { fontSize: "14px", padding: 0 }
                                      }}
                                    />
                                  </Box>
                                </Box>
                              </Box>
                            )}
                        </Box>
                      </Box>
                    )}
                  </Box>
                </ModernCard>
              );
            })}

            {/* Add Adhoc Template  */}

            {/* Adhoc Template Card */}
            {adhocCards.map((row, index) => {

              const sanitizedName = (row.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "");

              return (

                <ModernCard
                  key={index}
                  sx={{ mt: 2 }}
                >
                  {/* Header */}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      mb: 3
                    }}
                  >
                    <Typography variant="h6" fontWeight={600}>
                      {row.otherCode?.trim()
                        ? row.otherCode
                        : "Adhoc Template"}
                    </Typography>

                    <IconButton
                      color="error"
                      onClick={() =>
                        setAdhocCards(prev =>
                          prev.filter((_, i) => i !== index)
                        )
                      }
                    >
                      <CloseIcon />
                    </IconButton>
                  </Box>

                  {/* Use Previous Round */}
                  <Box sx={{ mb: 2 }}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={row.usePreviousRound ?? false}
                          disabled={roundNumber <= 1}
                          onChange={(e) => {
                            const checked = e.target.checked;

                            updateAdhocCard(index, {
                              usePreviousRound: checked,
                              otherCode: checked ? "" : row.otherCode
                            });
                          }}
                        />
                      }
                      label="Use Previous Round"
                    />
                  </Box>
                  {/* Name */}
                  {/* <Box sx={{ mb: 3 }}>
                    <TextField
                      fullWidth
                      label="Name"
                      value={row.otherCode ?? ""}
                      onChange={(e) =>
                        updateAdhocCard(index, {
                          otherCode: e.target.value.replace(/[^a-zA-Z0-9 ]/g, "")
                        })
                      }
                      error={
                        isDuplicateAdhocName(index, row.otherCode ?? "") ||
                        isExistingTemplateCode(row.otherCode ?? "")
                      }
                      helperText={
                        isDuplicateAdhocName(index, row.otherCode ?? "")
                          ? "Adhoc Template name already exists."
                          : isExistingTemplateCode(row.otherCode ?? "")
                            ? "This name matches an existing Input Template Code."
                            : ""
                      }
                    />

                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        mt: 0.5,
                        mb: 2
                      }}
                    >
                      <Typography
                        variant="caption"
                        sx={{
                          color: "primary.main",
                          fontWeight: 600
                        }}
                      >
                        Code : {sanitizedName}
                      </Typography>
                    </Box>

                    <ModernTextField
                      label="Description"
                      multiline
                      rows={3}
                      fullWidth
                      value={row.otherDescription ?? ""}
                      onChange={(e) =>
                        updateAdhocCard(index, {
                          otherDescription: e.target.value
                        })
                      }
                    />
                  </Box> */}

                  <Box sx={{ mb: 3 }}>
                    {!row.usePreviousRound ? (
                      <>
                        <TextField
                          fullWidth
                          label="Name"
                          value={row.otherCode ?? ""}
                          onChange={(e) =>
                            updateAdhocCard(index, {
                              otherCode: e.target.value.replace(/[^a-zA-Z0-9 ]/g, "")
                            })
                          }
                          error={
                            isDuplicateAdhocName(index, row.otherCode ?? "") ||
                            isExistingTemplateCode(row.otherCode ?? "")
                          }
                          helperText={
                            isDuplicateAdhocName(index, row.otherCode ?? "")
                              ? "Adhoc Template name already exists."
                              : isExistingTemplateCode(row.otherCode ?? "")
                                ? "This name matches an existing Input Template Code."
                                : ""
                          }
                        />
                      </>
                    ) : (
                      <FormControl fullWidth required>
                        <InputLabel id={`previous-adhoc-label-${index}`}>
                          Previous Round Adhoc Template
                        </InputLabel>

                        <Select
                          labelId={`previous-adhoc-label-${index}`}
                          label="Previous Round Adhoc Template"
                          value={row.otherCode ?? ""}
                          onChange={(e) => {
                            const selectedCode = String(e.target.value);

                            // const previousTemplate = getPreviousAdhocTemplates().find(
                            const previousTemplate = getPreviousAdhocTemplatesForCard(index).find(
                              (template) =>
                                normalizeAdhocCode(
                                  getPrevCode(template) || getPrevTitle(template)
                                ) === normalizeAdhocCode(selectedCode)
                            );

                            if (!previousTemplate) {
                              return;
                            }

                            updateAdhocCard(index, {
                              otherCode:
                                getPrevTitle(previousTemplate) ||
                                getPrevCode(previousTemplate),

                              // otherDescription:
                              //   (previousTemplate as any).description ??
                              //   (previousTemplate as any).otherDescription ??
                              //   "",
                              otherDescription: getPreviousAdhocDescription(previousTemplate),

                              dueDate:
                                previousTemplate.dueDate ??
                                (templateDueDate
                                  ? templateDueDate.toISOString()
                                  : undefined)
                            });
                          }}
                        >
                          {/* {getPreviousAdhocTemplates().map((template) => { */}
                          {getPreviousAdhocTemplatesForCard(index).map((template) => {
                            const code = getPrevCode(template);
                            const name = getPrevTitle(template);

                            return (
                              <MenuItem
                                key={`${template.roundId}-${code || name}`}
                                value={code || name}
                              >
                                {name || code}
                              </MenuItem>
                            );
                          })}
                        </Select>
                      </FormControl>
                    )}

                    {!row.usePreviousRound && (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "flex-end",
                          mt: 0.5,
                          mb: 2
                        }}
                      >
                        <Typography
                          variant="caption"
                          sx={{
                            color: "primary.main",
                            fontWeight: 600
                          }}
                        >
                          Code : {sanitizedName}
                        </Typography>
                      </Box>
                    )}

                    <ModernTextField
                      label="Description"
                      multiline
                      rows={3}
                      fullWidth
                      value={row.otherDescription ?? ""}
                      onChange={(e) =>
                        updateAdhocCard(index, {
                          otherDescription: e.target.value
                        })
                      }
                    />
                  </Box>
                  {/*Adhoc Applicable Datasets */}
                  <Box sx={{ mb: 3 }}>
                    <Autocomplete
                      multiple
                      disableCloseOnSelect
                      options={scenarios}
                      getOptionLabel={(option) => {
                        const MAX_DESC_LENGTH = 40;

                        const shortDesc =
                          option.description && option.description.length > MAX_DESC_LENGTH
                            ? option.description.substring(0, MAX_DESC_LENGTH) + "..."
                            : option.description;

                        return `${option.key}${shortDesc ? ` - ${shortDesc}` : ""}`;
                      }}
                      value={scenarios.filter((s) =>
                        row.applicableScenarios.includes(s.key)
                      )}
                      onChange={(_, values) => {

                        const selected = values.map(v => v.key);

                        const scenarioConfigs = {
                          ...(row.scenarioConfigs ?? {})
                        };

                        selected.forEach(key => {
                          if (!scenarioConfigs[key]) {
                            scenarioConfigs[key] = {
                              inputOption: "CollectInput",
                              previousRoundId: null
                            };
                          }
                        });

                        Object.keys(scenarioConfigs).forEach(key => {
                          if (!selected.includes(key as ScenarioKey)) {
                            delete scenarioConfigs[key as ScenarioKey];
                          }
                        });

                        updateAdhocCard(index, {
                          applicableScenarios: selected,
                          scenarioConfigs
                        });
                      }}
                      isOptionEqualToValue={(option, value) =>
                        option.key === value.key
                      }
                      renderTags={(value) =>
                        value.map((option) => (
                          <Chip
                            key={option.key}
                            label={option.key}
                            //label={`${option.key}${option.description ? ` - ${option.description}` : ""}`}
                            size="small"
                            sx={{
                              borderRadius: "8px",
                              fontWeight: 600,
                              height: 28,
                              mr: 0.75,
                              mb: 0.5
                            }}
                          />
                        ))
                      }
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Applicable Datasets"
                          required
                          InputLabelProps={{
                            ...params.InputLabelProps,
                            shrink: true
                          }}
                        />
                      )}
                    />
                  </Box>
                  {/* Adhoc Input Type */}
                  {row.applicableScenarios.map((sk) => {
                    const cfg = row.scenarioConfigs?.[sk];

                    const canUsePrevious = canUsePreviousRoundForAdhoc(
                      row.otherCode ?? "",
                      sk
                    );

                    const inputOptions: IDropdownOption[] = [
                      {
                        key: "CollectInput",
                        text: "Collect Input"
                      },
                      ...(canUsePrevious
                        ? [
                          {
                            key: "usePreviousRoundInput",
                            text: "Use Previous Round Input"
                          }
                        ]
                        : [])
                    ];

                    const selectedInput =
                      cfg?.inputOption &&
                        inputOptions.some(
                          option => String(option.key) === String(cfg.inputOption)
                        )
                        ? String(cfg.inputOption)
                        : "CollectInput";

                    return (
                      <Box key={`adhoc-input-${index}-${sk}`} sx={{ mb: 2 }}>
                        <FormControl fullWidth required>
                          <InputLabel>Dataset {sk} - Input Type</InputLabel>

                          <Select
                            value={selectedInput}
                            label={`Dataset ${sk} - Input Type`}
                            onChange={(e) => {
                              const value = e.target.value as InputOption;

                              if (value === "usePreviousRoundInput") {
                                updateAdhocCard(index, {
                                  scenarioConfigs: {
                                    ...(row.scenarioConfigs ?? {}),
                                    [sk]: {
                                      ...(row.scenarioConfigs?.[sk] ?? {}),
                                      inputOption: "usePreviousRoundInput",
                                      previousRoundId:
                                        getPreviousRoundIdForAdhoc(row.otherCode ?? "")
                                    }
                                  }
                                });

                                return;
                              }

                              updateAdhocCard(index, {
                                scenarioConfigs: {
                                  ...(row.scenarioConfigs ?? {}),
                                  [sk]: {
                                    ...(row.scenarioConfigs?.[sk] ?? {}),
                                    inputOption: "CollectInput",
                                    previousRoundId: null
                                  }
                                }
                              });
                            }}
                          >
                            {inputOptions.map((option) => (
                              <MenuItem
                                key={String(option.key)}
                                value={String(option.key)}
                              >
                                {option.text}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Box>
                    );
                  })}
                  {/* Due Date */}
                  <Box sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DatePicker
                        label="Due Date"
                        minDate={futureDueDate}
                        value={row.dueDate ? new Date(row.dueDate) : null}
                        onChange={(value) =>
                          updateAdhocCard(index, {
                            dueDate: value
                              ? value.toISOString()
                              : undefined
                          })
                        }
                        slotProps={{
                          textField: {
                            fullWidth: true,
                            required: true
                          }
                        }}
                      />
                    </LocalizationProvider>
                  </Box>

                  {/* TEAM MEMBERS */}
                  <Box sx={{ position: "relative", mt: 3 }}>
                    <Box
                      sx={{
                        border: "1px solid rgba(0, 0, 0, 0.23)",
                        borderRadius: 1,
                        px: 1.75,
                        pt: 1.5,
                        pb: 0.75,
                        "&:hover": {
                          borderColor: "rgba(0, 0, 0, 0.87)"
                        },
                        "& .ms-BasePicker-text": {
                          border: "none !important",
                          "&::after": {
                            display: "none !important"
                          }
                        }
                      }}
                    >
                      <Typography
                        variant="caption"
                        sx={{
                          position: "absolute",
                          top: -9,
                          left: 10,
                          px: 0.5,
                          backgroundColor: "background.paper",
                          color: "rgba(0, 0, 0, 0.6)",
                          fontSize: "0.75rem",
                          lineHeight: 1,
                          pointerEvents: "none"
                        }}
                      >
                        Team Members{" "}
                        <span style={{ color: "#d32f2f" }}>*</span>
                      </Typography>

                      <PeoplePicker
                        context={peoplePickerContext as any}
                        personSelectionLimit={20}
                        principalTypes={[PrincipalType.User]}
                        ensureUser={true}
                        resolveDelay={500}
                        onChange={(items: any[]) => {
                          updateAdhocCard(index, {
                            additionalTeamPersonas: items.map((p: any) => ({
                              key: p.id || p.loginName,
                              text: p.text,
                              secondaryText: p.secondaryText,
                              tertiaryText: p.loginName
                            }))
                          });
                        }}
                      />
                    </Box>
                  </Box>

                </ModernCard>
              );
            })}
            {/* Add Adhoc Template Button */}

            <Box
              sx={{
                display: "flex",
                justifyContent: "flex-end",
                mb: 2
              }}
            >
              <ModernButton
                variant="gradient"
                startIcon={<AddIcon />}
                onClick={addAdhocTemplate}
              >
                Add Adhoc Template
              </ModernButton>
            </Box>






          </Stack>
          {stakeholders.length === 0 && (
            <Box sx={{ py: 8, textAlign: "center", color: "text.secondary" }}>
              <PeopleIcon sx={{ fontSize: 48, mb: 2, opacity: 0.3 }} />
              <Typography>No stakeholders loaded from SharePoint.</Typography>
            </Box>
          )}
        </ModernCard>
        {/* {
          toast && (
            <Box sx={{ mt: 2 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )
        } */}
      </Box >
    </Fade >
  );


  const renderStep4 = () => {
    //console.log("REVIEW PAGE");

    //console.log("OTHER CARD REVIEW", otherCard);
    //console.log("STAKEHOLDERS REVIEW", stakeholders);
    const enabledStakeholders = stakeholders.filter((s) => s.enabled);
    // console.log(
    //   enabledStakeholders.map(s => ({
    //     stakeholder: s.stakeholderName,
    //     version: s.commonVersionSelections,
    //     versions: s.inputTemplateVersions
    //   }))
    // );
    return (
      <Fade in timeout={500}>
        <Box sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
          <ModernCard elevated gradient>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <CheckCircleIcon sx={{ fontSize: 48, color: "success.main" }} />
              <Box>
                <Typography variant="h5" fontWeight={700}>
                  Review Your Configuration
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Verify all details before creating the round
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }} />
              <ModernChip
                label={`Round #${roundNumber}`}
                colorVariant="primary"
                size="small"
              />
            </Box>
          </ModernCard>
          <ModernCard elevated>
            <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}>
              <InfoIcon sx={{ color: "primary.main" }} />
              <Typography variant="h6" fontWeight={600}>
                Round Details
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Stack spacing={1.5}>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Typography fontWeight={600} sx={{ minWidth: 180 }}>
                  Description:
                </Typography>
                <Typography color="text.secondary">{description}</Typography>
              </Box>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Typography fontWeight={600} sx={{ minWidth: 180 }}>
                  Submission Date:
                </Typography>
                <Typography color="text.secondary">
                  {customerSubmissionDate?.toLocaleDateString()}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", gap: 2 }}>
                <Typography fontWeight={600} sx={{ minWidth: 180 }}>
                  Template Due Date:
                </Typography>
                <Typography color="text.secondary">
                  {templateDueDate?.toLocaleDateString() || "-"}
                </Typography>
              </Box>
            </Stack>
          </ModernCard>
          <ModernCard elevated>
            <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}>
              <AssignmentIcon sx={{ color: "primary.main" }} />
              <Typography variant="h6" fontWeight={600}>
                Datasets ({scenarios.length})
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Box
              sx={{
                display: "grid",
                //gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gridTemplateColumns: {
                  xs: "1fr",
                  md: "minmax(300px, 1fr) minmax(300px, 1fr)"
                },
                gap: 2
              }}
            >
              {scenarios.map((s) => (
                <Box
                  key={s.key}
                  sx={{
                    p: 2,
                    borderRadius: 2,
                    backgroundColor: "background.default",
                    border: "1px solid",
                    borderColor: "divider"
                  }}
                >
                  <ModernChip
                    label={`Dataset ${s.key}`}
                    colorVariant="primary"
                    size="small"
                    sx={{ mb: 1 }}
                  />
                  <Typography variant="body2" color="text.secondary">
                    {s.description?.length > 40
                      ? s.description.substring(0, 40) + "..."
                      : s.description || "(No description)"}
                  </Typography>
                </Box>
              ))}
            </Box>
          </ModernCard>
          <ModernCard elevated>
            <Box sx={{ mb: 2, display: "flex", alignItems: "center", gap: 1 }}>
              <PeopleIcon sx={{ color: "primary.main" }} />
              <Typography variant="h6" fontWeight={600}>
                Input Templates ({enabledStakeholders.length})
              </Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Stack spacing={2}>
              {enabledStakeholders.map((sh, idx) => {
                const selectedScenarios = sh.applicableScenarios || [];
                return (
                  <Box
                    key={`${sh.stakeholderCode ?? idx}`}
                    sx={{
                      p: 2,
                      borderRadius: 2,
                      backgroundColor: "background.default",
                      border: "1px solid",
                      borderColor: "divider"
                    }}
                  >
                    <Typography variant="body1" fontWeight={600} gutterBottom>
                      {sh.stakeholderName}
                    </Typography>

                    <Typography variant="body2" sx={{ mt: 1 }}>
                      <strong>Version No.:</strong>{" "}
                      {sh.commonVersionSelections || "-"}
                    </Typography>

                    <Typography variant="body2">
                      <strong>Due Date:</strong>{" "}
                      {sh.dueDate
                        ? new Date(sh.dueDate).toLocaleDateString()
                        : "-"}
                    </Typography>

                    {sh.collectDraftInput && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        <strong>Collect Draft Input:</strong> Yes
                      </Typography>
                    )}

                    {sh.collectDraftInput && sh.commonDraftDueDate && (
                      <Typography variant="body2" sx={{ mt: 1 }}>
                        <strong>Draft Due Date:</strong>{" "}
                        {new Date(sh.commonDraftDueDate).toLocaleDateString()}
                      </Typography>
                    )}

                    <Typography variant="body2" sx={{ mt: 1 }}>
                      <strong>Datasets:</strong>{" "}
                      {selectedScenarios.length
                        ? selectedScenarios.map((k) => (
                          <Chip
                            key={k}
                            label={k}
                            size="small"
                            sx={{ ml: 0.5 }}
                          />
                        ))
                        : "-"}
                    </Typography>

                    <Box sx={{ mt: 1 }}>
                      {selectedScenarios.map((sk) => {
                        // const cfg = sh.scenarioConfigs?.[sk] || {};

                        const cfg = sh.scenarioConfigs?.[sk];
                        if (!cfg) return null;
                        const isStd = cfg.inputOption === "useStandardInput";
                        const isCopy =
                          cfg.inputOption === "usePreviousRoundInput";
                        const selectedStandard = (
                          sh.standardOptions ?? []
                        ).find(
                          (o) =>
                            String(o.id) === String(cfg.standardSelectedKey)
                        );

                        return (
                          <Box
                            key={`${sh.stakeholderCode ?? idx}-review-${sk}`}
                            sx={{ pl: 1, mt: 1 }}
                          >
                            <Typography variant="subtitle2">
                              Dataset {sk}:{" "}
                              {inputOptionToText(String(cfg.inputOption))}
                              {isCopy && (
                                <Chip
                                  size="small"
                                  color="info"
                                  label="Copied from previous round"
                                  sx={{ ml: 1 }}
                                />
                              )}
                            </Typography>
                            {isStd && (
                              <Typography variant="body2">
                                <strong>Template:</strong>{" "}
                                {selectedStandard
                                  ? selectedStandard.title
                                  : "-"}
                              </Typography>
                            )}
                          </Box>
                        );
                      })}
                    </Box>

                    <Typography variant="body2" sx={{ mt: 1 }}>
                      <strong>Extra Input Provider:</strong>{" "}
                      {sh.additionalTeamPersonas?.length
                        ? sh.additionalTeamPersonas.map((p) => (
                          <Chip
                            key={String(p.key)}
                            label={p.text || p.secondaryText}
                            size="small"
                            sx={{ ml: 0.5 }}
                          />
                        ))
                        : "-"}
                    </Typography>

                    <Typography variant="body2" sx={{ mt: 1 }}>
                      <strong>Stakeholder Users:</strong>{" "}
                      {sh.notifyUserPersonas?.length
                        ? sh.notifyUserPersonas.map((p) => (
                          <Chip
                            key={String(p.key)}
                            label={p.text || p.secondaryText}
                            size="small"
                            sx={{ ml: 0.5 }}
                          />
                        ))
                        : "-"}
                    </Typography>
                  </Box>
                );
              })}
            </Stack>

            {/* Adhoc Template Details */}
            <Divider sx={{ my: 3 }} />

            <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <PeopleIcon sx={{ color: "primary.main" }} />

              <Typography variant="h6" fontWeight={600}>
                Adhoc Templates ({adhocCards.length})
              </Typography>
            </Box>

            <Stack spacing={2} sx={{ mt: 2 }}>
              {adhocCards.map((card, idx) => (
                <Box
                  key={idx}
                  sx={{
                    p: 2,
                    borderRadius: 2,
                    backgroundColor: "background.default",
                    border: "1px solid",
                    borderColor: "divider"
                  }}
                >
                  <Typography variant="body1" fontWeight={600}>
                    {card.otherCode}
                  </Typography>

                  <Typography variant="body2" color="text.secondary">
                    <strong>Code:</strong>{" "}
                    {(card.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "")}
                  </Typography>

                  <Typography variant="body2" sx={{ mt: 1 }}>
                    <strong>Description:</strong>{" "}
                    {card.otherDescription || "-"}
                  </Typography>

                  <Typography variant="body2" sx={{ mt: 1 }}>
                    <strong>Due Date:</strong>{" "}
                    {card.dueDate
                      ? new Date(card.dueDate).toLocaleDateString()
                      : "-"}
                  </Typography>
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    <strong>Datasets:</strong>{" "}

                    {card.applicableScenarios.map(k => (
                      <Chip
                        key={k}
                        label={k}
                        size="small"
                        sx={{ ml: 0.5 }}
                      />
                    ))}
                  </Typography>
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    <strong>Team Members:</strong>{" "}

                    {card.additionalTeamPersonas?.length
                      ? card.additionalTeamPersonas.map(p => (
                        <Chip
                          key={String(p.key)}
                          label={p.text || p.secondaryText}
                          size="small"
                          sx={{ ml: 0.5 }}
                        />
                      ))
                      : "-"}
                  </Typography>
                </Box>
              ))}
            </Stack>

          </ModernCard>
          <ModernAlert severity="success" elevated>
            Ready to create this round! Click <strong>Complete</strong> to
            submit.
          </ModernAlert>
        </Box>
      </Fade>
    );
  };

  const steps = [
    {
      label: "Round Details",
      content: renderStep1(),
      validate: validateStep1
    },
    {
      label: "Datasets",
      content: renderStep2(),
      validate: validateStep2
    },
    {
      label: "Input Templates",
      content: renderStep3(),
      validate: validateStep3
    },
    {
      label: "Review",
      content: renderStep4()
    }
  ];

  if (permissionLoading) {
    return (
      <Box sx={{ p: 4 }}>
        <ModernLoadingState type="spinner" />
      </Box>
    );
  }

  if (!hasAccess) {
    return (
      <Fade in>
        <Box
          sx={{
            p: 4,
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
          }}
        >
          <ModernEmptyState
            type="access"
            title="Access denied"
            description="You do not have permission to view this page. Please contact your SharePoint administrator."
          />
        </Box>
      </Fade>
    );
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Fade in timeout={500}>
        <Box sx={{ p: 0 }}>
          <ModernStepper
            steps={steps}
            onComplete={onComplete}
            onCancel={() => navigate(`/opportunities/${id}/rounds`)}
            completeText={saving ? "Creating..." : "Submit"}
            completeDisabled={saving}
            loading={saving}
            showProgress
          />
          {toast && (
            <Box sx={{ mt: 2 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )}

          <Dialog
            open={folderCreationDialogOpen}
            disableEscapeKeyDown
            fullWidth
            maxWidth="sm"
          >
            <DialogTitle>
              Folder creation in progress
            </DialogTitle>

            <DialogContent>
              <Stack
                direction="row"
                spacing={2}
                alignItems="center"
                sx={{ py: 2 }}
              >
                <CircularProgress size={28} />

                <Typography>
                  Once the folders are created, we will notify you via email.
                </Typography>
              </Stack>
            </DialogContent>

            <DialogActions>
              <Button
                variant="contained"
                onClick={handleFolderDialogOk}
              >
                OK
              </Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={previousRoundDialogOpen}
            disableEscapeKeyDown
            fullWidth
            maxWidth="sm"
          >
            <DialogTitle>
              Previous Round Is Still Open
            </DialogTitle>

            <DialogContent>
              <Stack spacing={2} sx={{ py: 2 }}>
                <Typography>
                  A previous round is still open for this opportunity.
                  Please close the previous round before creating a new round.
                </Typography>

                <Typography
                  variant="h4"
                  align="center"
                  fontWeight={700}
                >
                  {previousRoundCountdown}
                </Typography>

                <Typography
                  variant="body2"
                  color="text.secondary"
                  align="center"
                >
                  Redirecting to the opportunity page...
                </Typography>
              </Stack>
            </DialogContent>
          </Dialog>
        </Box>
      </Fade>
    </LocalizationProvider>
  );
}