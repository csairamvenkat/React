import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  MenuItem,
  LinearProgress,
  Fade,
  Divider,
  Autocomplete,
  TextField,
} from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import PeopleIcon from '@mui/icons-material/People';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import BusinessIcon from '@mui/icons-material/Business';
import { ApiDataProvider } from '../../../api/ApiDataProvider';
import { triggerFlow } from '../../../flow/flowclient';
import {
  ModernCard,
  ModernButton,
  ModernTextField,
  ModernAutocomplete,
  ModernAlert,
  ModernLoadingState,
  ModernEmptyState,
} from '../../shared/mui';
import { SPHttpClient } from '@microsoft/sp-http';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';

type PricerUser = { key: number; text: string; email: string; login: string };

const regionOptions = [{ value: 'EUR', label: 'EUR' }];

type CountryOption = {
  id: number;
  title: string;
  label: string;
  code: string;
  groupId?: number;
  groupTitle?: string;
};

export default function CreateOpportunity() {
  const navigate = useNavigate();
  const cfg = (window as any).TENANT_CONFIG;
  const api = React.useMemo(
    () =>
      new ApiDataProvider((window as any).spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl,
      }),
    [cfg]
  );

  const [region, setRegion] = React.useState<string>('EUR');
  const [leadNumber, setLeadNumber] = React.useState<string>('');
  const [leadError, setLeadError] = React.useState<string | undefined>(undefined);
  // const [customer, setCustomer] = React.useState('');
  const [customer, setCustomer] = React.useState<any | null>(null);
  const [customerError, setCustomerError] = React.useState<string | undefined>(undefined);
  const [opportunityName, setOpportunityName] = React.useState('');
  const [oppError, setOppError] = React.useState<string | undefined>(undefined);
  const [country, setCountry] = React.useState<CountryOption[]>([]);
  const [selectedCountry, setSelectedCountry] = React.useState<CountryOption | null>(null);
  const [loadingCountries, setLoadingCountries] = React.useState(false);
  const [leadPricerOptions, setLeadPricerOptions] = React.useState<PricerUser[]>([]);
  const [loadingPricers, setLoadingPricers] = React.useState(false);
  const [selectedLeadPricer, setSelectedLeadPricer] = React.useState<PricerUser | null>(null);
  const [submitting, setSubmitting] = React.useState(false);
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const ALLOWED_GROUP_NAME = 'Pricing';
  const sanitizeProjectName = (value: string) =>
    value.replace(/[^a-zA-Z0-9 _-]/g, "");

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);

  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);


  const MAX_CUSTOMER = 20;
  const MAX_OPP = 30;
  const MAX_COMBINED = 40;

  // const allowedOppLen = React.useMemo(
  //   () => Math.min(MAX_OPP, Math.max(0, MAX_COMBINED - customer.length)),
  //   [customer.length]
  // );


  const allowedOppLen = React.useMemo(
    () =>
      Math.min(
        MAX_OPP,
        Math.max(0, MAX_COMBINED - (customer?.label?.length || 0))
      ),
    [customer?.label]
  );


  React.useEffect(() => {
    if (!hasAccess) return;

    void (async () => {
      try {
        setLoadingPricers(true);

        const spContext = (window as any).spfxContext;
        const currentUserLogin = spContext.pageContext.user.loginName
          .replace(/^i:0#\.f\|membership\|/i, '')
          .toLowerCase();

        const ctx = spContext;
        const url = `${cfg.siteUrl}/_api/web/sitegroups/GetByName('${encodeURIComponent(ALLOWED_GROUP_NAME)}')/users?$select=Id,Title,Email,LoginName`;

        const res = await ctx.spHttpClient.get(
          url,
          SPHttpClient.configurations.v1
        );

        if (!res.ok) throw new Error(`Pricing group users GET failed`);

        const data = await res.json();

        const users: PricerUser[] = (data.value ?? []).map((u: any) => ({
          key: u.Id,
          text: u.Title || u.LoginName,
          email: u.Email,
          login: (u.LoginName as string)
            .replace(/^i:0#\.f\|membership\|/i, '')
            .toLowerCase(),
        }));

        setLeadPricerOptions(users);

        const me = users.find(
          u => u.login === currentUserLogin
        );

        if (me) {
          setSelectedLeadPricer(me);
        }

      } catch (err) {
        console.error('Failed to load pricer users:', err);
      } finally {
        setLoadingPricers(false);
      }
    })();
  }, [cfg.siteUrl, hasAccess]);


  React.useEffect(() => {
    if (!hasAccess) return;
    void (async () => {
      try {
        setLoadingCountries(true);
        const ctx = (window as any).spfxContext;
        const listTitle = 'Country';
        const groupField = 'AssociatedGroup';
        const url =
          `${cfg.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
          `?$select=Id,Title,Code,${groupField}/Id,${groupField}/Title&$expand=${groupField}`;

        const res = await ctx.spHttpClient.get(url, SPHttpClient.configurations.v1);
        if (!res.ok) throw new Error(`Countries GET failed ${res.status}`);
        const data = await res.json();
        const items = (data.value ?? data.d?.results ?? []) as any[];

        const options = items.map((it) => ({
          id: it.Id,
          title: it.Title,
          label: `${it.Title}${it.Code ? ` (${it.Code})` : ''}`,
          code: it.Code,
          groupId: it[groupField]?.Id as number | undefined,
          groupTitle: it[groupField]?.Title as string | undefined,
        }));

        setCountry(options);
      } catch (error) {
        console.error('Failed to load countries:', error);
        setToast({ severity: 'error', text: 'Failed to load countries' });
      } finally {
        setLoadingCountries(false);
      }
    })();
  }, [cfg.siteUrl, hasAccess]);

  const checkOpportunityExists = async (opportunityName: string) => {
    try {
      const resp = await api.checkOpportunityExists({
        opportunityName,
      });
      return true;
    } catch (err: any) {
      return false;
    }
  };

  const onLeadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 6);
    setLeadNumber(val);
    setLeadError(undefined);
  };

  const onLeadBlur = () => {
    if (leadNumber.length > 0 && leadNumber.length < 6) {
      const padded = '000000'.substring(0, 6 - leadNumber.length) + leadNumber;
      setLeadNumber(padded);
    }
  };

  // const onCustomerChange = (value: string | null) => {
  //   const val = value || '';
  //   setCustomer(val);
  //   setCustomerError(undefined);
  //   if (val.length > MAX_CUSTOMER) {
  //     setCustomerError(`Max ${MAX_CUSTOMER} characters`);
  //   }
  // };

  const onCustomerChange = (value: any) => {
    let text = "";

    if (typeof value === "string") {
      text = value;
    } else if (value && typeof value === "object") {
      text = value.label || value.title || "";
    }

    setCustomer(text);
    setCustomerError(undefined);

    if (text.length > MAX_CUSTOMER) {
      setCustomerError(`Max ${MAX_CUSTOMER} characters`);
    }
  };

  const handleCustomerSearch = async (query: string): Promise<any[]> => {
    try {
      const resp = await api.searchCustomers(query, 10);
      const data = (resp as any)?.data || resp || [];
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Customer search failed:', error);
      return [];
    }
  };

  const onOppChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value || "";

    const sanitized = sanitizeProjectName(rawValue);

    const trimmed = sanitized.slice(0, allowedOppLen);

    setOpportunityName(trimmed);
    setOppError(undefined);

    if (customer.length + trimmed.length > MAX_COMBINED) {
      setOppError(`Total length exceeds ${MAX_COMBINED} characters`);
    }
  };

  const custLen = (customer || "").length;
  const oppLen = (opportunityName || "").length;

  const isFormValid =
    leadNumber.length === 6 &&
    !leadError &&
    custLen > 0 &&
    !customerError &&
    oppLen > 0 &&
    !oppError &&
    custLen + oppLen <= MAX_COMBINED &&
    selectedCountry !== null;

  // const isFormValid =
  //   leadNumber.length === 6 &&
  //   !leadError &&
  //   customer?.length > 0 &&
  //   !customerError &&
  //   opportunityName?.length > 0 &&
  //   !oppError &&
  //   customer.length + opportunityName.length <= MAX_COMBINED &&
  //   selectedCountry !== null;

  const onSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!isFormValid) return;

    const fullName = `${leadNumber} ${customer} ${opportunityName} ${selectedCountry.code}`;

    try {
      setSubmitting(true);

      const exists = await checkOpportunityExists(fullName);
      if (exists) {
        setToast({
          severity: "warning",
          text: "This opportunity (" + fullName + ") already exists. Please change the project name.",
        });
        setSubmitting(false);
        return;
      }
      const apiPayload = {
        leadNumber: leadNumber,
        title: `${leadNumber} ${customer} ${opportunityName} ${selectedCountry.code}`,
        customer: customer,
        region: region,
        country: selectedCountry.title,
        countryCode: selectedCountry.code,
        project_name: opportunityName,
        lead_pricer: selectedLeadPricer ? [{
          name: selectedLeadPricer.text,
          email: selectedLeadPricer.email,
          login_id: selectedLeadPricer.login,
        }] : [],
      }
      // console.log(apiPayload);
      const created = await api.createOpportunity(apiPayload);

      const safeOppName = sanitizeProjectName(opportunityName);

      const flowPayload = {
        eventType: 'OpportunityCreation',
        region: region,
        opportunityName: `${leadNumber} ${customer} ${opportunityName} ${selectedCountry.code}`,
        customer: customer,
        groupId: selectedCountry.groupId,
        groupTitle: selectedCountry.groupTitle,
        siteUrl: `${cfg.siteUrl}`,
        folderPath: `${cfg.serverRelativeLibrary}${customer}/${safeOppName}`
      };

      // console.log(flowPayload)
      await triggerFlow(flowPayload, "OpportunityCreationFlow");
      setToast({ severity: 'success', text: 'Opportunity created successfully!' });

      setTimeout(() => navigate(`/opportunities/${created.id}`), 1500);
    } catch (err: any) {
      setToast({ severity: 'error', text: `Error: ${err.message}` });
      setSubmitting(false);
    }
  };

  const remainingChars = Math.max(0, allowedOppLen - opportunityName.length);
  const charPercentage = ((allowedOppLen - remainingChars) / allowedOppLen) * 100;


  if (permissionLoading) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernLoadingState type="spinner" />
      </Box>
    );
  }

  if (!hasAccess) {
    return (
      <Fade in>
        <Box
          sx={{
            p: 0,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <ModernEmptyState
            type="access"
            title="Access denied"
            description="You do not have permission to view this page. Please contact your SharePoint administrator."
          />
        </Box>
      </Fade>
    );
  }


  return (
    <Fade in timeout={500}>
      <Box sx={{ p: 0 }}>
        {toast && (
          <Box sx={{ mb: 3 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )}

        <ModernCard
          icon={<BusinessIcon />}
          title="Create New Opportunity"
          subtitle="Fill in the details below to create a new pricing opportunity"
          gradient
          elevated
          sx={{ mb: 3 }}
        >
          <Box />
        </ModernCard>

        <form onSubmit={onSubmit}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <InfoIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Basic Information
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Enter the regional and lead details
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 3 }}>
                <ModernTextField
                  label="Region"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  select
                  required
                  helperIcon={<LocationOnIcon />}
                >
                  {regionOptions.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </ModernTextField>

                <ModernTextField
                  label="Lead Number"
                  value={leadNumber}
                  onChange={onLeadChange}
                  onBlur={onLeadBlur}
                  required
                  error={!!leadError}
                  // helperText={leadError || 'Exactly 6 digits, will auto-pad with leading zeros'}
                  helperText={leadError || 'Enter the OneCRM Lead Number. If fewer than 6 digits, leading zeros are added automatically. If unavailable, use the OneCRM Opportunity Number or enter 0.'}
                  showCharacterCount
                  inputProps={{ maxLength: 6 }}
                />
              </Box>
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <PeopleIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Customer & Project
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Search for an existing customer
                    {/* Search for an existing customer or enter a new one */}
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>

                <ModernAutocomplete
                  label="Customer"
                  value={customer}
                  onChange={(val) => {
                    // if (typeof val === "string") onCustomerChange(val);
                    // else if (val?.label) onCustomerChange(val.label);
                    setCustomer(val);
                    setCustomerError(undefined);
                  }}
                  onSearch={handleCustomerSearch}
                  // onInputChange={(text) => onCustomerChange(text)}
                  getOptionLabel={(option) =>
                    typeof option === "string" ? option : option?.label || ""
                  }
                  // freeSolo
                  required
                  error={!!customerError}
                  // placeholder="Start typing a customer name..."
                  // helperText={customerError || 'This customer will be treated as new if not found'}        
                  placeholder="Select a customer..."
                  helperText={customerError || 'Please select a customer from the list'}
                />

                <Box>
                  <ModernTextField
                    label="Project Name"
                    value={opportunityName}
                    onChange={onOppChange}
                    required
                    error={!!oppError}
                    // helperText={
                    //   oppError ||
                    //   "Only letters, numbers, spaces, hyphens (-), and underscores (_) are allowed"
                    // }
                    helperText={
                      oppError ||
                      "Use the same project name as in CL Pricing JIRA. Do not include the Lead Number, Customer and Country, as these are automatically added to the full Opportunity and folder name."
                    }
                    inputProps={{ maxLength: allowedOppLen }}
                  />
                  <Box sx={{ mt: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography variant="caption" color="text.secondary">
                        Combined length (Customer + Project)
                      </Typography>
                      <Typography
                        variant="caption"
                        fontWeight={600}
                        sx={{
                          color: remainingChars < 10 ? 'error.main' : 'primary.main',
                        }}
                      >
                        {remainingChars} characters remaining
                      </Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={charPercentage}
                      sx={{
                        height: 6,
                        borderRadius: 3,
                        backgroundColor: (theme) => theme.palette.grey[200],
                        '& .MuiLinearProgress-bar': {
                          borderRadius: 3,
                          background:
                            charPercentage > 90
                              ? 'linear-gradient(90deg, #d13438, #a4262c)'
                              : 'linear-gradient(90deg, #1e1450, #3d2fa0)',
                        },
                      }}
                    />
                  </Box>
                </Box>
              </Box>
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <LocationOnIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Location
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Select the country for this opportunity
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Autocomplete
                options={country}
                value={selectedCountry}
                onChange={(_, newValue) => setSelectedCountry(newValue)}

                getOptionLabel={(option) => option?.label || ""}


                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Country"
                    placeholder={loadingCountries ? "Loading countries..." : "Select Country"}
                    required
                    disabled={loadingCountries || !country.length}
                  />
                )}
                loading={loadingCountries}
                clearOnEscape
                autoHighlight
                fullWidth
              />
            </ModernCard>

            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
                <PersonSearchIcon sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    Lead Pricer
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Select the lead pricer for this opportunity
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Autocomplete
                options={leadPricerOptions}
                value={selectedLeadPricer}
                onChange={(_, newValue) => setSelectedLeadPricer(newValue)}
                getOptionLabel={(o) => o.text}
                isOptionEqualToValue={(a, b) => a.key === b.key}
                loading={loadingPricers}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Lead Pricer"
                    placeholder={loadingPricers ? 'Loading pricers...' : 'Select a pricer'}
                  />
                )}
                fullWidth
                clearOnEscape
                autoHighlight
              />
            </ModernCard>

            <Box
              sx={{
                display: 'flex',
                justifyContent: 'flex-end',
                gap: 2,
                p: 3,
                borderTop: '1px solid',
                borderColor: 'divider',
                backgroundColor: 'background.paper',
                borderRadius: 3,
                position: 'sticky',
                bottom: 0,
                zIndex: 10,
                boxShadow: '0 -4px 16px rgba(0, 0, 0, 0.1)',
              }}
            >
              <ModernButton
                variant="outlined"
                onClick={() => navigate('/opportunities')}
                disabled={submitting}
              >
                Cancel
              </ModernButton>
              <ModernButton
                variant="gradient"
                glow
                onClick={onSubmit}
                disabled={!isFormValid || submitting}
                loading={submitting}
              >
                Create Opportunity
              </ModernButton>
            </Box>
          </Box>
          {toast && (
            <Box sx={{ mt: 3, mb: 3 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )}
        </form>
      </Box>
    </Fade>
  );
}