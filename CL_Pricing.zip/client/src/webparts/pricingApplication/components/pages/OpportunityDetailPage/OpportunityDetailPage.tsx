import * as React from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Typography,
  IconButton,
  Tooltip,
  Divider,
  Fade,
  Stack,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Button,
  Drawer,
  CircularProgress,
  Backdrop,
} from '@mui/material';

import EditIcon from '@mui/icons-material/Edit';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import BusinessIcon from '@mui/icons-material/Business';
import PersonIcon from '@mui/icons-material/Person';
import GroupIcon from '@mui/icons-material/Group';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import AssignmentIcon from '@mui/icons-material/Assignment';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import SaveIcon from '@mui/icons-material/Save';
import CloseIcon from '@mui/icons-material/Close';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import type { IPersonaProps } from '@fluentui/react';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import { ApiDataProvider } from '../../../api/ApiDataProvider';
import RoundListView from '../../lists/RoundListView';
import { useCrumbs } from '../../shell/CrumbContext';
import {
  ModernCard,
  ModernLoadingState,
  ModernAlert,
  ModernChip,
  ModernButton,
} from '../../shared/mui';
import { triggerFlow } from '../../../flow/flowclient';

type TeamMember = {
  id: number;
  userId?: string;
  displayName: string;
  email?: string;
  avatarUrl?: string;
  role?: string;
};

export default function OpportunityDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const cfg = (window as any).TENANT_CONFIG;
  const spfxContext = (window as any).spfxContext;
  const ALLOWED_GROUP_NAME = 'Pricing';

  const api = React.useMemo(
    () =>
      new ApiDataProvider(spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl,
      }),
    [cfg, spfxContext]
  );

  const { names, setNames } = useCrumbs();
  const { opportunityName, customerName } = names;

  const [loadingOpp, setLoadingOpp] = React.useState(false);
  const [opp, setOpp] = React.useState<any>(null);
  const [region, setRegion] = React.useState("");
  const [leadPricerEmail, setLeadPricerEmail] = React.useState("");

  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const [loadingTeam, setLoadingTeam] = React.useState(false);
  const [team, setTeam] = React.useState<TeamMember[]>([]);
  const [panelOpen, setPanelOpen] = React.useState(false);
  const [isSaving, setIsSaving] = React.useState(false);
  const [adhocPeople, setAdhocPeople] = React.useState<{ displayName: string; email?: string }[]>([]);

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);
  const [togglingActive, setTogglingActive] = React.useState(false);

  const [hasRounds, setHasRounds] = React.useState(false);


  React.useEffect(() => {
    const state = location.state as {
      previousRoundStillOpen?: boolean;
    } | null;

    if (state?.previousRoundStillOpen) {
      setToast({
        severity: 'warning',
        text: 'Previous round is still open. Please close the previous round before creating a new round.'
      });

      navigate(location.pathname, {
        replace: true,
        state: {}
      });
    }
  }, [location, navigate]);


  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const peoplePickerContext = React.useMemo(
    () => ({
      absoluteUrl: spfxContext?.pageContext?.web?.absoluteUrl,
      msGraphClientFactory: spfxContext?.msGraphClientFactory,
      spHttpClient: spfxContext?.spHttpClient,
    }),
    [spfxContext]
  );

  const normalizeTeam = React.useCallback((arr: any[] = []): TeamMember[] => {
    return arr.map((m: any, index: number) => ({
      id: index + 1,
      userId: m.userId ?? m.user_id ?? undefined,
      displayName: m.displayName ?? m.name ?? m.fullName ?? '',
      email: m.email ?? m.mail ?? m.userPrincipalName ?? '',
      avatarUrl: m.avatarUrl ?? m.photoUrl ?? undefined,
      role: m.role ?? m.title ?? undefined,
      _raw: m,
    }));
  }, []);

  const toApiBidTeamMembers = React.useCallback((members: TeamMember[]) => {
    return members.map((m) => ({
      name: m.displayName,
      email: m.email ?? '',
      login_id: m.email ?? '',
    }));
  }, []);

  React.useEffect(() => {
    void (async () => {
      try {
        setLoadingOpp(true);
        setLoadingTeam(true);

        const data = await api.getOpportunity(Number(id));
        setOpp(data);
        setRegion(data.region || "");
        const uniqueEmailsleadPricer = Array.from(
          new Set(data.lead_pricer?.map((u) => u.email).filter(Boolean)));
        const uniqueEmailsleadPricerString = uniqueEmailsleadPricer.join(";");
        setLeadPricerEmail(uniqueEmailsleadPricerString);
        setNames({ opportunityName: data.title, customerName: data.customer });
        const initialTeam = normalizeTeam(data?.bid_team_members ?? []);
        setTeam(initialTeam);

        const rounds = await api.getRounds(Number(id), 1, 1);
        const listRound = Array.isArray(rounds) ? rounds : [];
        setHasRounds(listRound.length > 0);

      } catch (err: any) {
        setToast({ severity: 'error', text: `Load failed: ${err.message}` });
      } finally {
        setLoadingOpp(false);
        setLoadingTeam(false);
      }
    })();
  }, [api, id, setNames, normalizeTeam]);

  const openAddPanel = () => {
    setAdhocPeople([]);
    setPanelOpen(true);
  };
  const closePanel = () => {
    setPanelOpen(false);
    setAdhocPeople([]);
  };

  const savePanel = async () => {
    try {
      setIsSaving(true);

      if (!adhocPeople.length) {
        setToast({ severity: 'warning', text: 'Please select at least one person' });
        return;
      }

      const existingByEmail = new Map(team.map((m) => [m.email?.toLowerCase(), true]));
      const newMembers: TeamMember[] = [];

      adhocPeople.forEach((p, idx) => {
        const emailKey = (p.email ?? '').toLowerCase();
        if (emailKey && existingByEmail.has(emailKey)) return;

        newMembers.push({
          id: Date.now() + idx,
          displayName: p.displayName,
          email: p.email,
        });
      });

      if (newMembers.length === 0) {
        setToast({ severity: 'info', text: 'All selected people are already in the team' });
        return;
      }

      const next = [...team, ...newMembers];

      setTeam(next);

      const apiPayload = {
        bid_team_members: toApiBidTeamMembers(next),
      };
      await api.updateBidTeamMembers(Number(id), apiPayload);

      const flowPayload = {
        eventType: 'AddBidTeamMember',
        opportunityName: opportunityName,
        customer: customerName,
        siteUrl: `${cfg.siteUrl}`,
        folderPath: `${cfg.serverRelativeLibrary}${customerName}/${opportunityName}`,
        adhocPeople: adhocPeople,
        region: region,
        leadPricerEmail: leadPricerEmail,
        mainOpportunityFolderLink: cfg.siteUrl + "/EUR/" + customerName + "/" + opportunityName
      };
      await triggerFlow(flowPayload, 'OpportunityCreationFlow');

      setToast({ severity: 'success', text: `Added ${newMembers.length} member(s)` });
      closePanel();
    } catch (err: any) {
      setToast({ severity: 'error', text: `Save failed: ${err.message}` });
    } finally {
      setIsSaving(false);
    }
  };

  const removeMember = async (member: TeamMember) => {
    try {
      setIsSaving(true);

      const next = team.filter((m) => m.id !== member.id);
      setTeam(next);

      const apiPayload = {
        bid_team_members: toApiBidTeamMembers(next),
      };
      await api.updateBidTeamMembers(Number(id), apiPayload);

      const flowPayload = {
        eventType: 'RemoveBidTeamMember',
        opportunityName: opportunityName,
        customer: customerName,
        siteUrl: `${cfg.siteUrl}`,
        folderPath: `${cfg.serverRelativeLibrary}${customerName}/${opportunityName}`,
        adhocPeople: [
          {
            displayName: member.displayName,
            email: member.email,
          },
        ],
        region: region,
      };
      await triggerFlow(flowPayload, 'OpportunityCreationFlow');

      setToast({ severity: 'success', text: `Removed ${member.displayName}` });
    } catch (err: any) {
      setToast({ severity: 'error', text: `Remove failed: ${err.message}` });
    } finally {
      setIsSaving(false);
    }
  };

  if (loadingOpp || !opp) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernLoadingState type="shimmer" rows={4} height={100} />
      </Box>
    );
  }

  return (
    <Fade in timeout={500}>
      <Box sx={{ p: 0 }}>
        {toast && (
          <Box sx={{ mb: 3 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )}

        <Backdrop
          open={isSaving}
          sx={{
            color: '#fff',
            zIndex: (theme) => theme.zIndex.drawer + 999,
            flexDirection: 'column',
            gap: 2,
          }}
        >
          <CircularProgress color="inherit" />
          <Typography>Please wait...</Typography>
        </Backdrop>

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 3,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 3,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'linear-gradient(135deg, #1e1450, #3d2fa0)',
                color: 'white',
                boxShadow: '0 4px 16px rgba(30, 20, 80, 0.3)',
              }}
            >
              <BusinessIcon sx={{ fontSize: 28 }} />
            </Box>
            <Box>
              <Typography variant="h4" fontWeight={700}>
                Opportunity Details
              </Typography>
              <Typography variant="body2" color="text.secondary">
                View and manage opportunity information
              </Typography>
            </Box>
          </Box>
          {hasAccess && (
            <Box sx={{ display: 'flex', gap: 1 }}>
              {/* <Tooltip title="Edit Opportunity" arrow>
                <IconButton
                  onClick={() => navigate(`/opportunities/${opp.id}/edit`)}
                  sx={{
                    color: 'primary.main',
                    '&:hover': {
                      backgroundColor: 'primary.light',
                      color: 'white',
                      transform: 'scale(1.1)',
                    },
                    transition: 'all 0.2s',
                  }}
                >
                  <EditIcon />
                </IconButton>
              </Tooltip> */}
              <Tooltip
                title={
                  hasRounds
                    ? "This opportunity already contains rounds. Project Name and Country cannot be modified. Only Lead Pricer can be updated."
                    : "Edit Opportunity"
                }
                arrow
              >
                <span>
                  <IconButton
                    onClick={() => navigate(`/opportunities/${opp.id}/edit`)}
                    sx={{
                      color: 'primary.main',
                      '&:hover': {
                        backgroundColor: 'primary.light',
                        color: 'white',
                        transform: 'scale(1.1)',
                      },
                      transition: 'all 0.2s',
                    }}
                  >
                    <EditIcon />
                  </IconButton>
                </span>
              </Tooltip>
              <Tooltip title="Back to Opportunities" arrow>
                <IconButton
                  onClick={() => navigate('/opportunities')}
                  sx={{
                    color: 'primary.main',
                    '&:hover': {
                      backgroundColor: 'primary.light',
                      color: 'white',
                      transform: 'scale(1.1)',
                    },
                    transition: 'all 0.2s',
                  }}
                >
                  <ArrowBackIcon />
                </IconButton>
              </Tooltip>
            </Box>
          )}
        </Box>

        <ModernCard elevated hoverable sx={{ mb: 3 }}>
          <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" fontWeight={600}>
              Opportunity Information
            </Typography>
            <Stack direction="row" spacing={1} alignItems="center">
              <ModernButton
                variant="outlined"
                startIcon={<FolderOpenIcon />}
                onClick={() => {
                  const opportunityFolderUrl = `${cfg.siteBaseUrl}${cfg.serverRelativeLibrary}${customerName}/${opportunityName}`;
                  window.open(opportunityFolderUrl, "_blank");
                }}
              >
                Browse Directory
              </ModernButton>
              {/* <Tooltip title="Open Opportunity Folder" arrow>
                <IconButton
                  size="small"
                  color="primary"
                  onClick={() => window.open(opportunityFolderUrl, "_blank")}
                  sx={{
                    border: "1px solid",
                    borderColor: "divider"
                  }}
                >
                  <FolderOpenIcon /> Browse Directory
                </IconButton>
              </Tooltip> */}

              {hasAccess && (
                <Tooltip title={opp.active ? 'Mark as Inactive' : 'Mark as Active'} arrow>
                  <Box
                    onClick={async () => {
                      if (togglingActive) return;
                      const newActive = !opp.active;
                      setTogglingActive(true);
                      try {
                        const updated = await api.updateOpportunityActive(Number(id), newActive);
                        setOpp((prev: any) => ({ ...prev, active: updated.active }));
                        setToast({ severity: 'success', text: `Opportunity marked as ${newActive ? 'Active' : 'Inactive'}` });
                      } catch (err: any) {
                        setToast({ severity: 'error', text: `Failed to update status: ${err.message}` });
                      } finally {
                        setTogglingActive(false);
                      }
                    }}
                    sx={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      width: 90,
                      height: 32,
                      borderRadius: 999,
                      backgroundColor: opp.active ? '#4caf50' : '#bdbdbd',
                      cursor: togglingActive ? 'wait' : 'pointer',
                      opacity: togglingActive ? 0.7 : 1,
                      position: 'relative',
                      transition: 'background-color 0.3s ease',
                      userSelect: 'none',
                      px: '6px',
                      justifyContent: opp.active ? 'flex-start' : 'flex-end',
                    }}
                  >
                    <Typography
                      sx={{
                        color: '#fff',
                        fontWeight: 700,
                        fontSize: 13,
                        flex: 1,
                        textAlign: opp.active ? 'left' : 'right',
                        pl: opp.active ? '4px' : 0,
                        pr: opp.active ? 0 : '4px',
                        lineHeight: '32px',
                        transition: 'all 0.3s ease',
                      }}
                    >
                      {opp.active ? 'Active' : 'Inactive'}
                    </Typography>
                    <Box
                      sx={{
                        width: 24,
                        height: 24,
                        borderRadius: '50%',
                        backgroundColor: '#fff',
                        boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
                        flexShrink: 0,
                        transition: 'all 0.3s ease',
                      }}
                    />
                  </Box>
                </Tooltip>
              )}
            </Stack>
          </Box>
          <Divider sx={{ mb: 2 }} />

          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(2, 1fr)' },
              gap: 3,
            }}
          >
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <ConfirmationNumberIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                <Typography variant="caption" fontWeight={600} color="text.secondary">
                  Lead Number
                </Typography>
              </Box>
              <ModernChip label={opp.leadNumber} colorVariant="primary" size="medium" />
            </Box>

            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <PersonIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                <Typography variant="caption" fontWeight={600} color="text.secondary">
                  Customer
                </Typography>
              </Box>
              <Typography variant="body1" fontWeight={500}>
                {opp.customer}
              </Typography>
            </Box>

            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <BusinessIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                <Typography variant="caption" fontWeight={600} color="text.secondary">
                  Opportunity Name
                </Typography>
              </Box>
              <Typography variant="body1" fontWeight={500}>
                {opp.title}
              </Typography>
            </Box>

            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <LocationOnIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                <Typography variant="caption" fontWeight={600} color="text.secondary">
                  Country
                </Typography>
              </Box>
              <Typography variant="body1" fontWeight={500}>
                {opp.country} ({opp.countryCode})
              </Typography>
            </Box>

            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <PersonSearchIcon sx={{ fontSize: 18, color: 'primary.main' }} />
                <Typography variant="caption" fontWeight={600} color="text.secondary">
                  Lead Pricer
                </Typography>
              </Box>
              <Typography variant="body1" fontWeight={500}>
                {opp.lead_pricer?.[0]?.name ?? '—'}
              </Typography>
            </Box>
          </Box>
        </ModernCard>

        <ModernCard
          icon={<GroupIcon />}
          title="Bid Team"
          subtitle="Manage bid team members for this opportunity"
          elevated
          gradient
          sx={{ mb: 3 }}
          headerAction={
            hasAccess ? (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon sx={{ color: 'common.white' }} />}
                onClick={openAddPanel}
                sx={{ color: 'common.white', mt: 1, mr: 1 }}
              >
                Add Members
              </Button>
            ) : undefined
          }
        >
          <Divider sx={{ mb: 2 }} />

          {loadingTeam ? (
            <Box sx={{ py: 3, display: 'flex', justifyContent: 'center' }}>
              <CircularProgress size={28} />
            </Box>
          ) : team.length === 0 ? (
            <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
              No bid team members yet.
            </Typography>
          ) : (
            <List dense disablePadding>
              {team.map((member) => (
                <ListItem
                  key={member.id}
                  secondaryAction={
                    <Tooltip title="Remove" arrow>
                      <span>
                        <IconButton
                          size="small"
                          onClick={() => removeMember(member)}
                          disabled={isSaving}
                        >
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </span>
                    </Tooltip>
                  }
                >
                  <ListItemAvatar>
                    <Avatar src={member.avatarUrl} alt={member.displayName} sx={{ bgcolor: 'primary.light' }}>
                      {member.displayName?.charAt(0)}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Typography variant="body1" fontWeight={600}>
                          {member.displayName}
                        </Typography>
                        {member.role ? (
                          <ModernChip label={member.role} colorVariant="primary" size="small" />
                        ) : null}
                      </Stack>
                    }
                    secondary={member.email}
                  />
                </ListItem>
              ))}
            </List>
          )}
        </ModernCard>

        <ModernCard
          icon={<AssignmentIcon />}
          title="Rounds"
          subtitle="View and manage pricing rounds for this opportunity"
          elevated
          gradient
        >
          <Box sx={{ mt: 2 }}>
            <RoundListView opportunityId={Number(id)} showToolbar={true} />
          </Box>
        </ModernCard>

        <Drawer
          anchor="right"
          open={panelOpen}
          onClose={closePanel}
          PaperProps={{
            sx: {
              // width: { xs: '100%', sm: 520 },
              // p: 2,
              // pt: 8,
              width: { xs: '100%', sm: 520 },
              px: 3,
              py: 2.5,
              pt: 8,
              display: 'flex',
              flexDirection: 'column',
            },
          }}
        >
          <Stack direction="row" justifyContent="space-between" alignItems="center"
            sx={{
              //mb: 1 
              mb: 2,
              pb: 1
            }}>
            <Typography
              //variant="h6" fontWeight={700}>
              variant="h5"
              fontWeight={700}
              sx={{
                color: 'text.primary',
                letterSpacing: '-0.3px'
              }}
            >
              Add Bid Team Members

            </Typography>
            <IconButton onClick={closePanel}><CloseIcon /></IconButton>
          </Stack>
          <Divider sx={{ mb: 3 }} />

          <Stack spacing={3}>
            <Box
              sx={{
                '& .ms-BasePicker': {
                  minHeight: 56,
                  border: '1px solid rgba(0,0,0,0.23)',
                  borderRadius: '12px',
                  px: 1.5,
                  py: 1,
                  backgroundColor: '#fff',
                  transition: 'all 0.2s ease',
                },

                '& .ms-BasePicker:hover': {
                  borderColor: '#1e1450',
                },

                '& .ms-BasePicker:focus-within': {
                  border: '2px solid #1e1450',
                  padding: '15px',
                },

                '& .ms-TextField-fieldGroup': {
                  border: 'none !important',
                  background: 'transparent',
                },

                '& .ms-BasePicker-text': {
                  border: 'none !important',
                },

                '& .ms-TextField': {
                  marginTop: '8px',
                },

                '& .ms-Label': {
                  fontWeight: 600,
                  fontSize: '15px',
                  marginBottom: '8px',
                  color: '#1f1f1f',
                },
              }}
            >
              <PeoplePicker
                context={peoplePickerContext as any}
                titleText="Additional Bid Team Members"
                personSelectionLimit={100}
                principalTypes={[PrincipalType.User]}
                showtooltip={true}
                required={false}
                resolveDelay={500}
                onChange={(items: IPersonaProps[] = []) => {
                  const mapped = items.map((p) => ({
                    displayName: p.text ?? '',
                    email: p.secondaryText,
                  }));
                  setAdhocPeople(mapped);
                }}
              />
            </Box>

            {adhocPeople.length > 0 && (
              <List dense>
                {adhocPeople.map((p) => (
                  <ListItem key={p.email || p.displayName}>
                    <ListItemAvatar>
                      <Avatar sx={{ bgcolor: 'primary.light' }}>
                        {(p.displayName || '?').charAt(0)}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary={p.displayName} secondary={p.email} />
                  </ListItem>
                ))}
              </List>
            )}
          </Stack>

          {/* <Divider sx={{ my: 2 }} /> */}
          <Divider sx={{ mt: 3, mb: 2 }} />

          {toast && (
            <Box sx={{ mb: 3 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )}

          <Stack direction="row" spacing={1.5} justifyContent="flex-end" alignItems="center"
            sx={{
              pt: 1,
              pb: 1
            }}>
            <Button variant="text" onClick={closePanel} disabled={isSaving}>
              Cancel
            </Button>

            {/* <Button
              variant="contained"
              color="primary"
              startIcon={<SaveIcon sx={{ color: 'white' }} />}
              onClick={savePanel}
              disabled={isSaving}
              sx={{ color: 'white' }}
            >
              {isSaving ? 'Saving...' : 'Save'}
            </Button> */}
            <Button
              variant="contained"
              color="primary"
              startIcon={<SaveIcon sx={{ color: '#fff !important' }} />}
              onClick={savePanel}
              disabled={isSaving}
              sx={{
                color: '#fff !important',
                backgroundColor: '#3d2fa0',

                '&.Mui-disabled': {
                  color: '#fff !important',
                  backgroundColor: '#3d2fa0',
                  opacity: 0.7,
                },

                '& .MuiButton-startIcon': {
                  color: '#fff !important',
                },
              }}
            >
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </Stack>
        </Drawer>
      </Box>
    </Fade >
  );
}