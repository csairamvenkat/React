import * as React from "react";
import {
  Box,
  Typography,
  Button,
  Chip,
  CircularProgress,
} from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";
import { ApiDataProvider } from "../../../api/ApiDataProvider";
import { useCrumbs } from "../../shell/CrumbContext";

import SearchIcon from "@mui/icons-material/Search";
import { TextField, InputAdornment, Switch, FormControlLabel } from "@mui/material";


import PersonIcon from "@mui/icons-material/Person";
import AssignmentIcon from "@mui/icons-material/Assignment";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import { ModernDataTable, ModernChip, ModernButton } from "../../shared/mui";
import PeopleIcon from "@mui/icons-material/People";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import HourglassBottom from "@mui/icons-material/HourglassBottom";


interface UnifiedFileItem {
  id: string | number;
  name: string;
  opportunityTitle: string;
  opportunityCustomer: string;
  roundNumber: number;
  scenario: string;
  scenarioDescription: string;
  inputType: string;
  submissionType: string;
  versionNumber: string | null;
  status: string;
  revisionNumber: number | null;
  modified: string | null;
  stakeholderName: string;
  stakeholderCode: string;
  lastRevisionAttempt?: string | null;
  revisionAttempt?: string | null;
  notifyUsers?: { name: string; email: string }[];
  additionalTeam?: { name: string; email: string }[];
  isCurrentVersion?: string;
  dueDate?: string | null;
  draftDueDate?: string | null;
  submittedOn?: string | null;
  approvedOn?: string | null;
  submittedBy?: { name?: string; email?: string; login_id?: string };
  approvedBy?: { name?: string; email?: string; login_id?: string };
  isRevisionRequested: boolean | null;
}

export default function StakeholderDetailsPage() {

  const { setNames } = useCrumbs();

  const cfg = (window as any).TENANT_CONFIG;
  const spfxContext = (window as any).spfxContext;

  const api = React.useMemo(
    () =>
      new ApiDataProvider(spfxContext, {
        resource: cfg.apiResource,
        baseUrl: cfg.apiBaseUrl,
      }),
    [cfg, spfxContext]
  );


  let currentUserEmail = "";
  if ((window as any)?.spfxContext?.pageContext?.user?.email == "") {
    currentUserEmail = (window as any)?.spfxContext?.pageContext?.user?.loginName
      ?.toLowerCase();
  } else {
    currentUserEmail = (window as any)?.spfxContext?.pageContext?.user?.email
      ?.toLowerCase()
  }

  const [rows, setRows] = React.useState<UnifiedFileItem[]>([]);
  const [loading, setLoading] = React.useState(true);

  const [searchText, setSearchText] = React.useState("");
  // const [isPending, setIsPending] = React.useState(true);
  //const [mode, setMode] = React.useState<"pending" | "my">("pending");
  const [mode, setMode] = React.useState<
    "pending" | "my" | "mypending"
  >("pending");

  const [query, setQuery] = React.useState({
    page: 1,
    limit: 10,
    // isPending: true,
    // myRecord: true
  });

  const [totalRecords, setTotalRecords] = React.useState(0);
  const [submittingId, setSubmittingId] = React.useState<string | number | null>(null);

  // const [toggleOn, setToggleOn] = React.useState(false);
  const [selectedStatuses, setSelectedStatuses] = React.useState<string[]>([]);

  const [paginationModel, setPaginationModel] = React.useState({
    page: 0,
    pageSize: 10,
  });
  const [filterModel, setFilterModel] = React.useState({
    items: [],
  });

  const statusList = ["Unselect All", "Validated", "Draft Validated", "Submitted", "Rejected", "Retracted", "Revision Requested", "Created"];
  const myPendingStatuses = [
    "Created",
    "Retracted",
    "Rejected",
    "revision_requested"
  ];
  const statusColors: Record<string, { bg: string; color: string }> = {
    "Unselect All": { bg: '#eeeeee', color: '#424242' },
    Validated: { bg: '#e8f5e9', color: '#2e7d32' },
    "Draft Validated": {
      bg: '#e8f5e9',
      color: '#2e7d32'
    },
    Submitted: { bg: '#fff8e1', color: '#ed6c02' },
    Rejected: { bg: '#ffebee', color: '#d32f2f' },
    // Retracted: { bg: '#e6e4fc', color: '#221854' },
    Retracted: { bg: '#fddede', color: '#d32f2f' },
    "Revision Requested": { bg: '#e3f2fd', color: '#1565c0' },
    Created: { bg: '#f5f5f5', color: '#616161' },
  };
  const dueDateColors = [
    {
      min: -9999,
      max: 2,
      bg: "#ffcdd2"
    }, // red

    {
      min: 3,
      max: 5,
      bg: "#fff59d"
    }, // amber

    {
      min: 6,
      max: 7,
      bg: "#bbdefb"
    } // light blue
  ];

  // function mapStatusForApi(status: string) {
  //   return status === "Validated" ? "Approved" : status;
  // }
  function mapStatusForApi(status: string) {

    if (status === "Validated") {
      return "Approved";
    }
    if (status === "Draft Validated") {
      return "DraftApproved";
    }
    if (status === "Revision Requested") {
      return "revision_requested";
    }

    return status;
  }


  // const getDueDateStyle = (dueDate?: string | null, workflowStatus?: string | null) => {

  //   if (mode !== "mypending" && mode !== "pending") {
  //     return {};
  //   }

  //   if (workflowStatus === "Approved" || workflowStatus === "Validated") {
  //     return {};
  //   }

  //   if (!dueDate) {
  //     return {};
  //   }

  //   const today = new Date();
  //   const due = new Date(dueDate);

  //   today.setHours(0, 0, 0, 0);
  //   due.setHours(0, 0, 0, 0);

  //   const diffInMs = due.getTime() - today.getTime();

  //   const diffInDays = Math.floor(
  //     diffInMs / (1000 * 60 * 60 * 24)
  //   );

  //   if (diffInDays <= 2) {
  //     return {
  //       backgroundColor: "#ffcdd2",
  //       color: "#000",
  //       fontWeight: 600,
  //       borderRadius: "4px",
  //       px: 1,
  //       py: 0.5
  //     };
  //   }

  //   if (diffInDays >= 3 && diffInDays <= 5) {
  //     return {
  //       backgroundColor: "#fff59d",
  //       color: "#000",
  //       fontWeight: 600,
  //       borderRadius: "4px",
  //       px: 1,
  //       py: 0.5
  //     };
  //   }

  //   if (diffInDays >= 6 && diffInDays <= 7) {
  //     return {
  //       backgroundColor: "#bbdefb",
  //       color: "#000",
  //       fontWeight: 600,
  //       borderRadius: "4px",
  //       px: 1,
  //       py: 0.5
  //     };
  //   }

  //   return {};
  // };

  const getDueDateStyle = (dueDate?: string | null) => {
    if (!dueDate) return {};

    const today = new Date();
    const due = new Date(dueDate);

    today.setHours(0, 0, 0, 0);
    due.setHours(0, 0, 0, 0);

    const diffInDays = Math.floor(
      (due.getTime() - today.getTime()) /
      (1000 * 60 * 60 * 24)
    );

    if (diffInDays <= 2) {
      return {
        backgroundColor: "#ffcdd2",
        color: "#b71c1c",
        fontWeight: 600,
      };
    }

    if (diffInDays <= 5) {
      return {
        backgroundColor: "#fff59d",
        color: "#f57f17",
        fontWeight: 600,
      };
    }

    if (diffInDays <= 7) {
      return {
        backgroundColor: "#bbdefb",
        color: "#0d47a1",
        fontWeight: 600,
      };
    }

    return {
      backgroundColor: "#e8f5e9",
      color: "#1b5e20",
      fontWeight: 600,
    };
  };

  const getDueDateRowClass = (dueDate?: string | null) => {

    if (mode !== "mypending") {
      return "";
    }

    if (!dueDate) {
      return "";
    }

    const today = new Date();

    const due = new Date(dueDate);

    today.setHours(0, 0, 0, 0);
    due.setHours(0, 0, 0, 0);

    const diffInMs = due.getTime() - today.getTime();

    const diffInDays = Math.floor(
      diffInMs / (1000 * 60 * 60 * 24)
    );

    if (diffInDays <= 2) {
      return "due-red";
    }

    if (diffInDays >= 3 && diffInDays <= 5) {
      return "due-amber";
    }

    if (diffInDays >= 6 && diffInDays <= 7) {
      return "due-lightblue";
    }

    return "";
  };


  React.useEffect(() => {
    setNames((prev) => ({
      ...prev,
      stakeholderName: "Stakeholder",
    }));
  }, []);




  React.useEffect(() => {
    const t = setTimeout(() => {
      setPaginationModel(prev => ({ ...prev, page: 0 }));
      setQuery(prev => ({ ...prev, page: 1 }));
    }, 500);

    return () => clearTimeout(t);
  }, [searchText]);

  React.useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);

        // const { myRecord, isPending } = getApiFlags(mode, toggleOn);

        // const resp = await api.getStakeholderAllInputs({
        //   ...query,
        //   myRecord,
        //   isPending,
        //   search_text: searchText,
        // });
        //const myRecord = mode === "pending";
        const myRecord = mode === "pending" || mode === "mypending";
        const isMyPending = mode === "mypending";

        //const mappedStatuses = selectedStatuses.map(mapStatusForApi);
        // const mappedStatuses = selectedStatuses
        //   .filter(s => s !== "Unselect All")
        //   .map(mapStatusForApi);

        let mappedStatuses = selectedStatuses
          .filter(s => s !== "Unselect All")
          .map(mapStatusForApi);

        if (mode === "mypending" && mappedStatuses.length === 0) {
          mappedStatuses = myPendingStatuses;
        }

        const resp = await api.getStakeholderAllInputs({
          page: query.page,
          limit: query.limit,
          myRecord,
          search_text: searchText,
          workflowStatuses: mappedStatuses,
          isMyPending
        });


        setTotalRecords(Number(resp?.total ?? 0));

        const data = Array.isArray(resp.data) ? resp.data : [];

        const mapped: UnifiedFileItem[] = data.map((f: any) => {
          let status = f.workflowStatus ?? "-";

          if (status === "Approved") {
            status = "Validated";
          }

          if (status === "DraftApproved") {
            status = "Draft Validated";
          }

          return {
            id: f.id,
            name: f.opportunityTitle || "",
            opportunityTitle: f.opportunityTitle || "",
            opportunityCustomer: f.opportunityCustomer || "",
            roundNumber: Number(f.roundNumber || 1),

            scenario: f.scenarioName || "-",
            scenarioDescription: f.roundDescription || "-",

            inputType: mapInputType(f.inputType),
            submissionType: f.submissionType || "",
            versionNumber: f.versionNumber || null,

            status,
            revisionNumber: f.revisionNumber ?? 0,
            modified: f.exportedOn || f.createdOn || null,

            stakeholderCode: f.stakeholderCode || "",
            stakeholderName: (f.stakeholder || "").replace(/\"/g, ""),

            lastRevisionAttempt: f.lastRevisionAttempt ?? null,
            revisionAttempt: f.revisionAttempt ?? null,
            isCurrentVersion: f.isCurrentVersion,
            notifyUsers: (f.notify_users || []).map((u: any) => ({
              name: u.name,
              email: u.email
            })),

            additionalTeam: (f.additional_stakeholders || []).map((u: any) => ({
              name: u.name,
              email: u.email
            })),

            dueDate: f.dueDate || null,
            draftDueDate: f.draftDueDate || null,
            submittedOn: f.submittedOn || null,
            approvedOn: f.approvedOn || null,
            submittedBy: f.submittedBy ?? {},
            approvedBy: f.approvedBy ?? {},
            isRevisionRequested: f.isRevisionRequested
          };
        });

        setRows(mapped);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [query, mode, searchText, selectedStatuses]);
  // }, [query, mode, toggleOn, searchText]);
  // }, [query, isPending]);

  function isUserInNotifyOrTeam(
    row: UnifiedFileItem,
    currentEmail: string
  ): boolean {
    if (!currentEmail) return false;

    const notifyMatch = (row.notifyUsers ?? []).some(
      u => u.email?.toLowerCase() === currentEmail
    );

    const teamMatch = (row.additionalTeam ?? []).some(
      u => u.email?.toLowerCase() === currentEmail
    );

    return notifyMatch || teamMatch;
  }

  // function getApiFlags(mode: "pending" | "my", toggle: boolean) {
  //   if (mode === "pending") {
  //     return {
  //       myRecord: true,
  //       isPending: !toggle
  //     };
  //   }

  //   return {
  //     myRecord: false,
  //     isPending: !toggle
  //   };
  // }


  const handleSubmit = async (row: UnifiedFileItem) => {
    try {
      setSubmittingId(row.id);

      const folderUrl = [
        cfg.siteUrl,
        "EUR",
        encodeURIComponent(row.opportunityCustomer),
        encodeURIComponent(row.opportunityTitle),
        encodeURIComponent(`RND ${row.roundNumber}`),
        encodeURIComponent(row.stakeholderCode),
      ].join("/");

      window.open(folderUrl, "_blank");
    } finally {
      setSubmittingId(null);
    }
  };

  const getStatusColorVariant = (status: string): 'success' | 'warning' | 'error' | 'info' | 'primary' | 'default' => {
    const s = (status || '').toLowerCase();
    if (s.includes('approved')) return 'success';
    if (s.includes('validated')) return 'success';
    if (s.includes('submitted') || s.includes('pending')) return 'warning';
    if (s.includes('reject') || s.includes('failed') || s.includes('retract')) return 'error';
    if (s.includes('revision')) return 'info';
    return 'default';
  };

  const baseColumns: GridColDef[] = [
    {
      field: "opportunityTitle",
      headerName: "Opportunity",
      align: "left",
      headerAlign: "left",
      width: 180,
      minWidth: 180,
      renderCell: (params) => {
        const row = params.row as UnifiedFileItem;

        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center",
            }}
          >
            <Typography
              variant="body2"
              sx={{
                cursor: "pointer",
                color: "primary.main",
                fontWeight: 600,
                textOverflow: "ellipsis",
                overflow: "hidden",
                whiteSpace: "nowrap",
                width: "100%",
                textAlign: "left"
              }}
              title={params.value}
              onClick={() => handleSubmit(row)}
            >
              {params.value}
            </Typography>
          </Box>
        );
      },
    },
    {
      field: "roundNumber",
      headerName: "Round No.",
      width: 100,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          {params.value}
        </Box>
      )
    },
    {
      field: "templateVersion",
      headerName: "Template - Version",
      width: 180,
      align: "left",
      headerAlign: "left",
      sortable: false,
      renderCell: (params) => {
        const row = params.row as UnifiedFileItem;

        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center",
            }}
          >
            <Typography variant="body2">
              {row.stakeholderName || "-"}
              {row.versionNumber ? ` - ${row.versionNumber}` : ""}
            </Typography>
          </Box>
        );
      },
    },
    {
      field: "datasetRevisionInputType",
      headerName: "Dataset - Revision",
      width: 250,
      align: "left",
      headerAlign: "left",
      sortable: false,
      renderCell: (params) => {
        const row = params.row as UnifiedFileItem;

        const displayText = `${row.scenario || "-"} - ${row.revisionNumber ?? 0
          }`;

        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center",
              gap: 0.5,
              flexWrap: "nowrap",
              whiteSpace: "nowrap",
              overflow: "hidden",
            }}
          >
            <Typography
              variant="body2"
              sx={{
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                minWidth: 0,
                textAlign: "left",
              }}
              title={displayText}
            >
              {displayText}
            </Typography>

            {row.submissionType === "Draft" && (
              <>
                <Chip
                  label="Draft"
                  size="small"
                  sx={{
                    height: 22,
                    fontSize: "0.7rem",
                    color: "#ed6c02",
                    border: "1px solid #ed6c02",
                    backgroundColor: "#fff8e1",
                    fontWeight: 500,
                    flexShrink: 0,
                  }}
                />
              </>
            )}
          </Box>
        );
      },
    },
    {
      field: "status",
      headerName: "Status",
      width: 120,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => {
        const originalStatus = params.value || '';
        const row = params.row;

        const showRevisionIcon = row.isRevisionRequested == true;

        const v = showRevisionIcon
          ? "Revision Requested"
          : originalStatus;

        if (!v || v === '—') {
          return (
            <Box
              sx={{
                width: '100%',
                height: '100%',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <Typography variant="body2">—</Typography>
            </Box>
          );
        }

        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-start",
              py: 0.5   // slightly increase top/bottom spacing
            }}
          >
            <ModernChip
              label={v}
              size="small"
              colorVariant={getStatusColorVariant(v) as any}
              sx={{
                my: 0.25
              }}
            />
          </Box>
        );
      }
    },
    {
      field: "submittedOn",
      headerName: "Submitted On",
      width: 105,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          {typeof params.value === "string" ? new Date(params.value).toLocaleDateString() : "-"}
        </Box>
      )
    },
    {
      field: "dueDate",
      headerName: "Due Date",
      width: 105,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => {
        const row = params.row as UnifiedFileItem;

        const displayDueDate =
          row.submissionType === "Draft"
            ? row.draftDueDate
            : row.dueDate;

        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center"
            }}
          >
            <Box
              sx={{
                ...getDueDateStyle(displayDueDate),
                px: 1.5,
                py: 0.5,
                borderRadius: "4px",
                fontWeight: 600,
                minWidth: 90,
                textAlign: "center"
              }}
            >
              {typeof displayDueDate === "string"
                ? new Date(displayDueDate).toLocaleDateString()
                : "-"}
            </Box>
          </Box>
        );
      }
    },
    {
      field: "approvedOn",
      headerName: "Validated On",
      width: 105,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
          }}
        >
          {typeof params.value === "string" ? new Date(params.value).toLocaleDateString() : "-"}
        </Box>
      )
    }
  ];

  const notifyColumn: GridColDef = {
    field: "contacts",
    //headerName: "Notify / Team",
    headerName: "Input Provider",
    width: 180,
    align: "left",
    headerAlign: "left",
    sortable: false,
    renderCell: (params) => {
      const submittedByName: string | undefined = params.row.submittedBy?.name;
      const users = params.row.notifyUsers || [];
      const team = params.row.additionalTeam || [];

      if (submittedByName) {
        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "center",
              gap: 0.5,
            }}
          >
            <CheckCircleIcon sx={{ color: "#2e7d32", fontSize: 16, flexShrink: 0 }} />
            <Chip
              label={submittedByName}
              size="small"
              variant="filled"
              color="success"
              sx={{ height: 22, fontSize: "0.7rem", px: 0.5 }}
            />
          </Box>
        );
      }

      if (!users.length && !team.length) {
        return (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              flexDirection: "row",
              justifyContent: "flex-start",
              alignItems: "center",
              gap: 0.5,
            }}
          >
            {(mode === "pending" || mode === "my") && <HourglassBottom sx={{ color: "#ed6c02", fontSize: 16, flexShrink: 0 }} />}
            <Typography variant="caption" sx={{ color: "#ed6c02" }}>-</Typography>
          </Box>
        );
      }

      const allUsers = [...users, ...team];
      return (
        <Box
          sx={{
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 0.5,
          }}
        >
          {allUsers.map((u: any, i: number) =>
            i === 0 ? (
              <Box key={i} sx={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 0.5 }}>
                {(mode === "pending" || mode === "my") && <HourglassBottom sx={{ color: "#ed6c02", fontSize: 16, flexShrink: 0 }} />}
                <Chip
                  label={u.name || u}
                  size="small"
                  variant="filled"
                  color="default"
                  sx={{ height: 22, fontSize: "0.7rem", px: 0.5 }}
                />
              </Box>
            ) : (
              <Chip
                key={i}
                label={u.name || u}
                size="small"
                variant="filled"
                color="default"
                sx={{ height: 22, fontSize: "0.7rem", px: 0.5 }}
              />
            )
          )}
        </Box>
      );
    }
  };
  const removeAllFilters = () => {

    // clear status chips
    setSelectedStatuses([]);

    // clear search text
    setSearchText("");

    // clear datagrid column filters
    setFilterModel({
      items: [],
    });

    // reset pagination
    setPaginationModel(prev => ({
      ...prev,
      page: 0,
    }));

    setQuery(prev => ({
      ...prev,
      page: 1,
    }));
  };
  const actionColumn: GridColDef = {
    field: "actions",
    headerName: "Action",
    width: 180,
    align: "center",
    headerAlign: "center",
    sortable: false,
    renderCell: (params) => {
      const row = params.row as UnifiedFileItem;
      const isLoading = submittingId === row.id;

      let label = "Browse Directory";

      const canResubmit =
        row.isCurrentVersion === "1" &&
        row.isRevisionRequested == true &&
        isUserInNotifyOrTeam(row, currentUserEmail);

      // if (row.revisionAttempt === "1"){
      // }

      if (canResubmit) {
        label = "Re Submit";
      } else if (row.status === "Created") {
        label = "Submit";
      }

      return (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "100%"
          }}
        >
          <ModernButton
            variant={
              label == 'Browse Directory' ? 'outlined' : 'contained'
            }
            size="small"
            sx={{
              // minHeight: 28,
              // px: 1.25,
              // fontSize: "0.75rem"
              minHeight: 24,
              height: 24,
              minWidth: 120,
              px: 0.75,
              py: 0,
              fontSize: "0.72rem",
              lineHeight: 1,
              borderRadius: "6px"
            }}
            onClick={() => handleSubmit(row)}
            disabled={isLoading}
          >
            {isLoading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              label
            )}
          </ModernButton>
        </Box>
      );
    }
  };

  const columns = React.useMemo(() => {
    // const cols = [...baseColumns];

    // if (mode === "my") {
    //   cols.push(notifyColumn);
    // }

    // cols.push(actionColumn);
    const cols = [...baseColumns, actionColumn, notifyColumn];
    return cols;
  }, [mode, submittingId]);


  return (
    <Box sx={{ p: 0 }}>
      <Typography variant="h5" mb={2}>
        Stakeholders
      </Typography>

      <Box mb={2}>
        <Box mb={1.5}>
          <TextField
            fullWidth
            placeholder="Filter by opportunity title/customer, stakeholder, or status"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: "primary.main" }} />
                </InputAdornment>
              )
            }}
            sx={{
              width: "100%",
              "& .MuiOutlinedInput-root": {
                backgroundColor: "background.paper"
              }
            }}
          />
        </Box>

        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          flexWrap="wrap"
          gap={2}
        >
          <Box display="flex" gap={1.5} alignItems="center">
            <Chip
              icon={<PendingActionsIcon sx={{ fontSize: 18 }} />}
              label="My Pending Tasks"
              clickable
              color={mode === "mypending" ? "primary" : "default"}
              variant={mode === "mypending" ? "filled" : "outlined"}
              onClick={() => {
                setMode("mypending");

                setPaginationModel({
                  page: 0,
                  pageSize: paginationModel.pageSize
                });

                setQuery(prev => ({
                  ...prev,
                  page: 1,
                  limit: paginationModel.pageSize
                }));
              }}
              sx={{ fontWeight: mode === "mypending" ? 600 : 400 }}
            />
            <Chip
              icon={<AssignmentIcon sx={{ fontSize: 18 }} />}
              label="My Tasks"
              clickable
              color={mode === "pending" ? "primary" : "default"}
              variant={mode === "pending" ? "filled" : "outlined"}
              onClick={() => {
                setMode("pending");
                setPaginationModel({ page: 0, pageSize: paginationModel.pageSize });

                setQuery(prev => ({
                  ...prev,
                  page: 1,
                  limit: paginationModel.pageSize
                }));
              }}
              sx={{ fontWeight: mode === "pending" ? 600 : 400 }}
            />

            <Chip
              icon={<PeopleIcon sx={{ fontSize: 18 }} />}
              label="Show All Records"
              clickable
              color={mode === "my" ? "primary" : "default"}
              variant={mode === "my" ? "filled" : "outlined"}
              onClick={() => {
                setMode("my");
                setPaginationModel({ page: 0, pageSize: paginationModel.pageSize });

                setQuery(prev => ({
                  ...prev,
                  page: 1,
                  limit: paginationModel.pageSize
                }));
              }}
              sx={{ fontWeight: mode === "my" ? 600 : 400 }}
            />
          </Box>
          <Box
            display="flex"
            justifyContent="flex-end"
            mb={1}
          >
            {/* <Chip
              label="Remove Filters"
              clickable
              onClick={removeAllFilters}
              sx={{
                backgroundColor: "#212121",
                color: "#fff",
                fontWeight: 600
              }}
            /> */}
          </Box>
          <Box
            display="flex"
            gap={1}
            flexWrap="wrap"
            justifyContent="flex-end"
          >
            {statusList.map((status) => {
              const mappedStatus = mapStatusForApi(status);
              const isDisabledInMyPending =
                mode === "mypending" &&
                status !== "Unselect All" &&
                !myPendingStatuses.includes(mappedStatus);
              const isSelected = selectedStatuses.includes(status);

              const colors = statusColors[status] || {
                bg: '#f5f5f5',
                color: '#000'
              };

              return (
                <Chip
                  key={status}
                  size="small"
                  label={status}
                  clickable
                  disabled={isDisabledInMyPending}
                  onClick={() => {
                    if (isDisabledInMyPending) {
                      return;
                    }
                    if (status === "Unselect All") {
                      setSelectedStatuses([]);
                    }
                    else {
                      setSelectedStatuses(prev => {
                        if (prev.includes(status)) {
                          return prev.filter(s => s !== status);
                        }
                        return [...prev, status];
                      });
                    }

                    setPaginationModel(prev => ({ ...prev, page: 0 }));
                    setQuery(prev => ({ ...prev, page: 1 }));
                  }}
                  sx={{
                    backgroundColor: colors.bg,
                    border: isSelected
                      ? `2px solid ${colors.color}`
                      : '1px solid transparent',
                    color: colors.color,
                    fontWeight: 600,
                    opacity: isSelected ? 1 : 0.8,
                    '&:hover': { opacity: 1 }
                  }}
                />
              );
            })}
          </Box>
        </Box>

      </Box>

      <Box sx={{ p: 0 }}>
        <ModernDataTable
          rows={rows}
          columns={columns}
          // sx={{
          //   "& .MuiDataGrid-cell": {
          //     display: "flex",
          //     alignItems: "center"
          //   },

          //   "& .MuiDataGrid-cell[data-field='actions']": {
          //     display: "flex",
          //     alignItems: "center",
          //     justifyContent: "center"
          //   }
          // }}

          sx={{
            "& .MuiDataGrid-cell": {
              display: "flex",
              alignItems: "center",
            },

            "& .MuiDataGrid-cell[data-field='actions']": {
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            },

            // Whole row colors
            "& .row-status-approved, & .row-status-approved .MuiDataGrid-cell": {
              backgroundColor: "#e8f5e9 !important",
            },

            "& .row-status-pending, & .row-status-pending .MuiDataGrid-cell": {
              backgroundColor: "#fff8e1 !important",
            },

            "& .row-status-rejected, & .row-status-rejected .MuiDataGrid-cell": {
              backgroundColor: "#ffebee !important",
            },

            "& .row-status-retracted, & .row-status-retracted .MuiDataGrid-cell": {
              backgroundColor: "#e6e4fc !important",
            },

            "& .row-status-created, & .row-status-created .MuiDataGrid-cell": {
              backgroundColor: "#f5f5f5 !important",
            },
          }}

          getRowClassName={(params) => {
            const row = params.row as UnifiedFileItem;

            // Revision Requested has priority over the original status
            if (row.isRevisionRequested === true) {
              return "row-status-revision";
            }

            const status = String(row.status || "").toLowerCase();

            if (
              status.includes("approved") ||
              status.includes("validated")
            ) {
              return "row-status-approved";
            }

            if (
              status.includes("submitted") ||
              status.includes("pending")
            ) {
              return "row-status-pending";
            }

            if (status.includes("created")) {
              return "row-status-created";
            }

            if (status.includes("reject")) {
              return "row-status-rejected";
            }

            if (status.includes("retract")) {
              return "row-status-retracted";
            }

            return "";
          }}
          getRowHeight={() => 'auto'}
          loading={loading}
          filterModel={filterModel}
          onFilterModelChange={(model) => setFilterModel(model)}
          serverPagination
          rowCount={totalRecords}
          paginationModel={paginationModel}
          onPaginationModelChange={(model) => {
            setPaginationModel(model);
            // setQuery({
            //   page: model.page + 1,
            //   limit: model.pageSize
            // });

            setQuery(prev => ({
              ...prev,
              page: model.page + 1,
              limit: model.pageSize
            }));

          }}
          pageSizeOptions={[10, 25, 50]}
          // sx={{
          //   height: '100%'
          // }}
          autoHeight
          elevation={2}
        />
      </Box>
    </Box>
  );
}

function mapInputType(type: string) {
  switch (type) {
    case "CollectInput":
      return "Collect Input";
    case "useStandardInput":
      return "Use Standard Input";
    case "usePreviousRoundInput":
      return "Previous Round";
    default:
      return type || "-";
  }
}