import * as React from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Drawer,
  MenuItem,
  Divider,
  Fade,
  Stack,
  Link as MuiLink,
} from '@mui/material';
import DescriptionIcon from '@mui/icons-material/Description';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { GridColDef } from '@mui/x-data-grid';
import { ApiDataProvider } from '../../../api/ApiDataProvider';
import { triggerFlow } from '../../../flow/flowclient';
import { useCrumbs } from '../../shell/CrumbContext';
import { PageContainer } from '../../shared/PageContainer';
import {
  ModernCard,
  ModernButton,
  ModernTextField,
  ModernAlert,
  ModernLoadingState,
  ModernEmptyState,
  ModernDataTable,
  ModernChip,
} from '../../shared/mui';

type YesNo = '1' | '0';

interface FileItem {
  id: string | number;
  roundNumber: number | null;
  name: string;
  url: string;
  fileRelPath: string;
  size?: number | null;
  modified?: string | null;
  status?: string | null;
  scenario?: string | null;
  revisionNumber: number | null;
  inputType: string | null;
  isCurrentVersion?: YesNo;
  isCurrentApproved?: YesNo;
  listItemId?: number | null;
  uploadedBy?: { name?: string; email?: string };
  modifiedBy?: { name?: string; email?: string };
  notifyUsers?: { name?: string; email?: string; login_id?: string }[];
  stakeholderCode?: string;
  revisionAttempt?: number | null;
  lastRevisionAttempt?: string | null;
}

const decisionOptions = [
  { key: 'Approve', text: 'Approve' },
  { key: 'Reject', text: 'Reject' },
];

const safeReadJson = async (response: any) => {
  try {
    return await response.json();
  } catch {
    return null;
  }
};

const isFetchResponse = (res: any): res is Response =>
  typeof res?.ok === 'boolean';

export default function TemplateFilesPage() {
  const { id, roundId, templateId } = useParams<{ id: string; roundId: string; templateId: string }>();
  const { names, setNames } = useCrumbs();
  const { opportunityName, customerName, roundName, templateName } = names;
  const cfg = (window as any).TENANT_CONFIG;
  const ALLOWED_GROUP_NAME = 'Pricing';

  const api = React.useMemo(
    () => new ApiDataProvider((window as any).spfxContext, { resource: cfg.apiResource, baseUrl: cfg.apiBaseUrl }),
    [cfg]
  );

  const [files, setFiles] = React.useState<FileItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [showPanel, setShowPanel] = React.useState(false);
  const [activeFile, setActiveFile] = React.useState<FileItem | null>(null);

  const [drawerMode, setDrawerMode] = React.useState<'approval' | 'revision'>('approval');

  const [decision, setDecision] = React.useState('');
  const [comment, setComment] = React.useState('');
  const [revisionComment, setRevisionComment] = React.useState('');

  const [currentApproved, setCurrentApproved] = React.useState<FileItem[]>([]);
  const [inProgress, setInProgress] = React.useState<FileItem[]>([]);
  const [previousVersions, setPreviousVersions] = React.useState<FileItem[]>([]);

  const [saving, setSaving] = React.useState(false);
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);

  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);

  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);

  const getCurrentUser = () => {
    const u = (window as any)?.spfxContext?.pageContext?.user;
    return {
      name: u?.displayName ?? '',
      email: u?.email ?? u?.loginName ?? '',
    };
  };

  const toYesNo = (v: any): YesNo => (v === 1 || v === '1' || v === true ? '1' : '0');

  const getStatusColorVariant = (
    status: string
  ): 'success' | 'warning' | 'error' | 'info' | 'default' => {
    const s = (status || '').toLowerCase();
    if (s.includes('validated') || s.includes('approved')) return 'success';
    if (s.includes('pending') || s.includes('submitted')) return 'warning';
    if (s.includes('reject') || s.includes('failed')) return 'error';
    if (s.includes('revision')) return 'info';
    return 'default';
  };

  const mapApiToFileItem = (f: any): FileItem => {
    const rel = f.fileRelPath || '';
    const name = rel.split('/').pop() || rel || 'Unknown file';
    const absUrl = rel && cfg?.siteBaseUrl ? `${cfg.siteBaseUrl}${rel}` : rel;

    return {
      id: f.id ?? f.listItemId ?? name,
      roundNumber: f.roundNumber,
      name,
      url: absUrl,
      fileRelPath: rel,
      size: null,
      modified: f.exportedOn ?? f.createdOn ?? null,
      status: f.workflowStatus ?? null,
      scenario: f.scenarioName ?? null,
      revisionNumber: f.revisionNumber,
      inputType: f.inputType,
      isCurrentVersion: toYesNo(f.isCurrentVersion),
      isCurrentApproved: toYesNo(f.isCurrentApproved),
      listItemId: f.listItemId ?? null,
      uploadedBy: { name: f.uploadedByName ?? '', email: f.uploadedByEmail ?? '' },
      modifiedBy: { name: f.modifiedByName ?? '', email: f.modifiedByEmail ?? '' },
      notifyUsers: f.notifyUsers ?? [],
      stakeholderCode: f.stakeholderCode ?? null,
      revisionAttempt: f.revisionAttempt ?? null,
      lastRevisionAttempt: f.lastRevisionAttempt ?? null,
    };
  };

  React.useEffect(() => {
    loadData();
  }, [api, templateId, roundId, roundName]);
  // }, [api, templateId, cfg, roundId, setNames]);


  React.useEffect(() => {
    setNames(prev => ({
      ...prev,
      templateName: templateId
    }));
  }, [templateId, setNames]);


  const loadData = async () => {
    void (async () => {
      try {
        setLoading(true);

        // setNames(prev => ({
        //   ...prev,
        //   opportunityName: prev.opportunityName,
        //   customerName: prev.customerName,
        //   roundName: prev.roundName,
        //   templateName: templateId
        // }));


        const parsedRoundNumber =
          roundName && roundName.split(' ').length > 1
            ? Number(roundName.split(' ')[1])
            : null;


        if (!roundId || parsedRoundNumber === null) {
          setFiles([]);
          setCurrentApproved([]);
          setInProgress([]);
          setPreviousVersions([]);
          return;
        }

        const rawResp: unknown =  []; // await api.getAllCurrentStakeholersInputByRound(Number(roundId));

        if (!Array.isArray(rawResp)) {
          setFiles([]);
          setCurrentApproved([]);
          setInProgress([]);
          setPreviousVersions([]);
          setToast({
            severity: 'warning',
            text: 'API did not return a list. Please check the endpoint response.'
          });
          return;
        }
        const list = rawResp as any[];

        const results: FileItem[] = list.map(mapApiToFileItem);
        setFiles(results);

        const filterResult = results.filter(x => x.stakeholderCode === templateId && x.roundNumber === parsedRoundNumber)

        const curr = filterResult.filter(x => x.isCurrentApproved === '1' && (x.status || '').toLowerCase() === 'approved' && x.isCurrentVersion === '1');
        const prog = filterResult.filter(x => (x.status || '').toLowerCase() === 'submitted');
        const prev = filterResult.filter(
          x => (x.status || '').toLowerCase() === 'approved' && x.isCurrentVersion === '0'
        );

        setCurrentApproved(curr);
        setInProgress(prog);
        setPreviousVersions(prev);
      } catch (err: any) {
        setToast({ severity: 'error', text: `Failed to load files: ${err.message}` });
      } finally {
        setLoading(false);
      }
    })();
  }

  const submitToFlow = async () => {
    if (!activeFile || !decision) {
      setToast({
        severity: 'warning',
        text: 'Please select a decision before submitting.'
      });
      return;
    }

    try {
      setSaving(true);
      setShowPanel(false);
      setLoading(true);

      const notifyEmails = (activeFile.notifyUsers || [])
        .map((u: any) => u.email)
        .filter(Boolean)
        .join(';');

      let responseComplete;

      let roundNum = roundName && roundName.split(' ').length > 1 ? Number(roundName.split(' ')[1]) : 0;

      if (decision === 'Approve') {
        const completePayload = {
          opportunityId: Number(id),
          roundId: Number(roundId),
          roundNumber: roundNum,
          stakeholderCode: templateId,
          scenarioName: activeFile.scenario?.toString(),
          fileRelPath: activeFile.fileRelPath,
          processedData: {} as [],
          userStatus: 'Completed',
          workflowStatus: decision === 'Approve' ? 'Approved' : ''
        };

        responseComplete = await api.completeStakeholderInput(
          completePayload
        ) as any;
      } else {
        const rejectPayload = {
          opportunityId: Number(id),
          roundId: Number(roundId),
          roundNumber: roundNum,
          stakeholderCode: templateId,
          scenarioName: activeFile.scenario?.toString()
        };
        responseComplete = await api.rejectStakeholderInput(
          rejectPayload
        ) as any;
      }

      if (!responseComplete) {
        setToast({
          severity: 'error',
          text: 'Unable to reach server. Please check your network.'
        });
        return;
      }

      let data: any = null;

      if (isFetchResponse(responseComplete)) {
        if (!responseComplete.ok) {
          let errorMessage = 'Server error occurred. Please try again later.';

          try {
            const errorData = await responseComplete.json();
            if (errorData?.message) {
              errorMessage = errorData.message;
            }
          } catch {

          }

          setToast({ severity: 'error', text: errorMessage });
          return;
        }

        data = await responseComplete.json();
      }
      else {
        data = responseComplete;
      }

      if (!data?.id) {
        setToast({
          severity: 'error',
          text: 'Unexpected response from server.'
        });
        return;
      }

      const payload = {
        eventType: 'PricerDecision',
        opportunityId: id,
        roundId,
        templateId,
        decision,
        comment,
        context: {
          opportunityName,
          customerName
        },
        file: {
          name: activeFile.name,
          url: activeFile.fileRelPath,
          size: activeFile.size,
          modified: activeFile.modified,
          status: activeFile.status,
          scenario: activeFile.scenario
        },
        submittedAt: new Date().toISOString(),
        siteUrl: `${cfg.siteUrl}`,
        NotifyEmails: notifyEmails,
        webValidationUrl: `${cfg.serverRelativeUrl}`
      };

      await triggerFlow(payload, 'ApprovalFlow');

      await loadData();

      setActiveFile(null);
      setDecision('');
      setComment('');

      if (decision === 'Approve') {
        setToast({
          severity: 'success',
          text: 'The file has been validated and accepted. The stakeholder has been notified and the input is now confirmed for this round and scenario.'
        });
      }
      else {
        setToast({
          severity: 'warning',
          text: 'File Rejected'
        });
      }
    } catch (err: any) {
      setToast({
        severity: 'error',
        text: err?.message || 'Unexpected error occurred.'
      });
    } finally {
      setSaving(false);
      setLoading(false);
    }
  };


  const sendForRevision = async () => {
    if (!activeFile || !revisionComment.trim()) {
      setToast({ severity: 'warning', text: 'Please add a revision comment.' });
      return;
    }

    try {
      setSaving(true);
      setShowPanel(false);
      setLoading(true);

      const currentUser = getCurrentUser();


      const notifyEmails = (activeFile.notifyUsers || [])
        .map(u => u.email)
        .filter(Boolean)
        .join(';');

      let roundNum = roundName && roundName.split(' ').length > 1 ? Number(roundName.split(' ')[1]) : 0;

      await api.initiateRevision({
        opportunityId: Number(id),
        roundId: Number(roundId),
        roundNumber: roundNum,
        stakeholderCode: templateId ?? '',
        scenarioName: activeFile.scenario?.toString() ?? '',
      });

      const payload = {
        eventType: 'SendForRevision',
        opportunityId: id,
        roundId,
        templateId,
        comment: revisionComment,
        context: {
          opportunityName,
          customerName,
          roundName,
          templateName,
        },
        file: {
          id: activeFile.id,
          name: activeFile.name,
          url: activeFile.fileRelPath,
          size: activeFile.size,
          modified: activeFile.modified,
          status: activeFile.status,
          scenario: activeFile.scenario,
          listItemId: activeFile.listItemId,
          uploadedBy: activeFile.uploadedBy,
          modifiedBy: activeFile.modifiedBy,
          notifyUsers: notifyEmails,
        },
        requestedBy: currentUser,
        submittedAt: new Date().toISOString(),
        NotifyEmails: notifyEmails,
        RevisionComment: revisionComment,
        FilePath: activeFile.fileRelPath,
        siteUrl: `${cfg.siteUrl}`
      };

      await triggerFlow(payload, 'ApprovalFlow');

      setActiveFile(null);
      setRevisionComment('');

      setToast({
        severity: 'success',
        text: 'Revision request sent to the uploader.',
      });
    } catch (err: any) {
      setToast({ severity: 'error', text: `Error: ${err.message}` });
    } finally {
      setSaving(false);
      setLoading(false);
    }
  };

  const columnsBase: GridColDef[] = [
    {
      field: 'name',
      headerName: 'File',
      flex: 1,
      minWidth: 140,
      renderCell: (params) => (
        <MuiLink href={params.row.url} target="_blank" rel="noopener noreferrer" underline="hover">
          {params.value}
        </MuiLink>
      ),
    },
    {
      field: 'scenario',
      headerName: 'Scenario',
      width: 100,
      renderCell: (params) => params.value ?? '-',
    },
    {
      field: 'revisionNumber',
      headerName: 'Revision Number',
      width: 100,
      renderCell: (params) => params.value ?? '-',
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 100,
      renderCell: (params) => {
        const status = params.value || '';
        if (!status || status === '-') return <Typography variant="body2">-</Typography>;
        return (
          <ModernChip
            label={status}
            colorVariant={getStatusColorVariant(status)}
            size="small"
          />
        );
      },
    },
  ];

  const actionsColumn: GridColDef = {
    field: 'actions',
    headerName: 'Actions',
    width: 190,
    sortable: false,
    renderCell: (params) => {
      const row = params.row as FileItem;
      const status = (row.status || '').trim().toLowerCase();

      const isSubmitted = status === 'submitted';
      const canSendForRevision = row.isCurrentApproved === '1' && row.isCurrentVersion === '1' && row.inputType === "CollectInput";

      if (isSubmitted && hasAccess) {
        return (
          <ModernButton
            variant="gradient"
            size="small"
            onClick={() => {
              setActiveFile(row);
              setDrawerMode('approval');
              setShowPanel(true);
            }}
          >
            Validate / Reject
          </ModernButton>
        );
      }

      if (canSendForRevision && hasAccess) {
        return (
          <ModernButton
            variant="outlined"
            size="small"
            onClick={() => {
              setActiveFile(row);
              setDrawerMode('revision');
              setRevisionComment('');
              setShowPanel(true);
            }}
          >
            Send for revision
          </ModernButton>
        );
      }

      return <Typography variant="body2" color="text.secondary">No actions available</Typography>;
    },
  };

  const revisionExtraColumns: GridColDef[] = [
    // {
    //   field: 'revisionAttempt',
    //   headerName: 'Revision Attempts',
    //   width: 140,
    //   renderCell: (params) => params.value ?? '-',
    // },
    {
      field: 'lastRevisionAttempt',
      headerName: 'Last Revision Attempt',
      width: 180,
      renderCell: (params) => {
        if (!params.value) return <Typography variant="body2">-</Typography>;
        const date = new Date(params.value);
        return (
          <Typography variant="body2">
            {isNaN(date.getTime()) ? params.value : date.toLocaleDateString()}
          </Typography>
        );
      },
    },
  ];

  let columnsCurrentApproved;
  let columnsInProgress;
  let columnsPreviousApproved;

  if (!hasAccess) {
    columnsCurrentApproved = [...columnsBase, ...revisionExtraColumns];
    columnsInProgress = [...columnsBase];
    columnsPreviousApproved = [...columnsBase];
  } else {
    columnsCurrentApproved = [...columnsBase, ...revisionExtraColumns, actionsColumn];
    columnsInProgress = [...columnsBase, actionsColumn];
    columnsPreviousApproved = [...columnsBase];
  }


  if (loading) {
    return (
      <PageContainer size="lg">
        <Box sx={{ maxWidth: 1200, mx: 'auto', p: 0, width: '100%' }}>
          <ModernLoadingState type="shimmer" rows={5} height={80} />
        </Box>
      </PageContainer>
    );
  }

  return (
    <PageContainer size="lg">
      <Fade in timeout={500}>
        <Box sx={{ maxWidth: 1200, mx: 'auto', p: 0, width: '100%' }}>
          {toast && (
            <Box sx={{ mb: 3 }}>
              <ModernAlert
                severity={toast.severity}
                onClose={() => setToast(null)}
                elevated
                gradient
              >
                {toast.text}
              </ModernAlert>
            </Box>
          )}

          <ModernCard
            icon={<DescriptionIcon />}
            title={`Template Files - ${templateId}`}
            subtitle="Files available for actions"
            gradient
            elevated
            sx={{ mb: 3 }}
          >
            <Box />
          </ModernCard>

          {files.length === 0 ? (
            <ModernEmptyState
              type="empty"
              title="No files found"
              description="No files are currently pending approval or available for revision."
              animated
            />
          ) : (
            <>
              <ModernCard
                title="Current Approved Versions"
                subtitle="Latest approved files that can be sent for revision"
                elevated
                sx={{ mb: 3 }}
              >
                <ModernDataTable
                  rows={currentApproved}
                  columns={columnsCurrentApproved}
                  loading={loading}
                  pagination
                  pageSize={20}
                  pageSizeOptions={[10, 20, 50, 100]}
                  autoHeight
                  tableMinWidth={960}
                />
              </ModernCard>

              <ModernCard
                title="In Progress"
                subtitle="Files waiting for your approval"
                elevated
                sx={{ mb: 3 }}
              >
                <ModernDataTable
                  rows={inProgress}
                  columns={columnsInProgress}
                  loading={loading}
                  pagination
                  pageSize={20}
                  pageSizeOptions={[10, 20, 50, 100]}
                  autoHeight
                  tableMinWidth={640}
                />
              </ModernCard>

              <ModernCard
                title="Previous Approved Versions"
                subtitle="Older validated versions sent for revision"
                elevated
                sx={{ mb: 3 }}
              >
                <ModernDataTable
                  rows={previousVersions}
                  columns={columnsPreviousApproved}
                  loading={loading}
                  pagination
                  pageSize={20}
                  pageSizeOptions={[10, 20, 50, 100]}
                  autoHeight
                  tableMinWidth={460}
                />
              </ModernCard>
            </>
          )}

          <Drawer
            anchor="right"
            open={showPanel}
            onClose={() => {
              setShowPanel(false);
              setActiveFile(null);
              setDecision('');
              setComment('');
              setRevisionComment('');
              setDrawerMode('approval');
            }}
            PaperProps={{
              sx: {
                width: { xs: '100%', sm: '90%', md: 600 },
                p: 2,
                pt: 8,
              },
            }}
          >
            <Stack spacing={3}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <CheckCircleIcon sx={{ color: 'primary.main', fontSize: 28 }} />
                <Box>
                  <Typography variant="h6" fontWeight={600}>
                    {drawerMode === 'revision' ? 'Send for Revision' : 'File Validation'}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {drawerMode === 'revision'
                      ? 'Notify the uploader to revise this file'
                      : 'Review and approve or reject this file'}
                  </Typography>
                </Box>
              </Box>

              <Divider />

              {activeFile && (
                <ModernCard
                  elevated
                  sx={{
                    borderLeft: '4px solid',
                    borderLeftColor: 'primary.main',
                  }}
                >
                  <Stack spacing={2}>
                    <Box>
                      <Typography variant="caption" fontWeight={600} color="text.secondary">
                        File
                      </Typography>
                      <MuiLink
                        href={activeFile.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        underline="hover"
                        sx={{ display: 'block', mt: 0.5 }}
                      >
                        {activeFile.name}
                      </MuiLink>
                      <Typography variant="caption" color="text.secondary">
                        {activeFile.fileRelPath}
                      </Typography>
                    </Box>

                    <Box>
                      <Typography variant="caption" fontWeight={600} color="text.secondary">
                        Current Status
                      </Typography>
                      <Box sx={{ mt: 0.5 }}>
                        <ModernChip
                          label={activeFile.status ?? 'Unknown'}
                          colorVariant={getStatusColorVariant(activeFile.status ?? '')}
                          size="small"
                        />
                      </Box>
                    </Box>
                  </Stack>
                </ModernCard>
              )}

              {drawerMode === 'approval' && (
                <ModernCard elevated>
                  <Stack spacing={3}>
                    <ModernTextField
                      label="Decision"
                      value={decision}
                      onChange={(e) => setDecision(e.target.value)}
                      select
                      required
                      placeholder="Select a decision"
                    >
                      {decisionOptions.map((option) => (
                        <MenuItem key={option.key} value={option.key}>
                          {option.text}
                        </MenuItem>
                      ))}
                    </ModernTextField>

                    <ModernTextField
                      label="Comment (Optional)"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      multiline
                      rows={4}
                      placeholder="Add any comments or notes about this decision..."
                    />
                  </Stack>
                </ModernCard>
              )}

              {drawerMode === 'revision' && (
                <ModernCard elevated>
                  <Stack spacing={3}>
                    <Typography variant="subtitle1" fontWeight={600}>
                      Send file for revision
                    </Typography>

                    <Typography variant="body2" color="text.secondary">
                      This file has already been <strong>Validated/Approved</strong>. Request the uploader to revise it.
                    </Typography>

                    <ModernTextField
                      label="Revision comment for uploader"
                      value={revisionComment}
                      onChange={(e) => setRevisionComment(e.target.value)}
                      multiline
                      required
                      rows={4}
                      placeholder="Explain what needs to be revised (required)"
                    />
                  </Stack>
                </ModernCard>
              )}

              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'flex-end',
                  gap: 2,
                  pt: 2,
                  borderTop: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <ModernButton
                  variant="outlined"
                  onClick={() => {
                    setShowPanel(false);
                    setActiveFile(null);
                    setDecision('');
                    setComment('');
                    setRevisionComment('');
                    setDrawerMode('approval');
                  }}
                  disabled={saving}
                >
                  Cancel
                </ModernButton>
                <ModernButton
                  variant="gradient"
                  glow
                  onClick={drawerMode === 'revision' ? sendForRevision : submitToFlow}
                  disabled={
                    saving ||
                    !activeFile ||
                    (drawerMode === 'approval' && !decision) ||
                    (drawerMode === 'revision' && !revisionComment.trim())
                  }
                  loading={saving}
                >
                  {saving
                    ? 'Submitting…'
                    : drawerMode === 'revision'
                      ? 'Send for Revision'
                      : 'Submit Decision'}
                </ModernButton>
              </Box>

              {saving && (
                <Box sx={{ mt: 2 }}>
                  <ModernLoadingState type="spinner" text="Submitting..." />
                </Box>
              )}
            </Stack>
          </Drawer>
        </Box>
      </Fade>
    </PageContainer>
  );
}