import * as React from "react";
import {
    Drawer,
    Box,
    Stack,
    Typography,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Autocomplete,
    TextField,
    FormControlLabel,
    Checkbox
} from "@mui/material";


import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { ModernButton, ModernAlert, ModernCard } from "../../shared/mui";
import type { IPersonaProps } from "@fluentui/react";
import { SPHttpClient } from "@microsoft/sp-http";

import {
    EditInputTemplateDrawerProps,
    EditInputTemplateModel,
    InputOption,
    ScenarioConfig,
    ScenarioKey
} from "../../store/Models";

export const ChangeVersionDrawer: React.FC<EditInputTemplateDrawerProps> = ({
    open,
    onClose,
    round,
    currentRoundDetail,
    backendRound,
    roundNumber,
    templateCatalog,
    prevRoundScenarioMap,
    prevRoundApprovedScenarioMap,
    prevRoundId,
    spfxContext,
    api,
    onSaveSuccess
}) => {

    const peoplePickerContext = React.useMemo(() => ({
        absoluteUrl: spfxContext?.pageContext?.web?.absoluteUrl,
        msGraphClientFactory: spfxContext?.msGraphClientFactory,
        spHttpClient: spfxContext?.spHttpClient
    }), [spfxContext]);

    const [editor, setEditor] = React.useState<EditInputTemplateModel | null>(null);
    const [otherEditor, setOtherEditor] = React.useState({
        enabled: false,

        otherCode: "",

        applicableScenarios: [] as ScenarioKey[],

        scenarioConfigs:
            {} as Partial<Record<ScenarioKey, ScenarioConfig>>,

        dueDate: null as Date | null,

        groupUsers: [] as IPersonaProps[],

        notifyUsers: [] as IPersonaProps[],

        additionalTeam: [] as IPersonaProps[],

        inputTemplateVersions: [] as any[]
    });
    const [groupUsers, setGroupUsers] = React.useState<IPersonaProps[]>([]);

    const [saving, setSaving] = React.useState(false);

    const [inputTemplateVersions, setInputTemplateVersions] =
        React.useState<any[]>([]);

    // const [versionChanged, setVersionChanged] =
    //     React.useState(false);

    const [originalVersion, setOriginalVersion] =
        React.useState("");

    const versionChanged =
        !!editor &&
        editor.commonVersionSelections !== originalVersion;

    const isVersionChanged =
        !!editor &&
        editor.commonVersionSelections !== originalVersion;

    const hasMultipleVersions = inputTemplateVersions.length > 1;

    //const lockFields = !!editor && !isVersionChanged;
    const lockFields = !!editor && (!hasMultipleVersions || !isVersionChanged);

    React.useEffect(() => {
        if (open) {
            setSaving(false);
        }
    }, [open]);

    const otherHasCollectScenario =
        otherEditor.applicableScenarios.some(
            sk =>
                otherEditor.scenarioConfigs[sk]?.inputOption ===
                "CollectInput"
        );

    const otherHasStandardScenario =
        otherEditor.applicableScenarios.some(
            sk =>
                otherEditor.scenarioConfigs[sk]?.inputOption ===
                "useStandardInput"
        );

    const [toast, setToast] = React.useState<{
        severity: "success" | "error" | "warning" | "info";
        text: string;
    } | null>(null);
    const [standardTemplatesByStakeholder, setStandardTemplatesByStakeholder] =
        React.useState<
            Map<
                string,
                {
                    id: number;
                    title: string;
                    versionNumber: string;
                }[]
            >
        >(new Map());

    const prevRoundVersionMap = React.useMemo(() => {
        const map = new Map<string, string>();

        (backendRound?.inputs ?? []).forEach((inp: any) => {
            if (
                inp.workflowStatus === "Approved" &&
                inp.stakeholderCode &&
                inp.versionNumber
            ) {
                map.set(
                    String(inp.stakeholderCode).toLowerCase(),
                    String(inp.versionNumber)
                );
            }
        });

        return map;
    }, [backendRound]);

    React.useEffect(() => {
        if (!editor) return;

        const stakeholderKey = editor.stakeholderCode.toLowerCase();

        const approved =
            prevRoundApprovedScenarioMap.get(stakeholderKey) ??
            new Set<ScenarioKey>();

        const previousVersion =
            prevRoundVersionMap.get(stakeholderKey);

        const currentVersion =
            editor.commonVersionSelections || "";

        let changed = false;
        const nextConfigs = { ...editor.scenarioConfigs };

        Object.keys(nextConfigs).forEach(k => {
            const sk = k as ScenarioKey;
            const cfg = nextConfigs[sk];

            const canUsePrevious =
                approved.has(sk) &&
                previousVersion === currentVersion;

            if (
                cfg?.inputOption === "usePreviousRoundInput" &&
                !canUsePrevious
            ) {
                nextConfigs[sk] = {
                    ...cfg,
                    inputOption: "CollectInput",
                    previousRoundId: null
                };

                changed = true;
            }
        });

        if (changed) {
            setEditor(e =>
                e
                    ? {
                        ...e,
                        scenarioConfigs: nextConfigs
                    }
                    : e
            );
        }
    }, [
        editor,
        prevRoundApprovedScenarioMap,
        prevRoundVersionMap
    ]);


    function getScenarioRecordFromBackend(
        roundDetail: any,
        stakeholderName: string,
        stakeholderCode: string,
        scenarioKey: ScenarioKey
    ) {

        if (!roundDetail) return null;

        return (roundDetail.inputs ?? []).reduce((max: any, inp: any) => {
            const matches =
                String(inp.stakeholderCode || '') === stakeholderCode &&
                String(inp.scenarioName || '').toUpperCase() === scenarioKey &&
                String(inp.workflowStatus || '').toLowerCase() !== 'cancelled';
            if (!matches) return max;
            if (
                !max ||
                Number(inp.revisionNumber || 0) > Number(max.revisionNumber || 0)
            ) {
                return inp;
            }
            return max;
        }, null);
    }


    async function loadStandardTemplatesForStakeholder(stakeholderCode: string) {
        const response = await api.getStandardReference(Number(round.opportunityId));
        const list = Array.isArray(response) ? response : [];

        const filtered = list.filter(
            (item: any) =>
                String(item.stakeholder).toLowerCase() === stakeholderCode.toLowerCase()
        );

        setStandardTemplatesByStakeholder(prev => {
            const next = new Map(prev);
            next.set(
                stakeholderCode,
                filtered.map((i: any) => ({
                    id: Number(i.id),
                    title: String(i.title),
                    versionNumber: String(i.versionNumber || "")
                }))
            );
            return next;
        });
    }

    async function loadGroupUsers(stakeholderCode: string) {
        const meta =
            templateCatalog.get(stakeholderCode.toLowerCase());

        if (!meta?.groupIds?.length) {
            setGroupUsers([]);
            return;
        }

        const users: IPersonaProps[] = [];

        for (const gid of meta.groupIds) {
            const url =
                `${spfxContext.pageContext.web.absoluteUrl}` +
                `/_api/web/sitegroups/GetById(${gid})/users?$select=Id,Title,Email,LoginName`;


            const res = await spfxContext.spHttpClient.get(
                url,
                SPHttpClient.configurations.v1
            );


            const json = await res.json();

            (json.value ?? []).forEach((u: any) => {
                users.push({
                    key: String(u.Id),
                    text: u.Title || u.LoginName,
                    secondaryText: u.Email || u.LoginName,
                    tertiaryText: u.LoginName || u.Email
                });
            });
        }

        const deduped = Array.from(
            new Map(users.map(u => [u.secondaryText, u])).values()
        );

        setGroupUsers(deduped);
        return deduped;
    }

    async function loadInputTemplateVersions(stakeholderName: string) {
        try {
            const cfg = (window as any).TENANT_CONFIG;

            const endpoint =
                `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
                `?$select=Id,Title,VersionNumber,DraftApplicable,Active` +
                `&$filter=Title eq '${stakeholderName}' and Active eq 1`;

            const res = await spfxContext.spHttpClient.get(
                endpoint,
                SPHttpClient.configurations.v1
            );

            const data = await res.json();

            // console.log("Versions", data.value);

            setInputTemplateVersions(data.value || []);
            if ((data.value || []).length === 1) {
                setEditor(prev =>
                    prev
                        ? {
                            ...prev,
                            commonVersionSelections:
                                data.value[0].VersionNumber
                        }
                        : prev
                );
            }
        }
        catch (e) {
            console.error(e);
            setInputTemplateVersions([]);
        }
    }

    React.useEffect(() => {
        if (!editor) return;

        if (
            inputTemplateVersions.length === 1 &&
            editor.commonVersionSelections !== inputTemplateVersions[0].VersionNumber
        ) {
            setEditor(prev =>
                prev
                    ? {
                        ...prev,
                        commonVersionSelections:
                            inputTemplateVersions[0].VersionNumber
                    }
                    : prev
            );
        }
    }, [inputTemplateVersions, editor]);

    React.useEffect(() => {

        if (!editor) return;

        const selectedVersion =
            inputTemplateVersions.find(
                v =>
                    v.VersionNumber ===
                    editor.commonVersionSelections
            );

        const draftApplicable =
            selectedVersion?.DraftApplicable === true;

        if (draftApplicable) return;

        if (
            editor.collectDraftInput ||
            editor.commonDraftDueDate
        ) {
            setEditor(prev =>
                prev
                    ? {
                        ...prev,
                        collectDraftInput: false,
                        commonDraftDueDate: null
                    }
                    : prev
            );
        }

    }, [
        editor?.commonVersionSelections,
        inputTemplateVersions
    ]);

    React.useEffect(() => {

        if (!editor) return;

        const stakeholderKey =
            editor.stakeholderCode.toLowerCase();

        const versionInfo =
            templateCatalog
                .get(stakeholderKey)
                ?.versions
                ?.find(
                    v =>
                        v.versionNumber ===
                        editor.commonVersionSelections
                );

        const showStandard =
            versionInfo?.showStandard === true;

        if (showStandard) return;

        let changed = false;

        const nextConfigs = {
            ...editor.scenarioConfigs
        };

        Object.keys(nextConfigs).forEach(k => {

            const sk = k as ScenarioKey;

            const cfg =
                nextConfigs[sk];

            if (
                cfg?.inputOption ===
                "useStandardInput"
            ) {

                nextConfigs[sk] = {
                    ...cfg,
                    inputOption: "CollectInput",
                    standardReferenceId: null
                };

                changed = true;
            }
        });

        if (changed) {
            setEditor(prev =>
                prev
                    ? {
                        ...prev,
                        scenarioConfigs: nextConfigs
                    }
                    : prev
            );
        }

    }, [
        editor?.commonVersionSelections,
        templateCatalog
    ]);


    React.useEffect(() => {

        if (!editor) return;

        const stakeholderKey =
            editor.stakeholderCode.toLowerCase();

        const approved =
            prevRoundApprovedScenarioMap.get(
                stakeholderKey
            ) ?? new Set<ScenarioKey>();

        const previousVersion =
            prevRoundVersionMap.get(
                stakeholderKey
            );

        const currentVersion =
            editor.commonVersionSelections || "";

        let changed = false;

        const nextConfigs = {
            ...editor.scenarioConfigs
        };

        Object.keys(nextConfigs).forEach(k => {

            const sk =
                k as ScenarioKey;

            const cfg =
                nextConfigs[sk];

            const canUsePrevious =
                roundNumber > 1 &&
                approved.has(sk) &&
                previousVersion === currentVersion;

            if (
                cfg?.inputOption ===
                "usePreviousRoundInput" &&
                !canUsePrevious
            ) {
                nextConfigs[sk] = {
                    ...cfg,
                    inputOption:
                        "CollectInput",
                    previousRoundId:
                        null
                };

                changed = true;
            }
        });

        if (changed) {
            setEditor(prev =>
                prev
                    ? {
                        ...prev,
                        scenarioConfigs:
                            nextConfigs
                    }
                    : prev
            );
        }

    }, [
        editor?.commonVersionSelections
    ]);



    async function loadTemplate(stakeholderCode: string) {
        const it = currentRoundDetail.stakeholders.find(
            (r: any) => r.stakeholder_code === stakeholderCode
        );

        if (!it) return;
        //console.log("Stakeholder object:", it);
        await loadInputTemplateVersions(it.stakeholder);

        const stakeholderInputs = currentRoundDetail.inputs.filter(
            (i: any) => i.stakeholderCode === it.stakeholder_code
        );

        //console.log("Stakeholder Inputs", stakeholderInputs);

        const savedVersion =
            stakeholderInputs.find((i: any) => i.versionNumber)?.versionNumber ?? "";

        setOriginalVersion(savedVersion);

        //console.log("Saved Version:", savedVersion);

        await loadGroupUsers(stakeholderCode);
        const loadedUsers = await loadGroupUsers(stakeholderCode);

        const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

        it.applicableScenarios.forEach((s: any) => {
            const key: ScenarioKey =
                typeof s === "string" ? s : s.name;
            const desc = s.desc;

            const rec = getScenarioRecordFromBackend(
                currentRoundDetail,
                it.stakeholder,
                it.stakeholder_code,
                key
            );

            scenarioConfigs[key] = {
                inputOption: rec?.inputType,

                previousRoundId:
                    rec?.workflowStatus === "Approved" && rec?.inputType === "usePreviousRoundInput"
                        ? rec.roundId ?? null
                        : null,

                standardReferenceId:
                    rec?.standardInputInfo?.id
                        ? Number(rec.standardInputInfo.id)
                        : null,

                inputRequired: rec?.inputRequired,
                workflowStatus: rec?.workflowStatus,
                scenarioDescription: desc,
                revisionAttempt: rec?.revisionAttempt
            };

        });

        setEditor({
            stakeholderName: it.stakeholder!,
            stakeholderCode: it.stakeholder_code!,
            dueDate: it.dueDate ? new Date(it.dueDate) : null,
            existingScenarios: it.applicableScenarios.map((s: any) =>
                typeof s === "string" ? s : s.name
            ),
            newScenarios: [],
            scenarioConfigs,
            notifyUsers: (it.notifyUsers ?? []).map((u: any) => ({
                ...u,
                text: u.text || u.name,
                secondaryText: u.secondaryText || u.email,
                tertiaryText: u.tertiaryText || u.login_id || u.key,

                key: u.key || u.email
            })),
            additionalTeam: (it.additionalStakeholders ?? []).map((u: any) => ({
                ...u,
                text: u.text || u.name,
                secondaryText: u.secondaryText || u.email,
                id: u.id || buildLoginId(u.login_id || u.key)
            })),
            commonVersionSelections: savedVersion,
            collectDraftInput:
                it.collectDraftInput ?? false,

            commonDraftDueDate:
                it.draftDueDate
                    ? new Date(it.draftDueDate)
                    : null,
        });

        const hasStandardScenario =
            Object.values(scenarioConfigs).some(
                cfg => cfg?.inputOption === "useStandardInput"
            );

        if (hasStandardScenario) {
            await loadStandardTemplatesForStakeholder(
                it.stakeholder_code
            );
        }
    }

    const buildLoginId = (login_id?: string) => {
        if (!login_id) return "";

        return login_id.startsWith("i:0#.f|membership|")
            ? login_id
            : `i:0#.f|membership|${login_id}`;
    };

    const mergedNotifyOptions = React.useMemo(() => {
        const map = new Map<string, IPersonaProps>();

        groupUsers.forEach(u => {
            if (u.secondaryText) {
                map.set(u.secondaryText.toLowerCase(), u);
            }
        });

        (editor?.notifyUsers ?? []).forEach(u => {
            if (u.secondaryText) {
                map.set(u.secondaryText.toLowerCase(), u);
            }
        });

        return Array.from(map.values());
    }, [groupUsers, editor?.notifyUsers]);

    function resolveStandardTitle(
        stakeholderCode: string,
        standardReferenceId?: number | null
    ) {
        if (!standardReferenceId) return null;

        return (
            standardTemplatesByStakeholder
                .get(stakeholderCode)
                ?.find(t => t.id === standardReferenceId)?.title ?? null
        );
    }

    function handleClose() {
        setToast(null);
        setEditor(null);
        setGroupUsers([]);
        setSaving(false);
        onClose();
    }

    const allScenarioKeys = round.scenarios.map(s => s.key);
    // console.log(round.scenarios);
    const canAddMoreScenarios =
        editor ? editor.existingScenarios.length < allScenarioKeys.length : false;
    const getScenarioDescription = (key: string) => {
        const scenario = round.scenarios.find(s => s.key === key);
        return scenario?.description || "";
    };

    const getScenarioName = (key: string) => {
        const scenario = round.scenarios.find(s => s.key === key);
        return scenario?.key || `Dataset ${key}`;
    };

    const showStandardFields =
        currentRoundDetail?.stakeholders
            ?.find((s: any) => s.stakeholder_code === editor?.stakeholderCode)
            ?.stakeholderType
            ?.toLowerCase() === "standard";

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Drawer
                anchor="right"
                open={open}
                onClose={handleClose}
                PaperProps={{
                    sx: {
                        width: { xs: '100%', sm: 520 },
                        p: 2,
                        pt: 9,
                    },
                }}
            >
                <Typography variant="h6" fontWeight={700}>
                    Change Version Template
                </Typography>

                <Divider sx={{ my: 2 }} />
                {toast && (
                    <Box sx={{ mb: 2 }}>
                        <ModernAlert
                            severity={toast.severity}
                            onClose={() => setToast(null)}
                            elevated
                            gradient
                        >
                            {toast.text}
                        </ModernAlert>
                    </Box>
                )}
                <FormControl fullWidth>
                    <InputLabel
                        id="input-template-label"
                        shrink={Boolean(editor?.stakeholderCode)}
                        sx={{
                            backgroundColor: "#fff",
                            px: 0.5
                        }}
                    >
                        Input Template
                    </InputLabel>

                    <Select
                        labelId="input-template-label"
                        label="Input Template"
                        value={editor?.stakeholderCode ?? ""}
                        renderValue={(selected) => {
                            const item = round.inputTemplates.find(
                                it => it.stakeholderCode === selected
                            );

                            return item?.stakeholderName || "";
                        }}
                        onChange={async e => {
                            await loadTemplate(e.target.value);
                        }}
                    >
                        {round.inputTemplates
                            .filter(it => {
                                const stakeholder =
                                    currentRoundDetail?.stakeholders?.find(
                                        (s: any) =>
                                            s.stakeholder_code === it.stakeholderCode
                                    );

                                return (
                                    stakeholder?.stakeholderType?.toLowerCase() ===
                                    "standard"
                                );
                            })
                            .map(it => (
                                <MenuItem
                                    key={it.stakeholderCode}
                                    value={it.stakeholderCode}
                                >
                                    {it.stakeholderName}
                                </MenuItem>
                            ))}
                    </Select>
                </FormControl>

                {editor && (() => {

                    const versionsToShow = inputTemplateVersions;
                    const selectedVersion =
                        versionsToShow.length === 1
                            ? versionsToShow[0]
                            : versionsToShow.find(
                                v => v.VersionNumber === editor.commonVersionSelections
                            );
                    const isDraftVersion = selectedVersion?.DraftApplicable === true;

                    const isDueDateInvalid =
                        !!editor.commonDraftDueDate &&
                        !!editor.dueDate &&
                        editor.dueDate <= editor.commonDraftDueDate;

                    return (
                        <Stack spacing={2} sx={{ mt: 2 }}>

                            {/* Version */}
                            {showStandardFields && (
                                <>
                                    {inputTemplateVersions.length === 1 ? (
                                        <Box sx={{ display: "flex", alignItems: "center", mt: 1 }}>
                                            <Typography fontWeight={600}>
                                                Version:
                                            </Typography>

                                            <Typography sx={{ ml: 4 }}>
                                                {editor.commonVersionSelections}
                                            </Typography>
                                        </Box>
                                    ) : (
                                        <FormControl fullWidth>
                                            <InputLabel>Version</InputLabel>

                                            <Select
                                                label="Version"
                                                value={editor.commonVersionSelections ?? ""}
                                                onChange={(e) => {
                                                    const newVersion = String(e.target.value);

                                                    setEditor(ed =>
                                                        ed
                                                            ? {
                                                                ...ed,
                                                                commonVersionSelections: newVersion
                                                            }
                                                            : ed
                                                    );
                                                }}
                                            >
                                                {inputTemplateVersions.map(v => (
                                                    <MenuItem
                                                        key={v.VersionNumber}
                                                        value={v.VersionNumber}
                                                    >
                                                        {v.VersionNumber}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    )}
                                </>
                            )}

                            <ModernAlert
                                severity="warning"
                                elevated
                                gradient
                            >
                                Warning: Changing the version will cancel all previously submitted files associated with this Input Template. Users may be required to resubmit their inputs. Please note that this action is irreversible and cannot be undone.
                            </ModernAlert>
                            {/* Collect Draft Input */}
                            {selectedVersion?.DraftApplicable && (
                                <FormControlLabel
                                    sx={{
                                        m: 0,
                                        ml: 0,
                                        alignItems: "center"
                                    }}
                                    control={
                                        <Checkbox
                                            sx={{
                                                p: 0,
                                                mr: 1
                                            }}
                                            disabled={lockFields}
                                            checked={editor.collectDraftInput ?? false}
                                            onChange={(e) =>
                                                setEditor(ed =>
                                                    ed
                                                        ? {
                                                            ...ed,
                                                            collectDraftInput: e.target.checked,
                                                            commonDraftDueDate: e.target.checked
                                                                ? ed.commonDraftDueDate
                                                                : null
                                                        }
                                                        : ed
                                                )
                                            }
                                        />
                                    }
                                    label="Collect Draft Input"
                                />
                            )}

                            {/* Draft Due Date / Due Date */}
                            {showStandardFields &&
                                selectedVersion?.DraftApplicable &&
                                editor.collectDraftInput && (
                                    <DatePicker
                                        label="Draft Due Date"
                                        format="dd/MM/yyyy"
                                        disabled={lockFields}
                                        value={editor.commonDraftDueDate}
                                        onChange={(d) =>
                                            setEditor(ed =>
                                                ed
                                                    ? {
                                                        ...ed,
                                                        commonDraftDueDate: d
                                                    }
                                                    : ed
                                            )
                                        }
                                        slotProps={{
                                            textField: {
                                                error:
                                                    !!editor.commonDraftDueDate &&
                                                    editor.commonDraftDueDate <= new Date(),

                                                helperText:
                                                    !!editor.commonDraftDueDate &&
                                                        editor.commonDraftDueDate <= new Date()
                                                        ? "Draft Due Date must be a future date."
                                                        : ""
                                            }
                                        }}
                                    />
                                )}

                            {showStandardFields && (
                                <DatePicker
                                    label="Due Date"
                                    format="dd/MM/yyyy"
                                    disabled={lockFields}
                                    value={editor.dueDate}
                                    onChange={(d) =>
                                        setEditor(ed =>
                                            ed
                                                ? {
                                                    ...ed,
                                                    dueDate: d
                                                }
                                                : ed
                                        )
                                    }
                                    slotProps={{
                                        textField: {
                                            error: isDueDateInvalid,
                                            helperText: isDueDateInvalid
                                                ? "Due Date must be after Draft Due Date."
                                                : ""
                                        }
                                    }}
                                />
                            )}

                            <Box>
                                <Typography fontWeight={600}>Existing Datasets</Typography>
                                <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap" }}>
                                    {editor.existingScenarios.map(k => (
                                        <Chip key={k} label={k} size="small" />
                                    ))}
                                </Box>
                            </Box>

                            {canAddMoreScenarios && (
                                <FormControl fullWidth variant="outlined">
                                    <InputLabel
                                        shrink
                                        sx={{
                                            backgroundColor: "#fff",
                                            px: 0.5
                                        }}
                                    >
                                        Add Datasets
                                    </InputLabel>

                                    <Select
                                        multiple
                                        displayEmpty
                                        disabled={lockFields}
                                        value={editor.newScenarios}
                                        label="Add Datasets"
                                        onChange={e =>
                                            setEditor(ed => {
                                                if (!ed) return ed;

                                                const raw = e.target.value;
                                                const selected = Array.isArray(raw)
                                                    ? (raw.filter(Boolean) as ScenarioKey[])
                                                    : [];

                                                const nextConfigs = { ...ed.scenarioConfigs };

                                                selected.forEach(sk => {
                                                    if (!nextConfigs[sk]) {
                                                        nextConfigs[sk] = {
                                                            inputOption: "CollectInput",
                                                            previousRoundId: null,
                                                            standardReferenceId: null,
                                                            scenarioDescription: getScenarioDescription(sk),
                                                            versionSelections: [],
                                                            submissionTypes: ["Draft", "Final"],
                                                            collectDraftInput: false,
                                                            draftDueDate: null
                                                        };
                                                    }
                                                });

                                                return {
                                                    ...ed,
                                                    newScenarios: selected,
                                                    scenarioConfigs: nextConfigs
                                                };
                                            })
                                        }
                                        sx={{
                                            minHeight: 56,
                                            display: "flex",
                                            alignItems: "center"
                                        }}
                                    >
                                        {allScenarioKeys
                                            .filter(k => !editor.existingScenarios.includes(k))
                                            .map(k => (
                                                <MenuItem key={k} value={k}>
                                                    <Box
                                                        sx={{
                                                            display: "flex",
                                                            alignItems: "center",
                                                            gap: 1,
                                                            width: "100%"
                                                        }}
                                                    >
                                                        <Typography fontWeight={500}>
                                                            {getScenarioName(k)}
                                                        </Typography>

                                                        <Typography
                                                            variant="body2"
                                                            color="text.secondary"
                                                            sx={{
                                                                maxWidth: "260px",
                                                                overflow: "hidden",
                                                                textOverflow: "ellipsis",
                                                                whiteSpace: "nowrap"
                                                            }}
                                                        >
                                                            -{
                                                                getScenarioDescription(k).length > 40
                                                                    ? getScenarioDescription(k).substring(0, 40) + "..."
                                                                    : getScenarioDescription(k)
                                                            }
                                                        </Typography>
                                                    </Box>
                                                </MenuItem>
                                            ))}
                                    </Select>
                                </FormControl>
                            )}

                            {showStandardFields && (
                                <>
                                    {[...editor.existingScenarios, ...editor.newScenarios].map(sk => {
                                        const stakeholderKey = editor.stakeholderCode.toLowerCase();
                                        const isExisting = editor.existingScenarios.includes(sk);
                                        const versionInfo =
                                            templateCatalog
                                                .get(stakeholderKey)
                                                ?.versions
                                                ?.find(
                                                    v =>
                                                        v.versionNumber ===
                                                        editor.commonVersionSelections
                                                );

                                        const showStandard =
                                            versionInfo?.showStandard === true;

                                        const approvedScenario =
                                            prevRoundApprovedScenarioMap.get(stakeholderKey)?.has(sk) === true;

                                        const previousVersion =
                                            prevRoundVersionMap.get(stakeholderKey);

                                        const currentVersion =
                                            editor.commonVersionSelections || "";

                                        const canUsePrev =
                                            roundNumber > 1 &&
                                            approvedScenario &&
                                            previousVersion === currentVersion;

                                        const inputOptions: { key: InputOption; text: string }[] = [
                                            { key: "CollectInput", text: "Collect Input" },

                                            ...(showStandard ||
                                                editor.scenarioConfigs[sk]?.inputOption === "useStandardInput"
                                                ? [{
                                                    key: "useStandardInput" as InputOption,
                                                    text: "Use Standard Input"
                                                }]
                                                : []),

                                            ...(canUsePrev ||
                                                editor.scenarioConfigs[sk]?.inputOption === "usePreviousRoundInput"
                                                ? [{
                                                    key: "usePreviousRoundInput" as InputOption,
                                                    text: "Use Previous Round Input"
                                                }]
                                                : [])
                                        ];

                                        const selectedType =
                                            editor.scenarioConfigs[sk]?.inputOption ?? "CollectInput";
                                        return (
                                            <Box key={sk}>
                                                <FormControl fullWidth required variant="outlined">
                                                    <InputLabel
                                                        shrink
                                                        sx={{
                                                            backgroundColor: "#fff",
                                                            px: 0.5
                                                        }}
                                                    >
                                                        {`Input Type - Dataset ${sk}`}
                                                        {/*{isExisting && " (locked)"}*/}
                                                        {isExisting && !isVersionChanged && " (locked)"}
                                                    </InputLabel>

                                                    <Select
                                                        label={`Input Type - Dataset ${sk}`}
                                                        value={selectedType}
                                                        disabled={lockFields}
                                                        onChange={async e => {
                                                            const val = e.target.value as InputOption;
                                                            setEditor(ed =>
                                                                ed
                                                                    ? {
                                                                        ...ed,
                                                                        scenarioConfigs: {
                                                                            ...ed.scenarioConfigs,
                                                                            [sk]: {
                                                                                ...ed.scenarioConfigs[sk],
                                                                                inputOption: val,
                                                                                previousRoundId:
                                                                                    val === "usePreviousRoundInput" ? prevRoundId ?? null : null,
                                                                                standardReferenceId:
                                                                                    val === "useStandardInput"
                                                                                        ? ed.scenarioConfigs[sk]?.standardReferenceId ?? null
                                                                                        : null
                                                                            }
                                                                        }
                                                                    }
                                                                    : ed
                                                            );

                                                            if (val === "useStandardInput") {
                                                                await loadStandardTemplatesForStakeholder(
                                                                    editor.stakeholderCode
                                                                );
                                                            }
                                                        }}
                                                    >
                                                        {inputOptions.map(o => (
                                                            <MenuItem key={o.key} value={o.key}>
                                                                {o.text}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>
                                                </FormControl>
                                                {selectedType === "useStandardInput" && (
                                                    <FormControl fullWidth required sx={{ mt: 1 }}>
                                                        <InputLabel>Standard Template</InputLabel>
                                                        <Select
                                                            value={
                                                                editor.scenarioConfigs[sk]?.standardReferenceId ?? ""
                                                            }
                                                            disabled={lockFields}
                                                            onChange={e =>
                                                                setEditor(ed =>
                                                                    ed
                                                                        ? {
                                                                            ...ed,
                                                                            scenarioConfigs: {
                                                                                ...ed.scenarioConfigs,
                                                                                [sk]: {
                                                                                    ...ed.scenarioConfigs[sk],
                                                                                    standardReferenceId: Number(e.target.value)
                                                                                }
                                                                            }
                                                                        }
                                                                        : ed
                                                                )
                                                            }
                                                        >
                                                            {
                                                                (
                                                                    standardTemplatesByStakeholder.get(
                                                                        editor.stakeholderCode
                                                                    ) ?? []
                                                                )
                                                                    .filter(
                                                                        t =>
                                                                            t.versionNumber ===
                                                                            editor.commonVersionSelections
                                                                    )
                                                                    .map(t => (
                                                                        <MenuItem key={t.id} value={t.id}>
                                                                            {t.title}
                                                                        </MenuItem>
                                                                    ))
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                )}
                                            </Box>
                                        );
                                    })}
                                </>
                            )}
                            {showStandardFields && (
                                <Box>
                                    <Autocomplete
                                        multiple
                                        options={mergedNotifyOptions}
                                        value={editor.notifyUsers}
                                        disabled={lockFields}
                                        isOptionEqualToValue={(opt, val) =>
                                            (opt.secondaryText || "").toLowerCase() ===
                                            (val.secondaryText || "").toLowerCase()
                                        }
                                        getOptionLabel={(o) => o.text || ""}
                                        onChange={(_, v) =>
                                            setEditor(ed => (ed ? { ...ed, notifyUsers: v } : ed))
                                        }
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Stakeholder Users"
                                                error={
                                                    editor.notifyUsers.length === 0 &&
                                                    editor.additionalTeam.length === 0
                                                }
                                            />
                                        )}
                                    />

                                    {editor.notifyUsers.length === 0 &&
                                        editor.additionalTeam.length === 0 && (
                                            <Typography
                                                variant="caption"
                                                sx={{
                                                    color: "#d32f2f",
                                                    mt: 0.5,
                                                    ml: 1.5,
                                                    display: "block",
                                                    fontSize: "13px"
                                                }}
                                            >
                                                Required unless you add at least one Extra Input Provider
                                            </Typography>
                                        )}
                                </Box>
                            )}
                            <Box
                                sx={{
                                    "& .ms-BasePicker": {
                                        minHeight: 56,
                                        border: "1px solid rgba(0,0,0,0.23)",
                                        borderRadius: "4px",
                                        padding: "14px",
                                        backgroundColor: "#fff"
                                    },

                                    "& .ms-BasePicker:hover": {
                                        borderColor: "rgba(0,0,0,0.87)"
                                    },

                                    "& .ms-BasePicker-text": {
                                        border: "none !important",
                                        minHeight: "unset !important"
                                    },

                                    "& .ms-TextField-fieldGroup": {
                                        border: "none !important",
                                        background: "transparent"
                                    },

                                    "& .ms-BasePicker-input": {
                                        padding: "0 !important"
                                    },

                                    "& .ms-Label": {
                                        fontSize: "12px",
                                        transform: "translate(14px, -9px)",
                                        backgroundColor: "#fff",
                                        padding: "0 4px",
                                        position: "absolute",
                                        zIndex: 1
                                    }
                                }}
                            >
                                <PeoplePicker
                                    context={peoplePickerContext}
                                    titleText="Extra Input Provider"
                                    principalTypes={[PrincipalType.User]}
                                    personSelectionLimit={100}
                                    disabled={lockFields}
                                    defaultSelectedUsers={editor.additionalTeam.map(
                                        p => p.secondaryText || ""
                                    )}
                                    onChange={items =>
                                        setEditor(ed => (ed ? { ...ed, additionalTeam: items } : ed))
                                    }
                                />
                            </Box>
                            {
                                toast && (
                                    <Box sx={{ mb: 2 }}>
                                        <ModernAlert
                                            severity={toast.severity}
                                            onClose={() => setToast(null)}
                                            elevated
                                            gradient
                                        >
                                            {toast.text}
                                        </ModernAlert>
                                    </Box>
                                )
                            }
                            <Stack direction="row" justifyContent="flex-end" spacing={1}>
                                <ModernButton variant="outlined" onClick={handleClose}>
                                    Cancel
                                </ModernButton>
                                <ModernButton
                                    variant="gradient"
                                    glow
                                    loading={saving}
                                    disabled={saving || lockFields}
                                    onClick={async () => {
                                        try {
                                            setSaving(true);

                                            const hasUsers = editor.notifyUsers.length > 0;
                                            const hasAdditional = editor.additionalTeam.length > 0;

                                            const allScenarios = [
                                                ...editor.existingScenarios,
                                                ...editor.newScenarios
                                            ];

                                            const hasCollectInput = allScenarios.some(sk => {
                                                const cfg = editor.scenarioConfigs[sk];
                                                return (cfg?.inputOption ?? "CollectInput") === "CollectInput";
                                            });

                                            if (hasCollectInput && !editor.dueDate) {
                                                setToast({
                                                    severity: "error",
                                                    text: `Stakeholder "${editor.stakeholderName}" is missing Due Date.`
                                                });
                                                setSaving(false);
                                                return;
                                            }

                                            if (hasCollectInput && !hasUsers && !hasAdditional) {
                                                setToast({
                                                    severity: "error",
                                                    text: `Stakeholder "${editor.stakeholderName}": Please select either:
- At least one Stakeholder User OR
- At least one Extra Input Provider`
                                                });
                                                setSaving(false);
                                                return;
                                            }

                                            setToast(null);

                                            const updatedConfigs = { ...editor.scenarioConfigs };

                                            Object.keys(updatedConfigs).forEach(k => {
                                                const sk = k as ScenarioKey;
                                                const cfg = updatedConfigs[sk];

                                                if (cfg?.inputOption === "useStandardInput") {
                                                    const title = resolveStandardTitle(
                                                        editor.stakeholderCode,
                                                        cfg.standardReferenceId
                                                    );

                                                    if (title) {
                                                        updatedConfigs[sk] = {
                                                            ...cfg,
                                                            standardInputTemplateTitle: title
                                                        };
                                                    }
                                                }
                                            });

                                            const selectedVersion = inputTemplateVersions.find(
                                                v => v.VersionNumber === editor.commonVersionSelections
                                            );

                                            if (
                                                selectedVersion?.DraftApplicable &&
                                                editor.collectDraftInput &&
                                                !editor.commonDraftDueDate
                                            ) {
                                                setToast({
                                                    severity: "error",
                                                    text: "Draft Due Date is required."
                                                });

                                                setSaving(false);
                                                return;
                                            }

                                            if (
                                                editor.commonDraftDueDate &&
                                                editor.commonDraftDueDate <= new Date()
                                            ) {
                                                setToast({
                                                    severity: "error",
                                                    text: "Draft Due Date must be a future date."
                                                });

                                                setSaving(false);
                                                return;
                                            }
                                            if (
                                                editor.commonDraftDueDate &&
                                                editor.dueDate &&
                                                editor.dueDate <= editor.commonDraftDueDate
                                            ) {
                                                setToast({
                                                    severity: "error",
                                                    text: "Due Date must be after Draft Due Date."
                                                });

                                                setSaving(false);
                                                return;
                                            }

                                            const cleanedScenarioConfigs: Partial<
                                                Record<ScenarioKey, ScenarioConfig>
                                            > = {};

                                            Object.entries(updatedConfigs).forEach(([key, cfg]) => {
                                                cleanedScenarioConfigs[key as ScenarioKey] = {
                                                    ...cfg,

                                                    versionSelections: showStandardFields
                                                        ? cfg.versionSelections
                                                        : undefined,

                                                    submissionTypes: showStandardFields
                                                        ? cfg.submissionTypes
                                                        : undefined,

                                                    collectDraftInput: showStandardFields
                                                        ? editor.collectDraftInput
                                                        : undefined,

                                                    draftDueDate: showStandardFields
                                                        ? editor.commonDraftDueDate
                                                        : undefined
                                                };
                                            });

                                            for (const sk of allScenarios) {
                                                const cfg = updatedConfigs[sk];

                                                if (
                                                    cfg?.inputOption === "useStandardInput" &&
                                                    !cfg.standardReferenceId
                                                ) {
                                                    setToast({
                                                        severity: "error",
                                                        text: `Please select a Standard Template for Dataset ${sk}.`
                                                    });

                                                    setSaving(false);
                                                    return;
                                                }
                                            }

                                            const draftApplicable =
                                                selectedVersion?.DraftApplicable === true;

                                            await onSaveSuccess({
                                                ...editor,

                                                collectDraftInput: draftApplicable
                                                    ? editor.collectDraftInput
                                                    : false,

                                                commonDraftDueDate: draftApplicable
                                                    ? editor.commonDraftDueDate
                                                    : null,

                                                originalVersion,
                                                versionChanged,

                                                scenarioConfigs: cleanedScenarioConfigs,
                                                inputTemplateVersions
                                            } as any);

                                            handleClose();

                                        } catch (e: any) {
                                            console.error(e);

                                            setToast({
                                                severity: "error",
                                                text: e?.message || "Failed to save input template."
                                            });

                                            setSaving(false);
                                        }
                                    }}
                                >
                                    Save
                                </ModernButton>

                            </Stack>

                        </Stack>
                    );
                })()}

            </Drawer>
        </LocalizationProvider>
    );
};