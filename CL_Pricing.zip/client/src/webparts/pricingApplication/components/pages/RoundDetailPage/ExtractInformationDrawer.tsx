import * as React from "react";
import {
  Drawer,
  Box,
  Typography,
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Stack,
  CircularProgress
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { GridColDef } from "@mui/x-data-grid";

import {
  ModernButton,
  ModernDataTable
} from "../../shared/mui";

interface LibraryFile {
  name: string;
  url: string;
  serverRelativeUrl: string;
  timeLastModified?: string;
  length?: number;
  uniqueId?: string;
}

// interface OutputLog {
//   id: number;
//   fileName: string;
//   extractedBy: string;
//   createdOn: string;
// }

export interface OutputLog {
  id: number;
  opportunityId: number;
  roundId: number;
  fileRelPath: string;
  processedData: any;
  active: boolean;
  deleted: boolean;
  createdOn: string;
  createdBy: string;
}

interface ExtractInformationDrawerProps {
  open: boolean;
  onClose: () => void;

  existingRoundFiles: LibraryFile[];

  selectedOutputFile: string;
  setSelectedOutputFile: (value: string) => void;

  outputLogs: OutputLog[];

  onExtractInformation: () => void;

  loading?: boolean;
}

const outputLogColumns: GridColDef[] = [
  {
    field: "fileRelPath",
    headerName: "File Name",
    flex: 2,
    minWidth: 200,
    renderCell: (params) => (
      <Typography variant="body2">
        {params.row.fileRelPath ? params.row.fileRelPath.substring(params.row.fileRelPath.lastIndexOf('/') + 1) : ""}
      </Typography>
    )
  },
  {
    field: "createdBy",
    headerName: "Extracted By",
    flex: 1.5,
    minWidth: 180,
  },
  {
    field: "createdOn",
    headerName: "Created On",
    flex: 1.5,
    minWidth: 180,
    renderCell: (params) => (
      <Typography variant="body2">
        {params.row.createdOn
          ? new Date(params.row.createdOn).toLocaleDateString() : ""}
      </Typography>
    ),
  },
];

export default function ExtractInformationDrawer({
  open,
  onClose,
  existingRoundFiles,
  selectedOutputFile,
  setSelectedOutputFile,
  outputLogs,
  onExtractInformation,
  loading = false
}: ExtractInformationDrawerProps) {

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: "100%", sm: 520 },
          boxSizing: "border-box",
          p: 2,
          pt: 9,
        },
      }}
    >
      {/* <Box
        sx={{
          width: 1000,
          display: "flex",
          flexDirection: "column",
          height: "100%"
        }}
      > */}

      <Box
        sx={{
          width: "100%",
          display: "flex",
          flexDirection: "column",
          height: "100%"
        }}
      >
        {/* Header */}

        <Box
          sx={{
            p: 2,
            borderBottom: "1px solid #E5E7EB",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center"
          }}
        >
          <Typography variant="h6">
            Extract Outputs
          </Typography>

          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>

        {/* Body */}

        <Box
          sx={{
            p: 3,
            flex: 1,
            overflow: "auto"
          }}
        >

          {existingRoundFiles.length == 0 && (
            <>
              <Typography fontWeight={500}>
                No Output File is available to extract.
              </Typography>
            </>
          )
          }

          {existingRoundFiles.length > 0 && (
            <FormControl fullWidth>


              <InputLabel>
                Existing Output File
              </InputLabel>

              <Select
                value={selectedOutputFile}
                label="Existing Output File"
                onChange={(e) =>
                  setSelectedOutputFile(e.target.value)
                }
              >
                {existingRoundFiles.map((file) => (
                  <MenuItem
                    key={file.name}
                    value={file.name}
                  >
                    {file.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          )}


          {/* <Box sx={{ mt: 4 }}>
            <Typography
              variant="subtitle1"
              sx={{
                mb: 2,
                fontWeight: 600
              }}
            >
              Previous Outputs
            </Typography>

            {loading ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  py: 4
                }}
              >
                <CircularProgress />
              </Box>
            ) : (
              <Box
                sx={{
                  height: 300,
                  width: "100%"
                }}
              >
                <ModernDataTable
                  rows={outputLogs}
                  columns={outputLogColumns}
                  loading={loading}
                />
              </Box>
            )}
          </Box> */}

          <Box sx={{ mt: 4 }}>
            <Typography
              variant="subtitle1"
              sx={{
                mb: 2,
                fontWeight: 600
              }}
            >
              Previous Output
            </Typography>

            {loading ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  py: 4
                }}
              >
                <CircularProgress />
              </Box>
            ) : outputLogs.length > 0 ? (
              <Box
                sx={{
                  border: "1px solid #E5E7EB",
                  borderRadius: 2,
                  p: 2.5,
                  backgroundColor: "#FFFFFF",
                }}
              >
                <Stack spacing={2}>

                  <Box>
                    <Typography
                      variant="caption"
                      color="text.secondary"
                    >
                      File Name
                    </Typography>

                    <Typography
                      variant="body1"
                      fontWeight={500}
                    >
                      {outputLogs[0].fileRelPath
                        ? outputLogs[0].fileRelPath.substring(
                          outputLogs[0].fileRelPath.lastIndexOf("/") + 1
                        )
                        : ""}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography
                      variant="caption"
                      color="text.secondary"
                    >
                      Extracted By
                    </Typography>

                    <Typography variant="body1">
                      {outputLogs[0].createdBy}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography
                      variant="caption"
                      color="text.secondary"
                    >
                      Created On
                    </Typography>

                    <Typography variant="body1">
                      {outputLogs[0].createdOn
                        ? new Date(outputLogs[0].createdOn).toLocaleDateString()
                        : ""}
                    </Typography>
                  </Box>

                </Stack>
              </Box>
            ) : (
              <Typography
                variant="body2"
                color="text.secondary"
              >
                No previous output available.
              </Typography>
            )}
          </Box>
        </Box>

        {/* Footer */}

        <Box
          sx={{
            p: 2,
            borderTop: "1px solid #E5E7EB"
          }}
        >
          <Stack
            direction="row"
            spacing={2}
            justifyContent="flex-end"
          >
            <ModernButton
              variant="outlined"
              onClick={onClose}
            >
              Cancel
            </ModernButton>

            {/* <ModernButton
              variant="contained"
              onClick={onExtractInformation}
              disabled={
                loading ||
                !selectedOutputFile
              }
            >
              {loading
                ? "Extracting..."
                : "Extract Outputs"}
            </ModernButton> */}
            <ModernButton
              variant="contained"
              onClick={onExtractInformation}
              disabled={loading || !selectedOutputFile}
              sx={{
                "&.Mui-disabled": {
                  backgroundColor: "#D1D5DB",
                  color: "#eef0f4", // visible text
                },
              }}
            >
              {loading ? "Extracting..." : "Extract Outputs"}
            </ModernButton>
          </Stack>
        </Box>
      </Box>
    </Drawer>
  );
}