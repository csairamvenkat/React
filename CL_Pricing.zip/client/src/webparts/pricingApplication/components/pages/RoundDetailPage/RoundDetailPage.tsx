import * as React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import HourglassBottom from '@mui/icons-material/HourglassBottom';
import ExtractInformationDrawer, {
  OutputLog
} from "./ExtractInformationDrawer";
import {
  Box,
  Switch,
  Typography,
  Divider,
  Drawer,
  FormControl,
  FormControlLabel,
  RadioGroup,
  Radio,
  Select,
  MenuItem,
  InputLabel,
  Checkbox,
  Stack,
  Fade,
  IconButton,
  Chip,
  Tooltip,
  TextField,
  SvgIcon,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  CircularProgress
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import InfoIcon from '@mui/icons-material/Info';
import AssignmentIcon from '@mui/icons-material/Assignment';
import PeopleIcon from '@mui/icons-material/People';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import DescriptionIcon from '@mui/icons-material/Description';
import EventIcon from '@mui/icons-material/Event';
import CloseIcon from '@mui/icons-material/Close';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ApiDataProvider } from '../../../api/ApiDataProvider';
import { useCrumbs } from '../../shell/CrumbContext';
import { triggerFlow } from '../../../flow/flowclient';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Menu from '@mui/material/Menu';
import {
  ModernCard,
  ModernButton,
  ModernTextField,
  ModernAlert,
  ModernChip,
  ModernLoadingState,
  ModernEmptyState,
  ModernDataTable,
} from '../../shared/mui';
import { GridColDef } from '@mui/x-data-grid';
import type { IPersonaProps } from '@fluentui/react';
import { Add } from '@mui/icons-material';
import AddInputTemplateDrawer from './AddInputTemplateDrawer';
import { EditInputTemplateModel, UpdateInputTemplatePayload, ScenarioConfig, ChangeVersionPayload, ChangeVersionScenario } from '../../store/Models';
import { EditInputTemplateDrawer } from './EditInputTemplateDrawer';
import { ChangeVersionDrawer } from './ChangeVersionDrawer';
import CloseRoundDrawer from "./CloseRoundDrawer";
//import ExtractInformationDrawer from "./ExtractInformationDrawer";
import EditIcon from '@mui/icons-material/Edit';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

type ScenarioKey = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I' | 'J';

interface ScenarioRow {
  key: ScenarioKey;
  description?: string;
}
type EditorModel = {
  stakeholderName: string;
  stakeholderCode?: string;
  inputOption?: string;
  dueDate: Date | null;
  applicableScenarioKeys: ScenarioKey[];
  notifyPersonas: IPersonaProps[];
  additionalPersonas: IPersonaProps[];
  notifyOptions: IPersonaProps[];
  inputTypeLocked: true;
};

type InputOption = | "CollectInput" | "useStandardInput" | "usePreviousRoundInput";

interface StakeholderScenarioObject {
  key: ScenarioKey;
  name: ScenarioKey;
  description?: string;
}

interface InputTemplateRowView {
  enabled: boolean;
  stakeholderName?: string;
  stakeholderCode?: string;
  inputOption?: string;
  dueDate?: string;
  draftDueDate?: string;
  applicableScenarios: (ScenarioKey | StakeholderScenarioObject)[];
  notifyUserPersonas?: Partial<Record<ScenarioKey, IPersonaProps[]>>;
  notifyPersonas?: IPersonaProps[];
  additionalTeamPersonas?: IPersonaProps[];
  standardTemplateAvailable?: boolean | string;
  groupUsersPersona?: IPersonaProps[];
}

interface RoundViewModel {
  id: number;
  roundId: number;
  description?: string;
  customerSubmissionDate?: string;
  scenarios: ScenarioRow[];
  inputTemplates: InputTemplateRowView[];
  opportunityId: number;
  status?: string;
}

interface LibraryFile {
  name: string;
  url: string;
  serverRelativeUrl: string;
  timeLastModified?: string;
  length?: number;
  uniqueId?: string;
  File_x0020_Type?: string;
  OFileExtracted?: boolean;
}

interface ScenarioFile {
  stakeholder: string;
  name: string;
  url: string;
  serverRelativeUrl: string;
  scenario?: string;
  scenarioDescription?: string;
  status?: string;
  timeLastModified?: string;
  inputType?: string;
  revisionNumber?: number;
  submissionType?: string;
  stakeholderType?: string;
}

interface UnifiedFileItem {
  id: string | number;
  name: string;
  url: string;
  fileRelPath: string;
  scenario: string;
  scenarioDescription: string;
  inputType: string;
  rawInputType: string;
  status: string;
  revisionNumber: number | null;
  versionNumber: string | null;
  submissionType: string;
  modified: string | null;
  stakeholderName: string;
  stakeholderCode: string;
  dueDate: string;
  draftDueDate: string;
  notifyUsers: { name?: string; email?: string; login_id?: string }[];
  additionalTeamPersonas: string[];
  notifyEmails: string[];
  isCurrentVersion: '1' | '0';
  isCurrentApproved: '1' | '0';
  listItemId?: number | null;
  uploadedBy?: { name?: string; email?: string };
  modifiedBy?: { name?: string; email?: string };
  is_active?: boolean;
  inputRequired?: boolean;
  lastRevisionAttempt?: string | null;
  submittedBy: { name?: string; email?: string; login_id?: string };
  approvedBy: { name?: string; email?: string; login_id?: string };
  stakeholderType?: string | null;
}

interface PairRow {
  id: string;
  stakeholder: string;
  scenario: string;
  scenarioDescription?: string;
  versionNumber?: string | null;
  submissionType?: string;
  fileName?: string;
  status?: string;
  stakeholderType?: string;
  selectable: boolean;
}

interface TemplateCatalog {
  stakeholderName: string;
  stakeholderCode: string;
  groupIds: number[];
  versions: {
    versionNumber: string;
    showStandard: boolean;
  }[];
}

function formatISODateToLocal(iso?: string): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString();
}

function formatDateForFlow(
  date?: Date | string | null
): string {
  if (!date) return "";

  const d = date instanceof Date ? date : new Date(date);
  if (isNaN(d.getTime())) return "";

  const day = String(d.getDate()).padStart(2, "0");
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const year = d.getFullYear();

  return `${day}/${month}/${year}`;
}

function toPersonaFromApi(u: any): IPersonaProps {
  const key = String(u.id ?? u.login_id ?? u.email ?? Math.random().toString(36).slice(2));
  return {
    key,
    text: u.name ?? u.displayName ?? u.email ?? key,
    secondaryText: u.email ?? undefined,
  };
}

function encSeg(s?: string) {
  return encodeURIComponent(s || '');
}

function buildServerRelativeFolder(spfxContext: WebPartContext, segments: string[]) {
  const webRel = spfxContext.pageContext.web.serverRelativeUrl || '';
  const left = webRel.endsWith('/') ? webRel.slice(0, -1) : webRel;
  const rel = segments.map(encSeg).join('/');
  return `${left}/${rel}`;
}

function isStdTemplateAvailable(v: boolean | string | undefined) {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') return v.toLowerCase() === 'yes' || v.toLowerCase() === 'true';
  return false;
}

function norm(s?: string) { return (s ?? '').trim().toLowerCase(); }

function getRowKey(it: InputTemplateRowView, idx: number): string {
  return (it.stakeholderCode && `code:${it.stakeholderCode}`) ||
    (it.stakeholderName && `name:${it.stakeholderName}`) ||
    `idx:${idx}`;
}

export default function RoundDetailPage() {
  const { id, roundId } = useParams<{ id: string; roundId: string }>();
  const navigate = useNavigate();
  const cfg = (window as any).TENANT_CONFIG;
  const spfxContext: WebPartContext = (window as any).spfxContext;
  const ALLOWED_GROUP_NAME = 'Pricing';
  // const statusList = ["Created", "InProgress", "Submitted", "Approved", "Rejected", "Completed", "Cancelled", "Retracted"];
  const statusList = ["Validated", "Draft Validated", "Submitted", "Rejected", "Retracted", "Created"];
  const api = React.useMemo(
    () => new ApiDataProvider(spfxContext as any, { resource: cfg.apiResource, baseUrl: cfg.apiBaseUrl }),
    [cfg, spfxContext]
  );
  const { names, setNames } = useCrumbs();
  const { opportunityName } = names;
  const [customer, setCustomer] = React.useState("");
  const [loading, setLoading] = React.useState<boolean>(true);
  const [toast, setToast] = React.useState<{
    severity: 'success' | 'error' | 'warning' | 'info';
    text: string;
  } | null>(null);
  const [round, setRound] = React.useState<RoundViewModel | null>(null);

  const [editCustomerDateOpen, setEditCustomerDateOpen] =
    React.useState(false);

  const [customerSubmissionDateEdit, setCustomerSubmissionDateEdit] =
    React.useState<Date | null>(null);

  const [savingCustomerSubmissionDate, setSavingCustomerSubmissionDate] =
    React.useState(false);

  const [roundFolderName, setRoundFolderName] = React.useState<string>('');
  const [roundNumber, setRoundNumber] = React.useState<number>(1);
  const [backendRound, setBackendRound] = React.useState<any | null>(null);
  const [scenarioFilesByStakeholder, setScenarioFilesByStakeholder] =
    React.useState<{ [stakeholder_code: string]: ScenarioFile[] }>({});
  const [allRoundFiles, setAllRoundFiles] = React.useState<UnifiedFileItem[]>([]);
  const [filesLoading, setFilesLoading] = React.useState(false);

  const [inlinePanel, setInlinePanel] = React.useState<{
    show: boolean; file: UnifiedFileItem | null; mode: 'approval' | 'revision';
  }>({ show: false, file: null, mode: 'approval' });
  const [inlineDecision, setInlineDecision] = React.useState('');
  const [inlineComment, setInlineComment] = React.useState('');
  const [inlineRevisionComment, setInlineRevisionComment] = React.useState('');
  const [inlineSaving, setInlineSaving] = React.useState(false);
  const [showPrevApprovedPanel, setShowPrevApprovedPanel] = React.useState(false);

  const [showGeneratePanel, setShowGeneratePanel] = React.useState(false);
  const [pairRows, setPairRows] = React.useState<PairRow[]>([]);
  const [selectedPairIds, setSelectedPairIds] = React.useState<Set<string>>(new Set());
  const [sourceChoice, setSourceChoice] = React.useState<'existing' | 'template'>('template');
  const [existingRoundFiles, setExistingRoundFiles] = React.useState<LibraryFile[]>([]);
  const [selectedExistingFileName, setSelectedExistingFileName] = React.useState<string | undefined>(undefined);
  const [outputFileName, setOutputFileName] = React.useState<string>('output.xlsx');
  const [generating, setGenerating] = React.useState<boolean>(false);
  const userOverrodeFileNameRef = React.useRef(false);
  const LIBRARY_NAME = 'EUR';
  const [permissionLoading, setPermissionLoading] = React.useState(true);
  const [hasAccess, setHasAccess] = React.useState(false);
  const [inputTemplateCatalog, setInputTemplateCatalog] = React.useState<any[]>([]);
  const [templateCatalog, setTemplateCatalog] = React.useState<Map<string, TemplateCatalog>>(new Map());
  const [prevRoundDetails, setPrevRoundDetails] = React.useState<any>(null);
  const [allOpportunityRounds, setAllOpportunityRounds] =
    React.useState<any[]>([]);
  const [currentRoundDetails, setCurrentRoundDetails] = React.useState<any>(null);
  const [perScenarioNotify, setPerScenarioNotify] = React.useState<Record<string, Record<ScenarioKey, IPersonaProps[]>>>({});
  const [notifyScenarioKey, setNotifyScenarioKey] = React.useState<ScenarioKey | undefined>(undefined);
  const [addTemplateOpen, setAddTemplateOpen] = React.useState(false);

  const [folderCreationDialogOpen, setFolderCreationDialogOpen] =
    React.useState(false);

  // const [pendingFlowPayload, setPendingFlowPayload] =
  //   React.useState<any>(null);

  const [pendingFlowPayload, setPendingFlowPayload] =
    React.useState<any[]>([]);

  const handleInputTemplateFlowReady = (flowPayload: any) => {
    setPendingFlowPayload([flowPayload]);

    // Close the Add / Edit Input Template drawer
    setAddTemplateOpen(false);
    setEditOpen(false);

    // Trigger Power Automate immediately
    triggerFlow(
      flowPayload,
      "RoundCreationFlow"
    ).catch((error) => {
      console.error("Failed to start folder creation flow", error);

      setToast({
        severity: "error",
        text: "Failed to start folder creation."
      });
    });

    // Open the folder creation dialog
    setFolderCreationDialogOpen(true);
  };

  const handleFolderDialogOk = () => {
    if (!pendingFlowPayload.length) {
      return;
    }

    const flowsToTrigger = [...pendingFlowPayload];

    setFolderCreationDialogOpen(false);
    setPendingFlowPayload([]);

    void Promise.all(
      flowsToTrigger.map(payload =>
        triggerFlow(payload, "RoundCreationFlow")
      )
    ).catch(error => {
      console.error("Failed to start folder creation flow", error);

      setToast({
        severity: "error",
        text: "Failed to start folder creation."
      });
    });
  };

  React.useEffect(() => {
    if (!folderCreationDialogOpen) return;

    const timer = setTimeout(() => {
      setFolderCreationDialogOpen(false);
      setPendingFlowPayload([]);
    }, 25000);

    return () => {
      clearTimeout(timer);
    };
  }, [folderCreationDialogOpen]);
  const scenarioInputTypeMapRef = React.useRef<Map<string, Map<ScenarioKey, string>>>(new Map());
  const [addScenarioOpen, setAddScenarioOpen] = React.useState(false);
  const [leadPricerEmail, setLeadPricerEmail] = React.useState("");
  const [opportunityCountryName, setOpportunityCountryName] = React.useState("");
  const [bidTeamEmail, setBidTeamEmail] = React.useState<string[]>([]);
  const [expandedDatasetChips, setExpandedDatasetChips] = React.useState<Record<string, boolean>>({});
  const [expandedOutputDescriptions, setExpandedOutputDescriptions] =
    React.useState<Record<string, boolean>>({});
  const [addTemplateLoading, setAddTemplateLoading] = React.useState(false);
  const [editTemplateLoading, setEditTemplateLoading] = React.useState(false);
  const [changeVersionLoading, setChangeVersionLoading] = React.useState(false);
  const prevRoundIdRef = React.useRef<number | null>(null);

  const [standardTemplatesByStakeholder, setStandardTemplatesByStakeholder] =
    React.useState<Map<string, { id: number; title: string }[]>>(new Map())

  const [editOpen, setEditOpen] = React.useState(false);
  const [changeVersionOpen, setChangeVersionOpen] = React.useState(false);
  const [addDatasetOpen, setAddDatasetOpen] = React.useState(false);
  const [newDatasetDesc, setNewDatasetDesc] = React.useState('');
  const [savingDataset, setSavingDataset] = React.useState(false);
  const [showPrevApprovedToggle, setShowPrevApprovedToggle] = React.useState(false);
  const [actionAnchorEl, setActionAnchorEl] = React.useState<null | HTMLElement>(null);

  const [showRequiredOnly, setShowRequiredOnly] = React.useState<boolean | null>(true);
  const [selectedStatuses, setSelectedStatuses] = React.useState<string[]>([]);

  const [selectedActionRow, setSelectedActionRow] = React.useState<UnifiedFileItem | null>(null);
  const visibleRows = React.useMemo(() => {
    const map = new Map<string, UnifiedFileItem[]>();
    allRoundFiles.forEach(f => {
      const key = `${f.stakeholderCode}|${f.scenario}|${f.submissionType}`;

      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(f);
    });

    const result: UnifiedFileItem[] = [];

    map.forEach(rows => {
      const current = rows.find(r => r.isCurrentVersion === '1');

      const validatedRows = rows
        .filter(r =>
          ['validated', 'approved', 'draft validated'].includes(
            String(r.status || '').toLowerCase()
          )
        )
        .sort((a, b) =>
          Number(b.revisionNumber || 0) -
          Number(a.revisionNumber || 0)
        );

      const latestValidated = validatedRows[0];

      if (!showPrevApprovedToggle) {
        if (current) result.push(current);

        if (
          latestValidated &&
          latestValidated.id !== current?.id
        ) {
          result.push(latestValidated);
        }
      } else {
        validatedRows
          .slice(1)
          .forEach(row => result.push(row));
      }

    });

    return result;
  }, [allRoundFiles, showPrevApprovedToggle]);

  const hasSubmittedInputs = React.useMemo(() => {
    if (!backendRound?.inputs || !Array.isArray(backendRound.inputs)) {
      return false;
    }

    return backendRound.inputs.some((input: any) => {
      const status = String(input.workflowStatus ?? '')
        .trim()
        .toLowerCase();

      return status === 'submitted';
    });
  }, [backendRound]);;

  const tableRows = React.useMemo(() => {
    return [...visibleRows];
  }, [visibleRows]);


  type NewScenarioDraft = {
    key: ScenarioKey;
    desc: string;
  };

  const [newScenarios, setNewScenarios] = React.useState<NewScenarioDraft[]>([]);

  const getDueDateStyle = (dueDate?: string | null) => {
    if (!dueDate) return {};

    const today = new Date();
    const due = new Date(dueDate);

    today.setHours(0, 0, 0, 0);
    due.setHours(0, 0, 0, 0);

    const diffInDays = Math.floor(
      (due.getTime() - today.getTime()) /
      (1000 * 60 * 60 * 24)
    );

    if (diffInDays <= 2) {
      return {
        backgroundColor: "#ffcdd2",
        color: "#b71c1c",
        fontWeight: 600
      };
    }

    if (diffInDays <= 5) {
      return {
        backgroundColor: "#fff59d",
        color: "#f57f17",
        fontWeight: 600
      };
    }

    if (diffInDays <= 7) {
      return {
        backgroundColor: "#bbdefb",
        color: "#0d47a1",
        fontWeight: 600
      };
    }

    return {
      backgroundColor: "#e8f5e9",
      color: "#1b5e20",
      fontWeight: 600
    };
  };


  function getNextScenarioKey(
    used: ScenarioKey[],
    offset = 0
  ): ScenarioKey | null {
    const baseCode = 'A'.charCodeAt(0);
    const nextCode = baseCode + used.length + offset;
    if (nextCode > 'J'.charCodeAt(0)) return null;
    return String.fromCharCode(nextCode) as ScenarioKey;
  }

  // Generate Output Drawer Description
  const renderOutputDescription = (
    row: PairRow
  ) => {
    const description = (row.scenarioDescription ?? '').trim();

    const displayStatus =
      String(row.status || '').toLowerCase() === 'approved'
        ? 'Validated'
        : String(row.status || '').toLowerCase() === 'draft approved'
          ? 'Draft Validated'
          : row.status;

    if (!description) {
      return (
        <Typography variant="body2">
          <strong>{row.scenario}</strong>
          {displayStatus && (
            <span style={{ marginLeft: 6 }}>
              ({displayStatus})
            </span>
          )}
        </Typography>
      );
    }

    const isExpanded = !!expandedOutputDescriptions[row.id];
    const shouldTruncate = description.length > 40;

    const displayText =
      !isExpanded && shouldTruncate
        ? `${description.substring(0, 40)}...`
        : description;

    return (
      <Box>
        <Typography variant="body2">
          <strong>{row.scenario}</strong> - {displayText}
          {displayStatus && (
            <span style={{ marginLeft: 6 }}>
              ({displayStatus})
            </span>
          )}
        </Typography>

        {shouldTruncate && (
          <Typography
            component="span"
            variant="caption"
            sx={{
              ml: 0.5,
              color: 'primary.main',
              cursor: 'pointer',
              fontWeight: 600,
            }}
            onClick={(e) => {
              e.stopPropagation();

              setExpandedOutputDescriptions(prev => ({
                ...prev,
                [row.id]: !prev[row.id],
              }));
            }}
          >
            {isExpanded ? 'Read less' : 'Read more'}
          </Typography>
        )}
      </Box>
    );
  };



  function addScenarioDraft() {
    if (!round) return;

    const usedKeys = [
      ...round.scenarios.map(s => s.key),
      ...newScenarios.map(s => s.key),
    ];


    const nextKey = getNextScenarioKey(usedKeys);
    if (!nextKey) {
      setToast({ severity: 'warning', text: 'Maximum dataset limit reached (A–J).' });
      return;
    }

    setNewScenarios(prev => [
      ...prev,
      { key: nextKey, desc: '' },
    ]);
  }


  function updateScenarioDraft(
    key: ScenarioKey,
    desc: string
  ): void {
    setNewScenarios(prev =>
      prev.map(s =>
        s.key === key
          ? { ...s, desc }
          : s
      )
    );
  }

  function removeLastScenarioDraft(): void {
    setNewScenarios(prev => {
      if (prev.length === 0) return prev;
      return prev.slice(0, -1);
    });
  }

  const handleToggle = async (

    row: UnifiedFileItem,
  ) => {
    const newValue = !row.inputRequired;

    setAllRoundFiles((prev) =>
      prev.map((item) =>
        item.id === row.id
          ? { ...item, inputRequired: newValue }
          : item
      )
    );
    setSelectedActionRow((prev) =>
      prev
        ? { ...prev, inputRequired: newValue }
        : prev
    );

    try {
      await api.updateInputRequired({
        id: Number(row.id),
        inputRequired: newValue
      });

      setToast({
        severity: "success",
        text: `Record ${newValue ? "Required" : "Not Required"} updated successfully`
      });

    } catch (error) {
      setAllRoundFiles((prev) =>
        prev.map((item) =>
          item.id === row.id
            ? { ...item, inputRequired: !newValue }
            : item
        )
      );

      setToast({
        severity: "error",
        text: "Failed to update status"
      });
    }
  };


  /* To Enable Edit of Customer submission Date*/
  const handleOpenCustomerDateEdit = () => {
    if (!round?.customerSubmissionDate) {
      setCustomerSubmissionDateEdit(null);
    } else {
      const date = new Date(round.customerSubmissionDate);

      setCustomerSubmissionDateEdit(
        isNaN(date.getTime()) ? null : date
      );
    }

    setEditCustomerDateOpen(true);
  };


  const handleSaveCustomerSubmissionDate = async () => {
    if (!round || !customerSubmissionDateEdit) {
      setToast({
        severity: 'warning',
        text: 'Please select a customer submission date.'
      });
      return;
    }

    try {
      setSavingCustomerSubmissionDate(true);
      setToast(null);

      const updatedDate =
        customerSubmissionDateEdit.toISOString();

      await api.updateRoundMainInfo(round.roundId, {
        customerSubmissionDate: updatedDate
      });

      // Update UI immediately
      setRound(prev => {
        if (!prev) return prev;

        return {
          ...prev,
          customerSubmissionDate: updatedDate
        };
      });

      // Keep backendRound in sync as well
      setBackendRound((prev: any) => {
        if (!prev) return prev;

        return {
          ...prev,
          customerSubmissionDate: updatedDate
        };
      });

      setEditCustomerDateOpen(false);

      setToast({
        severity: 'success',
        text: 'Customer submission date updated successfully.'
      });

    } catch (err: any) {
      setToast({
        severity: 'error',
        text:
          err?.message ||
          'Failed to update customer submission date.'
      });
    } finally {
      setSavingCustomerSubmissionDate(false);
    }
  };

  const handleOpenActionsMenu = (
    event: React.MouseEvent<HTMLElement>,
    row: UnifiedFileItem
  ) => {
    event.stopPropagation();
    setActionAnchorEl(event.currentTarget);
    setSelectedActionRow(row);
  };

  const handleCloseActionsMenu = () => {
    setActionAnchorEl(null);
    setSelectedActionRow(null);
  };



  React.useEffect(() => {
    let active = true;

    (async () => {
      try {
        setPermissionLoading(true);

        const spContext = (window as any).spfxContext;
        const webUrl = spContext.pageContext.web.absoluteUrl;

        const response = await fetch(
          `${webUrl}/_api/web/currentuser/groups?$select=Title,Id`,
          {
            headers: {
              Accept: 'application/json;odata=nometadata',
            },
            credentials: 'same-origin',
          }
        );

        if (!response.ok) {
          throw new Error('Failed to fetch user groups');
        }

        const groups = await response.json();
        const isMember = groups.value.some(
          (g: any) => g.Title === ALLOWED_GROUP_NAME
        );

        if (!active) return;

        setHasAccess(isMember);
      } catch (error) {
        console.error('Permission check failed', error);
        setHasAccess(false);
      } finally {
        if (active) setPermissionLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, []);



  React.useEffect(() => {
    (async () => {
      const listTitle = "InputTemplate";
      const endpoint =
        `${cfg.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
        `?$select=Title,Code,VersionNumber,StandardTemplateAvailable,AssociatedGroup/Id,AssociatedGroup/Title` +
        `&$expand=AssociatedGroup`;

      const res = await spfxContext.spHttpClient.get(
        endpoint,
        SPHttpClient.configurations.v1
      );

      const json = await res.json();
      setInputTemplateCatalog(json.value ?? []);
    })();
  }, []);


  React.useEffect(() => {
    (async () => {
      try {
        const listTitle = 'InputTemplate';
        const endpoint =
          `${cfg.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items` +
          `?$select=Title,Code,VersionNumber,StandardTemplateAvailable,AssociatedGroup/Id,AssociatedGroup/Title` +
          `&$expand=AssociatedGroup`;
        const res = await spfxContext.spHttpClient.get(endpoint, SPHttpClient.configurations.v1);
        if (!res.ok) throw new Error(`Catalog GET failed: ${res.status}`);
        const json = await res.json();
        const items = json.value ?? [];

        const map = new Map<string, TemplateCatalog>();

        // items.forEach((it: any) => {
        //   const code = String(it.Code || "").trim();
        //   const title = String(it.Title || "").trim();
        //   if (!code) return;

        //   const groups: number[] = Array.isArray(it.AssociatedGroup)
        //     ? it.AssociatedGroup.map((g: any) => g.Id)
        //     : it.AssociatedGroup?.Id
        //       ? [it.AssociatedGroup.Id]
        //       : [];

        //   const key = code.toLowerCase();

        //   // if (!map.has(key)) {
        //   //   map.set(key, {
        //   //     stakeholderName: title,
        //   //     stakeholderCode: code,
        //   //     groupIds: groups,
        //   //     showStandard: isStdTemplateAvailable(it.StandardTemplateAvailable)
        //   //   });
        //   // }

        //   const existing = map.get(key);

        //   const currentShowStandard =
        //     isStdTemplateAvailable(it.StandardTemplateAvailable);

        //   if (!existing) {
        //     map.set(key, {
        //       stakeholderName: title,
        //       stakeholderCode: code,
        //       groupIds: groups,
        //       showStandard: currentShowStandard
        //     });
        //   } else {
        //     existing.showStandard =
        //       existing.showStandard || currentShowStandard;

        //     existing.groupIds = Array.from(
        //       new Set([
        //         ...existing.groupIds,
        //         ...groups
        //       ])
        //     );
        //   }
        // });


        items.forEach((it: any) => {

          const code = String(it.Code || "").trim();
          const title = String(it.Title || "").trim();

          if (!code) return;

          const groups: number[] =
            Array.isArray(it.AssociatedGroup)
              ? it.AssociatedGroup.map((g: any) => g.Id)
              : it.AssociatedGroup?.Id
                ? [it.AssociatedGroup.Id]
                : [];

          const key = code.toLowerCase();

          const versionNumber =
            String(it.VersionNumber || "").trim();

          const showStandard =
            isStdTemplateAvailable(
              it.StandardTemplateAvailable
            );

          const existing = map.get(key);

          if (!existing) {

            map.set(key, {
              stakeholderName: title,
              stakeholderCode: code,
              groupIds: groups,
              versions: [
                {
                  versionNumber,
                  showStandard
                }
              ]
            });

          } else {

            existing.groupIds = Array.from(
              new Set([
                ...existing.groupIds,
                ...groups
              ])
            );

            existing.versions.push({
              versionNumber,
              showStandard
            });
          }
        });

        setTemplateCatalog(map);
      } catch (e: any) {
        setTemplateCatalog(new Map());
        setToast({ severity: 'warning', text: `Could not load InputTemplate catalog: ${e.message}` });
      }
    })();
  }, [spfxContext]);

  React.useEffect(() => {
    if (!hasAccess) return;
    void (async () => {
      const o = await api.getOpportunity(Number(id));
      setCustomer(o.customer || "");
      const uniqueEmailsleadPricer = Array.from(
        new Set(o.lead_pricer?.map((u) => u.email).filter(Boolean)));
      const uniqueEmailsleadPricerString = uniqueEmailsleadPricer.join(";");
      setLeadPricerEmail(uniqueEmailsleadPricerString);
      const emailArray: string[] =
        o.bid_team_members?.map((member: any) => member.email) ?? [];
      setBidTeamEmail(emailArray);
      setOpportunityCountryName(o.country || "");
    })();
  }, [api, id, hasAccess]);

  React.useEffect(() => {
    void (async () => {
      try {
        setLoading(true);
        setToast(null);
        const r = await (api as any).getRound(Number(roundId));
        setBackendRound(r);

        setNames(prev => ({
          ...prev,
          opportunityName: r.opportunityTitle,
          roundName: `RND ${r.roundNumber?.toString()}`,
        }));

        setRoundNumber(Number(r.roundNumber || 1));

        const scenarios: ScenarioRow[] = (r.scenarioList ?? []).map((s: any) => ({
          key: s.name as ScenarioKey,
          description: s.desc ?? '',
        }));

        const inputTemplates: InputTemplateRowView[] = (r.stakeholders ?? []).map((st: any) => {
          const normalizedAS: (ScenarioKey | StakeholderScenarioObject)[] =
            (st.applicableScenarios ?? []).map((item: any) => ({
              key: (item.name) as ScenarioKey,
              description: item.desc ?? '',
            }));
          const notifyMap: Record<ScenarioKey, IPersonaProps[]> = {} as any;
          const notifyPersonas = (st.notifyUsers ?? []).map(toPersonaFromApi);
          return {
            enabled: !!st.active,
            stakeholderName: st.stakeholder ?? '',
            stakeholderCode: st.stakeholder_code ?? '',
            inputOption: (st.applicableScenarios?.[0]?.input_type) || 'CollectInput',
            dueDate: st.dueDate ?? undefined,
            draftDueDate: st.draftDueDate ?? undefined,
            applicableScenarios: normalizedAS,
            notifyUserPersonas: notifyMap,
            notifyPersonas,
            additionalTeamPersonas: (st.additionalStakeholders ?? []).map(toPersonaFromApi),
          } as InputTemplateRowView;
        });
        const normalized: RoundViewModel = {
          id: Number(r.id ?? roundId),
          roundId: Number(r.id ?? roundId),
          description: r.description ?? '',
          customerSubmissionDate: r.customerSubmissionDate ?? undefined,
          status: r.status ?? r.userStatus ?? '',
          scenarios,
          inputTemplates,
          opportunityId: Number(r.opportunityId ?? id),
        };
        setRound(normalized);
        setCurrentRoundDetails(r);
        setRoundFolderName(`RND ${r.roundNumber?.toString()}`);
      } catch (err: any) {
        setToast({ severity: 'error', text: `Failed to load round: ${err.message}` });
      } finally {
        setLoading(false);
      }
    })();
  }, [api, id, roundId, setNames]);

  // const remainingStakeholders = React.useMemo(() => {
  //   const addedCodes = new Set(
  //     (round?.inputTemplates || [])
  //       .map(it => (it.stakeholderCode || "").toLowerCase())
  //   );

  //   return Array.from(templateCatalog.values())
  //     .filter(s => !addedCodes.has(s.stakeholderCode.toLowerCase()))
  //     .map(s => ({
  //       stakeholderName: s.stakeholderName,
  //       stakeholderCode: s.stakeholderCode,
  //       groupIds: s.groupIds,
  //       showStandard: s.showStandard
  //     }));
  // }, [round, templateCatalog]);

  const remainingStakeholders = React.useMemo(() => {
    const addedCodes = new Set(
      (round?.inputTemplates || [])
        .map(it => (it.stakeholderCode || "").toLowerCase())
    );

    return Array.from(templateCatalog.values())
      .filter(
        s => !addedCodes.has(s.stakeholderCode.toLowerCase())
      )
      .map(s => ({
        stakeholderName: s.stakeholderName,
        stakeholderCode: s.stakeholderCode,
        groupIds: s.groupIds,

        showStandard: s.versions.some(
          v => v.showStandard
        ),

        versions: s.versions
      }));
  }, [round, templateCatalog]);


  React.useEffect(() => {
    const map = new Map<string, Map<ScenarioKey, string>>();
    if (backendRound?.inputs && Array.isArray(backendRound.inputs)) {
      (backendRound.inputs as any[]).forEach(inp => {
        const sName = String(inp.stakeholder || '');
        const scenario: ScenarioKey | undefined = String(inp.scenarioName || '').toUpperCase() as ScenarioKey;
        const iType = String(inp.inputType || '');
        if (!sName || !scenario) return;
        if (!map.has(sName)) map.set(sName, new Map());
        map.get(sName)!.set(scenario, iType);
      });
    }
    scenarioInputTypeMapRef.current = map;
  }, [backendRound]);


  React.useEffect(() => {
    if (!round || !backendRound) return;

    const out: Record<string, Record<ScenarioKey, IPersonaProps[]>> = {};

    const rowKeyByStakeholder = new Map<string, string>();
    round.inputTemplates.forEach((it, idx) => {
      rowKeyByStakeholder.set(
        (it.stakeholderCode ?? it.stakeholderName ?? `idx:${idx}`),
        getRowKey(it, idx)
      );
      rowKeyByStakeholder.set(
        (it.stakeholderName ?? it.stakeholderCode ?? `idx:${idx}`),
        getRowKey(it, idx)
      );
    });

    (backendRound.stakeholders ?? []).forEach((st: any) => {
      const keyA = String(st.stakeholder_code ?? '');
      const keyB = String(st.stakeholder ?? '');
      const rk =
        rowKeyByStakeholder.get(keyA) ||
        rowKeyByStakeholder.get(keyB);
      if (!rk) return;

      const perScenario: Record<ScenarioKey, IPersonaProps[]> = {
        A: [], B: [], C: [], D: [], E: [],
        F: [], G: [], H: [], I: [], J: [],
      };

      (st.applicableScenarios ?? []).forEach((sc: any) => {
        const sk = String(sc.name || '').toUpperCase() as ScenarioKey;
        if (!sk) return;
        perScenario[sk] = (sc.notify_users ?? []).map(toPersonaFromApi);
      });

      out[rk] = perScenario;
    });

    setPerScenarioNotify(out);
  }, [round, backendRound]);


  React.useEffect(() => {
    if (!backendRound) return;

    const nameToCode = new Map<string, string>();
    (backendRound.stakeholders ?? []).forEach((s: any) => {
      const name = String(s.stakeholder || '');
      const code = String(s.stakeholder_code || name || '');
      if (name) nameToCode.set(name, code);
    });

    const absolute = spfxContext?.pageContext?.web?.absoluteUrl || '';
    const results: { [stakeholder_code: string]: ScenarioFile[] } = {};

    (backendRound.inputs ?? []).forEach((inp: any) => {
      const sName = String(inp.stakeholder || '');
      // const sCode = nameToCode.get(sName) || sName || '';
      const sCode =
        String(inp.stakeholderCode || '').trim() ||
        nameToCode.get(sName) ||
        sName;
      if (!sCode) return;

      const fileRelPath: string | null = inp.fileRelPath ?? null;
      const fileName = fileRelPath ? fileRelPath.split('/').pop() || '' : '—';
      const url = fileRelPath ? `${absolute}${fileRelPath}` : '';
      const status = String(inp.workflowStatus || inp.userStatus || '') || '—';
      const scen = String(inp.scenarioName || '').toUpperCase();
      let inputType = String(inp.inputType);
      switch (inputType) {
        case 'CollectInput':
          inputType = 'Collect Input';
          break;
        case 'useStandardInput':
          inputType = 'Use Standard Input';
          break;
        case 'usePreviousRoundInput':
          inputType = 'Use Previous Round Input';
          break;
        default:
          inputType || '-';
      }
      const revisionNumber = Number(inp.revisionNumber);

      const sf: ScenarioFile = {
        stakeholder: sCode,
        name: fileName || '—',
        url,
        serverRelativeUrl: fileRelPath || '',
        scenario: scen,
        scenarioDescription: inp.scenarioDescription ?? '',
        status,
        inputType,
        revisionNumber,
        submissionType: inp.submissionType,
        stakeholderType: inp.stakeholderType ?? '',
        timeLastModified: inp.createdOn || inp.exportedOn || undefined,
      };

      if (!results[sCode]) results[sCode] = [];
      results[sCode].push(sf);
    });

    setScenarioFilesByStakeholder(results);
  }, [backendRound, spfxContext]);

  React.useEffect(() => {
    if (!backendRound || !round) return;
    let active = true;

    const toYesNo = (v: any): '1' | '0' => (v === 1 || v === '1' || v === true ? '1' : '0');

    const codeToTemplate = new Map<string, InputTemplateRowView>();
    (round.inputTemplates || []).forEach(it => {
      if (it.stakeholderCode) codeToTemplate.set(it.stakeholderCode, it);
    });

    const mapInputTypeLabel = (raw: string) => {
      switch (raw) {
        case 'CollectInput': return 'Collect Input';
        case 'useStandardInput': return 'Use Standard Input';
        case 'usePreviousRoundInput': return 'Use Previous Round Input';
        default: return raw || '—';
      }
    };

    (async () => {
      try {
        setFilesLoading(true);
        const mappedStatuses = selectedStatuses.map((s) => {
          switch (s) {
            case "Validated":
              return "Approved";

            case "Draft Validated":
              return "DraftApproved";

            default:
              return s;
          }
        });
        const rawResp = await api.getAllCurrentStakeholersInputByRound(
          Number(roundId),
          {
            workflowStatuses: mappedStatuses
          }
        );
        if (!active) return;
        if (!Array.isArray(rawResp)) { setAllRoundFiles([]); return; }

        const parsedRoundNumber = roundNumber;
        const mapped: UnifiedFileItem[] = (rawResp as any[])
          .filter(f => f.roundNumber === parsedRoundNumber)
          .map(f => {
            const rel = (f.fileRelPath || '').trim();
            const absUrl = rel
              ? new URL(rel, cfg?.siteBaseUrl).href
              : '';
            const name = rel.split('/').pop() || rel || 'Unknown file';
            const code = f.stakeholderCode ?? '';
            const tmpl = codeToTemplate.get(code);
            let wfStatus = f.workflowStatus ?? '—';
            if (f.workflowStatus === 'Approved') {
              wfStatus = "Validated";
            }
            else if (wfStatus === "DraftApproved") {
              wfStatus = "Draft Validated";
            }
            return {
              id: f.id ?? f.listItemId ?? name,
              lastRevisionAttempt: f.lastRevisionAttempt ?? null,
              name,
              url: absUrl,
              fileRelPath: rel,
              scenario: f.scenarioName ?? '—',
              scenarioDescription: f.scenarioDescription ?? '—',
              rawInputType: f.inputType ?? '',
              inputType: mapInputTypeLabel(f.inputType ?? ''),
              status: wfStatus,
              revisionNumber: f.revisionNumber ?? null,
              versionNumber: f.versionNumber ?? null,
              submissionType: f.submissionType ?? '',
              modified: f.submittedOn ?? null,
              stakeholderCode: code,
              stakeholderName: tmpl?.stakeholderName ?? code,
              dueDate: tmpl?.dueDate ?? '',
              draftDueDate: tmpl?.draftDueDate ?? '',
              notifyUsers: f.notifyUsers ?? [],
              additionalTeamPersonas:
                (f.additionalStakeholders ?? [])
                  .map((u: any) => u.name)
                  .filter(Boolean),
              notifyEmails: [
                ...((f.notifyUsers ?? []) as { email?: string }[])
                  .map((u) => u.email)
                  .filter(Boolean),

                ...((f.additionalStakeholders ?? []) as { email?: string }[])
                  .map((u) => u.email)
                  .filter(Boolean),
              ] as string[],
              isCurrentVersion: toYesNo(f.isCurrentVersion),
              isCurrentApproved: toYesNo(f.isCurrentApproved),
              listItemId: f.listItemId ?? null,
              uploadedBy: { name: f.uploadedByName ?? '', email: f.uploadedByEmail ?? '' },
              modifiedBy: { name: f.modifiedByName ?? '', email: f.modifiedByEmail ?? '' },
              is_active: f.active === true || f.active === 1 || f.active === "1",
              inputRequired: f.inputRequired === true,
              submittedBy: f.submittedBy ?? {},
              approvedBy: f.approvedBy ?? {},
              stakeholderType: f.stakeholderType,
            } as UnifiedFileItem;
          });


        if (active) setAllRoundFiles(mapped);
      } catch {
        if (active) setAllRoundFiles([]);
      } finally {
        if (active) setFilesLoading(false);
      }
    })();

    return () => { active = false; };
  }, [backendRound, round, api, roundId, roundNumber, cfg, selectedStatuses]);


  const filteredRows = React.useMemo(() => {
    const rows = Array.isArray(allRoundFiles) ? tableRows : [];

    return rows.filter((row) => {
      if (!row) return false;

      if (showRequiredOnly === null) return true;

      const value = row.inputRequired === true;

      return showRequiredOnly ? value : !value;
    });
  }, [tableRows, showRequiredOnly]);


  async function handleSaveMultipleDatasets() {
    if (!round || newScenarios.length === 0) return;

    const invalid = newScenarios.some(s => !s.desc.trim());
    if (invalid) {
      setToast({ severity: 'warning', text: 'All datasets must have a description.' });
      return;
    }

    try {
      setSavingDataset(true);
      setToast(null);

      const scenarioList = [
        ...round.scenarios.map(s => ({
          name: s.key,
          desc: s.description ?? '',
        })),
        ...newScenarios.map(s => ({
          name: s.key,
          desc: s.desc.trim(),
        })),
      ];

      await api.updateRoundMainInfo(round.roundId, {
        scenarioList,
      });

      setRound(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          scenarios: [
            ...prev.scenarios,
            ...newScenarios.map(s => ({
              key: s.key,
              description: s.desc.trim(),
            })),
          ],
        };
      });

      setNewScenarios([]);
      setAddDatasetOpen(false);
      setToast({ severity: 'success', text: 'Datasets added successfully.' });

      await refreshBackendRound();
    } catch (e: any) {
      setToast({ severity: 'error', text: e.message });
    } finally {
      setSavingDataset(false);
    }
  }
  const hasNonAdhocValidatedFile = React.useMemo(() => {
    const keys = Object.keys(scenarioFilesByStakeholder || {});

    for (const key of keys) {
      const files = scenarioFilesByStakeholder[key] || [];

      for (const file of files) {
        const status = String(file.status || '').trim().toLowerCase();
        const stakeholderType = String(file.stakeholderType || '').trim().toLowerCase();

        const isValidated =
          status === 'approved' ||
          status === 'draftapproved';

        const isAdhoc =
          stakeholderType === 'adhoc';

        if (isValidated && !isAdhoc) {
          return true;
        }
      }
    }

    return false;
  }, [scenarioFilesByStakeholder]);

  React.useEffect(() => {
    const latestValidatedMap = new Map<string, ScenarioFile>();

    Object.keys(scenarioFilesByStakeholder).forEach(code => {
      const files = scenarioFilesByStakeholder[code] || [];

      files.forEach(f => {
        // const status = String(f.status || '').toLowerCase();
        // if (status !== 'approved' && status !== 'validated') return;
        const status = String(f.status || '').toLowerCase();

        const stakeholderType =
          String(f.stakeholderType || '').trim().toLowerCase();
        const isAdhoc = stakeholderType === 'adhoc';
        const isSelectable =
          status === 'approved' ||
          status === 'validated' ||
          status === 'draftapproved';

        // Do not show Adhoc templates in Generate Output drawer
        if (!isSelectable || isAdhoc) return;

        if (!isSelectable) return;
        const scen = String(f.scenario || '').toUpperCase();

        if (!scen) return;

        const submissionType = String(
          (f as any).submissionType || ''
        ).toLowerCase();

        //const id = `${code}|${scen}|${submissionType}`;

        const id = `${code}|${scen}`;

        // const existing = latestValidatedMap.get(id);

        // const oldRev = Number(existing?.revisionNumber || 0);
        // const newRev = Number(f.revisionNumber || 0);
        // if (!existing || newRev > oldRev) {
        //   latestValidatedMap.set(id, f);
        //   if (!existing || newRev > oldRev) {
        //     latestValidatedMap.set(id, f);
        //   }
        // }


        const existing = latestValidatedMap.get(id);

        const currentStatus = String(f.status || "").toLowerCase();
        const existingStatus = String(existing?.status || "").toLowerCase();

        const isCurrentFinal =
          currentStatus === "approved" ||
          currentStatus === "validated";

        const isExistingFinal =
          existingStatus === "approved" ||
          existingStatus === "validated";

        if (!existing) {
          latestValidatedMap.set(id, f);
        }
        else if (isCurrentFinal && !isExistingFinal) {
          // Replace Draft with Final
          latestValidatedMap.set(id, f);
        }
        else if (isCurrentFinal === isExistingFinal) {
          // Same type (both Final or both Draft) -> keep latest revision
          if (
            Number(f.revisionNumber || 0) >
            Number(existing.revisionNumber || 0)
          ) {
            latestValidatedMap.set(id, f);
          }
        }

      });
    });

    const rows: PairRow[] = Array.from(latestValidatedMap.entries()).map(([id, f]) => {

      // const currentFile = allRoundFiles.find(
      //   x =>
      //     x.stakeholderCode === f.stakeholder &&
      //     x.scenario === f.scenario
      // );

      const currentFile = allRoundFiles.find(
        x =>
          x.stakeholderCode === f.stakeholder &&
          x.scenario === f.scenario &&
          (x.submissionType || '').toLowerCase() ===
          ((f as any).submissionType || '').toLowerCase()
      );

      // return {
      //   id,
      //   stakeholder: f.stakeholder,
      //   scenario: String(f.scenario || '').toUpperCase(),
      //   versionNumber: currentFile?.versionNumber,
      //   submissionType: currentFile?.submissionType,
      //   fileName: f.name,
      //   status: f.status,
      //   selectable: true
      // };
      return {
        id,
        stakeholder: f.stakeholder,
        scenario: String(f.scenario || '').toUpperCase(),
        scenarioDescription:
          round?.scenarios.find(
            s => s.key === String(f.scenario || '').toUpperCase()
          )?.description
          ?? f.scenarioDescription
          ?? currentFile?.scenarioDescription
          ?? '',
        versionNumber: currentFile?.versionNumber,
        submissionType: f.submissionType,
        fileName: f.name,
        status:
          String(f.status).toLowerCase() === 'draftapproved'
            ? 'Draft Approved'
            : f.status,
        selectable: true
      };
    });

    setPairRows(rows);

    const defSel = new Set<string>();
    rows.forEach(r => defSel.add(r.id));

    setSelectedPairIds(defSel);

    //}, [scenarioFilesByStakeholder]);
  }, [scenarioFilesByStakeholder, allRoundFiles, round]);

  const groupedPairRows = React.useMemo(() => {
    const groups: { [stakeholder: string]: PairRow[] } = {};
    pairRows.forEach(r => {
      if (!groups[r.stakeholder]) groups[r.stakeholder] = [];
      groups[r.stakeholder].push(r);
    });
    return groups;
  }, [pairRows]);

  async function spGetFolderFilesBasic(serverRelativeFolderUrl: string): Promise<any[]> {
    const select = `$select=Name,TimeLastModified,ServerRelativeUrl,Length,UniqueId,ListItemAllFields/OFileExtracted&$expand=ListItemAllFields`;
    const endpoint =
      `${spfxContext.pageContext.web.absoluteUrl}` +
      `/_api/web/GetFolderByServerRelativeUrl('${encodeURIComponent(serverRelativeFolderUrl)}')/Files?${select}`;

    const resp: SPHttpClientResponse = await spfxContext.spHttpClient.get(endpoint, SPHttpClient.configurations.v1);
    if (!resp.ok) {
      const txt = await resp.text();
      throw new Error(`Files fetch failed (${resp.status}): ${txt}`);
    }
    const json = await resp.json();
    return (json?.value || []) as any[];
  }

  async function updateLastExtracted(
    selectedServerRelativeUrl: string
  ): Promise<void> {

    // First make sure no other output file in this round
    // is marked as the last extracted file.
    for (const file of existingRoundFiles) {

      const endpoint =
        `${spfxContext.pageContext.web.absoluteUrl}` +
        `/_api/web/GetFileByServerRelativeUrl('${encodeURIComponent(
          file.serverRelativeUrl
        )}')/ListItemAllFields`;

      const response = await spfxContext.spHttpClient.post(
        endpoint,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata",
            "Content-Type": "application/json;odata=nometadata",
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE",
          },
          body: JSON.stringify({
            isLastextracted: false,
          }),
        }
      );

      if (!response.ok) {
        const errorText = await response.text();

        throw new Error(
          `Failed to reset isLastextracted for "${file.name}" ` +
          `(${response.status}): ${errorText}`
        );
      }
    }

    // Now mark ONLY the selected file as the last extracted file.
    const selectedEndpoint =
      `${spfxContext.pageContext.web.absoluteUrl}` +
      `/_api/web/GetFileByServerRelativeUrl('${encodeURIComponent(
        selectedServerRelativeUrl
      )}')/ListItemAllFields`;

    const selectedResponse =
      await spfxContext.spHttpClient.post(
        selectedEndpoint,
        SPHttpClient.configurations.v1,
        {
          headers: {
            Accept: "application/json;odata=nometadata",
            "Content-Type": "application/json;odata=nometadata",
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE",
          },
          body: JSON.stringify({
            isLastextracted: true,
          }),
        }
      );

    if (!selectedResponse.ok) {
      const errorText = await selectedResponse.text();

      throw new Error(
        `Failed to mark selected file as last extracted ` +
        `(${selectedResponse.status}): ${errorText}`
      );
    }
  }



  const refreshBackendRound = React.useCallback(async () => {
    const r = await (api as any).getRound(Number(roundId));
    setBackendRound(r);
    setRound(mapRound(r));
    setCurrentRoundDetails(r);
  }, [api, roundId]);

  function mapRound(r: any): RoundViewModel {
    const scenarios: ScenarioRow[] = (r.scenarioList ?? []).map((s: any) => ({
      key: s.name as ScenarioKey,
      description: s.desc ?? '',
    }));

    const inputTemplates: InputTemplateRowView[] = (r.stakeholders ?? []).map((st: any) => {
      const normalizedAS = (st.applicableScenarios ?? []).map((item: any) => ({
        key: item.name as ScenarioKey,
        description: item.desc ?? '',
      }));
      return {
        enabled: !!st.active,
        stakeholderName: st.stakeholder ?? '',
        stakeholderCode: st.stakeholder_code ?? '',
        inputOption: st.applicableScenarios?.[0]?.input_type || 'CollectInput',
        dueDate: st.dueDate ?? undefined,
        draftDueDate: st.draftDueDate ?? undefined,
        applicableScenarios: normalizedAS,
        notifyPersonas: (st.notifyUsers ?? []).map(toPersonaFromApi),
        additionalTeamPersonas: (st.additionalStakeholders ?? []).map(toPersonaFromApi),
      };
    });

    return {
      id: Number(r.id),
      roundId: Number(r.id),
      description: r.description ?? '',
      customerSubmissionDate: r.customerSubmissionDate ?? undefined,
      scenarios,
      inputTemplates,
      opportunityId: Number(r.opportunityId),
    };
  }


  React.useEffect(() => {
    void (async () => {
      if (!showGeneratePanel || !customer || !opportunityName || !roundFolderName) {
        setExistingRoundFiles([]);
        return;
      }
      try {
        const folderSrvRel = buildServerRelativeFolder(spfxContext, [
          LIBRARY_NAME,
          customer,
          opportunityName,
          roundFolderName,
        ]);
        const items = await spGetFolderFilesBasic(folderSrvRel);
        const excelExtensions = [
          '.xlsx', '.xlsm', '.xlsb', '.xltx', '.xltm', // modern
          '.xls', '.xlt', '.xlm', '.xlb',              // legacy
          '.xlsmhtml', '.xlshtml',                     // HTML-based
          '.xlam', '.xla', '.xll',                     // add-ins
          '.xml', '.xlsxml', '.xlw'                    // xml & others
        ];
        const files: LibraryFile[] = items
          .map((f: any) => ({
            name: f.Name as string,
            url: `${spfxContext.pageContext.web.absoluteUrl}${f.ServerRelativeUrl}`,
            serverRelativeUrl: f.ServerRelativeUrl as string,
            timeLastModified: f.TimeLastModified as string,
            length: Number(f.Length),
            uniqueId: f.UniqueId as string,
            File_x0020_Type: f.File_x0020_Type,
            OFileExtracted: f.ListItemAllFields?.OFileExtracted
          }))
          .filter(
            f =>
              f.OFileExtracted === false &&
              excelExtensions.some(ext =>
                f.name.toLowerCase().endsWith(ext)
              )
          );
        setExistingRoundFiles(files);
      } catch (err: any) {
        setToast({ severity: 'error', text: `Failed to load existing output files: ${err.message}` });
      }
    })();
  }, [showGeneratePanel, customer, opportunityName, roundFolderName, spfxContext]);

  function toggleRowSelection(row: PairRow) {
    if (!row.selectable) return;
    setSelectedPairIds(prev => {
      const next = new Set(prev);
      if (next.has(row.id)) next.delete(row.id); else next.add(row.id);
      return next;
    });
  }


  async function handleGenerate() {
    try {
      if (!round) return;
      const chosen = pairRows.filter(r => selectedPairIds.has(r.id));
      if (chosen.length === 0) {
        setToast({ severity: 'warning', text: 'Please select at least one Validated (Input, Dataset) row.' });
        return;
      }
      if (sourceChoice === 'template' && !outputFileName) {
        setToast({ severity: 'warning', text: 'Please provide an output file name.' });
        return;
      }
      if (sourceChoice === 'existing' && !selectedExistingFileName) {
        setToast({ severity: 'warning', text: 'Please choose an existing output Excel file.' });
        return;
      }


      const finalOutputFileName =
        sourceChoice === 'template'
          ? forceXlsx(outputFileName)
          : selectedExistingFileName

      setGenerating(true);
      setToast(null);
      const grouped = new Map<string, ScenarioKey[]>();
      chosen.forEach(r => {
        const scen = r.scenario as ScenarioKey;
        if (!grouped.has(r.stakeholder)) grouped.set(r.stakeholder, []);
        grouped.get(r.stakeholder)!.push(scen);
      });
      const apiResults: Array<{ stakeholder: string; scenarios: ScenarioKey[]; versionNumber: string | null; submissionType: string; apiResult: any }> = [];
      const tasks: Promise<any>[] = [];

      const codeToName = new Map<string, string>();
      round.inputTemplates.forEach(it => {
        const code = String(it.stakeholderCode || '').trim();
        const name = String(it.stakeholderName || '').trim();
        if (code) codeToName.set(code, name || code);
      });


      grouped.forEach((scenarios, stakeholder) => {
        const selectedFile = allRoundFiles.find(
          x =>
            x.stakeholderCode === stakeholder &&
            scenarios.includes(x.scenario as ScenarioKey)
        );
        const payload = {
          roundId: round.roundId,
          stakeholder: stakeholder,
          scenarios,
        };
        tasks.push(
          (api as any).generateOutputFile(payload)
            .then((result: any) => {
              apiResults.push({ stakeholder, scenarios, versionNumber: selectedFile?.versionNumber ?? "", submissionType: selectedFile?.submissionType ?? "", apiResult: result });
            })
            .catch((err: any) => {
              apiResults.push({ stakeholder, scenarios, versionNumber: selectedFile?.versionNumber ?? "", submissionType: selectedFile?.submissionType ?? "", apiResult: { error: err?.message || 'API failed' } });
            })
        );
      });
      await Promise.all(tasks);
      const targetFolderRel = `/${LIBRARY_NAME}/${customer ?? ''}/${opportunityName ?? ''}/${roundFolderName ?? ''}`;
      const selections = chosen.map(r => {
        const file = allRoundFiles.find(
          x =>
            x.stakeholderCode === r.stakeholder &&
            x.scenario === r.scenario
        );

        return {
          stakeholder: r.stakeholder,
          scenario: r.scenario,
          versionNumber: file?.versionNumber ?? "",
          submissionType: file?.submissionType ?? ""
        };
      });
      const flowPayload = {
        eventType: 'GeneratedFile',
        roundId: round.roundId,
        opportunityId: round.opportunityId,
        triggeredBy: spfxContext.pageContext.user.email,
        opportunityName: opportunityName,
        roundNumber,
        opportunityFolderLink: `${cfg.siteUrl}/${LIBRARY_NAME}/${customer ?? ''}/${opportunityName ?? ''}`,
        outputFolderLink: `${cfg.siteUrl}/${LIBRARY_NAME}/${customer ?? ''}/${opportunityName ?? ''}/${roundFolderName ?? ''}`,
        Gselections: selections,
        GexistingFileName: sourceChoice === 'existing' ? selectedExistingFileName : undefined,
        GtemplateFileName: 'Templates.xlsx',
        GoutputFileName: finalOutputFileName,
        GtargetFolderRel: targetFolderRel,
        GsourceChoice: sourceChoice,
        GBodyGenerateOuput: apiResults,
        siteUrl: `${cfg.siteUrl}`
      };

      // console.log(flowPayload);
      triggerFlow(flowPayload, 'outputGenerationFlow');

      setToast({
        severity: 'info',
        text: 'Your file is being generated. You will be notified by email once it is ready.'
      });

    } catch (err: any) {
      setToast({ severity: 'error', text: `Failed to generate file(s): ${err.message}` });
    } finally {
      setGenerating(false);
      setShowGeneratePanel(false);
    }
  }

  // Close Round State Variables
  const [closingRound, setClosingRound] = React.useState(false);
  const [closeDialogOpen, setCloseDialogOpen] = React.useState(false);

  const [closeRoundDrawerOpen, setCloseRoundDrawerOpen] = React.useState(false);
  const [extractInfo, setExtractInfo] = React.useState(false);
  const [selectedOutputFile, setSelectedOutputFile] = React.useState("");
  const [closeRoundData, setCloseRoundData] = React.useState<any>(null);
  const [loadingCloseRoundData, setLoadingCloseRoundData] = React.useState(false);
  const [closeRoundResponse, setCloseRoundResponse] = React.useState<any>(null);
  const [closeRoundError, setCloseRoundError] = React.useState("");
  // Close Round State Variables

  // Extract Information State Variables

  const [extractInformationDrawerOpen, setExtractInformationDrawerOpen] = React.useState(false);
  const [extractingInformation, setExtractingInformation] = React.useState(false);

  const [outputLogs, setOutputLogs] = React.useState<OutputLog[]>([]);
  const [loadingOutputLogs, setLoadingOutputLogs] = React.useState(false);

  // Extract Information State Variables

  const loadCloseRoundFiles = async () => {
    try {

      if (!customer || !opportunityName || !roundFolderName) {
        return;
      }
      const folderSrvRel = buildServerRelativeFolder(spfxContext, [
        LIBRARY_NAME,
        customer,
        opportunityName,
        roundFolderName,
      ]);

      const items = await spGetFolderFilesBasic(folderSrvRel);

      const excelExtensions = [
        ".xlsx",
        ".xlsm",
        ".xlsb",
        ".xltx",
        ".xltm",
        ".xls"
      ];
      const files: LibraryFile[] = items
        .map((f: any) => ({
          name: f.Name,
          url: `${spfxContext.pageContext.web.absoluteUrl}${f.ServerRelativeUrl}`,
          serverRelativeUrl: f.ServerRelativeUrl,
          timeLastModified: f.TimeLastModified,
          length: Number(f.Length),
          uniqueId: f.UniqueId,
          OFileExtracted: f.ListItemAllFields?.OFileExtracted,
        }))
        .filter(
          f =>
            f.OFileExtracted === false &&
            excelExtensions.some(ext =>
              f.name.toLowerCase().endsWith(ext)
            )
        );

      setExistingRoundFiles(files);

    } catch (err: any) {
      setToast({
        severity: "error",
        text: err.message
      });
    }
  };

  const loadExtractOutputFiles = async () => {
    try {
      if (!customer || !opportunityName || !roundFolderName) {
        return;
      }

      const folderSrvRel = buildServerRelativeFolder(spfxContext, [
        LIBRARY_NAME,
        customer,
        opportunityName,
        roundFolderName,
      ]);

      const items = await spGetFolderFilesBasic(folderSrvRel);

      const excelExtensions = [
        ".xlsx",
        ".xlsm",
        ".xlsb",
        ".xltx",
        ".xltm",
        ".xls",
      ];

      const files: LibraryFile[] = items
        .map((f: any) => ({
          name: f.Name,
          url: `${spfxContext.pageContext.web.absoluteUrl}${f.ServerRelativeUrl}`,
          serverRelativeUrl: f.ServerRelativeUrl,
          timeLastModified: f.TimeLastModified,
          length: Number(f.Length),
          uniqueId: f.UniqueId,
          OFileExtracted: f.ListItemAllFields?.OFileExtracted,
        }))
        // .filter((f) =>
        //   excelExtensions.some((ext) =>
        //     f.name.toLowerCase().endsWith(ext)
        //   )
        // );
        .filter(
          (f) =>
            f.OFileExtracted === false &&
            excelExtensions.some((ext) =>
              f.name.toLowerCase().endsWith(ext)
            )
        );

      setExistingRoundFiles(files);
    } catch (err: any) {
      setToast({
        severity: "error",
        text: err.message || "Failed to load output files",
      });
    }
  };

  const handleOpenExtractInformationDrawer = async () => {

    setExtractInformationDrawerOpen(true);

    await Promise.all([
      //loadCloseRoundFiles(),
      loadExtractOutputFiles(),
      loadOutputLogs()
    ]);

  };

  const handleCloseExtractInformationDrawer = () => {
    setExtractInformationDrawerOpen(false);
  };

  const handleOpenCloseRoundDrawer = async () => {
    setCloseRoundError("");
    setCloseRoundDrawerOpen(true);

    await loadCloseRoundFiles();

  };

  async function handleCloseRound() {
    try {
      //If  Checknox Selected and  Close Round In Close Round Drawer then
      if (extractInfo && !selectedOutputFile) {
        setCloseRoundError("Please select an existing output file.");
        return;
      }

      setCloseRoundError("");
      setClosingRound(true);

      //Always closes the round
      await api.closeRound(Number(roundId));

      //If  Checkbox Selected and clicked Close Round In Close Round Drawer then extract information
      if (extractInfo) {
        await processExtractInformation();
      }

      await refreshBackendRound();
      setCloseRoundDrawerOpen(false);
      setToast({
        severity: "success",
        text: "Round closed successfully."
      });

    } catch (err: any) {
      setToast({
        severity: 'error',
        text: err.message || 'Failed to close round'
      });
    } finally {
      setClosingRound(false);
    }
  }

  const saveGenerateOutputLog = async (
    flowResponse: any, filepath: string
  ) => {
    const flowProcessedData = (flowResponse && typeof flowResponse === 'object')
      ? (() => { const c = { ...flowResponse }; delete (c as any).success; return c; })()
      : null;
    const payload = {
      opportunityId: Number(id),
      roundId: Number(roundId),
      fileRelPath: filepath,
      processedData: flowProcessedData,
      extractedOn: new Date().toISOString(),
      extractedBy: spfxContext.pageContext.user.email
    };

    await api.generateOutputLog(payload);
  };
  const processExtractInformation = async () => {

    if (!selectedOutputFile) {
      throw new Error("Please select an existing output file.");
    }

    // Build flow payload
    const targetFolderRel =
      `/${LIBRARY_NAME}/${customer ?? ""}/${opportunityName ?? ""}/${roundFolderName ?? ""}`;

    const flowPayloadToExtractInformation = {
      eventType: "ExtractInformation",
      roundId: round?.roundId,
      opportunityId: round?.opportunityId,
      triggeredBy: spfxContext.pageContext.user.email,
      opportunityName,
      roundNumber,
      opportunityFolderLink:
        `${cfg.siteUrl}/${LIBRARY_NAME}/${customer}/${opportunityName}`,
      outputFolderLink:
        `${cfg.siteUrl}/${LIBRARY_NAME}/${customer}/${opportunityName}/${roundFolderName}`,
      GexistingFileName: selectedOutputFile,
      GoutputFileName: selectedOutputFile,
      GtargetFolderRel: targetFolderRel,//+'/',
      siteUrl: `${cfg.siteUrl}`,
      listTitle: 'EUR',
      webValidationUrl: `${cfg.serverRelativeUrl}`
    };
    // Trigger Power Automate Flow
    const extractInformationResponse = await triggerFlow(
      flowPayloadToExtractInformation,
      "outputGenerationFlow"
    );

    const filepath = targetFolderRel + "/" + selectedOutputFile;
    // console.log("flowResponse on calling extractInformationResponse : ", extractInformationResponse)

    // On success call GenerateOutputLog API
    // if (extractInformationResponse?.success) {
    //   await saveGenerateOutputLog(extractInformationResponse, filepath);
    // }

    if (extractInformationResponse?.success) {
      const selectedFile = existingRoundFiles.find(
        file => file.name === selectedOutputFile
      );

      if (!selectedFile) {
        throw new Error(
          `Selected output file "${selectedOutputFile}" could not be found.`
        );
      }

      // Mark the selected file as the last extracted file
      await updateLastExtracted(
        selectedFile.serverRelativeUrl
      );

      // Save extraction log
      await saveGenerateOutputLog(
        extractInformationResponse,
        filepath
      );
      // Refresh Previous Output
      await loadOutputLogs();
    }

    return extractInformationResponse;
  };
  const handleExtractInformation = async () => {
    try {
      setExtractingInformation(true);

      await processExtractInformation();


      setExtractInformationDrawerOpen(false);
      setToast({
        severity: "success",
        text: "Information extracted successfully."
      });

    } catch (err: any) {
      setToast({
        severity: "error",
        text: err.message
      });
    } finally {
      setExtractingInformation(false);
    }
  };
  const loadOutputLogs = async () => {
    try {
      setLoadingOutputLogs(true);

      const response = await api.getOutputLogs(Number(roundId));

      setOutputLogs(response || []);
    }
    catch (err: any) {
      setToast({
        severity: "error",
        text: err.message
      });
    }
    finally {
      setLoadingOutputLogs(false);
    }
  };


  function assertStakeholderFields(
    it: InputTemplateRowView
  ): asserts it is InputTemplateRowView & {
    stakeholderName: string;
    stakeholderCode: string;
  } {
    if (!it.stakeholderName || !it.stakeholderCode) {
      throw new Error("Stakeholder name or code is missing");
    }
  }

  function buildFullPayloadForRow(
    stakeholderType: string,
    it: InputTemplateRowView & {
      stakeholderName: string;
      stakeholderCode: string;
    },
    round: RoundViewModel,
    opportunityIdNum: number,
    // notifyList?: IPersonaProps[],
    // additionalList?: IPersonaProps[],
    notifyList?: any,
    additionalList?: any,
    scenarioConfigs?: Partial<Record<ScenarioKey, ScenarioConfig>>,
    commonVersionSelections?: string,
    collectDraftInput?: boolean,
    commonDraftDueDate?: Date | null,
  ) {

    const clean = (val?: string) =>
      val ? val.replace(/^i:0#\.f\|membership\|/i, "") : null;
    const isStandard = stakeholderType?.toLowerCase() === "standard";

    const applicableScenarios = it.applicableScenarios.map(s => {
      const key = normalizeScenarioKeyApplicableScenario(s);
      const scenarioObj =
        typeof s === "object" && s?.description
          ? s
          : round.scenarios.find(sc => sc.key === key);
      const scenarioCfg = scenarioConfigs?.[key];

      let inputType: InputOption = "CollectInput";

      if (scenarioCfg?.inputOption) {
        inputType = scenarioCfg.inputOption;
      } else {
        const fromView = getScenarioInputType(it.stakeholderName, key);
        if (
          fromView === "CollectInput" ||
          fromView === "useStandardInput" ||
          fromView === "usePreviousRoundInput"
        ) {
          inputType = fromView;
        }
      }

      return {
        name: key,
        desc: scenarioObj?.description || ``,
        input_type: inputType,
        isStandardRate: inputType === "useStandardInput",
        isCopiedPreviousRound: inputType === "usePreviousRoundInput",
        referenceData:
          inputType === "useStandardInput"
            ? Number(scenarioCfg?.standardReferenceId) ?? null
            : inputType === "usePreviousRoundInput"
              ? Number(scenarioCfg?.previousRoundId) ?? null
              : null
        // versionSelections:
        //   commonVersionSelections
        //     ? [commonVersionSelections]
        //     : [],

        // submissionTypes:
        //   collectDraftInput
        //     ? ["Draft", "Final"]
        //     : ["Final"],

        // draftDueDate:
        //   collectDraftInput && commonDraftDueDate
        //     ? commonDraftDueDate.toISOString()
        //     : null
      };
    });

    const notify_users =
      (notifyList ?? it.notifyPersonas ?? []).map((p: any) => {
        const email = clean(p.secondaryText as string) ?? "";

        const login_id = clean(
          (p.tertiaryText as string) || (p.id as string)
        );

        return {
          name: p.text || email,
          email,
          login_id
        };
      });

    const additionalStakeholders =
      (additionalList ?? it.additionalTeamPersonas ?? []).map((p: any) => {
        const email = clean(p.secondaryText as string) ?? "";

        const login_id = clean(
          (p.id as string) || (p.tertiaryText as string)
        );

        return {
          name: p.text || email,
          email,
          login_id
        };
      });

    // return {
    //   opportunityId: opportunityIdNum,
    //   roundId: round.roundId,
    //   stakeholder: it.stakeholderName,
    //   stakeholder_code: it.stakeholderCode,
    //   dueDate: it.dueDate ? new Date(it.dueDate).toISOString() : undefined,
    //   notify_users,
    //   additionalStakeholders,
    //   // notify_users: (notifyList ?? it.notifyPersonas ?? []).map(personaToApiUser),
    //   // additionalStakeholders: (additionalList ?? it.additionalTeamPersonas ?? []).map(personaToApiUser),
    //   applicableScenarios,
    //   versionNumber: commonVersionSelections ?? undefined,

    //   collectDraftInput: collectDraftInput ?? false,

    //   draftDueDate:
    //     collectDraftInput && commonDraftDueDate
    //       ? commonDraftDueDate.toISOString()
    //       : null
    // };
    const payload: any = {
      opportunityId: opportunityIdNum,
      roundId: round.roundId,
      stakeholder: it.stakeholderName,
      stakeholder_code: it.stakeholderCode,
      stakeholderType,
      dueDate: it.dueDate ? new Date(it.dueDate).toISOString() : undefined,
      notify_users,
      additionalStakeholders,
      applicableScenarios
    };

    if (isStandard) {
      payload.versionNumber = commonVersionSelections;
      payload.collectDraftInput = collectDraftInput ?? false;

      if (isStandard && collectDraftInput && commonDraftDueDate) {
        payload.draftDueDate = commonDraftDueDate.toISOString();
      }
    }

    return payload;
  }

  const prevRoundApprovedScenarioMap = React.useMemo(() => {
    const map = new Map<string, Set<ScenarioKey>>();
    if (!prevRoundDetails?.inputs) return map;

    const nameToCode = new Map<string, string>();
    prevRoundDetails.inputs.forEach((inp: any) => {
      if (
        inp.workflowStatus === "Approved" &&

        // inp.isCurrentApproved === "1" &&
        // inp.isCurrentVersion === "1" &&

        inp.scenarioName &&
        inp.stakeholder
      ) {
        // const code = nameToCode.get(norm(inp.stakeholder));

        const code = inp.stakeholderCode
          ? norm(inp.stakeholderCode)
          : nameToCode.get(norm(inp.stakeholder));
        if (!code) return;

        if (!map.has(code)) {
          map.set(code, new Set());
        }

        map.get(code)!.add(inp.scenarioName as ScenarioKey);
      }
    });

    // prevRoundDetails.inputs.forEach((inp: any) => {
    //   if (String(inp.workflowStatus).toLowerCase() !== "approved") return;

    //   const stakeholderCode = String(
    //     inp.stakeholder_code ?? inp.stakeholder ?? ""
    //   ).toLowerCase();

    //   const scenarioKey = String(inp.scenarioName ?? "").toUpperCase() as ScenarioKey;

    //   if (!stakeholderCode || !scenarioKey) return;

    //   if (!map.has(stakeholderCode)) {
    //     map.set(stakeholderCode, new Set());
    //   }

    //   map.get(stakeholderCode)!.add(scenarioKey);
    // });

    return map;
  }, [prevRoundDetails]);



  async function ensurePrevRoundLoaded(): Promise<any | null> {
    if (prevRoundDetails || roundNumber <= 1) {
      return prevRoundDetails;
    }

    try {
      const all = await (api as any).getRounds(Number(id));
      setAllOpportunityRounds(Array.isArray(all) ? all : []);
      const prev = all.find((r: any) => r.roundNumber === roundNumber - 1);
      setPrevRoundDetails(prev);
      return prev;
    } catch {
      setPrevRoundDetails(null);
    }

    return null;
  }



  function forceXlsx(name: string): string {
    const clean = name.trim();
    if (!clean) return 'output.xlsx';

    return clean.replace(/\.[^/.]+$/, '') + '.xlsx';
  }

  const prevRoundScenarioMap = React.useMemo(() => {
    const map = new Map<string, Set<ScenarioKey>>();

    if (!prevRoundDetails?.stakeholders) {
      return map;
    }

    for (const sh of prevRoundDetails.stakeholders) {
      const code = String(
        sh.stakeholder_code ?? sh.stakeholder ?? ""
      )
        .trim()
        .toLowerCase();

      if (!code) continue;

      const scenarioKeys = new Set<ScenarioKey>();

      (sh.applicableScenarios ?? []).forEach((sc: any) => {
        const key = String(sc.name ?? sc.key ?? "")
          .toUpperCase() as ScenarioKey;

        if (key) {
          scenarioKeys.add(key);
        }
      });

      map.set(code, scenarioKeys);
    }

    return map;
  }, [prevRoundDetails]);

  function getAddedUsers(
    previous: IPersonaProps[],
    current: IPersonaProps[]
  ) {
    const prevEmails = new Set(
      previous.map(p => p.secondaryText).filter(Boolean)
    );

    return current.filter(
      p => p.secondaryText && !prevEmails.has(p.secondaryText)
    );
  }

  function getRemovedUsers(
    previous: IPersonaProps[],
    current: IPersonaProps[]
  ) {
    const currEmails = new Set(
      current.map(p => p.secondaryText).filter(Boolean)
    );

    return previous.filter(
      p => p.secondaryText && !currEmails.has(p.secondaryText)
    );
  }


  function normalizeScenarioKeyApplicableScenario(
    s: ScenarioKey | { key?: string; name?: string }
  ): ScenarioKey {
    if (typeof s === "string") {
      return s as ScenarioKey;
    }
    return (s.key ?? s.name ?? "").toUpperCase() as ScenarioKey;
  }



  function buildStakeholderFlowBlock(
    row: {
      stakeholderName: string;
      stakeholderCode: string;
      dueDate?: string;
      applicableScenarios: ScenarioKey[];
      scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>>;
      notifyPersonas?: IPersonaProps[];
      additionalTeamPersonas?: IPersonaProps[];
      inputTemplateGroupIds?: number[];
      roundIdFolder: string;

      inputTemplateVersions?: {
        VersionNumber: string;
        DraftApplicable: boolean;
        Active: boolean;
      }[];

      commonVersionSelections?: string;
      collectDraftInput?: boolean;
      commonDraftDueDate?: Date | null;
    },
    scenarios: { key: ScenarioKey; description?: string }[]
  ) {
    const collectDatasets: {
      scenarioKey: ScenarioKey;
      scenarioDescription: string;
    }[] = [];

    const isAdhoc = (row.inputTemplateGroupIds ?? []).length === 0;

    const otherScenarioBlocks: any[] = [];

    const selectedVersion =
      row.inputTemplateVersions?.find(
        v => v.VersionNumber === row.commonVersionSelections
      );

    const draftApplicable =
      selectedVersion?.DraftApplicable ?? false;

    for (const scenarioKey of row.applicableScenarios) {
      const cfg = row.scenarioConfigs?.[scenarioKey];
      const scenario = scenarios.find(s => s.key === scenarioKey);

      // const selectedStandard =
      //   cfg?.inputOption === "useStandardInput"
      //     ? standardTemplatesByStakeholder
      //       .get(row.stakeholderCode)
      //       ?.find(t => t.id === cfg.standardReferenceId)
      //     : null;

      if (cfg?.inputOption === "CollectInput") {
        collectDatasets.push({
          scenarioKey,
          scenarioDescription: scenario?.description ?? ""
        });
        continue;
      }

      const inputType =
        cfg?.inputOption === "useStandardInput"
          ? "Standard"
          : cfg?.inputOption === "usePreviousRoundInput"
            ? "PreviousRound"
            : "CollectInput";
      const submissionType =
        draftApplicable && row.collectDraftInput
          ? "Draft"
          : "Final";

      const revisionNumber =
        getLatestRevisionNumber(
          allOpportunityRounds.flatMap(
            (r: any) => r?.inputs ?? []
          ),
          Number(round?.opportunityId),
          row.stakeholderCode,
          scenarioKey,
          inputType,
          row.commonVersionSelections || "",
          submissionType
        );

      const scenarioBlock: any = {
        scenarioKey,
        scenarioDescription: scenario?.description ?? "",
        inputOption: cfg?.inputOption ?? "",

        standardReferenceId:
          cfg?.inputOption === "useStandardInput"
            ? cfg.standardReferenceId ?? null
            : null,

        // ...(selectedStandard
        //   ? { standardInputTemplateTitle: selectedStandard.title }
        //   : {}),

        standardInputTemplateTitle:
          cfg?.standardInputTemplateTitle ?? null,

        previousRoundId:
          cfg?.inputOption === "usePreviousRoundInput"
            ? cfg.previousRoundId ?? null
            : null,
        versionNo: row.commonVersionSelections || "",
        submissionType,
        revisionNumber,
        inputType
      };
      // if (!isAdhoc) {
      //   scenarioBlock.draftDueDate =
      //     cfg?.draftDueDate
      //       ? cfg.draftDueDate.toLocaleDateString()
      //       : null;
      // }
      if (!isAdhoc) {
        scenarioBlock.draftDueDate =
          cfg?.draftDueDate
            ? formatDateForFlow(cfg.draftDueDate)
            : null;
      }
      otherScenarioBlocks.push(scenarioBlock);
    }

    const stakeholderAdditionalTeamMembers =
      (row.additionalTeamPersonas ?? []).map(p => ({
        id: String(p.secondaryText || ""),
        displayName: String(p.text || ""),
        email: String(p.secondaryText || "")
      }));

    const stakeholderNotifyUsers =
      (row.notifyPersonas ?? []).map(p => ({
        displayName: String(p.text || ""),
        email: String(p.secondaryText || "")
      }));

    const NotifyUsersEmailString = Array.from(
      new Set([
        ...(row.notifyPersonas ?? []).map(p => p.secondaryText),
        ...(row.additionalTeamPersonas ?? []).map(p => p.secondaryText)
      ].filter(Boolean))
    ).join(";");

    const finalScenarios = [...otherScenarioBlocks];
    if (collectDatasets.length > 0) {

      const collectScenarioBlock: any = {
        Dataset: collectDatasets,
        inputOption: "CollectInput",

        notifyUsers: stakeholderNotifyUsers,
        additionalTeamMembers: stakeholderAdditionalTeamMembers,
        versionNo: row.commonVersionSelections || "",

        submissionType:
          draftApplicable && row.collectDraftInput
            ? "Draft"
            : "Final"
      };

      if (!isAdhoc) {
        collectScenarioBlock.collectDraftInput =
          draftApplicable
            ? row.collectDraftInput
            : false;

        // collectScenarioBlock.draftDueDate =
        //   draftApplicable &&
        //     row.collectDraftInput &&
        //     row.commonDraftDueDate
        //     ? row.commonDraftDueDate.toLocaleDateString()
        //     : null;

        collectScenarioBlock.draftDueDate =
          draftApplicable &&
            row.collectDraftInput &&
            row.commonDraftDueDate
            ? formatDateForFlow(row.commonDraftDueDate)
            : null;
      }


      finalScenarios.push(collectScenarioBlock);
    }
    return {
      stakeholderName: row.stakeholderName,
      stakeholderCode: row.stakeholderCode,
      //dueDate: row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "",
      dueDate: row.dueDate ?? "",
      InputTemplateGroupIds: row.inputTemplateGroupIds ?? [],
      scenarios: finalScenarios,
      editFolderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${row.roundIdFolder}/${row.stakeholderCode}`,
      additionalTeamMembers: stakeholderAdditionalTeamMembers,
      NotifyUsersEmailString
    };
  }


  function buildStakeholderFlowBlock_CollectGrouped(
    row: {
      stakeholderName: string;
      stakeholderCode: string;
      stakeholderType: string;
      dueDate?: string;
      applicableScenarios: ScenarioKey[];
      scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>>;
      notifyUsers?: IPersonaProps[];
      additionalTeam?: IPersonaProps[];
      inputTemplateGroupIds?: number[];

      commonVersionSelections?: string;
      collectDraftInput?: boolean;
    },
    scenarios: { key: ScenarioKey; description?: string }[],
    standardTemplatesByStakeholder: Map<string, { id: number; title: string }[]>
  ) {
    const collectDatasets: {
      scenarioKey: ScenarioKey;
      scenarioDescription: string;
    }[] = [];

    const otherScenarioBlocks: any[] = [];

    for (const scenarioKey of row.applicableScenarios) {
      const cfg = row.scenarioConfigs?.[scenarioKey];
      const scenario = scenarios.find(s => s.key === scenarioKey);

      if (!cfg?.inputOption) continue;

      if (cfg.inputOption === "CollectInput") {
        collectDatasets.push({
          scenarioKey,
          scenarioDescription: scenario?.description ?? ""
        });
        continue;
      }
      const standardTitle =
        cfg.inputOption === "useStandardInput"
          ? cfg.standardInputTemplateTitle ?? ""
          : "";


      // otherScenarioBlocks.push({
      //   scenarioKey,
      //   scenarioDescription: scenario?.description ?? "",
      //   inputOption: cfg.inputOption,
      //   standardReferenceId:
      //     cfg.inputOption === "useStandardInput"
      //       ? cfg.standardReferenceId ?? null
      //       : null,
      //   standardInputTemplateTitle: standardTitle,
      //   previousRoundId:
      //     cfg.inputOption === "usePreviousRoundInput"
      //       ? cfg.previousRoundId ?? null
      //       : null
      // });

      otherScenarioBlocks.push({
        scenarioKey,
        scenarioDescription: scenario?.description ?? "",
        inputOption: cfg.inputOption,

        standardReferenceId:
          cfg.inputOption === "useStandardInput"
            ? cfg.standardReferenceId ?? null
            : null,

        standardInputTemplateTitle: standardTitle,

        previousRoundId:
          cfg.inputOption === "usePreviousRoundInput"
            ? cfg.previousRoundId ?? null
            : null,

        versionNo:
          (row as any).commonVersionSelections ?? "",

        submissionType:
          (row as any).collectDraftInput
            ? "Draft"
            : "Final"

        // providedBy:
        //   cfg.providedBy ?? null
      });
    }

    const notifyUsers = (row.notifyUsers ?? []).map(p => ({
      displayName: p.text,
      email: p.secondaryText
    }));

    const additionalTeamMembers = (row.additionalTeam ?? []).map(p => ({
      displayName: p.text,
      email: p.secondaryText
    }));

    const finalScenarios = [...otherScenarioBlocks];

    if (collectDatasets.length > 0) {
      finalScenarios.push({
        Dataset: collectDatasets,
        inputOption: "CollectInput",
        notifyUsers,
        additionalTeamMembers,
        versionNo:
          row.commonVersionSelections ?? "",

        submissionType:
          row.collectDraftInput
            ? "Draft"
            : "Final"
      });
    }

    const NotifyUsersEmailString = Array.from(
      new Set([
        ...(row.notifyUsers ?? []).map(p => p.secondaryText),
        ...(row.additionalTeam ?? []).map(p => p.secondaryText)
      ].filter(Boolean))
    ).join(";");

    return {
      stakeholderName: row.stakeholderName,
      stakeholderCode: row.stakeholderCode,
      stakeholderType: row.stakeholderType,
      dueDate: row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "",
      InputTemplateGroupIds: row.inputTemplateGroupIds ?? [],
      scenarios: finalScenarios,
      additionalTeamMembers,
      NotifyUsersEmailString
    };
  }
  function getLatestRevisionNumber(
    inputs: any[],
    opportunityId: number,
    stakeholderCode: string,
    dataset: string,
    inputType: string,
    versionNumber: string,
    submissionType: string
  ): number {
    const expectedInputType =
      String(inputType ?? "").trim().toLowerCase();

    const matchingInputs = (inputs || []).filter((item: any) => {
      const actualInputType =
        String(item.inputType ?? "").trim().toLowerCase();

      const inputTypeMatches =
        expectedInputType === "standard"
          ? actualInputType === "standard" ||
          actualInputType === "usestandardinput"
          : expectedInputType === "previousround"
            ? actualInputType === "previousround" ||
            actualInputType === "usepreviousroundinput"
            : actualInputType === expectedInputType;

      return (
        Number(item.opportunityId) === Number(opportunityId) &&

        String(item.stakeholderCode ?? "").trim().toLowerCase() ===
        String(stakeholderCode ?? "").trim().toLowerCase() &&

        String(item.scenarioName ?? "").trim().toLowerCase() ===
        String(dataset ?? "").trim().toLowerCase() &&

        inputTypeMatches &&

        String(item.versionNumber ?? "").trim().toLowerCase() ===
        String(versionNumber ?? "").trim().toLowerCase() &&

        String(item.submissionType ?? "").trim().toLowerCase() ===
        String(submissionType ?? "").trim().toLowerCase()
      );
    });

    return matchingInputs.reduce(
      (max: number, item: any) =>
        Math.max(max, Number(item.revisionNumber) || 0),
      0
    );
  }

  async function handleChangeVersionSave(
    params: EditInputTemplateModel
  ) {

    if (!round) return;

    const original = round.inputTemplates.find(
      it => it.stakeholderCode === params.stakeholderCode
    );

    if (!original) return;

    const allScenarios = [
      ...params.existingScenarios,
      ...params.newScenarios
    ];

    const versions =
      (params as any).inputTemplateVersions ?? [];

    const selectedVersion =
      versions.find(
        (v: any) =>
          v.VersionNumber === params.commonVersionSelections
      );

    const draftApplicable =
      selectedVersion?.DraftApplicable ?? false;

    const submissionType =
      draftApplicable && params.collectDraftInput
        ? "Draft"
        : "Final";

    // const scenarios: ChangeVersionScenario[] =
    //   allScenarios.map(sk => ({
    //     name: sk,

    //     desc:
    //       params.scenarioConfigs[sk]
    //         ?.scenarioDescription ?? "",

    //     isStandardRate:
    //       params.scenarioConfigs[sk]?.inputOption ===
    //       "useStandardInput",

    //     isCopiedPreviousRound:
    //       params.scenarioConfigs[sk]?.inputOption ===
    //       "usePreviousRoundInput",

    //     referenceData:
    //       params.scenarioConfigs[sk]
    //         ?.standardReferenceId ?? null,

    //     input_type:
    //       params.scenarioConfigs[sk]
    //         ?.inputOption ?? "CollectInput"
    //   }));

    const scenarios: ChangeVersionScenario[] =
      allScenarios.map(sk => {
        const inputOption =
          params.scenarioConfigs[sk]?.inputOption ?? "CollectInput";

        const inputType =
          inputOption === "useStandardInput"
            ? "Standard"
            : inputOption === "usePreviousRoundInput"
              ? "PreviousRound"
              : "CollectInput";

        const latestRevisionNumber =
          getLatestRevisionNumber(
            allOpportunityRounds.flatMap(
              (r: any) => r?.inputs ?? []
            ),
            Number(round.opportunityId),
            params.stakeholderCode,
            sk,
            inputType,
            params.commonVersionSelections ?? "",
            submissionType
          );

        return {
          name: sk,

          desc:
            params.scenarioConfigs[sk]
              ?.scenarioDescription ?? "",

          isStandardRate:
            inputOption === "useStandardInput",

          isCopiedPreviousRound:
            inputOption === "usePreviousRoundInput",

          referenceData:
            params.scenarioConfigs[sk]
              ?.standardReferenceId ?? null,

          input_type: inputOption,

          revisionNumber: latestRevisionNumber
        };
      });

    const payload: ChangeVersionPayload = {
      opportunityId: round.opportunityId,
      roundId: round.roundId,
      stakeholder_code: params.stakeholderCode,
      stakeholderType: "Standard",
      description: "",
      dueDate: params.dueDate?.toISOString(),
      collectDraftInput: params.collectDraftInput ?? false,
      draftDueDate:
        params.commonDraftDueDate?.toISOString(),
      versionNumber:
        params.commonVersionSelections ?? "",
      notify_users: params.notifyUsers
        .filter(u => u.secondaryText)
        .map(u => {

          const email =
            typeof u.secondaryText === "string"
              ? u.secondaryText.replace(
                /^i:0#\.f\|membership\|/i,
                ""
              )
              : "";

          const loginId =
            typeof u.tertiaryText === "string" &&
              u.tertiaryText.trim()
              ? u.tertiaryText.replace(
                /^i:0#\.f\|membership\|/i,
                ""
              )
              : email;

          return {
            name: u.text || email,
            email,
            login_id: loginId
          };
        }),
      additionalStakeholders: params.additionalTeam
        .filter(u => u.secondaryText)
        .map(u => {

          const email =
            typeof u.secondaryText === "string"
              ? u.secondaryText.replace(
                /^i:0#\.f\|membership\|/i,
                ""
              )
              : "";

          const loginId =
            typeof u.tertiaryText === "string" &&
              u.tertiaryText.trim()
              ? u.tertiaryText.replace(
                /^i:0#\.f\|membership\|/i,
                ""
              )
              : email;

          return {
            name: u.text || email,
            email,
            login_id: loginId
          };
        }),
      applicableScenarios: scenarios
    };

    await api.changeVersion(payload);

    const roundIdFolder = `RND ${("" + roundNumber).slice(-2)}`;
    // triggerFlow(
    //   {
    //     eventType: "StakeholderUsersUpdated",
    //     actionType: "changeVersion",
    //     region: "EUR",
    //     siteUrl: cfg.siteUrl,
    //     opportunityName,
    //     opportunityCountryName,
    //     roundNumber,
    //     roundIdFolder,
    //     customer: `${customer}`,
    //     fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
    //     editFolderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${roundIdFolder}/${params.stakeholderCode}`,
    //     leadPricerEmailString: leadPricerEmail,
    //     bidTeamMembers: bidTeamEmail,
    //     oldVersion: params.originalVersion,
    //     newVersion: params.commonVersionSelections,
    //     changedBy: spfxContext.pageContext.user.email,
    //     changedOn: new Date().toLocaleDateString()
    //   },
    //   "RoundCreationFlow"
    // );
    const flowPayloadChangeVersion = {
      eventType: "StakeholderUsersUpdated",
      actionType: "changeVersion",
      region: "EUR",
      siteUrl: cfg.siteUrl,
      opportunityName,
      opportunityCountryName,
      roundNumber,
      roundIdFolder,
      customer: `${customer}`,
      fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
      editFolderPath:
        `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${roundIdFolder}/${params.stakeholderCode}`,
      leadPricerEmailString: leadPricerEmail,
      bidTeamMembers: bidTeamEmail,
      oldVersion: params.originalVersion,
      newVersion: params.commonVersionSelections,
      changedBy: spfxContext.pageContext.user.email,
      changedOn: new Date().toLocaleDateString()
    };
    const meta =
      templateCatalog.get(
        params.stakeholderCode.toLowerCase()
      );
    // const versions =
    //   (params as any).inputTemplateVersions ?? [];
    const stakeholderForFlow =
      buildStakeholderFlowBlock(
        {
          stakeholderName: params.stakeholderName,
          stakeholderCode: params.stakeholderCode,
          //dueDate: params.dueDate?.toISOString(),
          dueDate: formatDateForFlow(params.dueDate),
          applicableScenarios: allScenarios,
          scenarioConfigs: params.scenarioConfigs,
          notifyPersonas: params.notifyUsers,
          additionalTeamPersonas: params.additionalTeam,
          inputTemplateGroupIds: meta?.groupIds ?? [],
          roundIdFolder,
          inputTemplateVersions: versions,
          commonVersionSelections:
            params.commonVersionSelections,
          collectDraftInput:
            params.collectDraftInput,
          commonDraftDueDate:
            params.commonDraftDueDate
        },
        round.scenarios
      );

    // await triggerFlow(
    //   {
    //     region: "EUR",
    //     siteUrl: cfg.siteUrl,
    //     opportunityName,
    //     opportunityCountryName,
    //     roundNumber,
    //     roundIdFolder,
    //     customer: `${customer}`,
    //     fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
    //     stakeholders: [stakeholderForFlow],
    //     folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
    //     leadPricerEmailString: leadPricerEmail,
    //     bidTeamMembers: bidTeamEmail,
    //     oldVersion: params.originalVersion,
    //     newVersion: params.commonVersionSelections,
    //     changedBy: spfxContext.pageContext.user.email,
    //     changedOn: new Date().toLocaleDateString()
    //   },
    //   "RoundCreationFlow"
    // );

    const flowPayloadRoundCreation = {
      region: "EUR",
      siteUrl: cfg.siteUrl,
      opportunityName,
      opportunityCountryName,
      roundNumber,
      roundIdFolder,
      customer: `${customer}`,
      fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
      stakeholders: [stakeholderForFlow],
      folderPath:
        `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
      leadPricerEmailString: leadPricerEmail,
      bidTeamMembers: bidTeamEmail,
      oldVersion: params.originalVersion,
      newVersion: params.commonVersionSelections,
      changedBy: spfxContext.pageContext.user.email,
      changedOn: new Date().toLocaleDateString()
    };
    setPendingFlowPayload([
      flowPayloadChangeVersion,
      flowPayloadRoundCreation
    ]);

    setFolderCreationDialogOpen(true);
    await refreshBackendRound();
  }

  async function handleEditSave(editor: EditInputTemplateModel) {
    if (!round) return;

    const original = round.inputTemplates.find(
      it => it.stakeholderCode === editor.stakeholderCode
    );
    if (!original) return;

    const isDueDateChanged =
      (original.dueDate
        ? new Date(original.dueDate).toISOString().split("T")[0]
        : null) !==
      (editor.dueDate
        ? editor.dueDate.toISOString().split("T")[0]
        : null);

    // On Update Of Draft Due Date
    const originalDraftDueDate =
      (original as any).draftDueDate
        ? new Date((original as any).draftDueDate)
          .toISOString()
          .split("T")[0]
        : null;

    const updatedDraftDueDate =
      editor.commonDraftDueDate
        ? editor.commonDraftDueDate.toISOString().split("T")[0]
        : null;

    const isDraftDueDateChanged =
      originalDraftDueDate !== updatedDraftDueDate;


    const scenarioConfigs = editor.scenarioConfigs || {};
    const newScenarios = editor.newScenarios || [];

    const requiredDatasets = Object.entries(scenarioConfigs)
      .filter(([key, config]: any) => {
        const isNewScenario = newScenarios.includes(key);

        // const needsInput =
        //   config.inputRequired === true &&
        //   String(config.workflowStatus || '').toLowerCase() !== 'approved';

        const needsInput =
          config.inputRequired === true &&
          (
            String(config.workflowStatus || '').toLowerCase() !== 'approved' ||
            Boolean(config.revisionAttempt)
          );

        return isNewScenario || needsInput;
      })
      // .map(([key]) => key);
      .map(([key, config]: any) => ({
        dataset: key,
        description: config.scenarioDescription
      }));

    const inputRequiredHtml =
      requiredDatasets.length > 0
        ? `
      <div>
        <p><strong>Inputs Required</strong></p>
        <ul>
          ${requiredDatasets
          .map((dataset) => `<li>
  ${dataset.dataset} - ${dataset.description || 'No Description'}
</li>`)
          .join('')}
        </ul>
      </div>
    `
        : `
      <div>
        <p><strong>Inputs Required</strong></p>
        <p><strong>All required dataset files have already been submitted.</strong></p>
        <ul>
          ${requiredDatasets
          .map((dataset) => `<li>
  ${dataset.dataset} - ${dataset.description || 'No Description'}
</li>`)
          .join('')}
        </ul>
      </div>
    `;

    const hasCollectInput = Object.values(editor.scenarioConfigs ?? {}).some(
      (config) => config?.inputOption === "CollectInput"
    );

    const addedScenarios = editor.newScenarios;

    const addedNotify = getAddedUsers(
      original.notifyPersonas ?? [],
      editor.notifyUsers
    );

    const addedAdditional = getAddedUsers(
      original.additionalTeamPersonas ?? [],
      editor.additionalTeam
    );
    const removedAdditional = getRemovedUsers(
      original.additionalTeamPersonas ?? [],
      editor.additionalTeam
    );

    // const dueDateN = editor.dueDate ? new Date(editor.dueDate).toLocaleDateString() : '';

    // const draftDueDateN =
    //   editor.collectDraftInput && editor.commonDraftDueDate
    //     ? new Date(editor.commonDraftDueDate).toLocaleDateString()
    //     : '';

    const dueDateN = formatDateForFlow(editor.dueDate);

    const draftDueDateN = formatDateForFlow(
      editor.collectDraftInput
        ? editor.commonDraftDueDate
        : null
    );

    const collectDraftInput = editor.collectDraftInput ?? false;

    const updatedTemplate: InputTemplateRowView = {
      ...original,
      dueDate: editor.dueDate ? editor.dueDate.toISOString() : undefined,
      draftDueDate:
        editor.collectDraftInput && editor.commonDraftDueDate
          ? editor.commonDraftDueDate.toISOString()
          : undefined,

      applicableScenarios: [
        ...original.applicableScenarios,
        ...editor.newScenarios
      ],
      notifyPersonas: editor.notifyUsers,
      additionalTeamPersonas: editor.additionalTeam
    };

    assertStakeholderFields(updatedTemplate);
    const stakeholderType =
      currentRoundDetails?.stakeholders
        ?.find(
          (s: any) =>
            s.stakeholder_code === editor.stakeholderCode
        )
        ?.stakeholderType;

    const isStandard =
      stakeholderType?.toLowerCase() === "standard";
    const payload = buildFullPayloadForRow(
      stakeholderType ?? "Standard",
      updatedTemplate,
      round,
      Number(id),
      editor.notifyUsers,
      editor.additionalTeam,
      editor.scenarioConfigs,
      isStandard ? editor.commonVersionSelections : "",
      isStandard ? editor.collectDraftInput : false,
      isStandard ? editor.commonDraftDueDate : null,
      //stakeholderType ?? "Adhoc"
    );
    // console.log("Update Payload", payload);

    await api.updateRound(payload);

    setRound(prev => {
      if (!prev) return prev;

      return {
        ...prev,
        inputTemplates: prev.inputTemplates.map(it =>
          it.stakeholderCode === updatedTemplate.stakeholderCode
            ? updatedTemplate
            : it
        )
      };
    });

    const roundIdFolder = `RND ${("" + roundNumber).slice(-2)}`;

    if (addedScenarios.length > 0) {


      const StakeholderUsersString = editor.notifyUsers
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");

      const AdditionalTeamMemberString = editor.additionalTeam
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");

      const CombineEmailsString = StakeholderUsersString + ";" + AdditionalTeamMemberString;

      const flowStakeholderApplicableScenarioAdded = buildStakeholderFlowBlock_CollectGrouped(
        {
          stakeholderName: editor.stakeholderName,
          stakeholderCode: editor.stakeholderCode,
          stakeholderType: stakeholderType,
          //dueDate: editor.dueDate?.toISOString(),
          dueDate: formatDateForFlow(editor.dueDate),
          applicableScenarios: editor.newScenarios,
          scenarioConfigs: editor.scenarioConfigs,
          notifyUsers: editor.notifyUsers,
          additionalTeam: editor.additionalTeam,
          inputTemplateGroupIds:
            templateCatalog.get(editor.stakeholderCode.toLowerCase())?.groupIds ?? [],
          commonVersionSelections: editor.commonVersionSelections,
          collectDraftInput: editor.collectDraftInput,
        },

        round.scenarios,
        standardTemplatesByStakeholder
      );

      const flowPayloadAppAddSc = {
        eventType: "ApplicableScenarioAdded",
        siteUrl: cfg.siteUrl,
        opportunityName,
        roundNumber,
        roundIdFolder,
        stakeholders: [flowStakeholderApplicableScenarioAdded],
        NotifyUsersEmailStringOthers: CombineEmailsString,
        StakeholderName: updatedTemplate.stakeholderName,
        StakeholderCode: updatedTemplate.stakeholderCode,
        customer: `${customer}`,
        fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
        folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
        region: "EUR",
        opportunityCountryName: opportunityCountryName,
        leadPricerEmailString: leadPricerEmail,
        bidTeamMembers: bidTeamEmail,
        collectDraftInput,
        draftDueDate: draftDueDateN,
        // applicableScenarios: applicableScenariosForFlow
        // stakeholders: [flowStakeholder]
      }

      // console.log("Flow Trigger for Adding Scenario : ", flowPayloadAppAddSc)

      //await triggerFlow(flowPayloadAppAddSc, "RoundCreationFlow");
      handleInputTemplateFlowReady(flowPayloadAppAddSc);
    }

    if (addedNotify.length > 0 && hasCollectInput == true) {

      const NotifyUsersEmailStringOthers = addedNotify
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");
      const stakeholderType =
        currentRoundDetails?.stakeholders?.find(
          (s: any) =>
            s.stakeholder_code === updatedTemplate.stakeholderCode
        )?.stakeholderType ?? "Standard";

      const flowPayloadStakeholderUser = {
        eventType: "StakeholderUsersUpdated",
        actionType: "userUpdated",
        region: "EUR",
        siteUrl: cfg.siteUrl,
        opportunityName,
        roundNumber,
        roundIdFolder,
        StakeholderName: updatedTemplate.stakeholderName,
        StakeholderCode: updatedTemplate.stakeholderCode,
        StakeholderType: stakeholderType,
        customer: `${customer}`,
        fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
        folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
        NotifyUsersEmailStringOthers,
        inputRequiredHtml: inputRequiredHtml,
        opportunityCountryName: opportunityCountryName,
        leadPricerEmailString: leadPricerEmail,
        dueDate: dueDateN,
        collectDraftInput,
        draftDueDate: draftDueDateN,
      };

      // console.log(flowPayloadStakeholderUser);
      await triggerFlow(flowPayloadStakeholderUser, "RoundCreationFlow");
    }
    if (
      (isDueDateChanged && hasCollectInput === true) ||
      (isDraftDueDateChanged && collectDraftInput === true)
    ) {
      const StakeholderUsersString = editor.notifyUsers
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");

      const AdditionalTeamMemberString = editor.additionalTeam
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");

      const NotifyUsersEmailStringOthers =
        StakeholderUsersString +
        (AdditionalTeamMemberString
          ? ";" + AdditionalTeamMemberString
          : "");

      const flowPayloadDueDate = {
        eventType: "StakeholderUsersUpdated",
        actionType: "dueDateChanged",
        changeType:
          isDueDateChanged && isDraftDueDateChanged
            ? "both"
            : isDraftDueDateChanged
              ? "draftDueDate"
              : "dueDate",
        isDraftDateChanged: isDraftDueDateChanged,
        region: "EUR",
        siteUrl: cfg.siteUrl,
        opportunityName,
        roundNumber,
        roundIdFolder,

        StakeholderName: updatedTemplate.stakeholderName,
        StakeholderCode: updatedTemplate.stakeholderCode,

        customer: `${customer}`,
        fullOpportunityName:
          `/EUR/${customer}/${opportunityName}`,

        folderPath:
          `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,

        dueDate: dueDateN,

        NotifyUsersEmailStringOthers,
        inputRequiredHtml,
        opportunityCountryName,
        leadPricerEmailString: leadPricerEmail,

        collectDraftInput,
        draftDueDate: draftDueDateN,
      };

      await triggerFlow(
        flowPayloadDueDate,
        "RoundCreationFlow"
      );
    }

    if (addedAdditional.length || removedAdditional.length) {

      const NotifyUsersEmailStringOthers = editor.notifyUsers
        .map(p => p.secondaryText)
        .filter(Boolean)
        .join(";");

      const leadPricerAndNotifyUsers =
        [
          leadPricerEmail,
          NotifyUsersEmailStringOthers
        ]
          .filter(Boolean)
          .join(";");

      const flowPayloadAdditional = {

        eventType: "AdditionalTeamUpdated",
        region: "EUR",
        siteUrl: cfg.siteUrl,
        opportunityName,
        roundNumber,
        roundIdFolder,
        StakeholderName: updatedTemplate.stakeholderName,
        StakeholderCode: updatedTemplate.stakeholderCode,
        customer: `${customer}`,
        fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
        folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
        editFolderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${roundIdFolder}/${updatedTemplate.stakeholderCode}`,
        addedMembers: addedAdditional.map(p => ({
          email: p.secondaryText,
          displayName: p.text
        })),
        removedMembers: removedAdditional.map(p => ({
          email: p.secondaryText,
          displayName: p.text
        })),
        inputRequiredHtml: inputRequiredHtml,
        opportunityCountryName: opportunityCountryName,
        leadPricerEmailString: leadPricerAndNotifyUsers,
        dueDate: dueDateN,
        collectDraftInput,
        draftDueDate: draftDueDateN,
      }
      // console.log(flowPayloadAdditional);
      await triggerFlow(flowPayloadAdditional, "RoundCreationFlow");
    }

    await refreshBackendRound();

  }


  if (loading) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernLoadingState type="shimmer" rows={5} height={120} />
      </Box>
    );
  }

  if (!loading && !round) {
    return (
      <Box sx={{ p: 0 }}>
        <ModernEmptyState
          type="error"
          title="Round not found"
          description="The requested round could not be found or you don't have permission to view it."
          animated
        />
      </Box>
    );
  }

  function getScenarioInputType(stakeholderName?: string, scenarioKey?: ScenarioKey): string | undefined {
    if (!stakeholderName || !scenarioKey) return undefined;
    return scenarioInputTypeMapRef.current.get(stakeholderName)?.get(scenarioKey);
  }

  const getStatusColorVariant = (status: string): 'success' | 'warning' | 'error' | 'info' | 'primary' | 'default' => {
    const s = (status || '').toLowerCase();
    if (s.includes('approved')) return 'success';
    if (s.includes('validated')) return 'success';
    if (s.includes('submitted') || s.includes('pending')) return 'warning';
    if (s.includes('reject') || s.includes('failed') || s.includes('retract')) return 'error';
    if (s.includes('revision')) return 'info';
    return 'default';
  };

  const isStakeholderMissing = (row: any) => {
    return (
      (!row.notifyUsers || row.notifyUsers.length === 0) &&
      (!row.additionalTeamPersonas || row.additionalTeamPersonas.length === 0)
    );
  };

  const hasApprovedFinalForSameDataset = (
    row: UnifiedFileItem
  ) => {
    return allRoundFiles.some(
      f =>
        f.id !== row.id &&
        f.stakeholderCode === row.stakeholderCode &&
        f.scenario === row.scenario &&
        (f.submissionType || '').toLowerCase() === 'final' &&
        (
          (f.status || '').toLowerCase() === 'validated' ||
          (f.status || '').toLowerCase() === 'approved'
        )
    );
  };


  const inlineSubmitToFlow = async () => {
    const activeFile = inlinePanel.file;
    if (!activeFile || !inlineDecision) {
      setToast({ severity: 'warning', text: 'Please select a decision before submitting.' });
      return;
    }
    try {
      setLoading(true);
      setInlineSaving(true);
      setInlinePanel(p => ({ ...p, show: false }));
      const notifyEmails = activeFile.notifyEmails?.join(';');
      if (inlineDecision === 'Approve') {
        await api.completeStakeholderInput({
          opportunityId: Number(id), roundId: Number(roundId), roundNumber,
          stakeholderCode: activeFile.stakeholderCode,
          scenarioName: activeFile.scenario,
          fileRelPath: activeFile.fileRelPath,
          processedData: [] as any, userStatus: 'Completed', workflowStatus: 'Approved',
          versionNumber: activeFile.versionNumber,
          submissionType: activeFile.submissionType
        });
      } else {
        await api.rejectStakeholderInput({
          opportunityId: Number(id), roundId: Number(roundId), roundNumber,
          stakeholderCode: activeFile.stakeholderCode, scenarioName: activeFile.scenario,
          versionNumber: activeFile.versionNumber,
          submissionType: activeFile.submissionType
        });
      }
      await triggerFlow({
        eventType: 'PricerDecision', opportunityId: id, roundId, templateId: activeFile.stakeholderCode,
        decision: inlineDecision, comment: inlineComment,
        opportunityName: opportunityName,
        file: { name: activeFile.name, url: activeFile.fileRelPath, status: activeFile.status, scenario: activeFile.scenario },
        submittedAt: new Date().toISOString(), siteUrl: cfg.siteUrl, NotifyEmails: notifyEmails,
        webValidationUrl: cfg.serverRelativeUrl,
        stakeholderInputTemplateName: activeFile.stakeholderName,
        mainOpportunityFolderLink: cfg.siteUrl + "/EUR/" + customer + "/" + opportunityName,
        costInputTemplateFolderLink: cfg.siteUrl + "/EUR/" + customer + "/" + opportunityName + "/RND " + roundNumber + "/" + activeFile.stakeholderCode,
        leadPricerEmail: leadPricerEmail,
        scenarioFormKey: activeFile.scenario,
        scenarioFormDescription: activeFile.scenarioDescription,
        roundNumber: roundNumber
      }, 'ApprovalFlow');
      setInlineDecision(''); setInlineComment('');
      if (inlineDecision === 'Approve') {
        setToast({
          severity: 'success',
          text: 'The file has been validated and accepted. The stakeholder has been notified and the input is now confirmed for this round and scenario.'
        });
      }
      else {
        setToast({
          severity: 'warning',
          text: 'The file has been rejected.'
        });
      }
      await refreshBackendRound();
    } catch (err: any) {
      setToast({ severity: 'error', text: err?.message || 'Unexpected error.' });
    } finally {
      setInlineSaving(false);
      setLoading(false);
      setFilesLoading(false);
    }
  };

  const inlineSendForRevision = async () => {
    const activeFile = inlinePanel.file;
    if (!activeFile || !inlineRevisionComment.trim()) {
      setToast({ severity: 'warning', text: 'Please add a revision comment.' });
      return;
    }
    try {
      setLoading(true);
      setInlineSaving(true);
      setInlinePanel(p => ({ ...p, show: false }));
      const notifyEmails = activeFile.notifyEmails?.join(';');
      await api.initiateRevision({
        opportunityId: Number(id), roundId: Number(roundId), roundNumber,
        stakeholderCode: activeFile.stakeholderCode, scenarioName: activeFile.scenario,
      });
      const cleanedPath = activeFile.fileRelPath.replace(cfg.serverRelativeUrl + '/', '');
      await triggerFlow({
        eventType: 'SendForRevision', opportunityId: id, roundId, templateId: activeFile.stakeholderCode,
        comment: inlineRevisionComment,
        //dueDate: activeFile.dueDate,
        dueDate: activeFile.dueDate
          ? formatDateForFlow(activeFile.dueDate)
          : "",
        context: { opportunityName, customer, roundName: names.roundName, templateName: activeFile.stakeholderCode },
        file: { id: activeFile.id, name: activeFile.name, url: activeFile.fileRelPath, status: activeFile.status, scenario: activeFile.scenario, listItemId: activeFile.listItemId, uploadedBy: activeFile.uploadedBy, modifiedBy: activeFile.modifiedBy, notifyUsers: notifyEmails },
        requestedBy: { name: (window as any)?.spfxContext?.pageContext?.user?.displayName ?? '', email: (window as any)?.spfxContext?.pageContext?.user?.email ?? '' },
        submittedAt: new Date().toISOString(), NotifyEmails: notifyEmails, RevisionComment: inlineRevisionComment,
        FilePath: cleanedPath, siteUrl: cfg.siteUrl,
        opportunityName: opportunityName,
        stakeholderInputTemplateName: activeFile.stakeholderName,
        mainOpportunityFolderLink: cfg.siteUrl + "/EUR/" + customer + "/" + opportunityName,
        costInputTemplateFolderLink: cfg.siteUrl + "/EUR/" + customer + "/" + opportunityName + "/RND " + roundNumber + "/" + activeFile.stakeholderCode,
        leadPricerEmail: leadPricerEmail,
        scenarioFormKey: activeFile.scenario,
        scenarioFormDescription: activeFile.scenarioDescription,
        roundNumber: roundNumber
      }, 'ApprovalFlow');
      setInlineRevisionComment('');
      setToast({ severity: 'success', text: 'The revision request has been sent to the stakeholder. They have been notified to review the comments and submit an updated input.' });
      await refreshBackendRound();
    } catch (err: any) {
      setToast({ severity: 'error', text: `Error: ${err.message}` });
    } finally {
      setInlineSaving(false);
      setLoading(false);
      setFilesLoading(false);
    }
  };




  const statusColors: Record<string, { bg: string; color: string }> = {
    Validated: {
      bg: '#e8f5e9',
      color: '#2e7d32'
    },
    Submitted: {
      bg: '#fff8e1',
      color: '#ed6c02'
    },
    Rejected: {
      bg: '#ffebee',
      color: '#d32f2f'
    },
    Retracted: {
      bg: '#e6e4fc',
      color: '#221854'
    },
    Created: {
      bg: '#f5f5f5',
      color: '#616161'
    }
  };

  return (
    <Fade in timeout={500}>
      <Box sx={{ p: 0 }}>
        {toast && (
          <Box sx={{ mb: 3 }}>
            <ModernAlert
              severity={toast.severity}
              onClose={() => setToast(null)}
              elevated
              gradient
            >
              {toast.text}
            </ModernAlert>
          </Box>
        )}
        <Box sx={{ mb: 3 }}>
          <ModernButton
            variant="outlined"
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate(`/opportunities/${id}/rounds`)}
          >
            Back
          </ModernButton>
        </Box>


        {backendRound?.userStatus === "Completed" && (
          <Box
            sx={{
              mb: 3,
              px: 2,
              py: 1.5,
              backgroundColor: "#fff8e1",
              border: "1px solid #f9c74f",
              borderRadius: 1,
              color: "#8a6d1d",
              fontWeight: 600,
            }}
          >
            Round is closed.
          </Box>
        )}


        <Divider sx={{ mb: 3 }} />

        {round && (
          <Stack spacing={3}>
            <ModernCard elevated>
              <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <InfoIcon sx={{ color: 'primary.main' }} />
                  <Typography variant="h6" fontWeight={600}>
                    Round Details
                  </Typography>
                </Box>
                <Stack direction="row" spacing={1}>
                  {hasNonAdhocValidatedFile && hasAccess && String(backendRound?.userStatus || '').toLowerCase() !== 'completed' && (

                    <ModernButton
                      variant="gradient"
                      glow
                      startIcon={<DescriptionIcon />}
                      onClick={() => setShowGeneratePanel(true)}
                    >
                      Generate Output File
                    </ModernButton>
                  )}
                  <ModernButton
                    variant="outlined"
                    startIcon={<FolderOpenIcon />}
                    onClick={() => {
                      const url =
                        `${cfg.siteUrl}/${LIBRARY_NAME}/${customer}/${opportunityName}/${roundFolderName}`;
                      window.open(url, "_blank");
                    }}
                  >
                    Browse Directory
                  </ModernButton>
                  {/* <ModernButton
                    color="error"
                    variant="contained"
                    // disabled={
                    //   closingRound ||
                    //   !closeRoundFile
                    // }
                    onClick={async () => {
                      await setCloseDialogOpen(true)
                      // handleCloseRound();
                    }}
                  > */}
                  {/* {closingRound ? 'Closing Round...' : 'Close Round'}
                  </ModernButton> */}
                  {hasAccess && backendRound?.userStatus !== "Completed" && (
                    <Tooltip
                      title={
                        hasSubmittedInputs
                          ? "Cannot close the round because one or more inputs are still in Submitted status."
                          : "Close Round"
                      }
                      arrow
                    >
                      <span>
                        <ModernButton
                          disabled={hasSubmittedInputs || closingRound}
                          onClick={handleOpenCloseRoundDrawer}
                          sx={{
                            color: '#fff !important',

                            '&.Mui-disabled': {
                              color: '#fff !important',
                              opacity: 0.6,
                            },

                            '& .MuiButton-startIcon': {
                              color: '#fff !important',
                            },
                          }}
                        >
                          {closingRound ? "Closing Round..." : "Close Round"}
                        </ModernButton>
                      </span>
                    </Tooltip>
                  )}

                  {hasAccess && backendRound?.userStatus === "Completed" && (

                    <ModernButton
                      variant="contained"
                      onClick={handleOpenExtractInformationDrawer}
                    >
                      Extract Outputs
                    </ModernButton>

                  )}
                </Stack>

              </Box>
              <Divider sx={{ my: 2 }} />
              <Stack spacing={2}>
                {/* <Box>
                  <Typography variant="body2" fontWeight={600} color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                    <EventIcon sx={{ fontSize: 18 }} /> Customer Submission Date
                  </Typography>
                  <Typography>{formatISODateToLocal(round.customerSubmissionDate) || '—'}</Typography>
                </Box> */}

                <Box>
                  <Typography
                    variant="body2"
                    fontWeight={600}
                    color="text.secondary"
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                      mb: 0.5
                    }}
                  >
                    <EventIcon sx={{ fontSize: 18 }} />

                    Customer Submission Date

                    {hasAccess && (
                      <Tooltip title="Edit Customer Submission Date">
                        <IconButton
                          size="small"
                          onClick={handleOpenCustomerDateEdit}
                          sx={{
                            ml: 0.5,
                            p: 0.25
                          }}
                        >
                          <EditIcon sx={{ fontSize: 17 }} />
                        </IconButton>
                      </Tooltip>
                    )}
                  </Typography>

                  <Typography>
                    {formatISODateToLocal(round.customerSubmissionDate) || '—'}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="body2" fontWeight={600} color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                    <DescriptionIcon sx={{ fontSize: 18 }} /> Description
                  </Typography>
                  <Typography>{round.description || '—'}</Typography>
                </Box>

                {/* Status */}
                <Box>
                  <Typography
                    variant="body2"
                    fontWeight={600}
                    color="text.secondary"
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                      mb: 0.5
                    }}
                  >
                    <AssignmentIcon sx={{ fontSize: 18 }} /> Status
                  </Typography>

                  <Typography>
                    {round.status || '—'}
                  </Typography>
                </Box>

                <Box>
                  {/* <Typography variant="body2" fontWeight={600} color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <AssignmentIcon sx={{ fontSize: 18 }} /> Datasets ({round.scenarios?.length || 0})
                  </Typography> */}
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body2"
                      fontWeight={600}
                      color="text.secondary"
                      sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                    >
                      <AssignmentIcon sx={{ fontSize: 18 }} />
                      Datasets ({round.scenarios?.length || 0})
                    </Typography>

                    {hasAccess && (
                      <Tooltip title="Add Dataset">
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() => setAddDatasetOpen(true)}
                        >
                          <Add />
                        </IconButton>
                      </Tooltip>
                    )}
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexWrap: "wrap",
                      gap: "8px",
                      mt: 0.5
                    }}
                  >
                    {round.scenarios.map((s) => {
                      const fullText = s.description
                        ? `${s.key} - ${s.description}`
                        : s.key;

                      const isExpanded = expandedDatasetChips[s.key];
                      const isLong = fullText.length > 40;

                      const displayText =
                        isExpanded || !isLong
                          ? fullText
                          : fullText.substring(0, 40) + "...";
                      // console.log("currentRoundDetails : ", currentRoundDetails);
                      // console.log("currentRoundDetails stakeholders", currentRoundDetails?.stakeholders);
                      return (
                        <Chip
                          key={s.key}
                          label={
                            <Box
                              sx={{
                                display: "flex",
                                flexDirection: isExpanded ? "column" : "row",
                                alignItems: "flex-start",
                                gap: "4px"
                              }}
                            >
                              <Typography
                                sx={{
                                  fontSize: "14px",
                                  fontWeight: 500,
                                  color: "#333",
                                  lineHeight: 1.4,
                                  whiteSpace: isExpanded ? "normal" : "nowrap",
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                  maxWidth: isExpanded ? "260px" : "220px",
                                  wordBreak: "break-word"
                                }}
                              >
                                {displayText}
                              </Typography>

                              {isLong && (
                                <Typography
                                  component="span"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setExpandedDatasetChips((prev) => ({
                                      ...prev,
                                      [s.key]: !prev[s.key]
                                    }));
                                  }}
                                  sx={{
                                    cursor: "pointer",
                                    color: "#1a237e",
                                    fontSize: "13px",
                                    fontWeight: 600,
                                    whiteSpace: "nowrap"
                                  }}
                                >
                                  {isExpanded ? "Read Less" : "Read More"}
                                </Typography>
                              )}
                            </Box>
                          }
                          sx={{
                            height: "auto",
                            maxWidth: "340px",
                            backgroundColor: "#f3f3f3",
                            border: "1px solid #bdbdbd",
                            borderRadius: "8px",
                            alignItems: "flex-start",

                            "& .MuiChip-label": {
                              display: "block",
                              padding: "6px 10px",
                              whiteSpace: "normal"
                            }
                          }}
                        />
                      );
                    })}
                  </Box>
                </Box>
              </Stack>
            </ModernCard>

            <ModernCard elevated>
              <Box
                sx={{
                  mb: 2,
                  // display: 'flex',
                  // justifyContent: 'space-between',
                  // alignItems: 'flex-start',
                  // flexWrap: 'wrap',
                  // gap: 2
                }}
              >
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    // width: '100%',
                    flexWrap: 'wrap',
                    gap: 2
                  }}
                >
                  {/* <Box sx={{ flex: 1, minWidth: 0 }}> */}


                  {/* <Stack direction="row" spacing={1}> */}

                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                      // mb: 1
                    }}
                  >
                    <PeopleIcon />

                    <Typography variant="h6">
                      Input Templates
                    </Typography>
                  </Box>

                  <Box
                    sx={{
                      display: 'flex',
                      // gap: 2,
                      // flexShrink: 0,
                      // marginLeft: 'auto',
                      // alignSelf: 'flex-start'
                      alignItems: 'center',
                      gap: 1.5,
                      flexWrap: 'wrap',
                    }}
                  >

                    {hasAccess && backendRound?.userStatus !== "Completed" && (
                      <ModernButton
                        variant="gradient"
                        glow
                        startIcon={<Add />}
                        loading={addTemplateLoading}
                        disabled={addTemplateLoading}
                        onClick={async () => {
                          try {
                            setAddTemplateLoading(true);

                            const prev = await ensurePrevRoundLoaded();

                            setAddTemplateOpen(true);

                            prevRoundIdRef.current = prev?.id ?? null;

                          } finally {
                            setAddTemplateLoading(false);
                          }
                        }}
                      >
                        Add Input Template
                      </ModernButton>
                    )}


                    {/* AddInput Template Drawer Region */}
                    {hasAccess && (

                      <AddInputTemplateDrawer
                        open={addTemplateOpen}
                        onClose={() => setAddTemplateOpen(false)}
                        onFlowReady={handleInputTemplateFlowReady}
                        roundId={round.roundId}
                        oppId={Number(id)}
                        currentRoundDetail={currentRoundDetails}
                        scenarios={round.scenarios}
                        remainingStakeholders={remainingStakeholders}
                        backendRound={prevRoundDetails}
                        allOpportunityRounds={allOpportunityRounds}
                        prevRoundScenarioMap={prevRoundScenarioMap}
                        prevRoundId={Number(prevRoundIdRef.current)}
                        prevRoundApprovedScenarioMap={prevRoundApprovedScenarioMap}
                        roundNumber={roundNumber}
                        opportunityName={opportunityName || ""}
                        opportunityCountryName={opportunityCountryName || ""}
                        leadPricerEmail={leadPricerEmail}
                        bidTeamEmail={bidTeamEmail}
                        customer={customer || ""}
                        spfxContext={spfxContext}
                        api={api}
                        onSaveSuccess={async (draftRows) => {
                          //   console.log("onSaveSuccess called", draftRows);
                          if (!round) return;

                          draftRows.forEach(r => {
                            const scenarioMap = new Map<ScenarioKey, string>();

                            Object.entries(r.scenarioConfigs).forEach(([k, scenarioCfg]) => {
                              if (scenarioCfg?.inputOption) {
                                scenarioMap.set(k as ScenarioKey, scenarioCfg.inputOption);
                              }
                            });

                            scenarioInputTypeMapRef.current.set(
                              r.stakeholderName,
                              scenarioMap
                            );
                          });

                          const payloadArray: Array<Omit<UpdateInputTemplatePayload, 'id'>> =
                            draftRows.map(r => {
                              const isAdhoc = !!(r as any).otherCode;
                              const it: InputTemplateRowView = {
                                enabled: true,
                                // stakeholderName: r.stakeholderName,
                                // stakeholderCode: r.stakeholderCode,

                                stakeholderName: isAdhoc
                                  ? (r as any).otherCode
                                  : r.stakeholderName,

                                stakeholderCode: isAdhoc
                                  ? (r as any).otherCode.replace(/[^a-zA-Z0-9]/g, "")
                                  : r.stakeholderCode,
                                applicableScenarios: r.applicableScenarios,
                                dueDate: r.dueDate ? r.dueDate.toISOString() : undefined,
                                notifyPersonas: r.notifyUsers,
                                additionalTeamPersonas: r.additionalTeam
                              };
                              const stakeholderType = isAdhoc
                                ? "Adhoc"
                                : "Standard";

                              assertStakeholderFields(it);


                              return buildFullPayloadForRow(
                                stakeholderType,
                                it,
                                round,
                                Number(id),
                                undefined,
                                undefined,
                                r.scenarioConfigs,
                                r.commonVersionSelections,
                                r.collectDraftInput,
                                r.commonDraftDueDate
                              );
                            });
                          // console.log("payloadArray :", payloadArray);
                          await api.createStakeholders(payloadArray);

                          setRound(prev => {
                            if (!prev) return prev;

                            return {
                              ...prev,
                              inputTemplates: [
                                ...prev.inputTemplates,
                                ...draftRows.map(r => ({
                                  enabled: true,
                                  stakeholderName: r.stakeholderName,
                                  stakeholderCode: r.stakeholderCode,
                                  applicableScenarios: r.applicableScenarios,
                                  dueDate: r.dueDate?.toISOString(),
                                  notifyPersonas: r.notifyUsers,
                                  additionalTeamPersonas: r.additionalTeam
                                }))
                              ]
                            };
                          });

                          await refreshBackendRound();

                          // setAddTemplateOpen(false);

                        }}
                      />

                    )}

                    <Dialog
                      open={folderCreationDialogOpen}
                      disableEscapeKeyDown
                      fullWidth
                      maxWidth="sm"
                    >
                      <DialogTitle>
                        Folder creation in progress
                      </DialogTitle>

                      <DialogContent>
                        <Stack
                          direction="row"
                          spacing={2}
                          alignItems="center"
                          sx={{ py: 2 }}
                        >
                          <CircularProgress size={28} />

                          <Typography>
                            Once the folders are created, we will notify you via email.
                          </Typography>
                        </Stack>
                      </DialogContent>

                      <DialogActions>
                        <ModernButton
                          variant="gradient"
                          onClick={handleFolderDialogOk}
                        >
                          OK
                        </ModernButton>
                      </DialogActions>
                    </Dialog>

                    {hasAccess && backendRound?.userStatus !== "Completed" && (
                      <ModernButton
                        size="small"
                        variant="outlined"
                        loading={editTemplateLoading}
                        disabled={editTemplateLoading}
                        onClick={async () => {
                          try {
                            setEditTemplateLoading(true);

                            const prev = await ensurePrevRoundLoaded();

                            setEditOpen(true);

                            prevRoundIdRef.current = prev?.id ?? null;

                          } finally {
                            setEditTemplateLoading(false);
                          }
                        }}
                      >
                        Edit Input Template
                      </ModernButton>
                    )}

                    {hasAccess && backendRound?.userStatus !== "Completed" && (
                      <ModernButton
                        size="small"
                        variant="outlined"
                        loading={changeVersionLoading}
                        disabled={changeVersionLoading}
                        onClick={async () => {
                          try {
                            setChangeVersionLoading(true);

                            const prev = await ensurePrevRoundLoaded();

                            setChangeVersionOpen(true);

                            prevRoundIdRef.current = prev?.id ?? null;

                          } finally {
                            setChangeVersionLoading(false);
                          }
                        }}
                      >
                        Change Version Template
                      </ModernButton>
                    )}


                    {allRoundFiles.some(
                      f =>
                        f.isCurrentVersion === '0' &&
                        ((f.status || '').toLowerCase() === 'validated' || (f.status || '').toLowerCase() === 'draft validated')
                    ) && (
                        <Box
                          sx={{
                            // ml: 2,
                            // px: 1.8,
                            // py: 0.8,
                            // minWidth: 235,
                            // height: 42,
                            // borderRadius: '10px',
                            // display: 'flex',
                            // alignItems: 'center',
                            // justifyContent: 'space-between',
                            // backgroundColor: '#fff'

                            px: 1.5,
                            py: 0.5,
                            height: 36,
                            borderRadius: '10px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 1,
                            backgroundColor: '#fff',
                          }}
                        >
                          <Typography
                            sx={{
                              fontSize: '13px',
                              fontWeight: 600,
                              color: '#1e293b',
                              mr: 1
                            }}
                          >
                            Previous Validated Versions
                          </Typography>

                          <Switch
                            checked={showPrevApprovedToggle}
                            onChange={() =>
                              setShowPrevApprovedToggle(!showPrevApprovedToggle)
                            }
                            size="small"
                            sx={{
                              width: 42,
                              height: 26,
                              padding: 0,

                              '& .MuiSwitch-switchBase': {
                                padding: '3px',
                                transitionDuration: '200ms',

                                '&.Mui-checked': {
                                  transform: 'translateX(16px)',
                                  color: '#ffffff',

                                  '& + .MuiSwitch-track': {
                                    backgroundColor: '#42B549',
                                    opacity: 1
                                  }
                                }
                              },

                              '& .MuiSwitch-thumb': {
                                width: 20,
                                height: 20,
                                backgroundColor: '#ffffff',
                                boxShadow: '0 1px 3px rgba(0,0,0,0.35)'
                              },

                              '& .MuiSwitch-track': {
                                borderRadius: 13,
                                backgroundColor: '#bdbdbd',
                                opacity: 1
                              }
                            }}
                          />
                        </Box>
                      )}


                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                      <Box
                        onClick={() => {
                          setShowRequiredOnly((prev) => {
                            if (prev === true) return false;
                            if (prev === false) return null;
                            return true;
                          });
                        }}
                        sx={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          width: 120,
                          height: 32,
                          borderRadius: 999,
                          backgroundColor: showRequiredOnly ? '#4caf50' : '#bdbdbd',
                          cursor: 'pointer',
                          px: 1,
                          justifyContent: showRequiredOnly ? 'flex-start' : 'flex-end',
                          transition: 'all 0.3s ease',
                        }}
                      >
                        <Typography
                          sx={{
                            color: '#fff',
                            fontWeight: 700,
                            fontSize: 12,
                            flex: 1,
                            textAlign: showRequiredOnly ? 'left' : 'right',
                          }}
                        >

                          {showRequiredOnly === true
                            ? 'Required'
                            : showRequiredOnly === false
                              ? 'Not Required' : 'ALL'}
                        </Typography>

                        <Box
                          sx={{
                            width: 22,
                            height: 22,
                            borderRadius: '50%',
                            backgroundColor: '#fff',
                            boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
                          }}
                        />
                      </Box>
                    </Box>

                  </Box>
                  {/* Edit Input Template Drawer Region */}
                  {hasAccess && (

                    <EditInputTemplateDrawer
                      open={editOpen}
                      onClose={() => setEditOpen(false)}
                      round={round}
                      currentRoundDetail={currentRoundDetails}
                      backendRound={prevRoundDetails}
                      roundNumber={roundNumber}
                      templateCatalog={templateCatalog}
                      prevRoundScenarioMap={prevRoundScenarioMap}
                      prevRoundApprovedScenarioMap={prevRoundApprovedScenarioMap}
                      prevRoundId={Number(prevRoundIdRef.current)}
                      spfxContext={spfxContext}
                      api={api}
                      onSaveSuccess={handleEditSave}
                    />
                  )}

                  {hasAccess && (

                    <ChangeVersionDrawer
                      open={changeVersionOpen}
                      onClose={() => setChangeVersionOpen(false)}
                      round={round}
                      currentRoundDetail={currentRoundDetails}
                      backendRound={backendRound}
                      roundNumber={roundNumber}
                      templateCatalog={templateCatalog}
                      prevRoundScenarioMap={prevRoundScenarioMap}
                      prevRoundApprovedScenarioMap={prevRoundApprovedScenarioMap}
                      prevRoundId={Number(prevRoundIdRef.current)}
                      spfxContext={spfxContext}
                      api={api}
                      onSaveSuccess={handleChangeVersionSave}
                    />


                  )}





                  {/* </Stack> */}




                  {/* </Box> */}
                </Box>

                <Box
                  sx={{
                    display: 'flex',
                    gap: 1,
                    flexWrap: 'wrap',
                    pt: 2
                  }}
                >

                  {statusList.map((status) => {
                    const isSelected = selectedStatuses.includes(status);

                    const colors = statusColors[status] || {
                      bg: '#f5f5f5',
                      color: '#000'
                    };

                    return (
                      <Chip
                        key={status}
                        size="small"
                        label={status}
                        clickable
                        onClick={() => {
                          setSelectedStatuses(prev => {
                            if (prev.includes(status)) {
                              return prev.filter(s => s !== status);
                            }
                            return [...prev, status];
                          });
                        }}
                        sx={{
                          // backgroundColor: isSelected ? '#1976d2' : colors.bg,
                          backgroundColor: colors.bg,
                          border: isSelected
                            ? `2px solid ${colors.color}`
                            : '1px solid transparent',
                          color: isSelected ? '#000' : colors.color,
                          fontWeight: 600,
                          // border: isSelected ? '2px solid #0d47a1' : '1px solid transparent'
                        }}
                      />
                    );
                  })}
                </Box>


                {/* <Box
                  sx={{
                    display: 'flex',
                    gap: 1,
                    flexWrap: 'wrap',
                    pt: 2
                  }}
                >
                  <Chip
                    size="small"
                    label="Validated"
                    sx={{
                      backgroundColor: '#e8f5e9',
                      color: '#2e7d32',
                      fontWeight: 600
                    }}
                  />

                  <Chip
                    size="small"
                    label="Submitted"
                    sx={{
                      backgroundColor: '#fff8e1',
                      color: '#ed6c02',
                      fontWeight: 600
                    }}
                  />

                  <Chip
                    size="small"
                    label="Rejected"
                    sx={{
                      backgroundColor: '#ffebee',
                      color: '#d32f2f',
                      fontWeight: 600
                    }}
                  />

                  <Chip
                    size="small"
                    label="Retracted"
                    sx={{
                      backgroundColor: '#e6e4fc',
                      color: '#221854',
                      fontWeight: 600
                    }}
                  />

                  <Chip
                    size="small"
                    label="Created"
                    sx={{
                      backgroundColor: '#f5f5f5',
                      color: '#616161',
                      fontWeight: 600
                    }}
                  />
                </Box> */}
                {/* CloseRoundDrawer Region*/}
                <CloseRoundDrawer
                  open={closeRoundDrawerOpen}
                  loading={closingRound}
                  extractInfo={extractInfo}
                  onExtractInfoChange={(value) => {
                    setExtractInfo(value);

                    if (!value) {
                      setCloseRoundError("");
                    }
                  }}
                  existingFiles={existingRoundFiles}
                  selectedFile={selectedOutputFile}
                  onSelectedFileChange={(value) => {
                    setSelectedOutputFile(value);
                    setCloseRoundError("");
                  }}
                  onClose={() => setCloseRoundDrawerOpen(false)}
                  onSubmit={handleCloseRound}
                  error={closeRoundError}
                />
                <ExtractInformationDrawer
                  open={extractInformationDrawerOpen}
                  onClose={handleCloseExtractInformationDrawer}
                  existingRoundFiles={existingRoundFiles}
                  selectedOutputFile={selectedOutputFile}
                  setSelectedOutputFile={setSelectedOutputFile}
                  outputLogs={outputLogs}
                  onExtractInformation={handleExtractInformation}
                  loading={extractingInformation || loadingOutputLogs}
                />

              </Box>
              <Divider sx={{ my: 2 }} />
              {filesLoading ? (
                <ModernLoadingState type="shimmer" rows={4} height={52} />
              ) : allRoundFiles.length === 0 ? (
                <ModernEmptyState type="empty" title="No files found" description="No input files have been submitted for this round yet." animated />
              ) : (
                <ModernDataTable
                  // rows={tableRows}
                  rows={filteredRows}
                  key={showPrevApprovedToggle ? 'validated' : 'current'}
                  autoHeight
                  pagination={false}
                  getRowHeight={() => 'auto'}
                  columns={[

                    {
                      field: "stakeholderName",
                      headerName: "Template-Version",
                      width: 320,
                      headerClassName: "sticky-col-1",
                      cellClassName: "sticky-col-1",

                      renderCell: (params) => {
                        const template =
                          params.row.stakeholder ??
                          params.row.stakeholderName ??
                          "—";

                        const version = params.row.versionNumber;
                        const type = params.row.stakeholderType ?? "—";

                        return (
                          <Stack
                            direction="row"
                            alignItems="center"
                            spacing={0.5}
                            sx={{
                              width: "100%",
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                            }}
                          >
                            <Typography variant="body2" noWrap component="span">
                              {template}
                            </Typography>

                            {type === "Adhoc" ? (
                              <Chip
                                label="Adhoc"
                                size="small"
                                sx={{
                                  height: 20,
                                  fontSize: 10,
                                  fontWeight: 600,
                                  flexShrink: 0,
                                  bgcolor: "#E0F7FA",
                                  color: "#006064",
                                  border: "1px solid #80DEEA",
                                  "& .MuiChip-label": {
                                    px: 1,
                                  },
                                }}
                              />
                            ) : (
                              <Typography variant="body2" noWrap component="span">
                                {" - "}
                                {version}
                              </Typography>
                            )}
                          </Stack>
                        );
                      },
                    },
                    {
                      field: 'datasetRevisionInputType',
                      headerName: 'Dataset - Revision - Input Type',
                      width: 260,
                      headerClassName: 'sticky-col-2',
                      cellClassName: 'sticky-col-2',

                      renderCell: (params) => {
                        const scenario = params.row.scenario || '—';

                        const revision =
                          params.row.revisionNumber !== null &&
                            params.row.revisionNumber !== undefined
                            ? params.row.revisionNumber
                            : '—';
                        const inputType = params.row.inputType || '—';
                        const value = params.row.submissionType ?? "—";
                        return (
                          <Box
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              overflow: 'hidden',
                              whiteSpace: 'nowrap',
                              textOverflow: 'ellipsis',
                              width: '100%',
                              minWidth: 0,
                              p: 2
                            }}
                          >
                            <Typography variant="body2">
                              {scenario} - {revision} - {inputType}
                            </Typography>
                            {value?.toLowerCase() === "draft" && (
                              <Chip
                                label="Draft"
                                size="small"
                                sx={{
                                  fontWeight: 600,
                                  minWidth: 50,
                                  ml: 1,
                                  bgcolor: "#FFF3E0",
                                  color: "#E65100",
                                  border: "1px solid #FFCC80",
                                }}
                              />
                            )}
                          </Box>
                        );
                      },
                    },
                    // {
                    //   field: "submissionType",
                    //   headerName: "Submission Type",
                    //   width: 130,
                    //   renderCell: (params) => {


                    //     return (

                    //     );
                    //   },
                    // },
                    {
                      field: 'name', headerName: 'File', flex: 1, minWidth: 160,
                      renderCell: (params) => {
                        const fileName = params.value || 'Unknown file';
                        const fileUrl = params.row.url;

                        // No uploaded file → plain text
                        if (!fileUrl) {
                          return (
                            <Typography variant="body2">
                              {fileName}
                            </Typography>
                          );
                        }

                        // File exists → hyperlink
                        return (
                          <a
                            href={fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            style={{
                              color: '#1976d2',
                              textDecoration: 'underline'
                            }}
                          >
                            {fileName}
                          </a>
                        );
                      },
                    },
                    {
                      field: 'status',
                      headerName: 'Status',
                      width: 170,

                      renderCell: (params) => {
                        const v = params.value || '';
                        const row = params.row;

                        if (!v || v === '—') {
                          return (
                            <Box
                              sx={{
                                width: '100%',
                                height: '100%',
                                display: 'flex',
                                alignItems: 'center'
                              }}
                            >
                              <Typography variant="body2">—</Typography>
                            </Box>
                          );
                        }

                        const ShowCrossIcon =
                          row.lastRevisionAttempt !== null &&
                          row.lastRevisionAttempt !== undefined &&
                          row.lastRevisionAttempt !== '';

                        return (
                          <Box
                            sx={{
                              width: '100%',
                              height: '100%',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'flex-start',
                              gap: 1
                            }}
                          >
                            <ModernChip
                              label={v}
                              colorVariant={getStatusColorVariant(v) as any}
                              size="small"
                            />

                            {ShowCrossIcon && (
                              <Tooltip
                                title={`Revision Requested on ${new Date(
                                  row.lastRevisionAttempt
                                ).toUTCString()}`}
                              >
                                {/* <SvgIcon sx={{ color: 'red', fontSize: 20 }} viewBox="0 0 24 24">
                                  <path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8z" />
                                  <path d="M6.7 14.8C6.25 13.97 6 13.01 6 12c0-3.31 2.69-6 6-6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8z" />
                                  <path d="M9 16.2l.9-3.4 2.3 2.3L9 16.2zm1.8-4.5l5.4-5.4 2.2 2.2-5.4 5.4-2.2-2.2zm6-6.5l2.2 2.2-.9.9-2.2-2.2.9-.9z" />
                                </SvgIcon> */}
                                <SvgIcon
                                  sx={{ color: 'red', fontSize: 20 }}
                                  viewBox="0 0 24 24"
                                >
                                  <g transform="scale(-1,1) translate(-24,0)">
                                    <path
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      d="M12 5a7 7 0 1 0 6.3 3.9M12 5v4M12 5l-2-2m2 2l2-2"
                                    />
                                  </g>
                                </SvgIcon>
                              </Tooltip>
                            )}
                          </Box>
                        );
                      }
                    },
                    {
                      field: 'modified', headerName: 'Submitted On', width: 110,
                      // renderCell: (params) => params.value ? new Date(params.value).toLocaleDateString() : '—',
                      renderCell: (params) => {

                        // console.log("Column Field:", params.field);
                        // console.log("Column Definition:", params.colDef);
                        // console.log("Cell Value:", params.value);
                        // console.log("Entire Row:", params.row);

                        return params.value
                          ? new Date(params.value).toLocaleDateString()
                          : '—';
                      },
                    },
                    // { field: 'dueDate', headerName: 'Due Date', width: 110 },
                    // {
                    //   field: "dueDate",
                    //   headerName: "Due Date",
                    //   width: 180,
                    //   renderCell: (params) => (
                    //     <Chip
                    //       label={params.value}
                    //       size="small"
                    //       sx={{
                    //         borderRadius: "6px",
                    //         ...getDueDateStyle(params.value)
                    //       }}
                    //     />
                    //   )
                    // },
                    {
                      field: "dueDate",
                      headerName: "Due Date",
                      width: 180,

                      renderCell: (params) => {
                        const submissionType =
                          String(params.row.submissionType ?? '').trim().toLowerCase();

                        const isDraft = submissionType === 'draft';

                        // const displayDueDate = isDraft
                        //   ? params.row.draftDueDate
                        //   : params.row.dueDate;
                        const rawDueDate = isDraft
                          ? params.row.draftDueDate
                          : params.row.dueDate;

                        const displayDueDate = rawDueDate
                          ? formatISODateToLocal(rawDueDate)
                          : '—';

                        return (
                          <Chip
                            label={displayDueDate || '—'}
                            size="small"
                            sx={{
                              borderRadius: "6px",
                              ...getDueDateStyle(rawDueDate)
                            }}
                          />
                        );
                      }
                    },
                    {
                      field: 'teamAndNotifyUsers',
                      headerName: 'Input Provider',
                      headerAlign: 'center',
                      align: 'center',
                      display: 'flex',
                      width: 250,

                      renderCell: (params) => {
                        const submittedByName: string | undefined =
                          params.row.submittedBy?.name;

                        const additionalTeamMembers: string[] =
                          params.row.additionalTeamPersonas || [];

                        const notifyUsers: any[] =
                          params.row.notifyUsers || [];

                        const notifyUserNames = notifyUsers
                          .map((u) => u.name)
                          .filter(Boolean);

                        const allUsers = [...additionalTeamMembers.map(n => ({ name: n, type: 'team' })), ...notifyUserNames.map(n => ({ name: n, type: 'notify' }))];

                        return (
                          <Box
                            sx={{
                              width: '100%',
                              height: '100%',
                              display: 'flex',
                              flexDirection: 'row',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexWrap: 'wrap',
                              gap: 0.5,
                            }}
                          >
                            {submittedByName ? (
                              <>
                                <CheckCircleIcon sx={{ color: "#2e7d32", fontSize: 16, flexShrink: 0 }} />
                                <Chip
                                  label={submittedByName}
                                  size="small"
                                  variant="filled"
                                  color="success"
                                  sx={{ height: 22, fontSize: "0.7rem", px: 0.5 }}
                                />
                              </>
                            ) : (
                              <>
                                {allUsers.map((u, index) =>
                                  index === 0 ? (
                                    <Box key={index} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 0.5 }}>
                                      <HourglassBottom sx={{ color: "#ed6c02", fontSize: 16, flexShrink: 0 }} />
                                      <Chip
                                        label={u.name}
                                        size="small"
                                        color={u.type === 'notify' ? 'primary' : 'default'}
                                      />
                                    </Box>
                                  ) : (
                                    <Chip
                                      key={index}
                                      label={u.name}
                                      size="small"
                                      color={u.type === 'notify' ? 'primary' : 'default'}
                                    />
                                  )
                                )}
                              </>
                            )}
                          </Box>
                        );
                      },
                    },
                    ...(backendRound?.userStatus !== "Completed"
                      ? ([
                        {
                          field: "actions",
                          headerName: "Actions",
                          minWidth: 120,
                          sortable: false,
                          align: "center",
                          headerAlign: "center",

                          renderCell: (params) => {
                            const row = params.row as UnifiedFileItem;

                            return (
                              <IconButton
                                size="small"
                                onClick={(e) => handleOpenActionsMenu(e, row)}
                              >
                                <MoreVertIcon fontSize="small" />
                              </IconButton>
                            );
                          },
                        },
                      ] as GridColDef[])
                      : []),
                  ] as GridColDef[]}
                  sx={{
                    '& .MuiDataGrid-cell': {
                      display: 'flex',
                      alignItems: 'center',
                    },
                    '& .MuiDataGrid-cell--autoHeight': {
                      alignItems: 'center',
                    },
                    '& .sticky-col-1': {
                      position: 'sticky',
                      left: 0,
                      zIndex: 1200,
                      backgroundColor: '#ffffff',
                    },

                    '& .sticky-col-2': {
                      position: 'sticky',
                      left: '220px',
                      zIndex: 1200,
                      backgroundColor: '#ffffff',
                    },
                    border: 'none',
                    '& .MuiDataGrid-row:hover .sticky-col-1, & .MuiDataGrid-row:hover .sticky-col-2': {
                      backgroundColor: '#f5f7fa !important',
                    },
                    '& .row-status-approved, & .row-status-approved .MuiDataGrid-cell': {
                      backgroundColor: '#e8f5e9 !important',
                    },

                    '& .row-status-pending, & .row-status-pending .MuiDataGrid-cell': {
                      backgroundColor: '#fff8e1 !important',
                    },

                    '& .row-status-rejected, & .row-status-rejected .MuiDataGrid-cell': {
                      backgroundColor: '#ffebee !important',
                    },

                    '& .row-status-retracted, & .row-status-retracted .MuiDataGrid-cell': {
                      backgroundColor: '#e6e4fc !important',
                    },
                    '& .MuiDataGrid-row:hover': {
                      backgroundColor: '#f5f7fa !important',
                    },
                    '& .MuiDataGrid-row:hover .MuiDataGrid-cell': {
                      backgroundColor: '#f5f7fa !important',
                    },
                    '& .row-status-created, & .row-status-created .MuiDataGrid-cell': {
                      backgroundColor: '#f5f5f5 !important',
                    },
                  }}
                  freezeColumns={[
                    { field: 'stakeholderName', left: 0 },
                    { field: 'datasetRevisionInputType', left: 220 },
                  ]}
                  getRowClassName={(params) => {
                    const status = String(params.row.status || '').toLowerCase();

                    if (status.includes('approved') || status.includes('validated')) {
                      return 'row-status-approved';
                    }

                    if (status.includes('submitted') || status.includes('pending')) {
                      return 'row-status-pending';
                    }
                    if (status.includes('created')) {
                      return 'row-status-created';
                    }

                    if (
                      status.includes('reject')
                    ) {
                      return 'row-status-rejected';
                    }

                    if (status.includes('retract')) {
                      return 'row-status-retracted';
                    }

                    return '';
                  }}
                />
              )}
            </ModernCard>
          </Stack>

        )}
        <Menu
          anchorEl={actionAnchorEl}
          open={Boolean(actionAnchorEl)}
          onClose={handleCloseActionsMenu}
        >
          {selectedActionRow && (
            <>
              {(selectedActionRow.status || '').toLowerCase() === 'submitted' &&
                hasAccess && (
                  <MenuItem
                    onClick={() => {
                      setInlinePanel({
                        show: true,
                        file: selectedActionRow,
                        mode: 'approval'
                      });

                      setInlineDecision('');
                      setInlineComment('');

                      handleCloseActionsMenu();
                    }}
                  >
                    Validate / Reject
                  </MenuItem>
                )}

              {selectedActionRow.isCurrentApproved === '1' &&
                (selectedActionRow.status === 'Validated' || selectedActionRow.status === 'Draft Validated') &&
                hasAccess &&
                !(
                  (selectedActionRow.submissionType || '').toLowerCase() === 'draft' &&
                  hasApprovedFinalForSameDataset(selectedActionRow)
                ) &&
                (
                  <MenuItem
                    disabled={isStakeholderMissing(selectedActionRow)}
                    onClick={() => {
                      if (isStakeholderMissing(selectedActionRow)) return;
                      setInlinePanel({
                        show: true,
                        file: selectedActionRow,
                        mode: 'revision'
                      });
                      setInlineRevisionComment('');
                      handleCloseActionsMenu();
                    }}
                    sx={{
                      '&.Mui-disabled': {
                        opacity: 0.8,
                        color: 'inherit',
                        cursor: 'not-allowed',
                      }
                    }}
                  >
                    Send for revision
                    {/* </ModernButton> */}
                    {/* {(!selectedActionRow.notifyUsers || selectedActionRow.notifyUsers.length === 0) && */}
                    {/* (!selectedActionRow.additionalTeamPersonas || selectedActionRow.additionalTeamPersonas.length === 0) && ( */}
                    {isStakeholderMissing(selectedActionRow) && (
                      <Typography
                        variant="caption"
                        sx={{
                          color: "#d32f2f",
                          fontSize: "0.7rem",
                          ml: 1,
                          fontWeight: 500
                        }}
                      >
                        (No Stakeholder or Extra Input Provider selected)
                      </Typography>
                    )}

                    {/* </Box>
                                ) : (
                                  <Typography
                                    variant="body2"
                                    color="text.secondary"
                                  >
                                    —
                                  </Typography> */}
                  </MenuItem>
                )}

              {selectedActionRow.rawInputType === 'CollectInput' &&
                (selectedActionRow.status === 'Created' || selectedActionRow.status === 'Rejected') &&
                hasAccess && (
                  // <MenuItem
                  //   disableRipple
                  //   onClick={(e) => e.stopPropagation()}
                  // >
                  //   <FormControlLabel
                  //     onClick={(e) => e.stopPropagation()}
                  //     label={
                  //       <Typography
                  //         sx={{
                  //           fontSize: '12px',
                  //           fontWeight: 500
                  //         }}
                  //       >
                  //         Is Required?
                  //       </Typography>
                  //     }
                  //     control={
                  //       <Switch
                  //         size="small"
                  //         checked={Boolean(selectedActionRow.inputRequired)}
                  //         onChange={(event) =>
                  //           handleToggle(selectedActionRow, event)
                  //         }
                  //         onClick={(e) => e.stopPropagation()}
                  //         sx={{
                  //           '& .MuiSwitch-switchBase.Mui-checked': {
                  //             color: '#fff',
                  //           },
                  //           '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                  //             backgroundColor: '#4CAF50',
                  //             opacity: 1,
                  //           },
                  //           '& .MuiSwitch-track': {
                  //             opacity: 1,
                  //           },
                  //         }}
                  //       />
                  //     }
                  //   />
                  // </MenuItem>
                  <MenuItem
                    disableRipple
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: '100%',
                        gap: 2,
                      }}
                    >
                      <Typography
                        sx={{
                          fontSize: '12px',
                          fontWeight: 500,
                        }}
                      >
                        Is Required?
                      </Typography>

                      <Box
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggle(selectedActionRow);
                        }}
                        sx={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          width: 90,
                          height: 28,
                          borderRadius: 999,
                          backgroundColor: selectedActionRow.inputRequired ? '#4caf50' : '#bdbdbd',
                          cursor: 'pointer',
                          position: 'relative',
                          transition: 'background-color 0.3s ease',
                          userSelect: 'none',
                          px: '6px',
                          justifyContent: selectedActionRow.inputRequired ? 'flex-start' : 'flex-end',
                        }}
                      >
                        <Typography
                          sx={{
                            color: '#fff',
                            fontWeight: 700,
                            fontSize: 11,
                            flex: 1,
                            textAlign: selectedActionRow.inputRequired ? 'left' : 'right',
                            pl: selectedActionRow.inputRequired ? '4px' : 0,
                            pr: selectedActionRow.inputRequired ? 0 : '4px',
                            lineHeight: '28px',
                            transition: 'all 0.3s ease',
                          }}
                        >
                          {selectedActionRow.inputRequired ? 'Yes' : 'No'}
                        </Typography>

                        <Box
                          sx={{
                            width: 20,
                            height: 20,
                            borderRadius: '50%',
                            backgroundColor: '#fff',
                            boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
                            flexShrink: 0,
                            transition: 'all 0.3s ease',
                          }}
                        />
                      </Box>
                    </Box>
                  </MenuItem>
                )}
            </>
          )}
        </Menu>

        <Drawer
          anchor="right"
          open={inlinePanel.show}
          onClose={() => setInlinePanel(p => ({ ...p, show: false }))}
          PaperProps={{
            sx: {
              width: { xs: '100%', sm: 520 },
              p: 2,
              pt: 8,
            },
          }}
        >
          <Box
            sx={{
              px: '10px', py: '10px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              borderBottom: '1px solid', borderColor: 'divider',
              backgroundColor: 'background.paper',
            }}
          >
            <Typography variant="h6" fontWeight={700}>
              {inlinePanel.mode === 'approval' ? 'Validate / Reject File' : 'Send for Revision'}
            </Typography>
            <IconButton onClick={() => setInlinePanel(p => ({ ...p, show: false }))}><CloseIcon /></IconButton>
          </Box>
          {inlinePanel.file && (
            <Stack spacing={2} sx={{ p: 3 }}>
              <Box>
                <Typography variant="body2" color="text.secondary">File</Typography>
                <Typography fontWeight={500}>{inlinePanel.file.name}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">Stakeholder</Typography>
                <Typography>{inlinePanel.file.stakeholderName}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">Dataset</Typography>
                <Typography>{inlinePanel.file.scenario}: {inlinePanel.file.scenarioDescription}</Typography>
              </Box>
              <Divider />
              {inlinePanel.mode === 'approval' ? (
                <>
                  <FormControl fullWidth size="small">
                    <InputLabel>Decision</InputLabel>
                    <Select value={inlineDecision} label="Decision" onChange={e => setInlineDecision(e.target.value)}>
                      <MenuItem value="Approve">Validate</MenuItem>
                      <MenuItem value="Reject">Reject</MenuItem>
                    </Select>
                  </FormControl>
                  <TextField
                    label="Comment (optional)"
                    multiline rows={3} fullWidth size="small"
                    value={inlineComment}
                    onChange={e => setInlineComment(e.target.value)}
                  />
                  <ModernButton variant="gradient" glow disabled={!inlineDecision || inlineSaving} onClick={inlineSubmitToFlow}>
                    {inlineSaving ? 'Submitting…' : 'Submit Decision'}
                  </ModernButton>
                </>
              ) : (
                <>
                  <TextField
                    label="Revision Comment"
                    multiline rows={3} fullWidth size="small"
                    value={inlineRevisionComment}
                    onChange={e => setInlineRevisionComment(e.target.value)}
                  />
                  <ModernButton variant="gradient" glow disabled={!inlineRevisionComment.trim() || inlineSaving} onClick={inlineSendForRevision}>
                    {inlineSaving ? 'Sending…' : 'Send for Revision'}
                  </ModernButton>
                </>
              )}
            </Stack>
          )}
        </Drawer>


        <Drawer
          anchor="right"
          open={showGeneratePanel}
          onClose={() => setShowGeneratePanel(false)}
          PaperProps={{
            sx: {
              width: { xs: '100%', sm: 520 },
              p: 2,
              pt: 8,
            },
          }}
        >
          <Box
            sx={{
              px: '10px', py: '10px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              borderBottom: '1px solid', borderColor: 'divider',
              backgroundColor: 'background.paper',
            }}
          >
            <Typography variant="h5" fontWeight={700}>Generate Output File</Typography>
            <IconButton onClick={() => setShowGeneratePanel(false)}><CloseIcon /></IconButton>
          </Box>
          <Box sx={{ p: 2 }}>
            {!round ? (
              <Typography>Round not found.</Typography>
            ) : (
              <Stack spacing={3}>
                <ModernCard elevated>
                  <Typography variant="body2" fontWeight={600} gutterBottom>
                    Select Input Template & Dataset
                  </Typography>
                  <Typography variant="caption" color="text.secondary" gutterBottom sx={{ display: 'block', mb: 2 }}>
                    Only Validated files are selectable; others are disabled
                  </Typography>
                  <Divider sx={{ my: 2 }} />
                  {pairRows.length === 0 ? (
                    <ModernEmptyState
                      type="empty"
                      title="No files available"
                      description={`No input template scenario files found in ${LIBRARY_NAME}/${customer}/${opportunityName}/${roundFolderName}.`}
                    />
                  ) : (
                    <Stack spacing={2}>
                      {Object.keys(groupedPairRows).map(stakeholder => {

                        const rows = groupedPairRows[stakeholder];
                        const validatedCount = rows.filter(r => r.selectable).length;
                        const selectedCount = rows.filter(r => selectedPairIds.has(r.id)).length;
                        return (
                          <Box
                            key={stakeholder}
                            sx={{ p: 2, borderRadius: 2, backgroundColor: 'background.default', border: '1px solid', borderColor: 'divider' }}
                          >
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                              <Typography variant="body1" fontWeight={600}>{stakeholder}</Typography>
                              <Typography variant="caption" color="text.secondary">
                                {selectedCount} selected / {validatedCount} validated
                              </Typography>
                            </Box>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                              {[...rows].sort((a, b) => a.scenario.localeCompare(b.scenario)).map(r => {
                                let wfStatus = r.status ?? '';
                                if (r.status === "Approved") {
                                  wfStatus = "Validated"
                                }
                                // const label = `Dataset ${r.scenario}${r.status ? ` (${wfStatus})` : ''}`;
                                const label =
                                  `Dataset ${r.scenario} - ${r.submissionType || ''} ${r.status ? `(${wfStatus})` : ''
                                  }`;
                                return (
                                  // <FormControlLabel
                                  //   key={r.id}
                                  //   control={
                                  //     <Checkbox
                                  //       disabled={!r.selectable}
                                  //       checked={selectedPairIds.has(r.id)}
                                  //       onChange={() => toggleRowSelection(r)}
                                  //       size="small"
                                  //     />
                                  //   }
                                  //   label={<Typography variant="body2">{label}</Typography>}
                                  // />
                                  <FormControlLabel
                                    key={r.id}
                                    control={
                                      <Checkbox
                                        disabled={!r.selectable}
                                        checked={selectedPairIds.has(r.id)}
                                        onChange={() => toggleRowSelection(r)}
                                        size="small"
                                      />
                                    }
                                    label={renderOutputDescription(r)}
                                  />
                                );
                              })}
                            </Box>
                          </Box>
                        );
                      })}
                    </Stack>
                  )}
                </ModernCard>
                <ModernCard elevated>
                  <FormControl component="fieldset">
                    <Typography component="legend" sx={{ fontWeight: 600, mb: 1 }}>
                      Destination
                    </Typography>
                    <RadioGroup
                      value={sourceChoice}
                      onChange={(e) => setSourceChoice(e.target.value as 'existing' | 'template')}
                    >
                      <FormControlLabel
                        value="template"
                        control={<Radio />}
                        label="Create new output file (default template applied automatically)"
                      />
                      <FormControlLabel
                        value="existing"
                        control={<Radio />}
                        label="Use existing output file (append/merge sheets)"
                      />
                    </RadioGroup>
                  </FormControl>
                </ModernCard>
                {sourceChoice === 'existing' && (
                  <FormControl fullWidth>
                    <InputLabel>Select an Existing Output Excel File</InputLabel>
                    <Select
                      value={selectedExistingFileName || ''}
                      onChange={(e) => {
                        const val = e.target.value as string;
                        setSelectedExistingFileName(val);
                        if (val && !userOverrodeFileNameRef.current) setOutputFileName(val);
                      }}
                      label="Select an Existing Output Excel File"
                    >
                      {existingRoundFiles.map(f => (
                        <MenuItem key={f.name} value={f.name}>
                          {f.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}
                {sourceChoice === 'template' && (
                  <>
                    <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                      A default Input Template will be applied automatically.
                    </Typography>
                    <ModernTextField
                      label="Output File Name"
                      value={outputFileName}
                      onBlur={() => {
                        if (sourceChoice === 'template') {
                          setOutputFileName(forceXlsx(outputFileName));
                        }
                      }}
                      onChange={(e) => {
                        userOverrodeFileNameRef.current = true;
                        setOutputFileName(e.target.value.replace(/[^a-zA-Z0-9_]/g, '').trim());
                      }}
                      required
                      helperText="Suggested deterministic name helps you locate the file later."
                    />
                  </>
                )}
                <Box sx={{ display: 'flex', gap: 2, pt: 2 }}>
                  <ModernButton
                    variant="gradient"
                    glow
                    onClick={handleGenerate}
                    disabled={
                      generating ||
                      selectedPairIds.size === 0 ||
                      (sourceChoice === 'existing' && !selectedExistingFileName) ||
                      (sourceChoice === 'template' && !outputFileName)
                    }
                    loading={generating}
                    fullWidth
                  >
                    {generating ? 'Generating…' : 'Generate'}
                  </ModernButton>
                  <ModernButton
                    variant="outlined"
                    onClick={() => setShowGeneratePanel(false)}
                    disabled={generating}
                    fullWidth
                  >
                    Cancel
                  </ModernButton>
                </Box>
                {generating && (
                  <Box sx={{ mt: 2 }}>
                    <ModernLoadingState type="spinner" />
                  </Box>
                )}
              </Stack>
            )}
          </Box>
        </Drawer>

        <Drawer
          anchor="right"
          open={addDatasetOpen}
          onClose={() => !savingDataset && setAddDatasetOpen(false)}
          PaperProps={{
            sx: {
              width: { xs: '100%', sm: 520 },
              p: 2,
              pt: 8,
            },
          }}
        >
          <Box
            sx={{
              px: '12px',
              py: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: '1px solid',
              borderColor: 'divider',
              backgroundColor: 'background.paper',
            }}
          >
            <Typography variant="h6" fontWeight={700}>
              Add Dataset
            </Typography>

            <IconButton
              onClick={() => !savingDataset && setAddDatasetOpen(false)}
              disabled={savingDataset}
            >
              <CloseIcon />
            </IconButton>
          </Box>

          <Box sx={{ p: 3 }}>
            <Stack spacing={3}>
              {newScenarios.map((s) => (
                <TextField
                  key={s.key}
                  label={`Dataset ${s.key} Description`}
                  value={s.desc}
                  onChange={(e) => updateScenarioDraft(s.key, e.target.value)}
                  multiline
                  rows={2}
                  required
                  fullWidth
                />
              ))}

              <Stack spacing={1}>
                <Stack direction="row" spacing={1} alignItems="flex-start">
                  <ModernButton
                    variant="outlined"
                    startIcon={<Add />}
                    onClick={addScenarioDraft}
                    disabled={savingDataset}
                  >
                    Add Dataset
                  </ModernButton>

                  <Stack spacing={0}>
                    <ModernButton
                      variant="outlined"
                      color="error"
                      onClick={removeLastScenarioDraft}
                      disabled={savingDataset || newScenarios.length === 0}
                    >
                      Remove Last
                    </ModernButton>

                    <Typography
                      variant="caption"
                      color="text.secondary"
                      sx={{ pl: 0.5, pt: 0.25 }}
                    >
                      {newScenarios.length > 0
                        ? `Removes Dataset ${newScenarios[newScenarios.length - 1].key}`
                        : 'No draft datasets to remove'}
                    </Typography>
                  </Stack>
                </Stack>
              </Stack>
              {toast && (
                <Box sx={{ mb: 3 }}>
                  <ModernAlert
                    severity={toast.severity}
                    onClose={() => setToast(null)}
                    elevated
                    gradient
                  >
                    {toast.text}
                  </ModernAlert>
                </Box>
              )}
              <ModernButton
                variant="gradient"
                glow
                loading={savingDataset}
                onClick={handleSaveMultipleDatasets}
                disabled={newScenarios.length === 0}
                fullWidth
              >
                Save All
              </ModernButton>
            </Stack>
          </Box>
        </Drawer>
        <Dialog
          open={editCustomerDateOpen}
          onClose={() => {
            if (!savingCustomerSubmissionDate) {
              setEditCustomerDateOpen(false);
            }
          }}
          maxWidth="xs"
          fullWidth
        >
          <DialogTitle>
            Edit Customer Submission Date
          </DialogTitle>

          <DialogContent>
            <Box sx={{ pt: 1 }}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Customer Submission Date"
                  value={customerSubmissionDateEdit}
                  onChange={(newValue) => {
                    setCustomerSubmissionDateEdit(newValue);
                  }}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      required: true,
                    }
                  }}
                />
              </LocalizationProvider>
            </Box>
          </DialogContent>

          <DialogActions sx={{ px: 3, pb: 2 }}>
            <ModernButton
              variant="outlined"
              onClick={() => setEditCustomerDateOpen(false)}
              disabled={savingCustomerSubmissionDate}
            >
              Cancel
            </ModernButton>

            <ModernButton
              variant="contained"
              onClick={handleSaveCustomerSubmissionDate}
              loading={savingCustomerSubmissionDate}
              disabled={!customerSubmissionDateEdit}
            >
              Save
            </ModernButton>
          </DialogActions>
        </Dialog>

        <Dialog
          open={closeDialogOpen}
          onClose={() => setCloseDialogOpen(false)}
          maxWidth="xs"
          fullWidth
        >
          <DialogTitle>
            Close Round
          </DialogTitle>

          <DialogContent>

            <DialogContentText>
              Are you sure you want to close this round?
              This action cannot be easily undone.
            </DialogContentText>

            {/* <Box mt={3}>

              <ModernButton
                component="label"
                variant="outlined"
              >
                Upload Final Output File

                <input
                  hidden
                  type="file"
                  onChange={(e) => {
                    const file = e.target.files?.[0] || null;
                    setCloseRoundFile(file);
                  }}
                />

              </ModernButton>

              {closeRoundFile && (
                <Typography mt={2} variant="body2">
                  Selected File: {closeRoundFile.name}
                </Typography>
              )}

            </Box> */}

            <Typography
              variant="body2"
              sx={{
                mt: 3,
                color: 'text.secondary'
              }}
            >
              All Active and Validated files will automatically be included when closing the round.
            </Typography>

          </DialogContent>
          <DialogActions>

            <ModernButton
              variant="outlined"
              onClick={() => {
                setCloseDialogOpen(false);
                //  setSelectedCloseFile('');
              }}
            >
              Cancel
            </ModernButton>

            <ModernButton
              color="error"
              variant="contained"
              disabled={
                closingRound}
              loading={closingRound}
              onClick={() => {
                handleCloseRound();
                setCloseDialogOpen(false);
              }}
            >
              {closingRound ? 'Closing Round...' : 'Close Round'}
            </ModernButton>

          </DialogActions>
        </Dialog>
      </Box>
    </Fade >
  );
}