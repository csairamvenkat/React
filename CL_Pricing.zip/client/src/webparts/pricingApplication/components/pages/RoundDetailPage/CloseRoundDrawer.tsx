import * as React from "react";
import {
  Drawer,
  Box,
  Typography,
  Divider,
  IconButton,
  Checkbox,
  FormControlLabel,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Paper
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { ModernButton } from "../../shared/mui";

interface LibraryFile {
  name: string;
  url: string;
  serverRelativeUrl: string;
  timeLastModified?: string;
  length?: number;
  uniqueId?: string;
  File_x0020_Type?: string;
}

interface CloseRoundDrawerProps {
  open: boolean;
  loading: boolean;

  extractInfo: boolean;
  onExtractInfoChange: (value: boolean) => void;

  existingFiles: LibraryFile[];
  selectedFile?: string;
  onSelectedFileChange: (value: string) => void;

  onClose: () => void;
  onSubmit: () => void;
  error?: string;
}

export default function CloseRoundDrawer({
  open,
  loading,
  extractInfo,
  onExtractInfoChange,
  existingFiles,
  selectedFile,
  onSelectedFileChange,
  onClose,
  onSubmit,
  error
}: CloseRoundDrawerProps) {
  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: '100%', sm: 520 },
          p: 2,
          pt: 9,
          display: "flex",
          flexDirection: "column"
        }
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 3,
          py: 2.5,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          minHeight: 72
        }}
      >
        <Typography variant="h5" fontWeight={600}>
          Close Round
        </Typography>

        <IconButton onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </Box>

      <Divider />

      {/* Body */}
      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          p: 3,
          bgcolor: "#F8F9FC"
        }}
      >
        <Paper
          elevation={0}
          sx={{
            p: 3,
            borderRadius: 3,
            border: "1px solid #E5E7EB",
            bgcolor: "#fff"
          }}
        >
          {/* <Typography
            variant="body1"
            sx={{
              mb: 3,
              lineHeight: 1.7
            }}
          >
            Closing the round will generate the final output file for all
            active validated datasets.
          </Typography> */}

          <FormControlLabel
            sx={{
              ml: 0,
              mb: extractInfo ? 3 : 0
            }}
            control={
              <Checkbox
                checked={extractInfo}
                onChange={(e) =>
                  onExtractInfoChange(e.target.checked)
                }
              />
            }
            label={
              <Typography fontWeight={500}>
                Extract Output
              </Typography>
            }
          />

          {extractInfo && existingFiles.length == 0 && (
            <>
              <Typography fontWeight={500}>
                No Output File is available
              </Typography>
              {error && (
                <Typography
                  color="error"
                  variant="body2"
                  sx={{ mt: 1 }}
                >
                  {error}
                </Typography>
              )}
            </>
          )}

          {extractInfo && existingFiles.length > 0 && (
            <>
              <FormControl fullWidth>
                <InputLabel id="existing-file-label">
                  Existing Output File
                </InputLabel>

                <Select
                  labelId="existing-file-label"
                  value={selectedFile ?? ""}
                  label="Existing Output File"
                  onChange={(e) =>
                    onSelectedFileChange(
                      e.target.value as string
                    )
                  }
                >
                  {existingFiles.map((file) => (
                    <MenuItem
                      key={file.serverRelativeUrl}
                      value={file.name}
                    >
                      {file.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {error && (
                <Typography
                  color="error"
                  variant="body2"
                  sx={{ mt: 1 }}
                >
                  {error}
                </Typography>
              )}
            </>
          )}
        </Paper>
      </Box>

      <Divider />

      {/* Footer */}
      <Box
        sx={{
          px: 3,
          py: 2,
          display: "flex",
          justifyContent: "flex-end",
          gap: 2,
          bgcolor: "#fff"
        }}
      >
        <ModernButton
          variant="outlined"
          onClick={onClose}
        >
          Cancel
        </ModernButton>

        {/* <ModernButton
          loading={loading}
          onClick={onSubmit}
        >
          Close Round
        </ModernButton> */}
        <ModernButton
          loading={loading}
          onClick={onSubmit}
          sx={{
            "&.Mui-disabled": {
              color: "#ffffff",
              opacity: 0.7,
            },
          }}
        >
          Close Round
        </ModernButton>
      </Box>
    </Drawer>
  );
}