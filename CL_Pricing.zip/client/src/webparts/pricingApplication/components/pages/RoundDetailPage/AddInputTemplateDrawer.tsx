import * as React from "react";
import AddIcon from "@mui/icons-material/Add";
import {
    Drawer,
    Box,
    Stack,
    Typography,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Checkbox,
    FormControlLabel,
    TextField,
    Autocomplete,
    IconButton
} from "@mui/material";
import {
    ModernTextField,
} from "../../shared/mui";
import CloseIcon from "@mui/icons-material/Close";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { SPHttpClient } from "@microsoft/sp-http";
import { ModernButton, ModernCard, ModernAlert } from "../../shared/mui";
import type { IPersonaProps } from "@fluentui/react";

import { AddInputTemplateDrawerProps, DraftRow, InputOption, ScenarioConfig, ScenarioKey } from '../../store/Models';
import { triggerFlow } from "../../../flow/flowclient";
import { Today } from "@mui/icons-material";

type AdhocDraftRow = DraftRow & {
    otherCode: string;
    usePreviousRound: boolean;
    description?: string;
    previousAdhocId?: number;
};
type PreviousAdhocTemplate = {
    id?: number;
    stakeholderName: string;
    stakeholderCode: string;
    description?: string;
    versionNumber?: string;
    applicableScenarios?: string[];
    inputType?: string;
    workflowStatus?: string;
    dueDate?: string | Date | null;
};
const today = new Date();
today.setHours(0, 0, 0, 0);

const AddInputTemplateDrawer: React.FC<AddInputTemplateDrawerProps> = ({
    open,
    onClose,
    onFlowReady,
    roundNumber,
    prevRoundScenarioMap,
    prevRoundApprovedScenarioMap,
    prevRoundId,
    oppId,
    scenarios,
    remainingStakeholders,
    backendRound,
    allOpportunityRounds,
    currentRoundDetail,
    spfxContext,
    opportunityName,
    opportunityCountryName,
    leadPricerEmail,
    bidTeamEmail,
    customer,
    api,
    onSaveSuccess
}) => {

    const peoplePickerContext = React.useMemo(() => ({
        absoluteUrl: spfxContext?.pageContext?.web?.absoluteUrl,
        msGraphClientFactory: spfxContext?.msGraphClientFactory,
        spHttpClient: spfxContext?.spHttpClient
    }), [spfxContext]);

    const [rows, setRows] = React.useState<DraftRow[]>([]);
    const [adhocCards, setAdhocCards] =
        React.useState<AdhocDraftRow[]>([]);
    const [standardTemplatesByStakeholder, setStandardTemplatesByStakeholder] =
        React.useState<
            Map<
                string,
                {
                    id: number;
                    title: string;
                    versionNumber: string;
                }[]
            >
        >(new Map());

    const [saving, setSaving] = React.useState(false);
    const [activeVersions, setActiveVersions] = React.useState<string[]>([]);
    const [existingTemplateCodes, setExistingTemplateCodes] =
        React.useState<string[]>([]);
    const [otherCard, setOtherCard] = React.useState({
        enabled: false,

        otherCode: "",

        applicableScenarios: [] as ScenarioKey[],

        scenarioConfigs:
            {} as Partial<Record<ScenarioKey, ScenarioConfig>>,

        dueDate: null as Date | null,

        groupUsers: [] as IPersonaProps[],

        notifyUsers: [] as IPersonaProps[],

        additionalTeam: [] as IPersonaProps[],

        inputTemplateVersions: [] as any[]
    });
    React.useEffect(() => {
        if (open) {
            setSaving(false);
            loadActiveVersions();
        }
    }, [open]);

    const [toast, setToast] = React.useState<{
        severity: 'success' | 'error' | 'warning' | 'info';
        text: string;
    } | null>(null);

    const allTemplatesAdded = remainingStakeholders.length === 0;
    const otherHasCollectScenario =
        otherCard.applicableScenarios.some(
            sk =>
                otherCard.scenarioConfigs[sk]?.inputOption ===
                "CollectInput"
        );

    const otherHasStandardScenario =
        otherCard.applicableScenarios.some(
            sk =>
                otherCard.scenarioConfigs[sk]?.inputOption ===
                "useStandardInput"
        );

    const cfg = (window as any).TENANT_CONFIG;
    const currentRoundDueDate = React.useMemo(() => {
        const dueDate = currentRoundDetail?.stakeholders
            ?.map((s: any) => s.dueDate)
            ?.find((d: any) => d);

        return dueDate ? new Date(dueDate) : null;
    }, [currentRoundDetail]);

    React.useEffect(() => {
        if (!open) return;
        setRows(
            remainingStakeholders.map(s => ({
                enabled: false,
                stakeholderName: s.stakeholderName,
                stakeholderCode: s.stakeholderCode,
                applicableScenarios: [],
                scenarioConfigs: {},
                //dueDate: null,
                dueDate: currentRoundDueDate
                    ? new Date(currentRoundDueDate)
                    : null,
                groupUsers: [],
                notifyUsers: [],
                additionalTeam: []
            }))
        );
    }, [open, remainingStakeholders]);


    const updateRow = (idx: number, patch: Partial<DraftRow>) => {
        setRows(prev => prev.map((r, i) => i === idx ? { ...r, ...patch } : r));
    };

    React.useEffect(() => {
        if (!open) return;

        (async () => {
            try {
                const endpoint =
                    `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
                    `?$select=Code`;

                const res = await spfxContext.spHttpClient.get(
                    endpoint,
                    SPHttpClient.configurations.v1
                );

                const data = await res.json();

                setExistingTemplateCodes(
                    (data.value ?? [])
                        .map((x: any) =>
                            String(x.Code ?? "")
                                .trim()
                                .toLowerCase()
                        )
                        .filter(Boolean)
                );
            } catch {
                setExistingTemplateCodes([]);
            }
        })();
    }, [open]);

    const updateAdhocCard = (
        index: number,
        patch: Partial<AdhocDraftRow>
    ) => {
        setAdhocCards(prev =>
            prev.map((row, i) =>
                i === index
                    ? { ...row, ...patch }
                    : row
            )
        );
    };

    function addAdhocTemplate() {
        setAdhocCards(prev => [
            ...prev,
            {
                enabled: true,

                stakeholderName: "Other",
                stakeholderCode: "OTHER",

                otherCode: "",
                usePreviousRound: false,


                applicableScenarios: [],
                scenarioConfigs: {},

                dueDate: null,

                groupUsers: [],
                notifyUsers: [],
                additionalTeam: [],

                inputTemplateVersions: [],

                commonVersionSelections: "",
                collectDraftInput: false,
                commonDraftDueDate: null
            }
        ]);
    }
    React.useEffect(() => {
        rows.forEach((row, idx) => {
            if (
                row.enabled &&
                row.stakeholderName &&
                (!row.inputTemplateVersions ||
                    row.inputTemplateVersions.length === 0)
            ) {
                loadInputTemplateVersions(
                    idx,
                    row.stakeholderName
                );
            }
        });
    }, [rows]);


    const prevRoundVersionMap = React.useMemo(() => {
        const map = new Map<string, string>();

        (backendRound?.inputs ?? []).forEach((inp: any) => {
            if (
                inp.workflowStatus === "Approved" &&
                inp.stakeholderCode &&
                inp.versionNumber
            ) {
                map.set(
                    String(inp.stakeholderCode).toLowerCase(),
                    String(inp.versionNumber)
                );
            }
        });

        return map;
    }, [backendRound]);

    const previousValidatedAdhocs = React.useMemo(() => {
        const result: PreviousAdhocTemplate[] = [];

        const allInputs: any[] = [];

        // allOpportunityRounds can contain:
        // 1. round objects having inputs[]
        // 2. input objects directly
        (allOpportunityRounds ?? []).forEach((item: any) => {
            if (Array.isArray(item?.inputs)) {
                allInputs.push(...item.inputs);
            } else if (
                item &&
                (
                    item.stakeholderType ||
                    item.stakeholder ||
                    item.stakeholderCode
                )
            ) {
                allInputs.push(item);
            }
        });

        // Also include current backend round inputs
        if (Array.isArray(backendRound?.inputs)) {
            allInputs.push(...backendRound.inputs);
        }

        console.log(
            "ALL INPUTS FOR PREVIOUS ADHOC:",
            allInputs
        );

        allInputs.forEach((input: any) => {
            const workflowStatus = String(
                input.workflowStatus ??
                input.workflow_status ??
                ""
            )
                .trim()
                .toLowerCase();

            // Your API returns Approved for completed/approved inputs
            if (workflowStatus !== "approved") {
                return;
            }

            const stakeholderType = String(
                input.stakeholderType ??
                input.stakeholder_type ??
                ""
            )
                .trim()
                .toLowerCase();

            // Only Adhoc templates
            if (stakeholderType !== "adhoc") {
                return;
            }

            const stakeholderName = String(
                input.stakeholder ??
                input.stakeholderName ??
                input.stakeholder_name ??
                input.name ??
                input.otherCode ??
                input.other_code ??
                ""
            ).trim();

            if (!stakeholderName) {
                return;
            }

            const stakeholderCode = String(
                input.stakeholderCode ??
                input.stakeholder_code ??
                stakeholderName
            ).trim();

            const versionNumber = String(
                input.versionNumber ??
                input.version_number ??
                input.versionNo ??
                input.version_no ??
                ""
            ).trim();

            let datasets: any[] = [];

            if (input.applicableScenarios) {
                datasets = input.applicableScenarios;
            } else if (input.applicable_scenarios) {
                datasets = input.applicable_scenarios;
            } else if (input.scenarios) {
                datasets = input.scenarios;
            } else if (input.datasets) {
                datasets = input.datasets;
            } else if (input.scenarioName) {
                // Your API uses scenarioName
                datasets = [input.scenarioName];
            }

            if (!Array.isArray(datasets)) {
                datasets = [datasets];
            }

            datasets = datasets
                .map((d: any) => {
                    if (typeof d === "string") {
                        return d;
                    }

                    return (
                        d?.scenarioKey ??
                        d?.scenarioName ??
                        d?.key ??
                        d?.name ??
                        d?.Dataset ??
                        null
                    );
                })
                .filter(Boolean);

            const description = String(
                input.description ??
                input.templateDescription ??
                input.template_description ??
                ""
            );

            result.push({
                id: Number(input.id),
                stakeholderName,
                stakeholderCode,
                description,
                versionNumber,
                applicableScenarios: datasets as string[],
                inputType:
                    input.inputType ??
                    input.input_type ??
                    "PreviousRound",
                workflowStatus:
                    input.workflowStatus ??
                    input.workflow_status,
                dueDate:
                    input.dueDate ??
                    input.due_date ??
                    null
            });
        });

        // Remove duplicates
        const unique = new Map<string, PreviousAdhocTemplate>();

        result.forEach((item) => {
            const key = [
                item.stakeholderCode,
                item.versionNumber,
                ...(item.applicableScenarios ?? [])
            ]
                .join("|")
                .toLowerCase();

            if (!unique.has(key)) {
                unique.set(key, item);
            }
        });

        const finalResult = Array.from(unique.values());

        console.log(
            "PREVIOUS APPROVED ADHOC TEMPLATES:",
            finalResult
        );

        return finalResult;
    }, [backendRound, allOpportunityRounds]);

    React.useEffect(() => {

        if (!open) return;

        setAdhocCards([]);

        setToast(null);

    }, [open]);

    React.useEffect(() => {
        rows.forEach((row, idx) => {
            const stakeholderKey =
                row.stakeholderCode.toLowerCase();

            const approved =
                prevRoundApprovedScenarioMap.get(stakeholderKey) ??
                new Set<ScenarioKey>();

            const previousVersion =
                prevRoundVersionMap.get(stakeholderKey);

            const currentVersion =
                row.commonVersionSelections || "";

            let changed = false;

            const nextConfigs = {
                ...row.scenarioConfigs
            };

            Object.keys(nextConfigs).forEach(k => {
                const sk = k as ScenarioKey;
                const cfg = nextConfigs[sk];

                // const canUsePrevious =
                //     approved.has(sk) &&
                //     previousVersion === currentVersion;

                const canUsePrevious =
                    roundNumber > 1 &&
                    approved.has(sk) &&
                    previousVersion === currentVersion;

                if (
                    cfg?.inputOption === "usePreviousRoundInput" &&
                    !canUsePrevious
                ) {
                    nextConfigs[sk] = {
                        ...cfg,
                        inputOption: "CollectInput",
                        previousRoundId: null
                    };

                    changed = true;
                }
            });

            if (changed) {
                updateRow(idx, {
                    scenarioConfigs: nextConfigs
                });
            }
        });
    }, [
        rows,
        prevRoundApprovedScenarioMap,
        prevRoundVersionMap
    ]);

    async function loadStandardTemplatesForStakeholder(stakeholderCode: string) {
        const response = await api.getStandardReference(Number(oppId));
        const list = Array.isArray(response) ? response : [];

        const filtered = list.filter(
            (item: any) =>
                String(item.stakeholder).toLowerCase() ===
                String(stakeholderCode).toLowerCase()
        );

        setStandardTemplatesByStakeholder(prev => {
            const next = new Map(prev);
            next.set(
                stakeholderCode,
                filtered.map((i: any) => ({
                    id: Number(i.id),
                    title: String(i.title),
                    versionNumber: String(i.versionNumber || "")
                }))
            );
            return next;
        });
    }


    async function loadGroupUsersForRow(
        idx: number,
        stakeholderCode: string
    ) {
        const meta = remainingStakeholders.find(
            s => s.stakeholderCode === stakeholderCode
        );

        if (!meta?.groupIds?.length) return;

        try {
            const users: IPersonaProps[] = [];

            for (const gid of meta.groupIds) {
                const url =
                    `${spfxContext.pageContext.web.absoluteUrl}` +
                    `/_api/web/sitegroups/GetById(${gid})/users?$select=Id,Title,Email,LoginName`;

                const res = await spfxContext.spHttpClient.get(
                    url,
                    SPHttpClient.configurations.v1
                );

                const json = await res.json();

                (json.value ?? []).forEach((u: any) => {
                    // users.push({
                    //     key: String(u.Id),
                    //     text: u.Title || u.LoginName,
                    //     secondaryText: u.Email || u.LoginName
                    // });
                    users.push({
                        key: String(u.Id),
                        text: u.Title || u.LoginName,
                        secondaryText: u.Email || u.LoginName,
                        tertiaryText: u.LoginName || u.Email
                    });

                });
            }

            const deduped = Array.from(
                new Map(users.map(u => [u.secondaryText, u])).values()
            );

            updateRow(idx, { groupUsers: deduped });
        } catch (e) {
            setToast({
                severity: "error",
                text: "Failed to load Stakeholder Users from group."
            });
        }
    }
    async function loadGroupUsersForOther() {
        try {
            const users: IPersonaProps[] = [];

            // TODO: Replace with actual Other group ids
            const otherGroupIds: number[] = [];

            for (const gid of otherGroupIds) {
                const url =
                    `${spfxContext.pageContext.web.absoluteUrl}` +
                    `/_api/web/sitegroups/GetById(${gid})/users?$select=Id,Title,Email,LoginName`;

                const res = await spfxContext.spHttpClient.get(
                    url,
                    SPHttpClient.configurations.v1
                );

                const json = await res.json();

                (json.value ?? []).forEach((u: any) => {
                    users.push({
                        key: String(u.Id),
                        text: u.Title || u.LoginName,
                        secondaryText: u.Email || u.LoginName,
                        tertiaryText: u.LoginName || u.Email
                    });
                });
            }

            const deduped = Array.from(
                new Map(
                    users.map(u => [u.secondaryText, u])
                ).values()
            );

            setOtherCard(prev => ({
                ...prev,
                groupUsers: deduped
            }));
        }
        catch {
            setToast({
                severity: "error",
                text: "Failed to load Other Stakeholder Users."
            });
        }
    }
    async function loadInputTemplateVersions(
        idx: number,
        stakeholderName: string
    ) {
        try {
            const endpoint =
                `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
                `?$select=Id,Title,VersionNumber,DraftApplicable,Active` +
                `&$filter=Title eq '${stakeholderName}'`;

            const res = await spfxContext.spHttpClient.get(
                endpoint,
                SPHttpClient.configurations.v1
            );

            const data = await res.json();

            // console.log("Stakeholder", stakeholderName);
            // console.log("SP Result", data.value);

            const activeVersions =
                (data.value || []).filter((v: any) => v.Active);

            // console.log("Active Versions", activeVersions);
            // console.log("Count", activeVersions.length);

            updateRow(idx, {
                inputTemplateVersions: activeVersions,

                commonVersionSelections:
                    activeVersions.length === 1
                        ? activeVersions[0].VersionNumber
                        : "",

                collectDraftInput: false,
                commonDraftDueDate: null
            });
        } catch {
            updateRow(idx, {
                inputTemplateVersions: []
            });
        }
    }

    // function isDuplicateAdhocName(
    //     currentIndex: number,
    //     name: string
    // ): boolean {

    //     const normalized =
    //         name.trim().toLowerCase();

    //     if (!normalized) {
    //         return false;
    //     }

    //     return adhocCards.some(
    //         (card, index) =>
    //             index !== currentIndex &&
    //             (card.otherCode ?? "")
    //                 .trim()
    //                 .toLowerCase() === normalized
    //     );
    // }

    function normalizeAdhocCode(name?: string): string {
        return (name ?? "")
            .replace(/[^a-zA-Z0-9]/g, "")
            .toLowerCase();
    }

    function isDuplicateAdhocName(
        currentIndex: number,
        name: string
    ): boolean {
        const normalizedCode = normalizeAdhocCode(name);

        if (!normalizedCode) {
            return false;
        }

        return adhocCards.some(
            (card, index) =>
                index !== currentIndex &&
                normalizeAdhocCode(card.otherCode) === normalizedCode
        );
    }

    async function loadInputTemplateVersionsForOther() {
        try {

            const endpoint =
                `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
                `?$select=Id,Title,VersionNumber,DraftApplicable,Active` +
                `&$filter=Title eq 'Other'`;

            const res = await spfxContext.spHttpClient.get(
                endpoint,
                SPHttpClient.configurations.v1
            );

            const data = await res.json();

            setOtherCard(prev => ({
                ...prev,
                inputTemplateVersions: data.value || []
            }));

        } catch {

            setOtherCard(prev => ({
                ...prev,
                inputTemplateVersions: []
            }));
        }
    }
    async function loadActiveVersions() {
        try {
            const response = await api.getVersionNumbers();

            const active = (Array.isArray(response) ? response : [])
                .filter((v: any) => v.active === true)
                .map((v: any) => String(v.versionNumber));

            setActiveVersions(active.length ? active : ["1"]);
        } catch (e) {
            console.error("Failed loading versions", e);
        }
    }
    function getLatestRevisionNumber(
        stakeholderCode: string,
        dataset: string,
        submissionType: string,
        versionNumber: string,
        inputType: string
    ): number {
        const matchingInputs = (allOpportunityRounds ?? [])
            .flatMap((round: any) => round?.inputs ?? [])
            .filter((input: any) => {

                const actualInputType =
                    String(input.inputType ?? "").trim().toLowerCase();

                const expectedInputType =
                    String(inputType ?? "").trim().toLowerCase();

                const inputTypeMatches =
                    expectedInputType === "standard"
                        ? actualInputType === "standard" ||
                        actualInputType === "usestandardinput"
                        : expectedInputType === "previousround"
                            ? actualInputType === "previousround" ||
                            actualInputType === "usepreviousroundinput"
                            : actualInputType === expectedInputType;

                return (
                    String(input.stakeholderCode ?? "").trim().toLowerCase() ===
                    String(stakeholderCode ?? "").trim().toLowerCase() &&

                    String(input.scenarioName ?? "").trim().toUpperCase() ===
                    String(dataset ?? "").trim().toUpperCase() &&

                    String(input.submissionType ?? "").trim().toLowerCase() ===
                    String(submissionType ?? "").trim().toLowerCase() &&

                    String(input.versionNumber ?? "").trim().toLowerCase() ===
                    String(versionNumber ?? "").trim().toLowerCase() &&

                    inputTypeMatches
                );
            });

        return matchingInputs.reduce(
            (max: number, input: any) =>
                Math.max(max, Number(input.revisionNumber) || 0),
            0
        );
    }
    function buildStakeholderFlowBlock(
        row: {
            stakeholderName: string;
            stakeholderCode: string;
            dueDate?: string;
            applicableScenarios: ScenarioKey[];
            scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>>;
            notifyPersonas?: IPersonaProps[];
            additionalTeamPersonas?: IPersonaProps[];
            inputTemplateGroupIds?: number[];
            roundIdFolder: string;

            inputTemplateVersions?: {
                VersionNumber: string;
                DraftApplicable: boolean;
                Active: boolean;
            }[];

            commonVersionSelections?: string;
            collectDraftInput?: boolean;
            commonDraftDueDate?: Date | null;
        },
        scenarios: { key: ScenarioKey; description?: string }[]
    ) {
        const collectDatasets: {
            scenarioKey: ScenarioKey;
            scenarioDescription: string;
        }[] = [];

        const isAdhoc = (row.inputTemplateGroupIds ?? []).length === 0;

        const otherScenarioBlocks: any[] = [];

        const selectedStandard =
            cfg?.inputOption === "useStandardInput"
                ? standardTemplatesByStakeholder
                    .get(row.stakeholderCode)
                    ?.find(t => t.id === cfg.standardReferenceId)
                : null;

        const selectedVersion =
            row.inputTemplateVersions?.find(
                v => v.VersionNumber === row.commonVersionSelections
            );

        const draftApplicable =
            selectedVersion?.DraftApplicable ?? false;

        for (const scenarioKey of row.applicableScenarios) {
            const cfg = row.scenarioConfigs?.[scenarioKey];
            const scenario = scenarios.find(s => s.key === scenarioKey);

            const selectedStandard =
                cfg?.inputOption === "useStandardInput"
                    ? standardTemplatesByStakeholder
                        .get(row.stakeholderCode)
                        ?.find(t => t.id === cfg.standardReferenceId)
                    : null;

            if (cfg?.inputOption === "CollectInput") {
                collectDatasets.push({
                    scenarioKey,
                    scenarioDescription: scenario?.description ?? ""
                });
                continue;
            }

            const submissionType =
                draftApplicable && row.collectDraftInput
                    ? "Draft"
                    : "Final";

            const versionNumber =
                row.commonVersionSelections || "";

            const inputType =
                cfg?.inputOption === "useStandardInput"
                    ? "Standard"
                    : cfg?.inputOption === "usePreviousRoundInput"
                        ? "PreviousRound"
                        : "CollectInput";

            const revisionNumber = getLatestRevisionNumber(
                row.stakeholderCode,
                scenarioKey,
                submissionType,
                versionNumber,
                inputType
            );

            const scenarioBlock: any = {
                scenarioKey,
                scenarioDescription: scenario?.description ?? "",
                inputOption: cfg?.inputOption ?? "",

                standardReferenceId:
                    cfg?.inputOption === "useStandardInput"
                        ? cfg.standardReferenceId ?? null
                        : null,

                ...(selectedStandard
                    ? { standardInputTemplateTitle: selectedStandard.title }
                    : {}),

                previousRoundId:
                    cfg?.inputOption === "usePreviousRoundInput"
                        ? cfg.previousRoundId ?? null
                        : null,
                // submissionType:
                //     versionNo:
                versionNo: row.commonVersionSelections || "",

                submissionType:
                    draftApplicable && row.collectDraftInput
                        ? "Draft"
                        : "Final",
                revisionNumber,
                inputType
            };


            if (!isAdhoc) {
                scenarioBlock.draftDueDate =
                    cfg?.draftDueDate
                        ? cfg.draftDueDate.toISOString()
                        : null;
            }


            otherScenarioBlocks.push(scenarioBlock);
        }

        const stakeholderAdditionalTeamMembers =
            (row.additionalTeamPersonas ?? []).map(p => ({
                id: String(p.secondaryText || ""),
                displayName: String(p.text || ""),
                email: String(p.secondaryText || "")
            }));

        const stakeholderNotifyUsers =
            (row.notifyPersonas ?? []).map(p => ({
                displayName: String(p.text || ""),
                email: String(p.secondaryText || "")
            }));

        const NotifyUsersEmailString = Array.from(
            new Set([
                ...(row.notifyPersonas ?? []).map(p => p.secondaryText),
                ...(row.additionalTeamPersonas ?? []).map(p => p.secondaryText)
            ].filter(Boolean))
        ).join(";");

        const finalScenarios = [...otherScenarioBlocks];
        if (collectDatasets.length > 0) {

            const collectScenarioBlock: any = {
                Dataset: collectDatasets,
                inputOption: "CollectInput",

                notifyUsers: stakeholderNotifyUsers,
                additionalTeamMembers: stakeholderAdditionalTeamMembers,
                versionNo: row.commonVersionSelections || "",

                submissionType:
                    draftApplicable && row.collectDraftInput
                        ? "Draft"
                        : "Final"
            };


            // Only for Input Templates
            if (!isAdhoc) {


                collectScenarioBlock.collectDraftInput =
                    draftApplicable
                        ? row.collectDraftInput
                        : false;

                collectScenarioBlock.draftDueDate =
                    draftApplicable &&
                        row.collectDraftInput &&
                        row.commonDraftDueDate
                        ? row.commonDraftDueDate.toLocaleDateString()
                        : null;
            }


            finalScenarios.push(collectScenarioBlock);
        }
        return {
            stakeholderName: row.stakeholderName,
            stakeholderCode: row.stakeholderCode,
            dueDate: row.dueDate ? new Date(row.dueDate).toLocaleDateString() : "",
            InputTemplateGroupIds: row.inputTemplateGroupIds ?? [],
            scenarios: finalScenarios,
            editFolderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}/${row.roundIdFolder}/${row.stakeholderCode}`,
            additionalTeamMembers: stakeholderAdditionalTeamMembers,
            NotifyUsersEmailString
        };
    }
    function hasApprovedPreviousInput(
        stakeholderCode: string,
        scenarioKey: ScenarioKey
    ): boolean {
        const code = String(stakeholderCode ?? "").trim().toLowerCase();
        const dataset = String(scenarioKey ?? "").trim().toLowerCase();

        if (!code || !dataset || roundNumber <= 1) {
            return false;
        }

        const allInputs: any[] = [];

        // backendRound inputs
        if (Array.isArray(backendRound?.inputs)) {
            allInputs.push(...backendRound.inputs);
        }

        // Historical rounds / inputs
        (allOpportunityRounds ?? []).forEach((item: any) => {
            if (Array.isArray(item?.inputs)) {
                allInputs.push(...item.inputs);
            } else if (
                item &&
                (
                    item.stakeholderType ||
                    item.stakeholder ||
                    item.stakeholderCode
                )
            ) {
                allInputs.push(item);
            }
        });

        return allInputs.some((input: any) => {
            const inputCode = String(
                input.stakeholderCode ??
                input.stakeholder_code ??
                input.stakeholder ??
                ""
            )
                .trim()
                .toLowerCase();

            if (inputCode !== code) {
                return false;
            }

            const stakeholderType = String(
                input.stakeholderType ??
                input.stakeholder_type ??
                ""
            )
                .trim()
                .toLowerCase();

            if (stakeholderType !== "adhoc") {
                return false;
            }

            const status = String(
                input.workflowStatus ??
                input.workflow_status ??
                input.status ??
                ""
            )
                .trim()
                .toLowerCase();

            // Backend currently uses Approved.
            // Keep Validated as well for compatibility.
            if (status !== "approved" && status !== "validated") {
                return false;
            }

            let inputDataset =
                input.scenarioName ??
                input.scenario_name ??
                null;

            if (!inputDataset) {
                const datasets =
                    input.applicableScenarios ??
                    input.applicable_scenarios ??
                    input.scenarios ??
                    input.datasets ??
                    [];

                if (Array.isArray(datasets)) {
                    return datasets.some((d: any) => {
                        const value = String(
                            typeof d === "string"
                                ? d
                                : d?.scenarioKey ??
                                d?.scenarioName ??
                                d?.key ??
                                d?.name ??
                                ""
                        )
                            .trim()
                            .toLowerCase();

                        return value === dataset;
                    });
                }
            }

            return (
                String(inputDataset ?? "")
                    .trim()
                    .toLowerCase() === dataset
            );
        });
    }
    function getExistingAdhocDatasets(
        stakeholderCode: string
    ): Set<string> {
        const code = String(stakeholderCode ?? "")
            .trim()
            .toLowerCase();

        const existingDatasets = new Set<string>();

        if (!code) {
            return existingDatasets;
        }

        const allInputs: any[] = [];

        // Current round
        if (Array.isArray(backendRound?.inputs)) {
            allInputs.push(...backendRound.inputs);
        }

        // All opportunity rounds
        (allOpportunityRounds ?? []).forEach((item: any) => {
            if (Array.isArray(item?.inputs)) {
                allInputs.push(...item.inputs);
            } else if (
                item &&
                (
                    item.stakeholderType ||
                    item.stakeholder ||
                    item.stakeholderCode
                )
            ) {
                allInputs.push(item);
            }
        });

        allInputs.forEach((input: any) => {
            const stakeholderType = String(
                input.stakeholderType ??
                input.stakeholder_type ??
                ""
            )
                .trim()
                .toLowerCase();

            // Only Adhoc records
            if (stakeholderType !== "adhoc") {
                return;
            }

            const inputCode = String(
                input.stakeholderCode ??
                input.stakeholder_code ??
                input.stakeholder ??
                ""
            )
                .trim()
                .toLowerCase();

            if (inputCode !== code) {
                return;
            }

            // API normally gives scenarioName for each input
            const scenarioName = String(
                input.scenarioName ??
                input.scenario_name ??
                ""
            )
                .trim()
                .toLowerCase();

            if (scenarioName) {
                existingDatasets.add(scenarioName);
                return;
            }

            // Fallback if API gives applicableScenarios/scenarios
            const datasets =
                input.applicableScenarios ??
                input.applicable_scenarios ??
                input.scenarios ??
                input.datasets ??
                [];

            if (Array.isArray(datasets)) {
                datasets.forEach((d: any) => {
                    const dataset = String(
                        typeof d === "string"
                            ? d
                            : d?.scenarioKey ??
                            d?.scenarioName ??
                            d?.key ??
                            d?.name ??
                            d?.Dataset ??
                            ""
                    )
                        .trim()
                        .toLowerCase();

                    if (dataset) {
                        existingDatasets.add(dataset);
                    }
                });
            }
        });

        return existingDatasets;
    }

    function getAvailableAdhocDatasets(
        stakeholderCode: string
    ) {
        const existingDatasets =
            getExistingAdhocDatasets(stakeholderCode);

        return scenarios.filter(s => {
            const dataset = String(s.key)
                .trim()
                .toLowerCase();

            return !existingDatasets.has(dataset);
        });
    }
    function getAvailablePreviousAdhocs(currentIndex: number) {
        // Stakeholders already selected in other Adhoc cards
        const usedStakeholderCodes = new Set(
            adhocCards
                .filter((_, index) => index !== currentIndex)
                .map(card =>
                    String(card.otherCode ?? "")
                        .trim()
                        .toLowerCase()
                )
                .filter(Boolean)
        );

        return previousValidatedAdhocs.filter(template => {
            const stakeholderCode = String(
                template.stakeholderCode ?? template.stakeholderName ?? ""
            )
                .trim()
                .toLowerCase();

            return !usedStakeholderCodes.has(stakeholderCode);
        });
    }

    function getAdhocInputOptions(
        stakeholderCode: string,
        scenarioKey: ScenarioKey
    ) {
        const options: { key: InputOption; text: string }[] = [
            {
                key: "CollectInput",
                text: "Collect Input"
            }
        ];

        if (
            roundNumber > 1 &&
            hasApprovedPreviousInput(
                stakeholderCode,
                scenarioKey
            )
        ) {
            options.push({
                key: "usePreviousRoundInput",
                text: "Use Previous Round Input"
            });
        }

        return options;
    }

    function getInputOptions(
        stakeholderCode: string,
        scenarioKey: ScenarioKey,
        showStandard: boolean,
        selectedVersion: string
    ) {
        const opts: { key: InputOption; text: string }[] = [
            { key: "CollectInput", text: "Collect Input" }
        ];


        if (showStandard) {
            opts.push({ key: "useStandardInput", text: "Use Standard Input" });
        }


        const key = stakeholderCode.toLowerCase();

        const scenarioExistsInPrev =
            prevRoundScenarioMap.get(key)?.has(scenarioKey) === true;

        const scenarioApprovedInPrev =
            prevRoundApprovedScenarioMap.get(key)?.has(scenarioKey) === true;

        const previousVersion =
            prevRoundVersionMap.get(key);


        const currentVersion = selectedVersion;

        const versionMatches =
            previousVersion === currentVersion;

        if (
            roundNumber > 1 &&
            scenarioExistsInPrev &&
            scenarioApprovedInPrev &&
            versionMatches
        ) {
            opts.push({
                key: "usePreviousRoundInput",
                text: "Use Previous Round Input"
            });
        }

        return opts;
    }

    async function saveAllInputTemplates() {
        if (!validateBeforeSave()) return;

        try {
            setSaving(true);
            // const cleanedRows = rows
            //     .filter(r => r.enabled)
            //     .map(({ groupUsers, ...rest }) => rest);


            const cleanedRows = [
                ...rows
                    .filter(r => r.enabled)
                    .map(({ groupUsers, ...rest }) => rest),

                ...adhocCards.map(card => ({
                    ...card,

                    stakeholderName: card.otherCode,

                    stakeholderCode:
                        (card.otherCode ?? "")
                            .replace(/[^a-zA-Z0-9]/g, ""),

                    additionalTeam: card.additionalTeam,

                    notifyUsers: [],

                    groupUsers: []
                }))
            ];
            await onSaveSuccess(cleanedRows as DraftRow[]);
            const roundIdFolder = `RND ${("" + roundNumber).slice(-2)}`;
            const stakeholdersForFlow = cleanedRows.map(row => {
                const meta = remainingStakeholders.find(
                    s => s.stakeholderCode === row.stakeholderCode
                );
                return buildStakeholderFlowBlock(
                    {
                        stakeholderName: row.stakeholderName!,
                        stakeholderCode: row.stakeholderCode!,
                        dueDate: row.dueDate?.toISOString(),
                        applicableScenarios: row.applicableScenarios,
                        scenarioConfigs: row.scenarioConfigs,
                        notifyPersonas: row.notifyUsers,
                        additionalTeamPersonas: row.additionalTeam,
                        inputTemplateGroupIds: meta?.groupIds ?? [],
                        roundIdFolder,
                        inputTemplateVersions: row.inputTemplateVersions,
                        commonVersionSelections: row.commonVersionSelections,
                        collectDraftInput: row.collectDraftInput,
                        commonDraftDueDate: row.commonDraftDueDate,
                    },
                    scenarios
                );
            });
            const flowPayload = {
                region: "EUR",
                siteUrl: cfg.siteUrl,
                opportunityName,
                opportunityCountryName: opportunityCountryName,
                roundNumber,
                roundIdFolder,
                customer: `${customer}`,
                fullOpportunityName: `/EUR/${customer}/${opportunityName}`,
                stakeholders: stakeholdersForFlow,
                folderPath: `${cfg.serverRelativeLibrary}${customer}/${opportunityName}`,
                leadPricerEmailString: leadPricerEmail,
                bidTeamMembers: bidTeamEmail
            };
            onFlowReady(flowPayload);
            handleClose();
        } catch (e) {
            console.error(e);
            setToast({
                severity: "error",
                text: "Failed to save input templates."
            });
        } finally {
            setSaving(false);
        }


    }

    function isStakeholderCodeExistsInCurrentRound(
        code: string
    ): boolean {

        const normalized =
            code.trim().toLowerCase();

        return (
            currentRoundDetail?.stakeholders ?? []
        ).some(
            (s: any) =>
                String(s.stakeholder_code ?? "")
                    .trim()
                    .toLowerCase() === normalized
        );
    }

    // function isExistingTemplateCode(
    //     code: string
    // ): boolean {

    //     const normalized =
    //         code.trim().toLowerCase();

    //     return existingTemplateCodes.includes(
    //         normalized
    //     );
    // }

    function isExistingTemplateCode(
        code: string
    ): boolean {

        const normalizedCode = normalizeAdhocCode(code);

        if (!normalizedCode) {
            return false;
        }

        return existingTemplateCodes.some(
            existingCode =>
                normalizeAdhocCode(existingCode) === normalizedCode
        );
    }

    function handleClose() {

        setRows([]);

        setAdhocCards([]);

        setToast(null);

        setSaving(false);

        setOtherCard({
            enabled: false,
            otherCode: "",
            applicableScenarios: [],
            scenarioConfigs: {},
            dueDate: null,
            groupUsers: [],
            notifyUsers: [],
            additionalTeam: [],
            inputTemplateVersions: []
        });

        onClose();
    }

    function validateBeforeSave(): boolean {
        const enabledRows = rows.filter(r => r.enabled);
        //const hasOtherEnabled = otherCard.enabled;
        const hasAdhocTemplates = adhocCards.length > 0;

        if (!enabledRows.length && !hasAdhocTemplates) {
            setToast({
                severity: "warning",
                text: "Please enable at least one Input Template."
            });
            return false;
        }

        for (const row of enabledRows) {
            if (!row.applicableScenarios.length) {
                setToast({
                    severity: "error",
                    text: `Stakeholder "${row.stakeholderName}" must select at least one Applicable Dataset.`
                });
                return false;
            }

            const hasCollectScenario = row.applicableScenarios.some(sk =>
                row.scenarioConfigs[sk]?.inputOption === "CollectInput"
            );

            const hasStandardScenario = row.applicableScenarios.some(sk =>
                row.scenarioConfigs[sk]?.inputOption === "useStandardInput"
            );



            if ((hasCollectScenario || hasStandardScenario) && !row.dueDate) {
                setToast({
                    severity: "error",
                    text: `Stakeholder "${row.stakeholderName}" is missing Due Date.`
                });
                return false;
            }

            for (const sk of row.applicableScenarios) {
                const scenarioCfg = row.scenarioConfigs[sk];

                if (!scenarioCfg?.inputOption) {
                    setToast({
                        severity: "error",
                        text: `Stakeholder "${row.stakeholderName}" â€¢ Dataset ${sk}: Please select an Input Type.`
                    });
                    return false;
                }
                const hasActiveVersion =
                    (row.inputTemplateVersions || []).some(
                        v => v.Active === true
                    );
                const selectedVersion =
                    row.inputTemplateVersions?.find(
                        v => v.VersionNumber === row.commonVersionSelections
                    );

                if (
                    selectedVersion?.DraftApplicable &&
                    row.collectDraftInput &&
                    !row.commonDraftDueDate
                ) {
                    setToast({
                        severity: "error",
                        text: `Stakeholder "${row.stakeholderName}": Please select Draft Due Date.`
                    });

                    return false;
                }
                if (
                    selectedVersion?.DraftApplicable &&
                    row.collectDraftInput &&
                    row.commonDraftDueDate &&
                    row.dueDate &&
                    row.commonDraftDueDate.getTime() >= row.dueDate.getTime()
                ) {
                    setToast({
                        severity: "error",
                        text: `Stakeholder "${row.stakeholderName}": Draft Due Date must be earlier than Due Date.`
                    });

                    return false;
                }
                if (scenarioCfg.inputOption === "useStandardInput") {
                    if (!scenarioCfg.standardReferenceId) {
                        setToast({
                            severity: "error",
                            text: `Stakeholder "${row.stakeholderName}" â€¢ Dataset ${sk}: Please select a Standard Template.`
                        });
                        return false;
                    }
                }

                if (scenarioCfg.inputOption === "usePreviousRoundInput") {
                    if (!scenarioCfg.previousRoundId) {
                        setToast({
                            severity: "error",
                            text: `Stakeholder "${row.stakeholderName}" â€¢ Dataset ${sk}: Previous Round reference is missing.`
                        });
                        return false;
                    }
                }
            }

            if (hasCollectScenario) {
                const hasNotify = row.notifyUsers.length > 0;
                const hasAdditional = row.additionalTeam.length > 0;

                if (!hasNotify && !hasAdditional) {
                    setToast({
                        severity: "error",
                        text: `Stakeholder "${row.stakeholderName}": Please select either:
- At least one Stakeholder User OR
- At least one Extra Input Provider`
                    });
                    return false;
                }
            }
        }
        //console.log("enabledRows", enabledRows.length);
        //console.log("otherEnabled", otherCard.enabled);

        for (const card of adhocCards) {

            if (!card.otherCode?.trim()) {
                setToast({
                    severity: "error",
                    text: "Please enter Name for Adhoc Template."
                });
                return false;
            }

            if (!card.applicableScenarios.length) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode || "New"}" must select at least one Applicable Dataset.`
                });
                return false;
            }

            if (!card.dueDate) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode || "New"}" is missing Due Date.`
                });
                return false;
            }

            if (!card.additionalTeam || card.additionalTeam.length === 0) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode || "New"}": Please select at least one Team Member.`
                });
                return false;
            }
        }

        for (let index = 0; index < adhocCards.length; index++) {

            const card = adhocCards[index];

            if (
                isDuplicateAdhocName(
                    index,
                    card.otherCode ?? ""
                )
            ) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode}" already exists. Please enter a unique name.`
                });

                return false;
            }

            const stakeholderCode =
                (card.otherCode ?? "")
                    .replace(/[^a-zA-Z0-9]/g, "");

            // if (
            //     isExistingTemplateCode(stakeholderCode)
            // ) {
            if (isExistingTemplateCode(card.otherCode ?? "")) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode}" already exists as an Input Template Code.`
                });

                return false;
            }

            if (
                isStakeholderCodeExistsInCurrentRound(
                    stakeholderCode
                )
            ) {
                setToast({
                    severity: "error",
                    text: `Adhoc Template "${card.otherCode}" already exists in the current round.`
                });

                return false;
            }

        }

        setToast(null);
        return true;
    }




    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Drawer anchor="right" open={open} onClose={handleClose}
                PaperProps={{
                    sx: {
                        width: { xs: '100%', sm: 520 },
                        p: 2,
                        pt: 9,
                    },
                }}>

                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
                    <Typography variant="h5" fontWeight={700}>Add Input Templates</Typography>
                    <IconButton onClick={onClose}><CloseIcon /></IconButton>
                </Box>

                <Divider sx={{ mb: 2 }} />


                {allTemplatesAdded && (
                    <ModernAlert
                        severity="info"
                        elevated
                        gradient
                        sx={{ mb: 2 }}
                    >
                        You have already added all available input templates.
                    </ModernAlert>
                )}


                {toast && (
                    <Box sx={{ mb: 3 }}>
                        <ModernAlert
                            severity={toast.severity}
                            onClose={() => setToast(null)}
                            elevated
                            gradient
                        >
                            {toast.text}
                        </ModernAlert>
                    </Box>
                )}
                {!allTemplatesAdded && (
                    <Stack spacing={2}>
                        {rows.map((row, idx) => {
                            const meta = remainingStakeholders.find(
                                s => s.stakeholderCode === row.stakeholderCode
                            );

                            const hasCollectScenario = row.applicableScenarios.some(sk =>
                                row.scenarioConfigs[sk]?.inputOption === "CollectInput"
                            );

                            const hasStandardScenario = row.applicableScenarios.some(sk =>
                                row.scenarioConfigs[sk]?.inputOption === "useStandardInput"
                            );

                            const versionsToShow = row.inputTemplateVersions ?? [];

                            const selectedVersion =
                                versionsToShow.length === 1
                                    ? versionsToShow[0]
                                    : versionsToShow.find(
                                        v => v.VersionNumber === row.commonVersionSelections
                                    );
                            const draftApplicable =
                                selectedVersion?.DraftApplicable ?? false;

                            return (
                                <ModernCard key={row.stakeholderCode}>
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                checked={row.enabled}
                                                onChange={async e => {
                                                    const enabled = e.target.checked;
                                                    await loadInputTemplateVersions(
                                                        idx,
                                                        row.stakeholderName
                                                    );

                                                    if (!enabled) {
                                                        updateRow(idx, {
                                                            enabled: false,
                                                            applicableScenarios: [],
                                                            scenarioConfigs: {},
                                                            groupUsers: [],
                                                            notifyUsers: [],
                                                            additionalTeam: [],
                                                            commonVersionSelections: "",
                                                            collectDraftInput: false,
                                                            commonDraftDueDate: null
                                                        });
                                                        return;
                                                    }

                                                    const autoScenarios =
                                                        scenarios.length === 1 ? [scenarios[0].key] : [];

                                                    const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

                                                    // autoScenarios.forEach(sk => {
                                                    //     scenarioConfigs[sk] = {
                                                    //         inputOption: "CollectInput"
                                                    //     };
                                                    // });

                                                    autoScenarios.forEach(sk => {
                                                        const key = row.stakeholderCode.toLowerCase();

                                                        // const canUsePrevious =
                                                        //     prevRoundApprovedScenarioMap.get(key)?.has(sk) === true &&
                                                        //     roundNumber > 1;

                                                        // const previousVersion =
                                                        //     prevRoundVersionMap.get(key);

                                                        // const currentVersion =
                                                        //     row.commonVersionSelections;

                                                        // const canUsePrevious =
                                                        //     roundNumber > 1 &&
                                                        //     prevRoundApprovedScenarioMap.get(key)?.has(sk) === true &&
                                                        //     previousVersion === currentVersion;

                                                        // scenarioConfigs[sk] = canUsePrevious
                                                        //     ? {
                                                        //         inputOption: "usePreviousRoundInput",
                                                        //         previousRoundId: prevRoundId ?? null
                                                        //     }
                                                        //     : {
                                                        //         inputOption: "CollectInput",
                                                        //         previousRoundId: null
                                                        //     };
                                                        // scenarioConfigs[sk] = canUsePrevious
                                                        //     ? {
                                                        //         inputOption: "usePreviousRoundInput",
                                                        //         previousRoundId: prevRoundId ?? null,

                                                        //         // versionSelections: [...activeVersions],
                                                        //         // submissionTypes: ["Draft", "Final"],
                                                        //         // collectDraftInput: false,
                                                        //         // draftDueDate: null
                                                        //     }
                                                        //     : {
                                                        //         inputOption: "CollectInput",
                                                        //         previousRoundId: null,

                                                        //         // versionSelections: [...activeVersions],
                                                        //         // submissionTypes: ["Draft", "Final"],
                                                        //         // collectDraftInput: false,
                                                        //         // draftDueDate: null
                                                        //     };
                                                        scenarioConfigs[sk] = {
                                                            inputOption: "CollectInput",
                                                            previousRoundId: null
                                                        };
                                                    });

                                                    updateRow(idx, {
                                                        enabled: true,
                                                        applicableScenarios: autoScenarios,
                                                        scenarioConfigs

                                                        // commonVersionSelections:
                                                        //     row.inputTemplateVersions?.length === 1
                                                        //         ? row.inputTemplateVersions[0].VersionNumber
                                                        //         : "",

                                                        // collectDraftInput: false,
                                                        // commonDraftDueDate: null
                                                    });

                                                    await loadGroupUsersForRow(idx, row.stakeholderCode);
                                                }}
                                            />
                                        }
                                        label={<Typography fontWeight={600}>{row.stakeholderName}</Typography>}
                                    />

                                    {row.enabled && (
                                        <Box sx={{ pl: 4, mt: 2 }}>

                                            {/* Version */}
                                            {versionsToShow.length === 1 ? (

                                                <Box
                                                    sx={{
                                                        display: "flex",
                                                        alignItems: "center",
                                                        minHeight: 56,
                                                        mt: 1,
                                                        pl: 0,
                                                        pr: 0
                                                    }}
                                                >
                                                    <Typography
                                                        variant="body1"
                                                        fontWeight={600}
                                                        sx={{ minWidth: 80 }}
                                                    >
                                                        Version:
                                                    </Typography>

                                                    <Typography variant="body1">
                                                        {versionsToShow[0].VersionNumber}
                                                    </Typography>
                                                </Box>

                                            ) : (

                                                <FormControl fullWidth required sx={{ mt: 1 }}>

                                                    <InputLabel>Version</InputLabel>

                                                    <Select
                                                        label="Version"
                                                        value={row.commonVersionSelections ?? ""}
                                                        onChange={(e) =>
                                                            updateRow(idx, {
                                                                commonVersionSelections: e.target.value,
                                                                collectDraftInput: false,
                                                                commonDraftDueDate: null
                                                            })
                                                        }
                                                    >
                                                        {versionsToShow.map(v => (
                                                            <MenuItem
                                                                key={v.VersionNumber}
                                                                value={v.VersionNumber}
                                                            >
                                                                {v.VersionNumber}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>

                                                </FormControl>

                                            )}

                                            {/* Collect Draft Input */}

                                            {selectedVersion?.DraftApplicable && (
                                                <FormControlLabel
                                                    sx={{
                                                        p: 0.5,
                                                        mr: 1
                                                    }}
                                                    control={
                                                        <Checkbox
                                                            checked={row.collectDraftInput ?? false}
                                                            onChange={(e) =>
                                                                updateRow(idx, {
                                                                    collectDraftInput: e.target.checked,
                                                                    commonDraftDueDate: null
                                                                })
                                                            }
                                                        />
                                                    }
                                                    label="Collect Draft Input"
                                                />
                                            )}

                                            {/* Draft Due Date */}

                                            {selectedVersion?.DraftApplicable &&
                                                row.collectDraftInput && (
                                                    <DatePicker
                                                        label="Draft Due Date"
                                                        value={row.commonDraftDueDate}
                                                        minDate={today}
                                                        maxDate={
                                                            row.dueDate
                                                                ? new Date(row.dueDate.getTime() - 24 * 60 * 60 * 1000)
                                                                : undefined
                                                        }
                                                        onChange={(d) =>
                                                            updateRow(idx, {
                                                                commonDraftDueDate: d
                                                            })
                                                        }
                                                        onError={(reason) => {
                                                            if (reason === "minDate") {
                                                                setToast({
                                                                    severity: "error",
                                                                    text: "Draft Due Date cannot be a past date."
                                                                });
                                                            }

                                                            if (reason === "maxDate") {
                                                                setToast({
                                                                    severity: "error",
                                                                    text: "Draft Due Date must be earlier than Due Date."
                                                                });
                                                            }
                                                        }}
                                                        slotProps={{
                                                            textField: {
                                                                fullWidth: true,
                                                                required: true,
                                                                sx: { mt: 1.5 }
                                                            }
                                                        }}
                                                    />
                                                )}

                                            <FormControl fullWidth required sx={{ mt: 1 }}>
                                                <InputLabel id={`dataset-label-${idx}`}>
                                                    Applicable Datasets
                                                </InputLabel>

                                                <Select
                                                    labelId={`dataset-label-${idx}`}
                                                    label="Applicable Datasets"
                                                    multiple
                                                    displayEmpty
                                                    value={row.applicableScenarios}
                                                    onChange={e => {
                                                        const selected = e.target.value as ScenarioKey[];
                                                        const cfgs = { ...row.scenarioConfigs };

                                                        selected.forEach(sk => {
                                                            if (!cfgs[sk]) //cfgs[sk] = { inputOption: "CollectInput" };
                                                                cfgs[sk] = {
                                                                    inputOption: "CollectInput",
                                                                    //versionSelections: [...activeVersions],
                                                                    // submissionTypes: ["Draft", "Final"],
                                                                    // collectDraftInput: false,
                                                                    // draftDueDate: null
                                                                };
                                                        });

                                                        Object.keys(cfgs).forEach(k => {
                                                            if (!selected.includes(k as ScenarioKey)) delete cfgs[k as ScenarioKey];
                                                        });

                                                        updateRow(idx, {
                                                            applicableScenarios: selected,
                                                            scenarioConfigs: cfgs
                                                        });
                                                    }}
                                                    renderValue={sel => (
                                                        <Box sx={{ display: "flex", gap: .5, flexWrap: "wrap" }}>
                                                            {(sel as ScenarioKey[]).map(k => <Chip key={k} label={k} size="small" />)}
                                                        </Box>
                                                    )}
                                                >
                                                    {scenarios.map(s => {
                                                        const fullText = `${s.key}${s.description ? ` - ${s.description}` : ""}`;

                                                        const shortText =
                                                            fullText.length > 40
                                                                ? fullText.substring(0, 40) + "..."
                                                                : fullText;

                                                        return (
                                                            <MenuItem key={s.key} value={s.key}>
                                                                {shortText}
                                                            </MenuItem>
                                                        );
                                                    })}
                                                </Select>
                                            </FormControl>

                                            {row.applicableScenarios.map(sk => {
                                                // const options = getInputOptions(
                                                //     row.stakeholderCode,
                                                //     sk,
                                                //     meta?.showStandard ?? false
                                                // );
                                                const options = getInputOptions(
                                                    row.stakeholderCode,
                                                    sk,
                                                    meta?.showStandard ?? false,
                                                    row.commonVersionSelections || ""
                                                );

                                                const cfg = row.scenarioConfigs[sk];
                                                // const hasActiveVersion =
                                                //     (row.inputTemplateVersions || []).some(
                                                //         v => v.Active === true
                                                //     );

                                                // const selectedStatuses =
                                                //     cfg?.submissionTypes ?? ["Draft", "Final"];

                                                // const filteredVersions =
                                                //     (row.inputTemplateVersions || []).filter(
                                                //         v =>
                                                //             v.Active === true &&
                                                //             selectedStatuses.includes(v.Status)
                                                //     );
                                                // const allowedOptions = getInputOptions(
                                                //     row.stakeholderCode,
                                                //     sk,
                                                //     meta?.showStandard ?? false

                                                // );
                                                const allowedOptions = getInputOptions(
                                                    row.stakeholderCode,
                                                    sk,
                                                    meta?.showStandard ?? false,
                                                    row.commonVersionSelections || ""
                                                );

                                                const selectedInputType = allowedOptions.some(
                                                    o => o.key === cfg?.inputOption
                                                )
                                                    ? cfg?.inputOption
                                                    : "CollectInput";

                                                return (
                                                    <Box key={sk} sx={{ mt: 2 }}>
                                                        <FormControl fullWidth>
                                                            <InputLabel>{`Input Type - Dataset ${sk}`}</InputLabel>
                                                            <Select
                                                                label={`Input Type - Dataset ${sk}`}
                                                                value={selectedInputType}
                                                                // value={cfg?.inputOption ?? "CollectInput"}
                                                                // onChange={async e => {
                                                                //     const val = e.target.value as InputOption;

                                                                //     const prevCfg = row.scenarioConfigs[sk] || {};

                                                                //     const next: ScenarioConfig = {
                                                                //         ...prevCfg,
                                                                //         inputOption: val
                                                                //     };
                                                                //     if (val === "usePreviousRoundInput") {
                                                                //         next.previousRoundId = prevRoundId ?? null;
                                                                //     }

                                                                //     if (val === "useStandardInput") {
                                                                //         await loadStandardTemplatesForStakeholder(row.stakeholderCode);
                                                                //         next.standardReferenceId ??= null;
                                                                //     }

                                                                //     updateRow(idx, {
                                                                //         scenarioConfigs: {
                                                                //             ...row.scenarioConfigs,
                                                                //             [sk]: next
                                                                //         }
                                                                //     });
                                                                // }}

                                                                onChange={async e => {
                                                                    const val = e.target.value as InputOption;

                                                                    // const next: ScenarioConfig = {
                                                                    //     inputOption: val,
                                                                    //     previousRoundId:
                                                                    //         val === "usePreviousRoundInput" ? prevRoundId ?? null : null,
                                                                    //     standardReferenceId:
                                                                    //         val === "useStandardInput"
                                                                    //             ? row.scenarioConfigs[sk]?.standardReferenceId ?? null
                                                                    //             : null
                                                                    // };

                                                                    const next: ScenarioConfig = {
                                                                        ...row.scenarioConfigs[sk],

                                                                        inputOption: val,

                                                                        previousRoundId:
                                                                            val === "usePreviousRoundInput"
                                                                                ? prevRoundId ?? null
                                                                                : null,

                                                                        standardReferenceId:
                                                                            val === "useStandardInput"
                                                                                ? row.scenarioConfigs[sk]?.standardReferenceId ?? null
                                                                                : null
                                                                    };

                                                                    if (val === "useStandardInput") {
                                                                        await loadStandardTemplatesForStakeholder(row.stakeholderCode);
                                                                    }

                                                                    updateRow(idx, {
                                                                        scenarioConfigs: {
                                                                            ...row.scenarioConfigs,
                                                                            [sk]: next
                                                                        }
                                                                    });
                                                                }}

                                                            >
                                                                {options.map(o => (
                                                                    <MenuItem key={o.key} value={o.key}>{o.text}</MenuItem>
                                                                ))}
                                                            </Select>
                                                        </FormControl>
                                                        {/* {cfg?.inputOption === "CollectInput" &&
                                                            hasActiveVersion && (
                                                                <FormControl fullWidth required sx={{ mt: 2 }}>
                                                                    <InputLabel
                                                                        shrink
                                                                        sx={{
                                                                            backgroundColor: "#fff",
                                                                            px: 0.5
                                                                        }}
                                                                    >
                                                                        Status - Dataset {sk}
                                                                    </InputLabel>

                                                                    <Select
                                                                        multiple
                                                                        value={
                                                                            row.scenarioConfigs[sk]?.submissionTypes ??
                                                                            ["Draft", "Final"]
                                                                        }
                                                                        renderValue={(selected) => (selected as string[]).join(", ")}
                                                                        onChange={(e) => {
                                                                            const value = e.target.value as string[];

                                                                            if (value.length === 0) {
                                                                                return;
                                                                            }

                                                                            updateRow(idx, {
                                                                                scenarioConfigs: {
                                                                                    ...row.scenarioConfigs,
                                                                                    [sk]: {
                                                                                        ...row.scenarioConfigs[sk],
                                                                                        submissionTypes: value
                                                                                    }
                                                                                }
                                                                            });
                                                                        }}
                                                                    >
                                                                        {["Draft", "Final"].map(v => {
                                                                            const selected =
                                                                                (
                                                                                    row.scenarioConfigs[sk]?.submissionTypes ??
                                                                                    ["Draft", "Final"]
                                                                                ).includes(v);

                                                                            const totalSelected =
                                                                                (
                                                                                    row.scenarioConfigs[sk]?.submissionTypes ??
                                                                                    ["Draft", "Final"]
                                                                                ).length;

                                                                            return (
                                                                                <MenuItem
                                                                                    key={v}
                                                                                    value={v}
                                                                                    disabled={selected && totalSelected === 1}
                                                                                >
                                                                                    {v}
                                                                                </MenuItem>
                                                                            );
                                                                        })}
                                                                    </Select>
                                                                </FormControl>)} */}
                                                        {/* {cfg?.inputOption === "CollectInput" &&
                                                            hasActiveVersion && (

                                                                <FormControl fullWidth required sx={{ mt: 2 }}>
                                                                    <InputLabel
                                                                        shrink
                                                                        sx={{
                                                                            backgroundColor: "#fff",
                                                                            px: 0.5
                                                                        }}
                                                                    >
                                                                        Version Number - Dataset {sk}
                                                                    </InputLabel>

                                                                    <Select
                                                                        multiple
                                                                        value={
                                                                            row.scenarioConfigs[sk]?.versionSelections ??
                                                                            filteredVersions.map(v => v.VersionNumber)
                                                                        }
                                                                        renderValue={(selected) => (selected as string[]).join(", ")}
                                                                        onChange={(e) => {
                                                                            const value = e.target.value as string[];

                                                                            if (value.length === 0) {
                                                                                return;
                                                                            }

                                                                            updateRow(idx, {
                                                                                scenarioConfigs: {
                                                                                    ...row.scenarioConfigs,
                                                                                    [sk]: {
                                                                                        ...row.scenarioConfigs[sk],
                                                                                        versionSelections: value
                                                                                    }
                                                                                }
                                                                            });
                                                                        }}
                                                                    >
                                                                        {filteredVersions.map(v => {
                                                                            const selected =
                                                                                (
                                                                                    row.scenarioConfigs[sk]?.versionSelections ?? []
                                                                                ).includes(v.VersionNumber);

                                                                            const totalSelected =
                                                                                (
                                                                                    row.scenarioConfigs[sk]?.versionSelections ?? []
                                                                                ).length;

                                                                            return (
                                                                                <MenuItem
                                                                                    key={v.VersionNumber}
                                                                                    value={v.VersionNumber}
                                                                                    disabled={selected && totalSelected === 1}
                                                                                >
                                                                                    {v.VersionNumber}
                                                                                </MenuItem>
                                                                            );
                                                                        })}
                                                                    </Select>
                                                                </FormControl>
                                                            )} */}
                                                        {/* {cfg?.inputOption === "CollectInput" &&
                                                            hasActiveVersion &&
                                                            row.scenarioConfigs[sk]?.submissionTypes?.includes("Draft") && (
                                                                <DatePicker
                                                                    label={`Draft Due Date - Dataset ${sk}`}
                                                                    value={
                                                                        row.scenarioConfigs[sk]?.draftDueDate ?? null
                                                                    }
                                                                    onChange={(d) =>
                                                                        updateRow(idx, {
                                                                            scenarioConfigs: {
                                                                                ...row.scenarioConfigs,
                                                                                [sk]: {
                                                                                    ...row.scenarioConfigs[sk],
                                                                                    draftDueDate: d
                                                                                }
                                                                            }
                                                                        })
                                                                    }
                                                                    slotProps={{
                                                                        textField: {
                                                                            fullWidth: true,
                                                                            sx: { mt: 2 }
                                                                        }
                                                                    }}
                                                                />
                                                            )} */}

                                                        {cfg?.inputOption === "useStandardInput" && (
                                                            <FormControl fullWidth required sx={{ mt: 1 }}>
                                                                <InputLabel>Standard Template</InputLabel>
                                                                <Select
                                                                    value={cfg.standardReferenceId ?? ""}
                                                                    onChange={e =>
                                                                        updateRow(idx, {
                                                                            scenarioConfigs: {
                                                                                ...row.scenarioConfigs,
                                                                                [sk]: {
                                                                                    ...cfg,
                                                                                    standardReferenceId: Number(e.target.value)
                                                                                }
                                                                            }
                                                                        })
                                                                    }
                                                                >
                                                                    {/* {(standardTemplatesByStakeholder.get(row.stakeholderCode) ?? [])
                                                                        .map(t => (
                                                                            <MenuItem key={t.id} value={t.id}>
                                                                                {t.title}
                                                                            </MenuItem>
                                                                        ))} */}
                                                                    {
                                                                        (standardTemplatesByStakeholder.get(row.stakeholderCode) ?? [])
                                                                            .filter(
                                                                                t =>
                                                                                    t.versionNumber ===
                                                                                    row.commonVersionSelections
                                                                            )
                                                                            .map(t => (
                                                                                <MenuItem key={t.id} value={t.id}>
                                                                                    {t.title}
                                                                                </MenuItem>
                                                                            ))
                                                                    }
                                                                </Select>
                                                            </FormControl>
                                                        )}
                                                    </Box>
                                                );
                                            })}

                                            {
                                                (hasStandardScenario || hasCollectScenario) && (
                                                    <DatePicker
                                                        label="Due Date"
                                                        value={row.dueDate}
                                                        minDate={today}
                                                        onChange={d => updateRow(idx, { dueDate: d })}
                                                        slotProps={{ textField: { required: true, fullWidth: true, sx: { mt: 2 } } }}
                                                    />
                                                )
                                            }


                                            {hasCollectScenario && (
                                                <>
                                                    <Box>
                                                        <Autocomplete
                                                            multiple
                                                            options={row.groupUsers}
                                                            value={row.notifyUsers}
                                                            getOptionLabel={(o) => o.text || ""}
                                                            onChange={(_, v) => updateRow(idx, { notifyUsers: v })}
                                                            renderInput={(params) => (
                                                                <TextField
                                                                    {...params}
                                                                    label="Stakeholder Users"
                                                                    sx={{ mt: 2 }}
                                                                    error={
                                                                        row.notifyUsers.length === 0 &&
                                                                        row.additionalTeam.length === 0
                                                                    }
                                                                />
                                                            )}
                                                        />

                                                        {row.notifyUsers.length === 0 &&
                                                            row.additionalTeam.length === 0 && (
                                                                <Typography
                                                                    variant="caption"
                                                                    sx={{
                                                                        color: "#d32f2f",
                                                                        mt: 0.5,
                                                                        ml: 1.5,
                                                                        display: "block",
                                                                        fontSize: "13px"
                                                                    }}
                                                                >
                                                                    Required unless you add at least one Extra Input Provider
                                                                </Typography>
                                                            )}
                                                    </Box>
                                                    <Box
                                                        sx={{
                                                            mt: 2,
                                                            position: "relative",
                                                            "& .ms-BasePicker": {
                                                                minHeight: 56,
                                                                border: "1px solid rgba(0,0,0,0.23)",
                                                                borderRadius: "4px",
                                                                padding: "14px",
                                                                backgroundColor: "#fff"
                                                            },

                                                            "& .ms-BasePicker:hover": {
                                                                borderColor: "rgba(0,0,0,0.87)"
                                                            },

                                                            "& .ms-BasePicker-text": {
                                                                border: "none !important",
                                                                minHeight: "unset !important",
                                                                background: "transparent"
                                                            },

                                                            "& .ms-TextField-fieldGroup": {
                                                                border: "none !important",
                                                                background: "transparent"
                                                            },

                                                            "& .ms-BasePicker-input": {
                                                                padding: "0 !important"
                                                            },

                                                            "& .ms-Label": {
                                                                position: "absolute",
                                                                top: "-10px",
                                                                left: "12px",
                                                                backgroundColor: "#fff",
                                                                padding: "0 4px",
                                                                fontSize: "12px",
                                                                zIndex: 1,
                                                                margin: 0,
                                                                color: "rgba(0,0,0,0.6)",
                                                            }
                                                        }}
                                                    >

                                                        <PeoplePicker
                                                            context={peoplePickerContext}
                                                            titleText="Extra Input Provider"
                                                            principalTypes={[PrincipalType.User]}
                                                            personSelectionLimit={100}
                                                            showtooltip
                                                            resolveDelay={500}
                                                            onChange={(items = []) => updateRow(idx, { additionalTeam: items })}
                                                        />
                                                    </Box>

                                                </>
                                            )}
                                        </Box>
                                    )}
                                </ModernCard>
                            );
                        })}
                        {/* Add Adhoc Template */}


                        {adhocCards.map((row, index) => {
                            const sanitizedName = (row.otherCode ?? "").replace(/[^a-zA-Z0-9]/g, "");
                            return (
                                <ModernCard key={index} sx={{ mb: 2 }}>
                                    <Box
                                        display="flex"
                                        justifyContent="space-between"
                                        alignItems="center"
                                    >
                                        <Typography variant="h6" fontWeight={600}>
                                            {row.otherCode?.trim()
                                                ? row.otherCode
                                                : `Adhoc Template ${index + 1}`}
                                        </Typography>

                                        <IconButton
                                            color="error"
                                            onClick={() =>
                                                setAdhocCards(prev =>
                                                    prev.filter((_, i) => i !== index)
                                                )
                                            }
                                        >
                                            <CloseIcon />
                                        </IconButton>
                                    </Box>

                                    {/*Adhoc Template  Name */}

                                    {/* Use Previous Round */}

                                    <FormControlLabel
                                        sx={{ mb: 1 }}
                                        control={
                                            <Checkbox
                                                checked={row.usePreviousRound ?? false}
                                                onChange={(e) => {
                                                    const checked = e.target.checked;

                                                    updateAdhocCard(index, {
                                                        usePreviousRound: checked,

                                                        // When unchecked, clear previous-round values
                                                        ...(checked
                                                            ? {}
                                                            : {
                                                                otherCode: "",
                                                                description: "",
                                                                previousAdhocId: undefined,
                                                                applicableScenarios: [],
                                                                scenarioConfigs: {},
                                                                commonVersionSelections: "",
                                                                inputTemplateVersions: []
                                                            })
                                                    });
                                                }}
                                            />
                                        }
                                        label={
                                            <Typography fontWeight={600}>
                                                Use Previous Round
                                            </Typography>
                                        }
                                    />

                                    {/* Adhoc Template Name */}

                                    <Box sx={{ mb: 3 }}>
                                        {row.usePreviousRound ? (
                                            <FormControl fullWidth required>
                                                <InputLabel>Previous Validated Adhoc</InputLabel>

                                                <Select
                                                    label="Previous Validated Adhoc"
                                                    value={row.previousAdhocId?.toString() ?? ""}
                                                    onChange={(e) => {
                                                        const selectedId = Number(e.target.value);

                                                        const selected =
                                                            previousValidatedAdhocs.find(
                                                                x => Number(x.id) === selectedId
                                                            );

                                                        if (!selected) {
                                                            return;
                                                        }

                                                        /*
                                                         * Copy datasets from previous validated Adhoc.
                                                        //  */
                                                        // const copiedDatasets =
                                                        //     (selected.applicableScenarios ?? []) as ScenarioKey[];

                                                        /*
                                                         * Every copied dataset should use Previous Round Input.
                                                         */
                                                        // const copiedScenarioConfigs:
                                                        //     Partial<Record<ScenarioKey, ScenarioConfig>> = {};

                                                        // copiedDatasets.forEach((dataset) => {
                                                        //     copiedScenarioConfigs[dataset] = {
                                                        //         inputOption: "usePreviousRoundInput",
                                                        //         previousRoundId: prevRoundId ?? null
                                                        //     };
                                                        // });

                                                        updateAdhocCard(index, {
                                                            usePreviousRound: true,

                                                            // 1. COPY NAME
                                                            otherCode: selected.stakeholderName,

                                                            // 2. COPY DESCRIPTION
                                                            description: selected.description ?? "",

                                                            // 3. COPY PREVIOUS ADHOC ID
                                                            previousAdhocId: selected.id,

                                                            // 4. COPY DATASETS
                                                            //applicableScenarios: copiedDatasets,

                                                            // 5. COPY VERSION
                                                            commonVersionSelections:
                                                                selected.versionNumber ?? "",

                                                            // 6. SET INPUT TYPE = PREVIOUS ROUND
                                                            //scenarioConfigs: copiedScenarioConfigs,
                                                            scenarioConfigs: {},

                                                            // 7. COPY DUE DATE
                                                            dueDate: selected.dueDate
                                                                ? new Date(selected.dueDate)
                                                                : null,

                                                            // No SharePoint InputTemplate lookup for Previous Adhoc
                                                            inputTemplateVersions: []
                                                        });
                                                    }}
                                                >
                                                    {getAvailablePreviousAdhocs(index).map(template => (
                                                        <MenuItem
                                                            key={`${template.stakeholderCode}-${template.versionNumber}`}
                                                            value={String(template.id)}
                                                        >
                                                            {template.stakeholderName}
                                                            {template.versionNumber
                                                                ? ` - ${template.versionNumber}`
                                                                : ""}
                                                        </MenuItem>
                                                    ))}
                                                </Select>
                                            </FormControl>
                                        ) : (
                                            <>
                                                <ModernTextField
                                                    label="Name"
                                                    required
                                                    value={row.otherCode ?? ""}
                                                    onChange={(e) =>
                                                        updateAdhocCard(index, {
                                                            otherCode: e.target.value.replace(
                                                                /[^a-zA-Z0-9 ]/g,
                                                                ""
                                                            )
                                                        })
                                                    }
                                                />

                                                <Box
                                                    sx={{
                                                        display: "flex",
                                                        justifyContent: "flex-end",
                                                        mt: 0.5
                                                    }}
                                                >
                                                    <Typography
                                                        variant="caption"
                                                        sx={{
                                                            color: "primary.main",
                                                            fontWeight: 600
                                                        }}
                                                    >
                                                        Code : {(row.otherCode ?? "").replace(
                                                            /[^a-zA-Z0-9]/g,
                                                            ""
                                                        )}
                                                    </Typography>
                                                </Box>
                                            </>
                                        )}
                                    </Box>

                                    {row.usePreviousRound && (
                                        <Box sx={{ mb: 3 }}>
                                            <ModernTextField
                                                label="Description"
                                                fullWidth
                                                multiline
                                                minRows={3}
                                                value={row.description ?? ""}
                                                disabled
                                            />
                                        </Box>
                                    )}
                                    {/* <Box sx={{ mb: 3 }}>
                                        <ModernTextField
                                            label="Name"
                                            required
                                            value={row.otherCode ?? ""}
                                            onChange={(e) =>
                                                updateAdhocCard(index, {
                                                    otherCode: e.target.value.replace(/[^a-zA-Z0-9 ]/g, "")
                                                })
                                            }
                                        />
                                        <Box
                                            sx={{
                                                display: "flex",
                                                justifyContent: "flex-end",
                                                mt: 0.5
                                            }}
                                        >
                                            <Typography
                                                variant="caption"
                                                sx={{
                                                    color: "primary.main",
                                                    fontWeight: 600
                                                }}
                                            >
                                                Code : {sanitizedName}
                                            </Typography>
                                        </Box>
                                    </Box> */}
                                    {row.usePreviousRound && (
                                        <Box
                                            sx={{
                                                display: "flex",
                                                alignItems: "center",
                                                minHeight: 56,
                                                mt: 1,
                                                mb: 1
                                            }}
                                        >
                                            <Typography
                                                variant="body1"
                                                fontWeight={600}
                                                sx={{ minWidth: 80 }}
                                            >
                                                Version:
                                            </Typography>

                                            <Typography variant="body1">
                                                {row.commonVersionSelections || "-"}
                                            </Typography>
                                        </Box>
                                    )}

                                    {/* Adhoc Template Applicable Datasets */}
                                    <FormControl fullWidth sx={{ mt: 2 }}>
                                        <InputLabel>Applicable Datasets</InputLabel>

                                        <Select
                                            multiple
                                            value={row.applicableScenarios}
                                            label="Applicable Datasets"
                                            onChange={(e) => {
                                                const selected = e.target.value as ScenarioKey[];

                                                const cfgs = {
                                                    ...row.scenarioConfigs
                                                };

                                                selected.forEach(sk => {
                                                    if (!cfgs[sk]) {
                                                        cfgs[sk] = {
                                                            inputOption: "CollectInput",
                                                            previousRoundId: null
                                                        };
                                                    }
                                                });

                                                Object.keys(cfgs).forEach(key => {
                                                    if (!selected.includes(key as ScenarioKey)) {
                                                        delete cfgs[key as ScenarioKey];
                                                    }
                                                });

                                                updateAdhocCard(index, {
                                                    applicableScenarios: selected,
                                                    scenarioConfigs: cfgs
                                                });
                                            }}
                                            renderValue={(selected) => (
                                                <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap" }}>
                                                    {(selected as ScenarioKey[]).map(sk => (
                                                        <Chip
                                                            key={sk}
                                                            label={sk}
                                                            size="small"
                                                        />
                                                    ))}
                                                </Box>
                                            )}
                                        >
                                            {/* {scenarios.map(s => { */}
                                            {getAvailableAdhocDatasets(
                                                row.otherCode || ""
                                            ).map(s => {
                                                const MAX_DESC_LENGTH = 40;

                                                const shortDesc =
                                                    s.description && s.description.length > MAX_DESC_LENGTH
                                                        ? s.description.substring(0, MAX_DESC_LENGTH) + "..."
                                                        : s.description;

                                                return (
                                                    <MenuItem
                                                        key={s.key}
                                                        value={s.key}
                                                    >
                                                        <Typography variant="body2">
                                                            <strong>{s.key}</strong>
                                                            {shortDesc ? ` - ${shortDesc}` : ""}
                                                        </Typography>
                                                    </MenuItem>
                                                );
                                            })}
                                        </Select>
                                    </FormControl>


                                    {/*Adhoc Template  Input Type */}

                                    {row.applicableScenarios.map(sk => {
                                        const cfg = row.scenarioConfigs[sk];

                                        const options = getAdhocInputOptions(
                                            row.otherCode || "",
                                            sk
                                        );

                                        const selectedInputType =
                                            options.some(option => option.key === cfg?.inputOption)
                                                ? cfg?.inputOption
                                                : "CollectInput";

                                        return (
                                            <Box key={sk} sx={{ mt: 2 }}>
                                                <FormControl fullWidth>
                                                    <InputLabel>
                                                        {`Input Type - Dataset ${sk}`}
                                                    </InputLabel>

                                                    <Select
                                                        label={`Input Type - Dataset ${sk}`}
                                                        value={selectedInputType}
                                                        onChange={(e) => {
                                                            const inputOption =
                                                                e.target.value as InputOption;

                                                            updateAdhocCard(index, {
                                                                scenarioConfigs: {
                                                                    ...row.scenarioConfigs,
                                                                    [sk]: {
                                                                        ...cfg,
                                                                        inputOption,
                                                                        previousRoundId:
                                                                            inputOption ===
                                                                                "usePreviousRoundInput"
                                                                                ? prevRoundId ?? null
                                                                                : null
                                                                    }
                                                                }
                                                            });
                                                        }}
                                                    >
                                                        {options.map(option => (
                                                            <MenuItem
                                                                key={option.key}
                                                                value={option.key}
                                                            >
                                                                {option.text}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        );
                                    })}

                                    {/* {row.applicableScenarios.map(sk => {
                                        const cfg = row.scenarioConfigs[sk];

                                        const options = getInputOptions(
                                            "other",
                                            sk,
                                            true
                                        );

                                        return (
                                            <Box key={sk} sx={{ mt: 2 }}>
                                                <FormControl fullWidth>
                                                    <InputLabel>
                                                        {`Input Type - Dataset ${sk}`}
                                                    </InputLabel>

                                                    <Select
                                                        label={`Input Type - Dataset ${sk}`}
                                                        value="CollectInput"
                                                        disabled
                                                    >
                                                        <MenuItem value="CollectInput">
                                                            Collect Input
                                                        </MenuItem>
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        );
                                    })} */}

                                    {/* Due Date */}
                                    <Box sx={{ mt: 1 }}>
                                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                                            <DatePicker
                                                label="Due Date"
                                                minDate={today}
                                                value={row.dueDate ? new Date(row.dueDate) : null}
                                                onChange={(value) =>
                                                    updateAdhocCard(index, {
                                                        dueDate: value
                                                            ? value
                                                            : null
                                                    })
                                                }
                                                slotProps={{
                                                    textField: {
                                                        fullWidth: true,
                                                        required: true
                                                    }
                                                }}
                                            />
                                        </LocalizationProvider>
                                    </Box>

                                    {/* TEAM MEMBERS */}
                                    <Box sx={{ position: "relative", mt: 3 }}>
                                        <Box
                                            sx={{
                                                border: "1px solid rgba(0, 0, 0, 0.23)",
                                                borderRadius: 1,
                                                px: 1.75,
                                                pt: 1.5,
                                                pb: 0.75,
                                                "&:hover": {
                                                    borderColor: "rgba(0, 0, 0, 0.87)"
                                                },
                                                "& .ms-BasePicker-text": {
                                                    border: "none !important",
                                                    "&::after": {
                                                        display: "none !important"
                                                    }
                                                }
                                            }}
                                        >
                                            <Typography
                                                variant="caption"
                                                sx={{
                                                    position: "absolute",
                                                    top: -9,
                                                    left: 10,
                                                    px: 0.5,
                                                    backgroundColor: "background.paper",
                                                    color: "rgba(0, 0, 0, 0.6)",
                                                    fontSize: "0.75rem",
                                                    lineHeight: 1,
                                                    pointerEvents: "none"
                                                }}
                                            >
                                                Team Members{" "}
                                                <span style={{ color: "#d32f2f" }}>*</span>
                                            </Typography>

                                            <PeoplePicker
                                                context={peoplePickerContext as any}
                                                personSelectionLimit={20}
                                                principalTypes={[PrincipalType.User]}
                                                ensureUser={true}
                                                resolveDelay={500}
                                                onChange={(items: any[]) => {
                                                    updateAdhocCard(index, {
                                                        additionalTeam: items.map((p: any) => ({
                                                            key: p.id || p.loginName,
                                                            text: p.text,
                                                            secondaryText: p.secondaryText,
                                                            tertiaryText: p.loginName
                                                        }))
                                                    });
                                                }}
                                            />
                                        </Box>
                                    </Box>
                                </ModernCard>
                            );
                        })}


                        {/* Add Adhoc Template Button*/}
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: "flex-end",
                                mb: 2
                            }}
                        >
                            <ModernButton
                                variant="gradient"
                                startIcon={<AddIcon />}
                                onClick={addAdhocTemplate}
                            >
                                Add Adhoc Template
                            </ModernButton>
                        </Box>




                        {toast && (
                            <Box sx={{ mb: 3 }}>
                                <ModernAlert
                                    severity={toast.severity}
                                    onClose={() => setToast(null)}
                                    elevated
                                    gradient
                                >
                                    {toast.text}
                                </ModernAlert>
                            </Box>
                        )}

                        <Stack direction="row" justifyContent="flex-end" spacing={1}>
                            <ModernButton variant="outlined" onClick={handleClose}>Cancel</ModernButton>

                            {!allTemplatesAdded && (
                                <ModernButton
                                    variant="gradient"
                                    glow
                                    loading={saving}
                                    disabled={saving}
                                    onClick={saveAllInputTemplates}
                                >
                                    Save All
                                </ModernButton>
                            )}

                        </Stack>
                    </Stack>
                )}
            </Drawer>
        </LocalizationProvider>
    );
};

export default AddInputTemplateDrawer;