import * as React from "react";
import {
    Drawer,
    Box,
    Stack,
    Typography,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Chip,
    Autocomplete,
    TextField,
    FormControlLabel,
    Checkbox
} from "@mui/material";


import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { ModernButton, ModernAlert, ModernCard } from "../../shared/mui";
import type { IPersonaProps } from "@fluentui/react";
import { SPHttpClient } from "@microsoft/sp-http";

import {
    EditInputTemplateDrawerProps,
    EditInputTemplateModel,
    InputOption,
    ScenarioConfig,
    ScenarioKey
} from "../../store/Models";

export const EditInputTemplateDrawer: React.FC<EditInputTemplateDrawerProps> = ({
    open,
    onClose,
    round,
    currentRoundDetail,
    backendRound,
    roundNumber,
    templateCatalog,
    prevRoundScenarioMap,
    prevRoundApprovedScenarioMap,
    prevRoundId,
    spfxContext,
    api,
    onSaveSuccess
}) => {

    const peoplePickerContext = React.useMemo(() => ({
        absoluteUrl: spfxContext?.pageContext?.web?.absoluteUrl,
        msGraphClientFactory: spfxContext?.msGraphClientFactory,
        spHttpClient: spfxContext?.spHttpClient
    }), [spfxContext]);

    const [editor, setEditor] = React.useState<EditInputTemplateModel | null>(null);
    const [expandedDescriptions, setExpandedDescriptions] =
        React.useState<Set<string>>(new Set());
    const [otherEditor, setOtherEditor] = React.useState({
        enabled: false,

        otherCode: "",

        applicableScenarios: [] as ScenarioKey[],

        scenarioConfigs:
            {} as Partial<Record<ScenarioKey, ScenarioConfig>>,

        dueDate: null as Date | null,

        groupUsers: [] as IPersonaProps[],

        notifyUsers: [] as IPersonaProps[],

        additionalTeam: [] as IPersonaProps[],

        inputTemplateVersions: [] as any[]
    });
    const [groupUsers, setGroupUsers] = React.useState<IPersonaProps[]>([]);

    const [saving, setSaving] = React.useState(false);
    const [savedCollectDraftInput, setSavedCollectDraftInput] =
        React.useState(false);

    const today = React.useMemo(() => {
        const d = new Date();
        d.setHours(0, 0, 0, 0);
        return d;
    }, []);

    //const [activeVersions, setActiveVersions] = React.useState<string[]>([]);
    const [inputTemplateVersions, setInputTemplateVersions] =
        React.useState<any[]>([]);

    React.useEffect(() => {
        if (open) {
            setSaving(false);
        }
    }, [open]);



    const otherHasCollectScenario =
        otherEditor.applicableScenarios.some(
            sk =>
                otherEditor.scenarioConfigs[sk]?.inputOption ===
                "CollectInput"
        );

    const otherHasStandardScenario =
        otherEditor.applicableScenarios.some(
            sk =>
                otherEditor.scenarioConfigs[sk]?.inputOption ===
                "useStandardInput"
        );

    const [toast, setToast] = React.useState<{
        severity: "success" | "error" | "warning" | "info";
        text: string;
    } | null>(null);
    const [standardTemplatesByStakeholder, setStandardTemplatesByStakeholder] =
        React.useState<
            Map<
                string,
                {
                    id: number;
                    title: string;
                    versionNumber: string;
                }[]
            >
        >(new Map());

    // React.useEffect(() => {
    //     if (!editor) return;

    //     const stakeholderKey = editor.stakeholderCode.toLowerCase();
    //     const approved =
    //         prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set<ScenarioKey>();

    //     let changed = false;
    //     const nextConfigs = { ...editor.scenarioConfigs };

    //     Object.keys(nextConfigs).forEach(k => {
    //         const sk = k as ScenarioKey;
    //         const cfg = nextConfigs[sk];

    //         if (
    //             cfg?.inputOption === "usePreviousRoundInput" &&
    //             !approved.has(sk)
    //         ) {
    //             nextConfigs[sk] = {
    //                 ...cfg,
    //                 inputOption: "CollectInput",
    //                 previousRoundId: null
    //             };
    //             changed = true;
    //         }
    //     });

    //     if (changed) {
    //         setEditor(e => (e ? { ...e, scenarioConfigs: nextConfigs } : e));
    //     }
    // }, [editor, prevRoundApprovedScenarioMap]);


    const prevRoundVersionMap = React.useMemo(() => {
        const map = new Map<string, string>();

        (backendRound?.inputs ?? []).forEach((inp: any) => {
            if (
                inp.workflowStatus === "Approved" &&
                inp.stakeholderCode &&
                inp.versionNumber
            ) {
                map.set(
                    String(inp.stakeholderCode).toLowerCase(),
                    String(inp.versionNumber)
                );
            }
        });

        return map;
    }, [backendRound]);

    React.useEffect(() => {
        if (!editor) return;

        const stakeholderKey = editor.stakeholderCode.toLowerCase();

        const approved =
            prevRoundApprovedScenarioMap.get(stakeholderKey) ??
            new Set<ScenarioKey>();

        const previousVersion =
            prevRoundVersionMap.get(stakeholderKey);

        const currentVersion =
            editor.commonVersionSelections || "";

        let changed = false;
        const nextConfigs = { ...editor.scenarioConfigs };

        Object.keys(nextConfigs).forEach(k => {
            const sk = k as ScenarioKey;
            const cfg = nextConfigs[sk];

            const canUsePrevious =
                approved.has(sk) &&
                previousVersion === currentVersion;

            if (
                cfg?.inputOption === "usePreviousRoundInput" &&
                !canUsePrevious
            ) {
                nextConfigs[sk] = {
                    ...cfg,
                    inputOption: "CollectInput",
                    previousRoundId: null
                };

                changed = true;
            }
        });

        if (changed) {
            setEditor(e =>
                e
                    ? {
                        ...e,
                        scenarioConfigs: nextConfigs
                    }
                    : e
            );
        }
    }, [
        editor,
        prevRoundApprovedScenarioMap,
        prevRoundVersionMap
    ]);


    function getScenarioRecordFromBackend(
        roundDetail: any,
        stakeholderName: string,
        stakeholderCode: string,
        scenarioKey: ScenarioKey
    ) {

        if (!roundDetail) return null;
        // return (roundDetail.inputs ?? []).find((inp: any) =>
        //     // String(inp.stakeholder || '') === stakeholderName &&
        //     String(inp.stakeholderCode || '') === stakeholderCode &&
        //     String(inp.scenarioName || '').toUpperCase() === scenarioKey && 
        //     String(inp.workflowStatus ||  '').toLowerCase() !== "cancelled"
        // ) || null;

        return (roundDetail.inputs ?? []).reduce((max: any, inp: any) => {
            const matches =
                String(inp.stakeholderCode || '') === stakeholderCode &&
                String(inp.scenarioName || '').toUpperCase() === scenarioKey &&
                String(inp.workflowStatus || '').toLowerCase() !== 'cancelled';
            if (!matches) return max;
            if (
                !max ||
                Number(inp.revisionNumber || 0) > Number(max.revisionNumber || 0)
            ) {
                return inp;
            }
            return max;
        }, null);
    }


    async function loadStandardTemplatesForStakeholder(stakeholderCode: string) {
        const response = await api.getStandardReference(Number(round.opportunityId));
        const list = Array.isArray(response) ? response : [];

        const filtered = list.filter(
            (item: any) =>
                String(item.stakeholder).toLowerCase() === stakeholderCode.toLowerCase()
        );


        // React.useEffect(() => {
        //     if (!editor) return;

        //     const stakeholderKey = editor.stakeholderCode.toLowerCase();
        //     const approved =
        //         prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set<ScenarioKey>();

        //     let changed = false;
        //     const nextConfigs = { ...editor.scenarioConfigs };

        //     Object.keys(nextConfigs).forEach(k => {
        //         const sk = k as ScenarioKey;
        //         const cfg = nextConfigs[sk];

        //         if (
        //             cfg?.inputOption === "usePreviousRoundInput" &&
        //             !approved.has(sk)
        //         ) {
        //             nextConfigs[sk] = {
        //                 ...cfg,
        //                 inputOption: "CollectInput",
        //                 previousRoundId: null
        //             };
        //             changed = true;
        //         }
        //     });

        //     if (changed) {
        //         setEditor(e => (e ? { ...e, scenarioConfigs: nextConfigs } : e));
        //     }
        // }, [prevRoundApprovedScenarioMap]);

        setStandardTemplatesByStakeholder(prev => {
            const next = new Map(prev);
            next.set(
                stakeholderCode,
                filtered.map((i: any) => ({
                    id: Number(i.id),
                    title: String(i.title),
                    versionNumber: String(i.versionNumber || "")
                }))
            );
            return next;
        });
    }

    async function loadGroupUsers(stakeholderCode: string) {
        const meta =
            templateCatalog.get(stakeholderCode.toLowerCase());

        if (!meta?.groupIds?.length) {
            setGroupUsers([]);
            return;
        }

        const users: IPersonaProps[] = [];

        for (const gid of meta.groupIds) {
            const url =
                `${spfxContext.pageContext.web.absoluteUrl}` +
                `/_api/web/sitegroups/GetById(${gid})/users?$select=Id,Title,Email,LoginName`;


            const res = await spfxContext.spHttpClient.get(
                url,
                SPHttpClient.configurations.v1
            );


            const json = await res.json();

            (json.value ?? []).forEach((u: any) => {
                users.push({
                    key: String(u.Id),
                    text: u.Title || u.LoginName,
                    secondaryText: u.Email || u.LoginName,
                    tertiaryText: u.LoginName || u.Email
                });
            });
        }

        const deduped = Array.from(
            new Map(users.map(u => [u.secondaryText, u])).values()
        );

        setGroupUsers(deduped);
        return deduped;
    }

    async function loadInputTemplateVersions(stakeholderName: string) {
        try {
            const cfg = (window as any).TENANT_CONFIG;

            const endpoint =
                `${cfg.siteUrl}/_api/web/lists/getbytitle('InputTemplate')/items` +
                `?$select=Id,Title,VersionNumber,DraftApplicable,Active` +
                `&$filter=Title eq '${stakeholderName}' and Active eq 1`;

            const res = await spfxContext.spHttpClient.get(
                endpoint,
                SPHttpClient.configurations.v1
            );

            const data = await res.json();

            // console.log("Versions", data.value);

            setInputTemplateVersions(data.value || []);
            if ((data.value || []).length === 1) {
                setEditor(prev =>
                    prev
                        ? {
                            ...prev,
                            commonVersionSelections:
                                data.value[0].VersionNumber
                        }
                        : prev
                );
            }
        }
        catch (e) {
            console.error(e);
            setInputTemplateVersions([]);
        }
    }

    React.useEffect(() => {
        if (!editor) return;

        if (
            inputTemplateVersions.length === 1 &&
            editor.commonVersionSelections !== inputTemplateVersions[0].VersionNumber
        ) {
            setEditor(prev =>
                prev
                    ? {
                        ...prev,
                        commonVersionSelections:
                            inputTemplateVersions[0].VersionNumber
                    }
                    : prev
            );
        }
    }, [inputTemplateVersions, editor]);



    async function loadTemplate(stakeholderCode: string) {
        const it = currentRoundDetail.stakeholders.find(
            (r: any) => r.stakeholder_code === stakeholderCode
        );
        // const it = currentRoundDetail.inputs.find(
        //     (r: any) => r.stakeholderCode === stakeholderCode
        // );
        //console.log("currentRoundDetail.stakeholders: ",currentRoundDetail.stakeholders)
        //console.log("currentRoundDetail : ",currentRoundDetail)
        // await loadInputTemplateVersions(
        //     //it.stakeholderName
        //     it.stakeholder
        // );

        if (!it) return;
        //console.log("Stakeholder object:", it);
        await loadInputTemplateVersions(it.stakeholder);

        const stakeholderInputs = currentRoundDetail.inputs.filter(
            (i: any) => i.stakeholderCode === it.stakeholder_code
        );

        //console.log("Stakeholder Inputs", stakeholderInputs);

        const savedVersion =
            stakeholderInputs.find((i: any) => i.versionNumber)?.versionNumber ?? "";

        //console.log("Saved Version:", savedVersion);



        await loadGroupUsers(stakeholderCode);
        const loadedUsers = await loadGroupUsers(stakeholderCode);

        // const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

        // it.applicableScenarios.forEach((s: any) => {
        //     const key: ScenarioKey =
        //         typeof s === "string" ? s : s.key;

        //     scenarioConfigs[key] = {
        //         inputOption: it.inputOption as InputOption
        //     };
        // });

        const scenarioConfigs: Partial<Record<ScenarioKey, ScenarioConfig>> = {};

        // const stakeholderKey = it.stakeholderCode!.toLowerCase();

        // const approvedScenarios =
        //     prevRoundApprovedScenarioMap.get(stakeholderKey) ?? new Set<ScenarioKey>();

        it.applicableScenarios.forEach((s: any) => {
            const key: ScenarioKey =
                typeof s === "string" ? s : s.name;
            const desc = s.desc;

            // const canUsePrevious =
            //     roundNumber > 1 && approvedScenarios.has(key);

            // scenarioConfigs[key] = {
            //     inputOption: canUsePrevious
            //         ? "usePreviousRoundInput"
            //         : "CollectInput",
            //     previousRoundId: canUsePrevious ? prevRoundId ?? null : null,
            //     standardReferenceId: null
            // };

            const rec = getScenarioRecordFromBackend(
                currentRoundDetail,
                it.stakeholder,
                it.stakeholder_code,
                key
            );

            scenarioConfigs[key] = {
                inputOption: rec?.inputType,

                previousRoundId:
                    rec?.workflowStatus === "Approved" && rec?.inputType === "usePreviousRoundInput"
                        ? rec.roundId ?? null
                        : null,

                standardReferenceId:
                    rec?.standardInputInfo?.id
                        ? Number(rec.standardInputInfo.id)
                        : null,

                inputRequired: rec?.inputRequired,
                workflowStatus: rec?.workflowStatus,
                scenarioDescription: desc,
                revisionAttempt: rec?.revisionAttempt

                // versionSelections:
                //     it.versionSelections?.length
                //         ? it.versionSelections
                //         : [...activeVersions],

                // submissionTypes:
                //     it.submissionTypes?.length
                //         ? it.submissionTypes
                //         : ["Draft", "Final"],

                // collectDraftInput:
                //     it.collectDraftInput ?? false,

                // draftDueDate:
                //     it.draftDueDate
                //         ? new Date(it.draftDueDate)
                //         : null
            };

            // scenarioConfigs[key] = {
            //     // inputOption: it.inputOption as InputOption,
            //     // previousRoundId:
            //     //     it.inputOption === "usePreviousRoundInput" ? prevRoundId ?? null : null,
            //     // standardReferenceId: it.standardReferenceId ?? null
            // };

        });
        const savedCollectDraftInput = it.collectDraftInput ?? false;

        setEditor({
            stakeholderName: it.stakeholder!,
            stakeholderCode: it.stakeholder_code!,
            dueDate: it.dueDate ? new Date(it.dueDate) : null,
            existingScenarios: it.applicableScenarios.map((s: any) =>
                typeof s === "string" ? s : s.name
            ),
            newScenarios: [],
            scenarioConfigs,
            // notifyUsers: it.notifyPersonas ?? [],
            // notifyUsers:
            //     it.notifyPersonas?.length > 0
            //         ? it.notifyPersonas
            //         : loadedUsers,
            // additionalTeam: it.additionalTeamPersonas ?? []
            notifyUsers: (it.notifyUsers ?? []).map((u: any) => ({
                ...u,
                text: u.text || u.name,
                secondaryText: u.secondaryText || u.email,
                tertiaryText: u.tertiaryText || u.login_id || u.key,

                key: u.key || u.email
            })),
            additionalTeam: (it.additionalStakeholders ?? []).map((u: any) => ({
                ...u,
                text: u.text || u.name,
                secondaryText: u.secondaryText || u.email,
                id: u.id || buildLoginId(u.login_id || u.key)
            })),
            commonVersionSelections: savedVersion,
            collectDraftInput:
                it.collectDraftInput ?? false,

            commonDraftDueDate:
                it.draftDueDate
                    ? new Date(it.draftDueDate)
                    : null,
        });
        setSavedCollectDraftInput(savedCollectDraftInput);

        // if (it.inputOption === "useStandardInput") {
        //     await loadStandardTemplatesForStakeholder(it.stakeholderCode);
        // }

        const hasStandardScenario =
            Object.values(scenarioConfigs).some(
                cfg => cfg?.inputOption === "useStandardInput"
            );

        if (hasStandardScenario) {
            await loadStandardTemplatesForStakeholder(
                it.stakeholder_code
            );
        }


    }



    const buildLoginId = (login_id?: string) => {
        if (!login_id) return "";

        return login_id.startsWith("i:0#.f|membership|")
            ? login_id
            : `i:0#.f|membership|${login_id}`;
    };

    const mergedNotifyOptions = React.useMemo(() => {
        const map = new Map<string, IPersonaProps>();

        groupUsers.forEach(u => {
            if (u.secondaryText) {
                map.set(u.secondaryText.toLowerCase(), u);
            }
        });

        (editor?.notifyUsers ?? []).forEach(u => {
            if (u.secondaryText) {
                map.set(u.secondaryText.toLowerCase(), u);
            }
        });

        return Array.from(map.values());
    }, [groupUsers, editor?.notifyUsers]);

    function resolveStandardTitle(
        stakeholderCode: string,
        standardReferenceId?: number | null
    ) {
        if (!standardReferenceId) return null;

        return (
            standardTemplatesByStakeholder
                .get(stakeholderCode)
                ?.find(t => t.id === standardReferenceId)?.title ?? null
        );
    }

    function handleClose() {
        setToast(null);
        setEditor(null);
        setGroupUsers([]);
        setSaving(false);
        setExpandedDescriptions(new Set());
        onClose();
    }

    const allScenarioKeys = round.scenarios.map(s => s.key);
    // console.log(round.scenarios);
    const canAddMoreScenarios =
        editor ? editor.existingScenarios.length < allScenarioKeys.length : false;
    const getScenarioDescription = (key: string) => {
        const scenario = round.scenarios.find(s => s.key === key);
        return scenario?.description || "";
    };

    const toggleDescription = (key: string) => {
        setExpandedDescriptions(prev => {
            const next = new Set(prev);

            if (next.has(key)) {
                next.delete(key);
            } else {
                next.add(key);
            }

            return next;
        });
    };

    const getScenarioName = (key: string) => {
        const scenario = round.scenarios.find(s => s.key === key);
        return scenario?.key || `Dataset ${key}`;
    };

    const showStandardFields =
        currentRoundDetail?.stakeholders
            ?.find((s: any) => s.stakeholder_code === editor?.stakeholderCode)
            ?.stakeholderType
            ?.toLowerCase() === "standard";

    return (
        <LocalizationProvider dateAdapter={AdapterDateFns}>
            <Drawer
                anchor="right"
                open={open}
                onClose={handleClose}
                PaperProps={{
                    sx: {
                        width: { xs: '100%', sm: 520 },
                        p: 2,
                        pt: 9,
                    },
                }}
            >
                <Typography variant="h6" fontWeight={700}>
                    Edit Input Template
                </Typography>

                <Divider sx={{ my: 2 }} />
                {toast && (
                    <Box sx={{ mb: 2 }}>
                        <ModernAlert
                            severity={toast.severity}
                            onClose={() => setToast(null)}
                            elevated
                            gradient
                        >
                            {toast.text}
                        </ModernAlert>
                    </Box>
                )}
                <FormControl fullWidth>
                    <InputLabel
                        id="input-template-label"
                        shrink={Boolean(editor?.stakeholderCode)}
                        sx={{
                            backgroundColor: "#fff",
                            px: 0.5
                        }}
                    >
                        Input Template
                    </InputLabel>

                    <Select
                        labelId="input-template-label"
                        label="Input Template"
                        value={editor?.stakeholderCode ?? ""}
                        renderValue={(selected) => {
                            const item = round.inputTemplates.find(
                                it => it.stakeholderCode === selected
                            );

                            return item?.stakeholderName || "";
                        }}
                        onChange={async e => {
                            await loadTemplate(e.target.value);
                        }}
                    >
                        {round.inputTemplates.map(it => (
                            <MenuItem key={it.stakeholderCode} value={it.stakeholderCode}>
                                {it.stakeholderName}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                {editor && (() => {

                    const versionsToShow = inputTemplateVersions;
                    const selectedVersion =
                        versionsToShow.length === 1
                            ? versionsToShow[0]
                            : versionsToShow.find(
                                v => v.VersionNumber === editor.commonVersionSelections
                            );
                    const isDraftVersion = selectedVersion?.DraftApplicable === true;
                    //console.log("Versions:", inputTemplateVersions);

                    // console.log("Versions:", versionsToShow);
                    // console.log("Selected Version:", editor.commonVersionSelections);
                    // console.log("Matched Version:", selectedVersion);

                    return (
                        <Stack spacing={2} sx={{ mt: 2 }}>

                            {/* Version */}
                            {showStandardFields && (
                                <Box
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        minHeight: 40,
                                        px: 0.5
                                    }}
                                >
                                    <Typography
                                        variant="body1"
                                        fontWeight={600}
                                        sx={{ minWidth: 80 }}
                                    >
                                        Version:
                                    </Typography>

                                    <Typography variant="body1">
                                        {editor.commonVersionSelections || "-"}
                                    </Typography>
                                </Box>
                            )}
                            {/* Collect Draft Input */}
                            {selectedVersion?.DraftApplicable && (
                                <FormControlLabel
                                    sx={{
                                        m: 0,
                                        ml: 0,
                                        alignItems: "center"
                                    }}
                                    control={
                                        <Checkbox
                                            sx={{
                                                p: 0,
                                                mr: 1
                                            }}
                                            checked={editor.collectDraftInput ?? false}
                                            disabled={
                                                savedCollectDraftInput === true &&
                                                editor.collectDraftInput === true
                                            }
                                            onChange={(e) =>
                                                setEditor(ed =>
                                                    ed
                                                        ? {
                                                            ...ed,
                                                            collectDraftInput: e.target.checked,
                                                            commonDraftDueDate: e.target.checked
                                                                ? ed.commonDraftDueDate
                                                                : null
                                                        }
                                                        : ed
                                                )
                                            }
                                        />
                                    }
                                    label="Collect Draft Input"
                                />
                            )}

                            {/* Draft Due Date / Due Date */}
                            {showStandardFields &&
                                selectedVersion?.DraftApplicable &&
                                editor.collectDraftInput && (
                                    // <DatePicker
                                    //     label="Draft Due Date"
                                    //     value={editor.commonDraftDueDate}
                                    //     onChange={(d) =>
                                    //         setEditor(ed =>
                                    //             ed
                                    //                 ? {
                                    //                     ...ed,
                                    //                     commonDraftDueDate: d
                                    //                 }
                                    //                 : ed
                                    //         )
                                    //     }
                                    // />

                                    <DatePicker
                                        label="Draft Due Date"
                                        format="dd/MM/yyyy"
                                        value={editor.commonDraftDueDate}
                                        minDate={today}
                                        onChange={(d) => {
                                            if (!d) {
                                                setEditor(ed =>
                                                    ed
                                                        ? {
                                                            ...ed,
                                                            commonDraftDueDate: null
                                                        }
                                                        : ed
                                                );
                                                return;
                                            }

                                            const selectedDraftDate = new Date(d);
                                            selectedDraftDate.setHours(0, 0, 0, 0);

                                            // Rule 1: Draft Due Date cannot be in the past
                                            if (selectedDraftDate < today) {
                                                setToast({
                                                    severity: "error",
                                                    text: "Draft Due Date cannot be a past date."
                                                });
                                                return;
                                            }

                                            // Rule 2: Draft Due Date must be before Due Date
                                            if (editor.dueDate) {
                                                const dueDate = new Date(editor.dueDate);
                                                dueDate.setHours(0, 0, 0, 0);

                                                if (selectedDraftDate >= dueDate) {
                                                    setToast({
                                                        severity: "error",
                                                        text: "Draft Due Date must be earlier than Due Date."
                                                    });
                                                    return;
                                                }
                                            }

                                            setToast(null);

                                            setEditor(ed =>
                                                ed
                                                    ? {
                                                        ...ed,
                                                        commonDraftDueDate: d
                                                    }
                                                    : ed
                                            );
                                        }}
                                        slotProps={{
                                            textField: {
                                                fullWidth: true,
                                                required: true
                                            }
                                        }}
                                    />
                                )}
                            <DatePicker
                                label="Due Date"
                                format="dd/MM/yyyy"
                                value={editor.dueDate}
                                minDate={today}
                                onChange={(d) => {
                                    if (!d) {
                                        setEditor(ed =>
                                            ed
                                                ? {
                                                    ...ed,
                                                    dueDate: null
                                                }
                                                : ed
                                        );
                                        return;
                                    }

                                    const selectedDueDate = new Date(d);
                                    selectedDueDate.setHours(0, 0, 0, 0);

                                    // Rule 1: Due Date cannot be in the past
                                    if (selectedDueDate < today) {
                                        setToast({
                                            severity: "error",
                                            text: "Due Date cannot be a past date."
                                        });
                                        return;
                                    }

                                    // Rule 2: Draft Due Date must be before Due Date
                                    if (editor.commonDraftDueDate) {
                                        const draftDueDate = new Date(editor.commonDraftDueDate);
                                        draftDueDate.setHours(0, 0, 0, 0);

                                        if (draftDueDate >= selectedDueDate) {
                                            setToast({
                                                severity: "error",
                                                text: "Draft Due Date must be earlier than Due Date."
                                            });
                                            return;
                                        }
                                    }

                                    setToast(null);

                                    setEditor(ed =>
                                        ed
                                            ? {
                                                ...ed,
                                                dueDate: d
                                            }
                                            : ed
                                    );
                                }}
                                slotProps={{
                                    textField: {
                                        fullWidth: true,
                                        required: true
                                    }
                                }}
                            />


                            {/*
                            <Box>
                                <Typography fontWeight={600}>Existing Datasets</Typography>
                                <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap" }}>
                                    {editor.existingScenarios.map(k => (
                                        <Chip key={k} label={k} size="small" />
                                    ))}
                                </Box>
                            </Box>
                             */}


                            <Box>
                                <Typography fontWeight={600} sx={{ mb: 1 }}>
                                    Existing Datasets
                                </Typography>

                                <Stack spacing={1.5}>
                                    {editor.existingScenarios.map(k => {
                                        const description = getScenarioDescription(k);
                                        const isExpanded = expandedDescriptions.has(k);

                                        const truncatedDescription =
                                            description.length > 40
                                                ? `${description.substring(0, 40)}...`
                                                : description;

                                        return (
                                            <Box key={k}>
                                                {/* Dataset Chip */}
                                                <Chip
                                                    label={k}
                                                    size="small"
                                                    sx={{ mb: 0.5 }}
                                                />

                                                {/* Dataset Description */}
                                                {description && (
                                                    <Box sx={{ ml: 0.5, mt: 0.5 }}>
                                                        <Typography
                                                            variant="caption"
                                                            fontWeight={600}
                                                            sx={{
                                                                display: "block",
                                                                mb: 0.25
                                                            }}
                                                        >
                                                            Dataset Description
                                                        </Typography>

                                                        <Typography
                                                            variant="caption"
                                                            sx={{
                                                                color: "text.secondary",
                                                                display: "inline"
                                                            }}
                                                        >
                                                            {isExpanded
                                                                ? description
                                                                : truncatedDescription}
                                                        </Typography>

                                                        {description.length > 40 && (
                                                            <Typography
                                                                component="button"
                                                                variant="caption"
                                                                onClick={() => toggleDescription(k)}
                                                                sx={{
                                                                    ml: 0.75,
                                                                    border: "none",
                                                                    background: "none",
                                                                    padding: 0,
                                                                    color: "primary.main",
                                                                    cursor: "pointer",
                                                                    fontWeight: 600,
                                                                    fontFamily: "inherit"
                                                                }}
                                                            >
                                                                {isExpanded ? "Read less" : "Read more"}
                                                            </Typography>
                                                        )}
                                                    </Box>
                                                )}
                                            </Box>
                                        );
                                    })}
                                </Stack>
                            </Box>

                            {canAddMoreScenarios && (
                                <FormControl fullWidth variant="outlined">
                                    <InputLabel
                                        shrink
                                        sx={{
                                            backgroundColor: "#fff",
                                            px: 0.5
                                        }}
                                    >
                                        Add Datasets
                                    </InputLabel>

                                    <Select
                                        multiple
                                        displayEmpty
                                        value={editor.newScenarios}
                                        label="Add Datasets"
                                        // onChange={e =>
                                        //     setEditor(ed =>
                                        //         ed
                                        //             ? {
                                        //                 ...ed,
                                        //                 newScenarios: e.target.value as ScenarioKey[]
                                        //             }
                                        //             : ed
                                        //     )
                                        // }
                                        onChange={e =>
                                            setEditor(ed => {
                                                if (!ed) return ed;

                                                const raw = e.target.value;
                                                const selected = Array.isArray(raw)
                                                    ? (raw.filter(Boolean) as ScenarioKey[])
                                                    : [];

                                                const nextConfigs = { ...ed.scenarioConfigs };

                                                selected.forEach(sk => {
                                                    // if (!nextConfigs[sk]) {
                                                    //     nextConfigs[sk] = {
                                                    //         inputOption: "CollectInput",
                                                    //         previousRoundId: null,
                                                    //         standardReferenceId: null
                                                    //     };
                                                    // }
                                                    if (!nextConfigs[sk]) {
                                                        nextConfigs[sk] = {
                                                            inputOption: "CollectInput",
                                                            previousRoundId: null,
                                                            standardReferenceId: null,
                                                            scenarioDescription: getScenarioDescription(sk),
                                                            versionSelections: [],
                                                            submissionTypes: ["Draft", "Final"],
                                                            collectDraftInput: false,
                                                            draftDueDate: null
                                                        };
                                                    }
                                                });

                                                return {
                                                    ...ed,
                                                    newScenarios: selected,
                                                    scenarioConfigs: nextConfigs
                                                };
                                            })
                                        }
                                        sx={{
                                            minHeight: 56,
                                            display: "flex",
                                            alignItems: "center"
                                        }}
                                    >
                                        {allScenarioKeys
                                            .filter(k => !editor.existingScenarios.includes(k))
                                            .map(k => (
                                                <MenuItem key={k} value={k}>
                                                    <Box
                                                        sx={{
                                                            display: "flex",
                                                            alignItems: "center",
                                                            gap: 1,
                                                            width: "100%"
                                                        }}
                                                    >
                                                        <Typography fontWeight={500}>
                                                            {getScenarioName(k)}
                                                        </Typography>

                                                        <Typography
                                                            variant="body2"
                                                            color="text.secondary"
                                                            sx={{
                                                                maxWidth: "260px",
                                                                overflow: "hidden",
                                                                textOverflow: "ellipsis",
                                                                whiteSpace: "nowrap"
                                                            }}
                                                        >
                                                            -{
                                                                getScenarioDescription(k).length > 40
                                                                    ? getScenarioDescription(k).substring(0, 40) + "..."
                                                                    : getScenarioDescription(k)
                                                            }
                                                        </Typography>
                                                    </Box>
                                                </MenuItem>
                                            ))}
                                    </Select>
                                </FormControl>
                            )}

                            {/* {editor.newScenarios.map(sk => { */}
                            {/* {[...editor.existingScenarios, ...editor.newScenarios].map(sk => {
                            if (!sk) return null;
                            const stakeholderKey = editor.stakeholderCode.toLowerCase();
                            */}

                            {/* {editor.existingScenarios.map(sk => (
                            <Box key={sk}>
                                <Typography fontWeight={600}>
                                    Dataset {sk} (existing – locked)
                                </Typography>
                            </Box>
                        ))} */}


                            {/* {editor.newScenarios.map(sk => { */}
                            {/* {[...editor.existingScenarios, ...editor.newScenarios].map(sk => {
                             */}
                            {showStandardFields && (
                                <>
                                    {[...editor.existingScenarios, ...editor.newScenarios].map(sk => {
                                        const stakeholderKey = editor.stakeholderCode.toLowerCase();
                                        const isExisting = editor.existingScenarios.includes(sk);
                                        // const showStandard =
                                        //     templateCatalog.get(stakeholderKey)?.showStandard === true;

                                        const versionInfo =
                                            templateCatalog
                                                .get(stakeholderKey)
                                                ?.versions
                                                ?.find(
                                                    v =>
                                                        v.versionNumber ===
                                                        editor.commonVersionSelections
                                                );

                                        const showStandard =
                                            versionInfo?.showStandard === true;

                                        debugger

                                        const approvedScenario =
                                            prevRoundApprovedScenarioMap.get(stakeholderKey)?.has(sk) === true;

                                        const previousVersion =
                                            prevRoundVersionMap.get(stakeholderKey);

                                        const currentVersion =
                                            editor.commonVersionSelections || "";

                                        const canUsePrev =
                                            !isExisting &&
                                            roundNumber > 1 &&
                                            approvedScenario &&
                                            previousVersion === currentVersion;

                                        // const canUsePrev =
                                        //     !isExisting &&
                                        //     roundNumber > 1 &&
                                        //     prevRoundApprovedScenarioMap.get(stakeholderKey)?.has(sk) === true;
                                        const selectedType =
                                            editor.scenarioConfigs[sk]?.inputOption ?? "CollectInput";

                                        const inputOptions: { key: InputOption; text: string }[] = [
                                            { key: "CollectInput" as InputOption, text: "Collect Input" },
                                            ...(showStandard
                                                ? [{ key: "useStandardInput" as InputOption, text: "Use Standard Input" }]
                                                : []),
                                            ...(canUsePrev || selectedType === "usePreviousRoundInput"
                                                ? [{ key: "usePreviousRoundInput" as InputOption, text: "Use Previous Round Input" }]
                                                : [])
                                        ];


                                        return (
                                            <Box key={sk}>
                                                <FormControl fullWidth required variant="outlined">
                                                    <InputLabel
                                                        shrink
                                                        sx={{
                                                            backgroundColor: "#fff",
                                                            px: 0.5
                                                        }}
                                                    >
                                                        {`Input Type - Dataset ${sk}`}
                                                        {isExisting && " (locked)"}
                                                    </InputLabel>

                                                    <Select
                                                        label={`Input Type - Dataset ${sk}`}
                                                        value={selectedType}
                                                        disabled={isExisting}
                                                        onChange={async e => {
                                                            if (isExisting) return;
                                                            const val = e.target.value as InputOption;
                                                            setEditor(ed =>
                                                                ed
                                                                    ? {
                                                                        ...ed,
                                                                        scenarioConfigs: {
                                                                            ...ed.scenarioConfigs,
                                                                            // [sk]: {
                                                                            //     inputOption: val,
                                                                            //     previousRoundId:
                                                                            //         val === "usePreviousRoundInput"
                                                                            //             ? prevRoundId
                                                                            //             : null,
                                                                            //     standardReferenceId:
                                                                            //         val === "useStandardInput" ? null : null
                                                                            // }
                                                                            [sk]: {
                                                                                ...ed.scenarioConfigs[sk],
                                                                                inputOption: val,
                                                                                previousRoundId:
                                                                                    val === "usePreviousRoundInput" ? prevRoundId ?? null : null,
                                                                                standardReferenceId:
                                                                                    val === "useStandardInput"
                                                                                        ? ed.scenarioConfigs[sk]?.standardReferenceId ?? null
                                                                                        : null
                                                                            }
                                                                        }
                                                                    }
                                                                    : ed
                                                            );

                                                            if (val === "useStandardInput") {
                                                                await loadStandardTemplatesForStakeholder(
                                                                    editor.stakeholderCode
                                                                );
                                                            }
                                                        }}
                                                    >
                                                        {inputOptions.map(o => (
                                                            <MenuItem key={o.key} value={o.key}>
                                                                {o.text}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>
                                                </FormControl>
                                                {/* {selectedType === "CollectInput" &&
                                        hasActiveVersion && (
                                            <FormControl fullWidth required sx={{ mt: 2 }}>
                                                <InputLabel
                                                    shrink
                                                    sx={{
                                                        backgroundColor: "#fff",
                                                        px: 0.5
                                                    }}
                                                >
                                                    Status - Dataset {sk}
                                                </InputLabel>

                                                <Select
                                                    multiple
                                                    value={
                                                        editor.scenarioConfigs[sk]?.submissionTypes ??
                                                        ["Draft", "Final"]
                                                    }
                                                    renderValue={(selected) => (selected as string[]).join(", ")}
                                                    onChange={(e) => {
                                                        const value = e.target.value as string[];

                                                        // At least 1 required
                                                        if (value.length === 0) {
                                                            return;
                                                        }

                                                        setEditor(ed =>
                                                            ed
                                                                ? {
                                                                    ...ed,
                                                                    scenarioConfigs: {
                                                                        ...ed.scenarioConfigs,
                                                                        [sk]: {
                                                                            ...ed.scenarioConfigs[sk],
                                                                            submissionTypes: value
                                                                        }
                                                                    }
                                                                }
                                                                : ed
                                                        );
                                                    }}
                                                >
                                                    {["Draft", "Final"].map(v => {
                                                        const selected =
                                                            (
                                                                editor.scenarioConfigs[sk]?.submissionTypes ??
                                                                ["Draft", "Final"]
                                                            ).includes(v);

                                                        const totalSelected =
                                                            (
                                                                editor.scenarioConfigs[sk]?.submissionTypes ??
                                                                ["Draft", "Final"]
                                                            ).length;

                                                        return (
                                                            <MenuItem
                                                                key={v}
                                                                value={v}
                                                                disabled={selected && totalSelected === 1}
                                                            >
                                                                {v}
                                                            </MenuItem>
                                                        );
                                                    })}
                                                </Select>
                                            </FormControl>
                                        )} */}
                                                {/* {selectedType === "CollectInput" &&
                                        hasActiveVersion && (
                                            <FormControl fullWidth required sx={{ mt: 2 }}>
                                                <InputLabel
                                                    shrink
                                                    sx={{
                                                        backgroundColor: "#fff",
                                                        px: 0.5
                                                    }}
                                                >
                                                    Version Number - Dataset {sk}
                                                </InputLabel>

                                                <Select
                                                    multiple
                                                    value={
                                                        editor.scenarioConfigs[sk]?.versionSelections ??
                                                        filteredVersions.map(v => v.VersionNumber)
                                                    }
                                                    renderValue={(selected) => (selected as string[]).join(", ")}
                                                    onChange={(e) => {
                                                        const value = e.target.value as string[];

                                                        // Prevent removing all selections
                                                        if (value.length === 0) {
                                                            return;
                                                        }

                                                        setEditor(ed =>
                                                            ed
                                                                ? {
                                                                    ...ed,
                                                                    scenarioConfigs: {
                                                                        ...ed.scenarioConfigs,
                                                                        [sk]: {
                                                                            ...ed.scenarioConfigs[sk],
                                                                            versionSelections: value
                                                                        }
                                                                    }
                                                                }
                                                                : ed
                                                        );
                                                    }}
                                                >
                                                    {filteredVersions.map(v => {
                                                        const selected =
                                                            (
                                                                editor.scenarioConfigs[sk]?.versionSelections ??
                                                                filteredVersions
                                                            ).includes(v.VersionNumber);

                                                        const totalSelected =
                                                            (
                                                                editor.scenarioConfigs[sk]?.versionSelections ??
                                                                filteredVersions
                                                            ).length;

                                                        return (
                                                            <MenuItem
                                                                key={v.VersionNumber}
                                                                value={v.VersionNumber}
                                                                disabled={selected && totalSelected === 1}
                                                            >
                                                                {v.VersionNumber}
                                                            </MenuItem>
                                                        );
                                                    })}
                                                </Select>
                                            </FormControl>
                                        )} */}
                                                {/* {selectedType === "CollectInput" &&
                                        hasActiveVersion &&
                                        (
                                            editor.scenarioConfigs[sk]
                                                ?.submissionTypes?.includes("Draft") ||
                                            editor.scenarioConfigs[sk]?.collectDraftInput
                                        ) && (
                                            <DatePicker
                                                label={`Draft Due Date - Dataset ${sk}`}
                                                value={
                                                    editor.scenarioConfigs[sk]?.draftDueDate ?? null
                                                }
                                                onChange={(d) =>
                                                    setEditor(ed =>
                                                        ed
                                                            ? {
                                                                ...ed,
                                                                scenarioConfigs: {
                                                                    ...ed.scenarioConfigs,
                                                                    [sk]: {
                                                                        ...ed.scenarioConfigs[sk],
                                                                        draftDueDate: d
                                                                    }
                                                                }
                                                            }
                                                            : ed
                                                    )
                                                }
                                                sx={{ mt: 2, width: "100%" }}
                                            />
                                        )} */}

                                                {!isExisting && selectedType === "useStandardInput" && (
                                                    <FormControl fullWidth required sx={{ mt: 1 }}>
                                                        <InputLabel>Standard Template</InputLabel>
                                                        <Select
                                                            value={
                                                                editor.scenarioConfigs[sk]?.standardReferenceId ?? ""
                                                            }
                                                            // onChange={e =>
                                                            //     setEditor(ed =>
                                                            //         ed
                                                            //             ? {
                                                            //                 ...ed,
                                                            //                 scenarioConfigs: {
                                                            //                     ...ed.scenarioConfigs,
                                                            //                     [sk]: {
                                                            //                         ...ed.scenarioConfigs[sk],
                                                            //                         standardReferenceId: Number(e.target.value)
                                                            //                     }
                                                            //                 }
                                                            //             }
                                                            //             : ed
                                                            //     )
                                                            // }
                                                            // onChange={e =>
                                                            //     setEditor(ed => {
                                                            //         if (!ed) return ed;


                                                            //         const selected = Array.isArray(e.target.value)
                                                            //             ? (e.target.value as ScenarioKey[])
                                                            //             : [];

                                                            //         const nextConfigs = { ...ed.scenarioConfigs };

                                                            //         selected.forEach(sk => {
                                                            //             if (!nextConfigs[sk]) {
                                                            //                 nextConfigs[sk] = {
                                                            //                     inputOption: "CollectInput",
                                                            //                     previousRoundId: null,
                                                            //                     standardReferenceId: null
                                                            //                 };
                                                            //             }
                                                            //         });

                                                            //         return {
                                                            //             ...ed,
                                                            //             newScenarios: selected,
                                                            //             scenarioConfigs: nextConfigs
                                                            //         };
                                                            //     })
                                                            // }
                                                            onChange={e =>
                                                                setEditor(ed =>
                                                                    ed
                                                                        ? {
                                                                            ...ed,
                                                                            scenarioConfigs: {
                                                                                ...ed.scenarioConfigs,
                                                                                [sk]: {
                                                                                    ...ed.scenarioConfigs[sk],
                                                                                    standardReferenceId: Number(e.target.value)
                                                                                }
                                                                            }
                                                                        }
                                                                        : ed
                                                                )
                                                            }
                                                        >
                                                            {/* {(standardTemplatesByStakeholder.get(
                                                                editor.stakeholderCode
                                                            ) ?? []).map(t => (
                                                                <MenuItem key={t.id} value={t.id}>
                                                                    {t.title}
                                                                </MenuItem>
                                                            ))} */}
                                                            {
                                                                (
                                                                    standardTemplatesByStakeholder.get(
                                                                        editor.stakeholderCode
                                                                    ) ?? []
                                                                )
                                                                    .filter(
                                                                        t =>
                                                                            t.versionNumber ===
                                                                            editor.commonVersionSelections
                                                                    )
                                                                    .map(t => (
                                                                        <MenuItem key={t.id} value={t.id}>
                                                                            {t.title}
                                                                        </MenuItem>
                                                                    ))
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                )}
                                            </Box>
                                        );
                                    })}
                                </>
                            )}
                            {showStandardFields && (
                                <Box>
                                    <Autocomplete
                                        multiple
                                        // options={groupUsers}
                                        options={mergedNotifyOptions}
                                        value={editor.notifyUsers}
                                        isOptionEqualToValue={(opt, val) =>
                                            (opt.secondaryText || "").toLowerCase() ===
                                            (val.secondaryText || "").toLowerCase()
                                        }
                                        getOptionLabel={(o) => o.text || ""}
                                        onChange={(_, v) =>
                                            setEditor(ed => (ed ? { ...ed, notifyUsers: v } : ed))
                                        }
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                label="Stakeholder Users"
                                                error={
                                                    editor.notifyUsers.length === 0 &&
                                                    editor.additionalTeam.length === 0
                                                }
                                            />
                                        )}
                                    />

                                    {editor.notifyUsers.length === 0 &&
                                        editor.additionalTeam.length === 0 && (
                                            <Typography
                                                variant="caption"
                                                sx={{
                                                    color: "#d32f2f",
                                                    mt: 0.5,
                                                    ml: 1.5,
                                                    display: "block",
                                                    fontSize: "13px"
                                                }}
                                            >
                                                Required unless you add at least one Extra Input Provider
                                            </Typography>
                                        )}
                                </Box>
                            )}
                            <Box
                                sx={{
                                    "& .ms-BasePicker": {
                                        minHeight: 56,
                                        border: "1px solid rgba(0,0,0,0.23)",
                                        borderRadius: "4px",
                                        padding: "14px",
                                        backgroundColor: "#fff"
                                    },

                                    "& .ms-BasePicker:hover": {
                                        borderColor: "rgba(0,0,0,0.87)"
                                    },

                                    "& .ms-BasePicker-text": {
                                        border: "none !important",
                                        minHeight: "unset !important"
                                    },

                                    "& .ms-TextField-fieldGroup": {
                                        border: "none !important",
                                        background: "transparent"
                                    },

                                    "& .ms-BasePicker-input": {
                                        padding: "0 !important"
                                    },

                                    "& .ms-Label": {
                                        fontSize: "12px",
                                        transform: "translate(14px, -9px)",
                                        backgroundColor: "#fff",
                                        padding: "0 4px",
                                        position: "absolute",
                                        zIndex: 1
                                    }
                                }}
                            >
                                <PeoplePicker
                                    context={peoplePickerContext}
                                    titleText="Extra Input Provider"
                                    principalTypes={[PrincipalType.User]}
                                    personSelectionLimit={100}
                                    defaultSelectedUsers={editor.additionalTeam.map(
                                        p => p.secondaryText || ""
                                    )}
                                    onChange={items =>
                                        setEditor(ed => (ed ? { ...ed, additionalTeam: items } : ed))
                                    }
                                />
                            </Box>
                            {
                                toast && (
                                    <Box sx={{ mb: 2 }}>
                                        <ModernAlert
                                            severity={toast.severity}
                                            onClose={() => setToast(null)}
                                            elevated
                                            gradient
                                        >
                                            {toast.text}
                                        </ModernAlert>
                                    </Box>
                                )
                            }
                            <Stack direction="row" justifyContent="flex-end" spacing={1}>
                                <ModernButton variant="outlined" onClick={handleClose}>
                                    Cancel
                                </ModernButton>
                                <ModernButton
                                    variant="gradient"
                                    glow
                                    loading={saving}
                                    disabled={saving}
                                    onClick={async () => {
                                        try {
                                            setSaving(true);

                                            const hasUsers = editor.notifyUsers.length > 0;
                                            const hasAdditional = editor.additionalTeam.length > 0;

                                            const allScenarios = [
                                                ...editor.existingScenarios,
                                                ...editor.newScenarios
                                            ];

                                            const hasCollectInput = allScenarios.some(sk => {
                                                const cfg = editor.scenarioConfigs[sk];
                                                return (cfg?.inputOption ?? "CollectInput") === "CollectInput";
                                            });

                                            if (hasCollectInput && !editor.dueDate) {
                                                setToast({
                                                    severity: "error",
                                                    text: `Stakeholder "${editor.stakeholderName}" is missing Due Date.`
                                                });
                                                setSaving(false);
                                                return;
                                            }

                                            if (hasCollectInput && !hasUsers && !hasAdditional) {
                                                setToast({
                                                    severity: "error",
                                                    text: `Stakeholder "${editor.stakeholderName}": Please select either:
- At least one Stakeholder User OR
- At least one Extra Input Provider`
                                                });
                                                setSaving(false);
                                                return;
                                            }

                                            setToast(null);

                                            const updatedConfigs = { ...editor.scenarioConfigs };

                                            Object.keys(updatedConfigs).forEach(k => {
                                                const sk = k as ScenarioKey;
                                                const cfg = updatedConfigs[sk];

                                                if (cfg?.inputOption === "useStandardInput") {
                                                    const title = resolveStandardTitle(
                                                        editor.stakeholderCode,
                                                        cfg.standardReferenceId
                                                    );

                                                    if (title) {
                                                        updatedConfigs[sk] = {
                                                            ...cfg,
                                                            standardInputTemplateTitle: title
                                                        };
                                                    }
                                                }
                                            });

                                            // await onSaveSuccess(editor);

                                            const selectedVersion = inputTemplateVersions.find(
                                                v => v.VersionNumber === editor.commonVersionSelections
                                            );

                                            if (
                                                selectedVersion?.DraftApplicable &&
                                                editor.collectDraftInput &&
                                                !editor.commonDraftDueDate
                                            ) {
                                                setToast({
                                                    severity: "error",
                                                    text: "Draft Due Date is required."
                                                });

                                                setSaving(false);
                                                return;
                                            }

                                            if (editor.commonDraftDueDate) {
                                                const draftDueDate = new Date(editor.commonDraftDueDate);
                                                draftDueDate.setHours(0, 0, 0, 0);

                                                if (draftDueDate < today) {
                                                    setToast({
                                                        severity: "error",
                                                        text: "Draft Due Date cannot be a past date."
                                                    });

                                                    setSaving(false);
                                                    return;
                                                }
                                            }

                                            const cleanedScenarioConfigs: Partial<
                                                Record<ScenarioKey, ScenarioConfig>
                                            > = {};

                                            Object.entries(updatedConfigs).forEach(([key, cfg]) => {
                                                cleanedScenarioConfigs[key as ScenarioKey] = {
                                                    ...cfg,

                                                    versionSelections: showStandardFields
                                                        ? cfg.versionSelections
                                                        : undefined,

                                                    submissionTypes: showStandardFields
                                                        ? cfg.submissionTypes
                                                        : undefined,

                                                    collectDraftInput: showStandardFields
                                                        ? cfg.collectDraftInput
                                                        : undefined,

                                                    draftDueDate: showStandardFields
                                                        ? cfg.draftDueDate
                                                        : undefined
                                                };
                                            });


                                            // await onSaveSuccess({
                                            //     ...editor,
                                            //     scenarioConfigs: updatedConfigs
                                            // });

                                            // console.log("Before onSaveSuccess");
                                            // console.log("Editor", editor);
                                            // console.log("Cleaned Configs", cleanedScenarioConfigs);

                                            for (const sk of allScenarios) {
                                                const cfg = updatedConfigs[sk];

                                                if (
                                                    cfg?.inputOption === "useStandardInput" &&
                                                    !cfg.standardReferenceId
                                                ) {
                                                    setToast({
                                                        severity: "error",
                                                        text: `Please select a Standard Template for Dataset ${sk}.`
                                                    });

                                                    setSaving(false);
                                                    return;
                                                }
                                            }
                                            await onSaveSuccess({

                                                ...editor,

                                                scenarioConfigs: cleanedScenarioConfigs,

                                                commonVersionSelections: editor.commonVersionSelections,
                                                collectDraftInput: editor.collectDraftInput,
                                                commonDraftDueDate: editor.commonDraftDueDate
                                            });
                                            //console.log("After onSaveSuccess");

                                            handleClose();

                                        } catch (e: any) {
                                            console.error(e);

                                            setToast({
                                                severity: "error",
                                                text: e?.message || "Failed to save input template."
                                            });

                                            setSaving(false);
                                        }
                                    }}
                                >
                                    Save
                                </ModernButton>

                            </Stack>

                        </Stack>
                    );
                })()}

            </Drawer>
        </LocalizationProvider>
    );
};