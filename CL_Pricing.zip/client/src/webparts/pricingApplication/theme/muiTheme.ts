/**
 * Modern Material-UI Theme for CL Pricing Application
 * Advanced design system with sophisticated styling
 */

import { createTheme, ThemeOptions, alpha } from '@mui/material/styles';

// Brand colors
const brandColors = {
  primary: {
    main: '#1e1450',
    light: '#3d2fa0',
    dark: '#0d0828',
    contrastText: '#ffffff',
  },
  secondary: {
    main: '#ececff',
    light: '#f5f5ff',
    dark: '#d9d9ff',
    contrastText: '#1e1450',
  },
  accent: {
    main: '#107C10',
    light: '#13a313',
    dark: '#0c5e0c',
    contrastText: '#ffffff',
  },
};

// Create advanced MUI theme
export const muiTheme = createTheme({
  palette: {
    mode: 'light',
    primary: brandColors.primary,
    secondary: brandColors.secondary,
    success: {
      main: '#107C10',
      light: '#dff6dd',
      dark: '#0c5e0c',
      contrastText: '#ffffff',
    },
    error: {
      main: '#d13438',
      light: '#fde7e9',
      dark: '#a4262c',
      contrastText: '#ffffff',
    },
    warning: {
      main: '#ffb900',
      light: '#fff4ce',
      dark: '#f59b00',
      contrastText: '#323130',
    },
    info: {
      main: '#0078d4',
      light: '#deecf9',
      dark: '#005a9e',
      contrastText: '#ffffff',
    },
    background: {
      default: '#fafafa',
      paper: '#ffffff',
    },
    text: {
      primary: '#323130',
      secondary: '#605e5c',
      disabled: '#d2d0ce',
    },
    divider: '#e1dfdd',
  },

  // Advanced typography with custom font scale
  typography: {
    fontFamily: '"Inter", "Segoe UI", "Roboto", "Helvetica Neue", sans-serif',
    h1: {
      fontSize: '2.5rem',
      fontWeight: 700,
      lineHeight: 1.2,
      letterSpacing: '-0.02em',
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 700,
      lineHeight: 1.3,
      letterSpacing: '-0.01em',
    },
    h3: {
      fontSize: '1.75rem',
      fontWeight: 600,
      lineHeight: 1.3,
      letterSpacing: '-0.01em',
    },
    h4: {
      fontSize: '1.5rem',
      fontWeight: 600,
      lineHeight: 1.4,
    },
    h5: {
      fontSize: '1.25rem',
      fontWeight: 600,
      lineHeight: 1.4,
    },
    h6: {
      fontSize: '1.125rem',
      fontWeight: 600,
      lineHeight: 1.4,
    },
    subtitle1: {
      fontSize: '1rem',
      fontWeight: 500,
      lineHeight: 1.5,
    },
    subtitle2: {
      fontSize: '0.875rem',
      fontWeight: 500,
      lineHeight: 1.5,
    },
    body1: {
      fontSize: '1rem',
      lineHeight: 1.6,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.6,
    },
    button: {
      fontSize: '0.875rem',
      fontWeight: 600,
      textTransform: 'none',
      letterSpacing: '0.02em',
    },
    caption: {
      fontSize: '0.75rem',
      lineHeight: 1.5,
    },
    overline: {
      fontSize: '0.75rem',
      fontWeight: 600,
      lineHeight: 2,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
    },
  },

  // Advanced shape with custom border radius
  shape: {
    borderRadius: 3,
  },

  // Sophisticated shadow system
  shadows: [
    'none',
    '0px 2px 4px rgba(0, 0, 0, 0.05)',
    '0px 4px 8px rgba(0, 0, 0, 0.08)',
    '0px 6px 12px rgba(0, 0, 0, 0.1)',
    '0px 8px 16px rgba(0, 0, 0, 0.12)',
    '0px 10px 20px rgba(0, 0, 0, 0.14)',
    '0px 12px 24px rgba(0, 0, 0, 0.16)',
    '0px 14px 28px rgba(0, 0, 0, 0.18)',
    '0px 16px 32px rgba(0, 0, 0, 0.2)',
    '0px 18px 36px rgba(0, 0, 0, 0.22)',
    '0px 20px 40px rgba(0, 0, 0, 0.24)',
    '0px 22px 44px rgba(0, 0, 0, 0.26)',
    '0px 24px 48px rgba(0, 0, 0, 0.28)',
    '0px 26px 52px rgba(0, 0, 0, 0.3)',
    '0px 28px 56px rgba(0, 0, 0, 0.32)',
    '0px 30px 60px rgba(0, 0, 0, 0.34)',
    '0px 32px 64px rgba(0, 0, 0, 0.36)',
    '0px 34px 68px rgba(0, 0, 0, 0.38)',
    '0px 36px 72px rgba(0, 0, 0, 0.4)',
    '0px 38px 76px rgba(0, 0, 0, 0.42)',
    '0px 40px 80px rgba(0, 0, 0, 0.44)',
    '0px 42px 84px rgba(0, 0, 0, 0.46)',
    '0px 44px 88px rgba(0, 0, 0, 0.48)',
    '0px 46px 92px rgba(0, 0, 0, 0.5)',
    '0px 48px 96px rgba(0, 0, 0, 0.52)',
  ],

  // Advanced component customization
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          scrollbarColor: '#c1c1c1 #f1f1f1',
          '&::-webkit-scrollbar, & *::-webkit-scrollbar': {
            width: 8,
            height: 8,
          },
          '&::-webkit-scrollbar-thumb, & *::-webkit-scrollbar-thumb': {
            borderRadius: 8,
            backgroundColor: '#c1c1c1',
            border: '2px solid #f1f1f1',
          },
          '&::-webkit-scrollbar-thumb:hover, & *::-webkit-scrollbar-thumb:hover': {
            backgroundColor: '#a8a8a8',
          },
        },
      },
    },

    // Elevated Button styling
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          padding: '10px 24px',
          fontSize: '0.875rem',
          fontWeight: 600,
          boxShadow: 'none',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:hover': {
            boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
            transform: 'translateY(-2px)',
          },
        },
        contained: {
          '&:hover': {
            boxShadow: '0px 6px 16px rgba(0, 0, 0, 0.2)',
          },
        },
        containedPrimary: {
          background: `linear-gradient(135deg, ${brandColors.primary.main} 0%, ${brandColors.primary.light} 100%)`,
          '&:hover': {
            background: `linear-gradient(135deg, ${brandColors.primary.dark} 0%, ${brandColors.primary.main} 100%)`,
          },
        },
        outlined: {
          borderWidth: 2,
          '&:hover': {
            borderWidth: 2,
            backgroundColor: alpha(brandColors.primary.main, 0.04),
          },
        },
        text: {
          '&:hover': {
            backgroundColor: alpha(brandColors.primary.main, 0.08),
          },
        },
      },
    },

    // Modern Card styling
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          border: '1px solid rgba(0, 0, 0, 0.06)',
          '&:hover': {
            boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.12)',
            transform: 'translateY(-4px)',
          },
        },
      },
    },

    // Sophisticated Paper
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
          padding: 0
        },
        elevation1: {
          boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
        },
        elevation2: {
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
        },
        elevation3: {
          boxShadow: '0px 6px 16px rgba(0, 0, 0, 0.12)',
        },
        rounded: {
          borderRadius: 3,
        },
      },
    },

    // Modern TextField
    MuiTextField: {
      defaultProps: {
        variant: 'outlined',
      },
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 8,
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            '&:hover': {
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: brandColors.primary.light,
              },
            },
            '&.Mui-focused': {
              '& .MuiOutlinedInput-notchedOutline': {
                borderWidth: 2,
                borderColor: brandColors.primary.main,
              },
            },
          },
        },
      },
    },

    // Chip with modern styling
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontWeight: 500,
          fontSize: '0.813rem',
          height: 28,
        },
        filled: {
          backgroundColor: alpha(brandColors.primary.main, 0.1),
          color: brandColors.primary.dark,
          '&:hover': {
            backgroundColor: alpha(brandColors.primary.main, 0.2),
          },
        },
      },
    },

    // Enhanced Table
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderBottom: `1px solid ${alpha('#000', 0.06)}`,
        },
        head: {
          fontWeight: 600,
          backgroundColor: alpha(brandColors.primary.main, 0.03),
          color: brandColors.primary.dark,
        },
      },
    },

    // Modern Dialog
    MuiDialog: {
      styleOverrides: {
        paper: {
          borderRadius: 16,
          boxShadow: '0px 20px 60px rgba(0, 0, 0, 0.3)',
        },
      },
    },

    // Sophisticated AppBar
    MuiAppBar: {
      styleOverrides: {
        root: {
          boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
          backgroundColor: '#ffffff',
          color: brandColors.primary.dark,
        },
      },
    },

    // Modern Tab styling
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          fontSize: '0.938rem',
          minHeight: 48,
          '&.Mui-selected': {
            color: brandColors.primary.main,
          },
        },
      },
    },

    // Enhanced List Items
    MuiListItemButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          marginBottom: 4,
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:hover': {
            backgroundColor: alpha(brandColors.primary.main, 0.08),
            transform: 'translateX(4px)',
          },
          '&.Mui-selected': {
            backgroundColor: alpha(brandColors.primary.main, 0.12),
            borderLeft: `3px solid ${brandColors.primary.main}`,
            '&:hover': {
              backgroundColor: alpha(brandColors.primary.main, 0.16),
            },
          },
        },
      },
    },

    // Modern Badge
    MuiBadge: {
      styleOverrides: {
        badge: {
          fontWeight: 600,
          fontSize: '0.688rem',
        },
      },
    },

    // Sophisticated Tooltip
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          backgroundColor: brandColors.primary.dark,
          fontSize: '0.813rem',
          padding: '8px 12px',
          borderRadius: 6,
          boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.2)',
        },
        arrow: {
          color: brandColors.primary.dark,
        },
      },
    },

    // Modern Switch
    MuiSwitch: {
      styleOverrides: {
        root: {
          width: 46,
          height: 26,
          padding: 0,
        },
        switchBase: {
          padding: 3,
          '&.Mui-checked': {
            transform: 'translateX(20px)',
            '& + .MuiSwitch-track': {
              backgroundColor: brandColors.accent.main,
              opacity: 1,
            },
          },
        },
        thumb: {
          width: 20,
          height: 20,
          boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.2)',
        },
        track: {
          borderRadius: 13,
          backgroundColor: '#e1dfdd',
          opacity: 1,
        },
      },
    },

    // Enhanced Stepper
    MuiStepIcon: {
      styleOverrides: {
        root: {
          fontSize: '1.75rem',
          '&.Mui-active': {
            color: brandColors.primary.main,
            filter: `drop-shadow(0px 4px 8px ${alpha(brandColors.primary.main, 0.3)})`,
          },
          '&.Mui-completed': {
            color: brandColors.accent.main,
          },
        },
      },
    },

    // Modern Alert
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          padding: '12px 16px',
        },
        standardSuccess: {
          backgroundColor: alpha(brandColors.accent.main, 0.1),
          color: brandColors.accent.dark,
        },
        standardError: {
          backgroundColor: alpha('#d13438', 0.1),
          color: '#a4262c',
        },
        standardWarning: {
          backgroundColor: alpha('#ffb900', 0.1),
          color: '#f59b00',
        },
        standardInfo: {
          backgroundColor: alpha('#0078d4', 0.1),
          color: '#005a9e',
        },
      },
    },
  },

  // Advanced breakpoints
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1280,
      xl: 1920,
    },
  },

  // Custom spacing
  spacing: 8,

} as ThemeOptions);

// Export theme utilities
export const muiColors = brandColors;
export const muiSpacing = (factor: number) => `${factor * 8}px`;

export default muiTheme;
