/**
 * Custom Fluent UI Theme for CL Pricing Application
 * Based on brand colors and design tokens
 */

import { createTheme, Theme } from '@fluentui/react';
import { colors } from './tokens';

/**
 * Custom theme configuration
 * Replaces all hardcoded colors throughout the application
 */
export const appTheme: Theme = createTheme({
  palette: {
    // Primary color (deep purple/navy #1e1450)
    themePrimary: colors.primary,
    themeLighterAlt: '#f5f4f9',
    themeLighter: '#d8d5e8',
    themeLight: '#b8b3d5',
    themeTertiary: '#7a71ab',
    themeSecondary: '#483d87',
    themeDarkAlt: colors.primaryDark,
    themeDark: '#120e31',
    themeDarker: colors.primaryDarker,

    // Accent color (success green #107C10)
    accent: colors.accent,

    // Neutral colors
    neutralPrimary: colors.neutralPrimary,
    neutralPrimaryAlt: '#3b3a39',
    neutralSecondary: colors.neutralSecondary,
    neutralSecondaryAlt: '#8a8886',
    neutralTertiary: colors.neutralTertiary,
    neutralTertiaryAlt: '#c8c6c4',
    neutralQuaternary: colors.neutralQuaternary,
    neutralQuaternaryAlt: colors.neutralQuaternaryAlt,
    neutralLight: colors.neutralLight,
    neutralLighter: colors.neutralLighter,
    neutralLighterAlt: colors.neutralLighterAlt,

    // Background colors
    white: colors.white,
    black: colors.black,

    // Semantic colors
    red: colors.error,
    redDark: colors.errorDark,

    green: colors.success,
    greenLight: colors.successLight,
    greenDark: colors.successDark,

    yellow: colors.warning,
    yellowLight: colors.warningLight,
    yellowDark: colors.warningDark,

    // Additional theme colors
    blackTranslucent40: 'rgba(0, 0, 0, 0.4)',
    whiteTranslucent40: 'rgba(255, 255, 255, 0.4)',
  },

  semanticColors: {
    // Body
    bodyBackground: colors.white,
    bodyBackgroundHovered: colors.neutralLighterAlt,
    bodyBackgroundChecked: colors.neutralLight,
    bodyStandoutBackground: colors.neutralLighterAlt,
    bodyFrameBackground: colors.white,
    bodyFrameDivider: colors.neutralLight,
    bodyText: colors.textPrimary,
    bodyTextChecked: colors.textPrimary,
    bodySubtext: colors.textSecondary,
    bodyDivider: colors.neutralLight,

    // Links
    link: colors.primary,
    linkHovered: colors.primaryDark,

    // Disabled states
    disabledBackground: colors.neutralLighter,
    disabledText: colors.textDisabled,
    disabledBodyText: colors.textDisabled,
    disabledSubtext: colors.neutralQuaternary,
    disabledBodySubtext: colors.neutralTertiary,

    // Focus
    focusBorder: colors.primary,

    // Variant borders
    variantBorder: colors.neutralLight,
    variantBorderHovered: colors.neutralTertiary,

    // Buttons (default)
    buttonBackground: colors.white,
    buttonBackgroundChecked: colors.neutralTertiary,
    buttonBackgroundHovered: colors.neutralLighter,
    buttonBackgroundCheckedHovered: colors.neutralLight,
    buttonBackgroundPressed: colors.neutralLight,
    buttonBackgroundDisabled: colors.neutralLighter,
    buttonBorder: colors.neutralSecondary,
    buttonText: colors.neutralPrimary,
    buttonTextHovered: colors.neutralPrimary,
    buttonTextChecked: colors.neutralDark,
    buttonTextCheckedHovered: colors.black,
    buttonTextPressed: colors.neutralDark,
    buttonTextDisabled: colors.neutralTertiary,
    buttonBorderDisabled: colors.neutralLighter,

    // Primary buttons
    primaryButtonBackground: colors.primary,
    primaryButtonBackgroundHovered: colors.primaryDark,
    primaryButtonBackgroundPressed: colors.primaryDarker,
    primaryButtonBackgroundDisabled: colors.neutralLighter,
    primaryButtonBorder: 'transparent',
    primaryButtonText: colors.white,
    primaryButtonTextHovered: colors.white,
    primaryButtonTextPressed: colors.white,
    primaryButtonTextDisabled: colors.neutralTertiary,

    // Accent buttons
    accentButtonBackground: colors.accent,
    accentButtonText: colors.white,

    // Input controls
    inputBackground: colors.white,
    inputBackgroundChecked: colors.primary,
    inputBackgroundCheckedHovered: colors.primaryDark,
    inputForegroundChecked: colors.white,
    inputBorder: colors.neutralSecondary,
    inputBorderHovered: colors.neutralPrimary,
    inputText: colors.textPrimary,
    inputTextHovered: colors.textPrimary,
    inputPlaceholderText: colors.textSecondary,
    inputFocusBorderAlt: colors.primary,
    inputIcon: colors.primary,
    inputIconHovered: colors.primaryDark,
    inputIconDisabled: colors.neutralTertiary,

    // Lists and menus
    listBackground: colors.white,
    listText: colors.textPrimary,
    listItemBackgroundHovered: colors.neutralLighter,
    listItemBackgroundChecked: colors.neutralLight,
    listItemBackgroundCheckedHovered: colors.neutralQuaternaryAlt,
    listHeaderBackgroundHovered: colors.neutralLighter,
    listHeaderBackgroundPressed: colors.neutralLight,

    // Menu
    menuBackground: colors.white,
    menuDivider: colors.neutralLight,
    menuIcon: colors.primary,
    menuHeader: colors.primary,
    menuItemBackgroundHovered: colors.neutralLighter,
    menuItemBackgroundPressed: colors.neutralLight,
    menuItemText: colors.textPrimary,
    menuItemTextHovered: colors.textPrimary,

    // Error and warning states
    errorBackground: colors.errorLight,
    errorText: colors.errorDark,
    errorIcon: colors.error,

    warningBackground: colors.warningLight,
    warningText: colors.neutralPrimary,
    warningHighlight: colors.warning,
    warningIcon: colors.warningDark,

    successBackground: colors.successLight,
    successIcon: colors.success,
    successText: colors.successDark,

    infoBackground: colors.infoLight,
    infoIcon: colors.info,

    // Message bar
    messageText: colors.textPrimary,
    messageLinkHovered: colors.primaryDark,

    // Cards and surfaces
    cardStandoutBackground: colors.white,
    cardShadow: '0 1.6px 3.6px 0 rgba(0, 0, 0, 0.132), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.108)',
  },

  fonts: {
    tiny: {
      fontSize: '10px',
      fontWeight: 400,
    },
    xSmall: {
      fontSize: '12px',
      fontWeight: 400,
    },
    small: {
      fontSize: '14px',
      fontWeight: 400,
    },
    smallPlus: {
      fontSize: '14px',
      fontWeight: 500,
    },
    medium: {
      fontSize: '16px',
      fontWeight: 400,
    },
    mediumPlus: {
      fontSize: '18px',
      fontWeight: 400,
    },
    large: {
      fontSize: '20px',
      fontWeight: 400,
    },
    xLarge: {
      fontSize: '24px',
      fontWeight: 500,
    },
    xLargePlus: {
      fontSize: '28px',
      fontWeight: 600,
    },
    xxLarge: {
      fontSize: '32px',
      fontWeight: 600,
    },
    xxLargePlus: {
      fontSize: '36px',
      fontWeight: 600,
    },
    superLarge: {
      fontSize: '42px',
      fontWeight: 600,
    },
    mega: {
      fontSize: '68px',
      fontWeight: 600,
    },
  },

  spacing: {
    s2: '4px',
    s1: '8px',
    m: '16px',
    l1: '20px',
    l2: '32px',
  },

  effects: {
    elevation4: '0 1.6px 3.6px 0 rgba(0, 0, 0, 0.132), 0 0.3px 0.9px 0 rgba(0, 0, 0, 0.108)',
    elevation8: '0 3.2px 7.2px 0 rgba(0, 0, 0, 0.132), 0 0.6px 1.8px 0 rgba(0, 0, 0, 0.108)',
    elevation16: '0 6.4px 14.4px 0 rgba(0, 0, 0, 0.132), 0 1.2px 3.6px 0 rgba(0, 0, 0, 0.108)',
    elevation64: '0 25.6px 57.6px 0 rgba(0, 0, 0, 0.22), 0 4.8px 14.4px 0 rgba(0, 0, 0, 0.18)',
    roundedCorner2: '2px',
    roundedCorner4: '4px',
    roundedCorner6: '6px',
  },
});

/**
 * Helper function to get theme colors for inline styles
 * Use this when you need to access theme colors in component logic
 */
export const getThemeColors = () => colors;
