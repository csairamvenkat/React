/**
 * Design Tokens for CL Pricing Application
 * Central source of truth for all design values
 */

// Brand Colors
export const colors = {
  // Primary brand color - deep purple/navy
  primary: '#1e1450',
  primaryLight: '#2d1f78',
  primaryDark: '#150f3a',
  primaryLighter: '#3d2fa0',
  primaryDarker: '#0d0828',

  // Secondary brand color - light lavender
  secondary: '#ececff',
  secondaryLight: '#f5f5ff',
  secondaryDark: '#d9d9ff',

  // Accent color - success green
  accent: '#107C10',
  accentLight: '#13a313',
  accentDark: '#0c5e0c',

  // Semantic colors
  success: '#107C10',
  successLight: '#dff6dd',
  successDark: '#0c5e0c',

  error: '#d13438',
  errorLight: '#fde7e9',
  errorDark: '#a4262c',

  warning: '#ffb900',
  warningLight: '#fff4ce',
  warningDark: '#f59b00',

  info: '#0078d4',
  infoLight: '#deecf9',
  infoDark: '#005a9e',

  // Neutral colors (gray scale)
  neutralPrimary: '#323130',
  neutralSecondary: '#605e5c',
  neutralTertiary: '#a19f9d',
  neutralQuaternary: '#d2d0ce',
  neutralQuaternaryAlt: '#e1dfdd',
  neutralLight: '#edebe9',
  neutralLighter: '#f3f2f1',
  neutralLighterAlt: '#faf9f8',
  neutralDark: '#201f1e',

  white: '#ffffff',
  black: '#000000',

  // Background colors
  backgroundPrimary: '#ffffff',
  backgroundSecondary: '#faf9f8',
  backgroundTertiary: '#f3f2f1',

  // Border colors
  borderPrimary: '#e1dfdd',
  borderSecondary: '#edebe9',

  // Text colors
  textPrimary: '#323130',
  textSecondary: '#605e5c',
  textTertiary: '#a19f9d',
  textDisabled: '#d2d0ce',
  textOnPrimary: '#ffffff',
  textOnAccent: '#ffffff',
};

// Spacing System (4px base unit)
export const spacing = {
  xs: '4px',
  sm: '8px',
  md: '16px',
  lg: '24px',
  xl: '32px',
  xxl: '48px',
  xxxl: '64px',
};

// Typography Scale
export const typography = {
  fontSize: {
    xs: '12px',
    sm: '14px',
    md: '16px',
    lg: '18px',
    xl: '20px',
    xxl: '24px',
    xxxl: '32px',
  },
  fontWeight: {
    regular: 400,
    medium: 500,
    semiBold: 600,
    bold: 700,
  },
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
};

// Responsive Breakpoints
export const breakpoints = {
  mobile: 480,
  tablet: 768,
  desktop: 1024,
  wide: 1440,
};

// Media Queries
export const mediaQueries = {
  mobile: `@media (max-width: ${breakpoints.tablet - 1}px)`,
  tablet: `@media (min-width: ${breakpoints.tablet}px) and (max-width: ${breakpoints.desktop - 1}px)`,
  desktop: `@media (min-width: ${breakpoints.desktop}px)`,
  wide: `@media (min-width: ${breakpoints.wide}px)`,

  // Mobile-first approach
  mobileAndUp: `@media (min-width: ${breakpoints.mobile}px)`,
  tabletAndUp: `@media (min-width: ${breakpoints.tablet}px)`,
  desktopAndUp: `@media (min-width: ${breakpoints.desktop}px)`,
};

// Border Radius
export const borderRadius = {
  none: '0',
  sm: '2px',
  md: '4px',
  lg: '8px',
  xl: '12px',
  round: '50%',
};

// Modern Shadows with depth
export const shadows = {
  none: 'none',
  xs: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
  sm: '0 2px 4px 0 rgba(0, 0, 0, 0.08)',
  md: '0 4px 12px 0 rgba(0, 0, 0, 0.1)',
  lg: '0 8px 24px 0 rgba(0, 0, 0, 0.12)',
  xl: '0 16px 48px 0 rgba(0, 0, 0, 0.15)',
  card: '0 2px 8px 0 rgba(0, 0, 0, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.04)',
  cardHover: '0 8px 24px 0 rgba(0, 0, 0, 0.12), 0 2px 8px 0 rgba(0, 0, 0, 0.08)',
  dialog: '0 20px 60px 0 rgba(0, 0, 0, 0.2), 0 8px 24px 0 rgba(0, 0, 0, 0.12)',
  button: '0 2px 4px 0 rgba(0, 0, 0, 0.1)',
  buttonHover: '0 4px 12px 0 rgba(0, 0, 0, 0.15)',
  inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)',
  // Colored shadows for primary elements
  primaryGlow: '0 4px 20px 0 rgba(30, 20, 80, 0.25)',
  accentGlow: '0 4px 20px 0 rgba(16, 124, 16, 0.25)',
};

// Z-Index Scale
export const zIndex = {
  dropdown: 1000,
  sticky: 1020,
  modal: 1050,
  popover: 1060,
  tooltip: 1070,
};

// Smooth Transitions
export const transitions = {
  fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
  base: '250ms cubic-bezier(0.4, 0, 0.2, 1)',
  slow: '350ms cubic-bezier(0.4, 0, 0.2, 1)',
  bounce: '500ms cubic-bezier(0.68, -0.55, 0.265, 1.55)',
  smooth: '300ms cubic-bezier(0.4, 0, 0.6, 1)',
};

// Container Max Widths
export const containerWidths = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  full: '100%',
};
