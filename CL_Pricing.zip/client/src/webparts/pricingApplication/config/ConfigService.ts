import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface TenantConfig {
    siteBaseUrl: string;
    siteUrl: string;
    serverRelativeLibrary: string;
    serverRelativeUrl: string;
    flowUrls: {};
    apiResource?: string;
    apiBaseUrl?: string;
}

export async function loadTenantConfig(context: WebPartContext): Promise<TenantConfig> {
    return {
        siteBaseUrl: "https://dpworld.sharepoint.com/",
        siteUrl: context.pageContext.web.absoluteUrl,
        serverRelativeLibrary: context.pageContext.site.serverRelativeUrl+"/EUR/",
        serverRelativeUrl: context.pageContext.site.serverRelativeUrl,
        flowUrls: {
            OpportunityCreationFlow: "https://default2bd16c9b7e2142749c067919f7647b.bb.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/95c5b2f7a79f4febb4a12382dc4665ba/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=-VabPKHbIxbBWsElv54KqNienUDYKwOB1C4QqLRKQXo", // v2 URL
            RoundCreationFlow: "https://default2bd16c9b7e2142749c067919f7647b.bb.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/5ef3b2d1f9c64b19947c6a2da0c2f463/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=UWRywhAQ1IGXNduHqZFM6eURzukEKaKlQV-eIl_Y_Kg", // v2 URL
            ApprovalFlow : "https://default2bd16c9b7e2142749c067919f7647b.bb.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/eae7377e9ce64fef8b184f43f9a46798/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=B2-b9Xq4OzXOZ2EEm4yWOLByEGgiltno9T7fnz5HQso", // v2 URL
            outputGenerationFlow: "https://default2bd16c9b7e2142749c067919f7647b.bb.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/00847f2352584596af429f5db5979247/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=WiybmCQ8dDza1TJwHEjvFEO8Wz11Q6xVDbVM16JM-3Y", // v2 URL
        },
        apiResource: "api://1adb1c92-7181-447b-ae47-d5d5bbab1b65", // uat
        apiBaseUrl: "https://hoappsuat.dpworld.com/CLPricing/api/api", // uat
        // apiBaseUrl: "http://localhost:5100/api", // local
    }
}