import { AadHttpClient, AadHttpClientFactory, HttpClient, HttpClientResponse, IHttpClientOptions } from '@microsoft/sp-http';
import { Opportunity, GenerateOutputLogRequest, Round, Template, TemplatePost, GenerateOutput, UpdateInputTemplatePayload, StandardTemplate, FileItem, RejectStakeholderInput, RoundMainInfo, OutputLog, ChangeVersionPayload } from '../components/store/Models';
export interface Paged<T> { items: T[]; total: number; }
export interface ApiConfig { resource: string; baseUrl: string; }


export class ApiDataProvider {

  constructor(private context: any, private cfg: ApiConfig) { }

  private mockMode = false;

  private mockOpportunities: Opportunity[] = [
    {
      id: 1,
      title: "",
      region: 'EUR',
      leadNumber: '009980',
      customer: 'Amazon',
      opportunityName: '009980 Amazon Giessen Healthcare AT',
      country: 'Austria (AT)',
      countryCode: 'AT',
      status: 'In-Progress',
      createdBy: 'Bilal Ahmed',
      createdDate: '2026-01-19',
      bid_team_members: [],
      project_name: ''
    },
    {
      id: 2,
      title: '',
      region: 'EUR',
      leadNumber: '012131',
      customer: 'Amazon',
      opportunityName: '012131 Amazon Inb & Outb Transport PL',
      country: 'Poland (PL)',
      countryCode: 'PL',
      status: 'In-Progress',
      createdBy: 'Muhammad Asif',
      createdDate: '2026-01-19',
      bid_team_members: [],
      project_name: ''
    }
  ];

  private mockRounds: Round[] = [
    {
      // id: 101, 
      opportunityId: 1, name: 'Round 1', createdOn: '2026-01-05'
    },
    {
      // id: 102,
      opportunityId: 1, name: 'Round 2', createdOn: '2026-01-06'
    },
    {
      // id: 201,
      opportunityId: 2, name: 'Round Alpha', createdOn: '2026-01-07'
    }
  ];

  private mockTemplates: Template[] = [
    { id: 1001, roundId: 1, name: 'Template A', createdOn: '2026-01-05' },
    { id: 1002, roundId: 1, name: 'Template B', createdOn: '2026-01-06' },
    { id: 2001, roundId: 1, name: 'Template X', createdOn: '2026-01-07' }
  ];

  private async client(): Promise<AadHttpClient> {
    return this.context.aadHttpClientFactory.getClient(this.cfg.resource);
  }

  // private async get(path: string): Promise<any> {
  //   const c = await this.client();
  //   const res: HttpClientResponse = await c.get(`${this.cfg.baseUrl}${path}`, AadHttpClient.configurations.v1);
  //   if (!res.ok) throw new Error(`GET ${path} failed ${res.status}`);
  //   return res.json();
  // }


  private async get<T>(path: string, signal?: AbortSignal): Promise<T> {
    const c = await this.client();
    const url = `${this.cfg.baseUrl}${path}`;

    const options: IHttpClientOptions = {
      headers: { Accept: 'application/json' },
      signal
    } as any;

    const res: HttpClientResponse = await c.get(url, AadHttpClient.configurations.v1, options);
    if (!res.ok) throw new Error(`GET ${path} failed ${res.status}`);
    return res.json() as Promise<T>;
  }


  private async post(path: string, body: any): Promise<any> {
    const c = await this.client();
    const res: HttpClientResponse = await c.post(`${this.cfg.baseUrl}${path}`, AadHttpClient.configurations.v1, {
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(`POST ${path} failed ${res.status}`);
    return res.json();
  }

  private async put(path: string, body: any): Promise<any> {
    const c = await this.client();
    const res: HttpClientResponse = await c.fetch(`${this.cfg.baseUrl}${path}`, AadHttpClient.configurations.v1, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(`PUT ${path} failed ${res.status}`);
    return res.json();
  }

  private async patch(path: string, body: any): Promise<any> {
    const c = await this.client();

    const res: HttpClientResponse = await c.fetch(
      `${this.cfg.baseUrl}${path}`,
      AadHttpClient.configurations.v1,
      {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      }
    );

    // if (!res.ok) {
    //   throw new Error(`PATCH ${path} failed ${res.status}`);
    // }
    if (!res.ok) {
      const errorText = await res.text();

      let message = `PATCH ${path} failed ${res.status}`;

      try {
        const errorBody = JSON.parse(errorText);

        if (Array.isArray(errorBody?.message)) {
          message = errorBody.message.join(", ");
        } else if (errorBody?.message) {
          message = errorBody.message;
        } else if (errorBody?.error) {
          message = errorBody.error;
        }
      } catch {
        if (errorText) {
          message = errorText;
        }
      }

      throw new Error(message);
    }

    return res.json();
  }


  private async del(path: string): Promise<void> {
    const c = await this.client();
    const res: HttpClientResponse = await c.fetch(`${this.cfg.baseUrl}${path}`, AadHttpClient.configurations.v1, { method: 'DELETE' });
    if (!res.ok) throw new Error(`DELETE ${path} failed ${res.status}`);
  }

  async getOpportunities(payload: any) {
    return this.post(`/opportunity/search`, payload);
  }

  async getOpportunity(id: number): Promise<Opportunity> {
    return this.get(`/opportunity/${id}`);
  }

  async updateBidTeamMembers(id: number, payload: any) {
    return this.put(`/opportunity/${id}/bid-team-members`, payload);
  }


  async searchCustomers(name: string, limit: number, signal?: AbortSignal): Promise<string[]> {
    return this.get(`/opportunity/customers/search?name=${name}&page_number=1&page_size=${limit}`);
  }


  async createOpportunity(payload: Omit<Opportunity, 'id'>): Promise<Opportunity> {
    return this.post('/opportunity', payload);
  }

  async updateOpportunity(id: number, patch: Partial<Opportunity>): Promise<Opportunity> {
    return this.put(`/opportunity/${id}`, patch);
  }

  async updateOpportunityActive(id: number, active: boolean): Promise<Opportunity> {
    return this.put(`/opportunity/${id}/active`, { active });
  }

  async deleteOpportunity(id: number): Promise<void> {
    return this.del(`/opportunity/${id}`);
  }

  async checkOpportunityExists(payload: { opportunityName: string }): Promise<any> {
    return this.post('/opportunity/scenarios/search', payload);
  }

  async getRounds(opportunityId: number, page: number, pageSize: number): Promise<Paged<Round>> {
    return this.get(`/opportunity-round/opportunity/${opportunityId}`);
  }

  async getStandardReference(opportunityId: number): Promise<StandardTemplate> {
    return this.get(`/standard-input/opportunity/${opportunityId}`);
  }

  // async getAllCurrentStakeholersInputByRound(roundId: number): Promise<FileItem> {
  //   return this.get(`/opportunity-round/${roundId}/inputs`);
  // }


  async getAllCurrentStakeholersInputByRound(
    roundId: number,
    payload: { workflowStatuses: string[] }
  ): Promise<any> {
    return this.post(`/opportunity-round/${roundId}/inputs`, payload);
  }

  async getRound(roundId: number): Promise<Round> {
    return this.get(`/opportunity-round/${roundId}`);
  }

  async closeRound(roundId: number): Promise<any> {
    return this.patch(`/opportunity-round/${roundId}/close`, {});
  }

  public async generateOutputLog(payload: GenerateOutputLogRequest): Promise<any> {
    return this.post("/opportunity-round/output-log", payload);
  }

  async createRound(payload: Omit<Round, 'id'>): Promise<Round> {
    return this.post(`/opportunity-round/`, payload);
  }

  async createStakeholders(payload: Array<Omit<UpdateInputTemplatePayload, 'id'>>): Promise<UpdateInputTemplatePayload[]> {
    return this.post(`/opportunity-round/stakeholder`, payload);
  }

  async updateRoundMainInfo(id: number, patch: Partial<RoundMainInfo>): Promise<RoundMainInfo> {
    return this.put(`/opportunity-round/${id}`, patch);
  }

  async updateRound(patch: Partial<UpdateInputTemplatePayload>): Promise<UpdateInputTemplatePayload> {
    return this.put(`/opportunity-round/stakeholder`, patch);
  }

  async changeVersion(patch: Partial<ChangeVersionPayload>): Promise<ChangeVersionPayload> {
    return this.post(`/opportunity-round/stakeholder/change-version`, patch);
  }

  async deleteRound(roundId: number): Promise<void> {
    return this.del(`/rounds/${roundId}`);
  }

  async getTemplates(roundId: number, page: number, pageSize: number): Promise<Paged<Template>> {
    return this.get(`/rounds/${roundId}/templates?page=${page}&pageSize=${pageSize}`);
  }

  async getTemplate(templateId: number): Promise<Template> {
    return this.get(`/templates/${templateId}`);
  }

  async createTemplate(payload: Omit<Template, 'id'>): Promise<Template> {
    return this.post(`/rounds//templates`, payload);
  }

  async completeStakeholderInput(payload: Omit<TemplatePost, 'id'>): Promise<TemplatePost> {
    return this.post(`/opportunity-round/stakeholder-input/complete`, payload);
  }

  async rejectStakeholderInput(payload: Omit<RejectStakeholderInput, 'id'>): Promise<RejectStakeholderInput> {
    return this.post(`/opportunity-round/stakeholder-input/reject`, payload);
  }

  async initiateRevision(payload: { opportunityId: number; roundId: number; roundNumber: number; stakeholderCode: string; scenarioName: string }): Promise<any> {
    return this.post(`/opportunity-round/stakeholder-input/initiate-revision`, payload);
  }

  async generateOutputFile(payload: Omit<GenerateOutput, 'id'>): Promise<GenerateOutput> {
    return this.post(`/opportunity-round/inputs-by-stakeholder-and-scenario`, payload);
  }

  async updateTemplate(templateId: number, patch: Partial<Template>): Promise<Template> {
    return this.put(`/templates/${templateId}`, patch);
  }

  async updateInputRequired(payload: {
    id: number;
    inputRequired: boolean;
  }): Promise<any> {
    return this.patch(`/opportunity-round/input/required`, payload);
  }

  async deleteTemplate(templateId: number): Promise<void> {
    return this.del(`/templates/${templateId}`);
  }

  async printAccessToken(): Promise<void> {
    const provider = await this.context.aadTokenProviderFactory.getTokenProvider();
    const token = await provider.getToken(this.cfg.resource);
    // console.log('[AAD Access Token]', token);
  }


  async getStakeholderAllInputs(payload: {
    page: number;
    limit: number;
    myRecord: boolean;
    search_text?: string;
    workflowStatuses: string[];
    isMyPending?: boolean;
  }): Promise<any> {
    return this.post(
      `/opportunity-round/get-stakeholder-all-inputs`,
      payload
    );
  }
  public async getOutputLogs(roundId: number): Promise<OutputLog[]> {
    return this.get(
      `/opportunity-round/${roundId}/output-logs`
    );
  }

}