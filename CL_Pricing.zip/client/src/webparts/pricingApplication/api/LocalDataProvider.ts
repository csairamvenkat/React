import { update } from "@microsoft/sp-lodash-subset/lib/index";
import { IDataProvider } from "../components/store/DataProvider";
import { Opportunity } from "../components/store/Models";

const STORAGE_KEY = 'spfx_mock_opportunities_v1';
const seed: Opportunity[] = [
    {
        id: 1,
        region: 'EUR',
        title: '',
        leadNumber: 'ABC-123',
        customer: 'Amazon',
        opportunityName: '65426 Amazon FC DE',
        country: 'Germany',
        countryCode: 'DE',
        status: 'In-Progress',
        createdBy: 'Bilal Ahmed',
        createdDate: '2025-01-15',
             project_name: '',
        bid_team_members: [] 
    },
    {
        id: 2,
        region: 'EUR',
        title: '',
        leadNumber: 'XYZ-123',
        customer: 'Amazon',
        opportunityName: '65426 Amazon ZZ AB',
        country: 'UAE',
        countryCode: 'DE',
        status: 'In-Progress',
        createdBy: 'Muhammad Asif',
        createdDate: '2025-02-20',
             project_name: '',
        bid_team_members: [] 
    }
];

function load(): Opportunity[] {
    try {
        const raw = localStorage.getItem(STORAGE_KEY); return raw ?
        JSON.parse(raw): seed;
    }
    catch{
        return seed;
    }
}

function save(items: Opportunity[]) {
    try {
        localStorage.setItem(STORAGE_KEY,JSON.stringify(items));
    }
    catch{

    }
}

export class LocalDataProvider implements IDataProvider {
    private items: Opportunity[] = load();
    private seq: number = Math.max(0, ...this.items.map(o => o.id));

    async list() { return [...this.items];}
    async get(id: number) {
        return this.items.find(o => o.id === id)
    }
    async create(payload: Omit<Opportunity, 'id'>){
        const nextId = ++this.seq;
        const created = { id: nextId, ...payload};
        this.items = [created, ...this.items];
        save(this.items);
        return created;
    }
    async update(id: number, patch: Partial<Opportunity>){
        let updated: Opportunity | null = null;
        this.items = this.items.map(o => (o.id === id ? (updated = { ...o, ...patch})! : o));
        save(this.items);
        return updated;
    }
    async remove(id: number) {
       this.items = this.items.filter(o => o.id !== id);
       save(this.items);
    }
}