import * as React from 'react';
import * as ReactDom from 'react-dom';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import AppRouter from './components/AppRouter';
import { loadTenantConfig } from './config/ConfigService';

export default class PricingApplicationWebPart extends BaseClientSideWebPart<{}> {
  public async render(): Promise<void> {
    const cfg = await loadTenantConfig(this.context);
    (window as any).TENANT_CONFIG = cfg;
    (window as any).spfxContext = this.context;

    // Toggle this ON to use mock UI for files
  (window as any).MOCK_MODE = true;

    ReactDom.render(
      React.createElement(AppRouter, {}),
      this.domElement
    );
  }
  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }
}