import { HttpClient, HttpClientResponse } from '@microsoft/sp-http';

export async function triggerFlow(
  payload: Record<string, any>,
  type: string = 'default'
): Promise<any> {

  const context = (window as any).spfxContext;
  const cfg = (window as any).TENANT_CONFIG;

  if (!context) {
    throw new Error('SPFx context not found on window.spfxContext.');
  }

  const map = cfg?.flowUrls || {};
  const flowUrl = map[type] || '';

  if (!flowUrl) {
    throw new Error(`Flow URL not found for type "${type}".`);
  }

  // console.log('[triggerFlow]', type, flowUrl, payload);

  const res: HttpClientResponse = await context.httpClient.post(
    flowUrl,
    HttpClient.configurations.v1,
    {
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }
  );

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Flow HTTP trigger failed: ${res.status} ${res.statusText} ${text}`);
  }

  try {
    return await res.json();
  } catch {
    return { status: res.statusText, statusCode: res.status };
  }
}




// import {
//   AadTokenProvider,
//   HttpClient,
//   HttpClientResponse,
//   AadHttpClient
// } from '@microsoft/sp-http';

// const POWER_AUTOMATE_RESOURCE = 'https://service.flow.microsoft.com';

// export async function triggerFlow(
//   payload: Record<string, any>,
//   type: string = 'default'
// ): Promise<any> {

//   const context = (window as any).spfxContext;
//   const cfg = (window as any).TENANT_CONFIG;

//   if (!context) {
//     throw new Error('SPFx context not found on window.spfxContext.');
//   }

//   const map: Record<string, string> = cfg?.flowUrls || {};
//   const flowUrl: string = map[type] || '';

//   if (!flowUrl) {
//     throw new Error(`Flow URL not found for type "${type}".`);
//   }

//   const tokenProvider: AadTokenProvider =
//     await context.aadTokenProviderFactory.getTokenProvider();

//   const accessToken: string = await tokenProvider.getToken(POWER_AUTOMATE_RESOURCE);
//   if (!accessToken) {
//     throw new Error('Failed to acquire Power Automate access token.');
//   }

//   const res: HttpClientResponse = await context.httpClient.post(
//     flowUrl,
//     HttpClient.configurations.v1,
//     {
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${accessToken}`
//       },
//       body: JSON.stringify(payload)
//     }
//   );

//   if (!res.ok) {
//     const text = await res.text().catch(() => '');
//     throw new Error(`Flow HTTP trigger failed: ${res.status} ${res.statusText} ${text}`);
//   }

//   try {
//     return await res.json();
//   } catch {
//     return { status: res.statusText, statusCode: res.status };
//   }
// }